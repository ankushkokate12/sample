import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'projects/services/src/lib/auth-guard.service';
import { DummyComponent } from './components/dummy/dummy.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'welcome-screen',
    component: DummyComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'master',
    loadChildren: () => import('../../../../projects/master/src/app/app.module').then((m) => m.AppModule),
    canActivate: [AuthGuardService],
  },
  {
    path: 'pickup',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/regular/regular.module').then((m) => m.RegularModule),
    canActivate: [AuthGuardService],
  },
  {
    path: 'called-pickup',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/called-pickup/called-pickup.module').then(
        (m) => m.CalledPickupModule
      ),
    canActivate: [AuthGuardService],
  },
  {
    path: 'message',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/message/message.module').then((m) => m.MessageModule),

    canActivate: [AuthGuardService],
  },
  {
    path: 'user-management',
    loadChildren: () =>
      import('../../../../projects/usermanagement/src/app/user-mgmt/user-mgmt.module').then((m) => m.UserMgmtModule),
    canActivate: [AuthGuardService],
  },
  {
    path: 'group-management',
    loadChildren: () =>
      import('../../../../projects/usermanagement/src/app/group-mgmt/group-mgmt.module').then((m) => m.GroupMgmtModule),
    canActivate: [AuthGuardService],
  },

  {
    path: 'master-query',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/master-query/master-query.module').then((m) => m.MasterQueryModule),
    canActivate: [AuthGuardService],
  },
  {
    path: 'convey-pickup',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/convey-pickup/convey-pickup.module').then(
        (m) => m.ConveyPickupModule
      ),
    canActivate: [AuthGuardService],
  },
  {
    path: 'finders',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/finders/finders.module').then((m) => m.FindersModule),
    canActivate: [AuthGuardService],
  },
  {
    path: 'sc-operations',
    loadChildren: () =>
      import('../../../../projects/pickup/src/app/sc-operations/sc-operations.module').then((m) => m.ScOperationsModule),
    canActivate: [AuthGuardService],
  },

  { path: '', redirectTo: 'login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
