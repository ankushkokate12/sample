import { Component } from '@angular/core';
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { ICONNAMEREGISTRY } from './icon-name.constant';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'login';

  iconNames: Array<string> = ICONNAMEREGISTRY;

  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    //inorder to register new custom icons below code is added.
    //icon name should be same as svg filename and it should be added in constants file ./icon-name.constant.
    this.iconNames.forEach(icon => {
    this.matIconRegistry.addSvgIcon(
      icon,
      this.domSanitizer.bypassSecurityTrustResourceUrl(`./assets/images/${icon}.svg`)
    );
  })
  }

  showHelp() {
    console.log('control pressed');
  }
}
