import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreModule } from '@ngrx/store';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { FooterComponent } from 'projects/tools/src/lib/components/footer/footer.component';
import { OpenTabsNavComponent } from 'projects/tools/src/lib/components/open-tabs-nav/open-tabs-nav.component';
import { HttpErrorHandler } from 'projects/tools/src/lib/http-error-handler.service';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { NavigationReducer } from 'projects/tools/src/lib/reducers/navigation.reducer';
import { MaterialModule, ToolsModule } from 'projects/tools/src/public-api';
import { NavbarComponent } from 'projects/top-nav-bar/src/app/navbar/navbar.component';
import { DevconsoleLoggerFacility } from 'projects/vendors/src/lib/bd.devconsole-logger.facility';
import { CustomeInterceptor } from 'projects/vendors/src/lib/custome.interceptor';
import { LoadingInterceptor } from 'projects/vendors/src/lib/loading.interceptor';
import { LoggerFacility } from 'projects/vendors/src/lib/LoggerFacility';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DummyComponent } from './components/dummy/dummy.component';
import { LoginComponent } from './components/login/login.component';
import { NoDataFoundModule } from './components/no-data-found/no-data-found.module';
import { WebconfigService } from './services/webconfig.service';
import { CacheRouteReuseStrategy } from './cache-route-reuse.strategy';
import { RouteReuseStrategy } from '@angular/router';

export function appInit(webConfigService: WebconfigService) {
  return () => webConfigService.loadSettings();
}
@NgModule({
  declarations: [AppComponent, LoginComponent, FooterComponent, OpenTabsNavComponent, NavbarComponent, DummyComponent],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    NoDataFoundModule,
    HttpClientModule,
    MaterialModule,
    ToolsModule,
    StoreModule.forRoot({ navigations: NavigationReducer }),
    FlexLayoutModule
  ],

  providers: [
    MessageService,
    HttpErrorHandler,
    { provide: LoggerFacility, useClass: DevconsoleLoggerFacility },

    {
      provide: APP_INITIALIZER,
      useFactory: appInit,
      multi: true,
      deps: [BdWebConfigService]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CustomeInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoadingInterceptor,
      multi: true
    },
    // {
    // // TO DO : Uncomment for Tab Persistent.
    //   provide: RouteReuseStrategy,
    //   useClass: CacheRouteReuseStrategy,
    // },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(dateAdapter: DateAdapter<Date>) {
    dateAdapter.setLocale('en-in'); // DD/MM/YYYY
  }
}
