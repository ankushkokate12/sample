import { ActivatedRouteSnapshot, DetachedRouteHandle, RouteReuseStrategy } from "@angular/router";
import { ITabs } from 'projects/tools/src/lib/components/controls/tabs/tabs.interface';

export class CacheRouteReuseStrategy implements RouteReuseStrategy {

  handlers: { [key: string]: DetachedRouteHandle } = {};

  // Lets save the current state of the child url in stored tabs
  saveTabCurrentState(route: ActivatedRouteSnapshot) {
    let activeUrl = route['_routerState']?.url.split("?")[0] + "/";
    const tabsData = JSON.parse(sessionStorage.getItem('tabsData'));

    tabsData?.find((tab: ITabs) => {
      let matchTabUrl = `/${tab.tabUrl}/`
      if (activeUrl.match(matchTabUrl)) {
        tab.newUrl = activeUrl;
        sessionStorage.setItem('tabsData', JSON.stringify(tabsData));
        return;
      }
    });
  }

  // Generate the unique key to manage the snapshots
  calcStoreKey(route: ActivatedRouteSnapshot) {
    const key = route['_routerState']?.url.split("?")[0].replace(/\//g, '-')
    return key;
  }

  // we are always going to load fresh view if its new tab
  private isNewTab(route: ActivatedRouteSnapshot): boolean {
    if (route.queryParams.isNewTab === 'YES') {
      return false;
    }
    return true
  }

  shouldDetach(route: ActivatedRouteSnapshot): boolean {
    // TODO: seems event emitter creating some issue with few screens. So disabling at this level only
    return false;
  }

  store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
    this.handlers[this.calcStoreKey(route)] = handle;
  }

  // TODO: Handle the detachment of deleted tab snapshot from store
  shouldAttach(route: ActivatedRouteSnapshot): boolean {
    return this.isNewTab(route) && !!route.routeConfig && !!this.handlers[this.calcStoreKey(route)] && route.queryParams?.showSnap === 'YES'
  }

  retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle {
    if (!route.routeConfig) return null;
    return this.handlers[this.calcStoreKey(route)];
  }

  shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
    this.saveTabCurrentState(future);
    return this.calcStoreKey(curr) === this.calcStoreKey(future);
  }

}
