import { Component, OnInit } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.scss']
})
export class DummyComponent implements OnInit {

  constructor(private messageService: MessageService) {
    this.messageService.sendHeaderShowMessage(true);
  }

  ngOnInit(): void {
  }

}