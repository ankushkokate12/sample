import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { Properties } from 'projects/vendors/src/lib/bd.propertybundle';
import { LoginValidation } from 'projects/vendors/src/lib/validations/login-validation';
import { loginconfig } from './login.config';

const loginValidations = new LoginValidation();
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  // @ViewChild(DynamicFormComponent) loginForm: DynamicFormComponent;
  regConfig: FieldConfig[];
  errorMsg: string;
  apiUrl: any;
  loginForm: any;
  currentUser: any;

  constructor(
    private messageService: MessageService,
    private webconfig: BdWebConfigService,
    private eventEmitterService: EventEmitterService,
    private authenticationService: AuthenticationService,
    private restService: RestService,
    private router: Router
  ) { }

  ngOnInit() {
    this.currentUser = this.authenticationService.currentUserValue;
    if (!this.currentUser) {
      this.messageService.sendHeaderShowMessage(false);
      this.regConfig = loginconfig;

      this.eventEmitterService.subsVar = this.eventEmitterService.
        invokeCommonComponentFunction.subscribe((fieldData: any) => {
          this.apiUrl = fieldData.ApiUrl;
          if (fieldData.eventRef == Properties.BTNLOGIN) {
            this.login();
          }
        });
    } else {
      this.router.navigate(['/welcome-screen']);
    }

  }

  ngOnDestroy() {
    if (this.eventEmitterService.subsVar) {
      this.eventEmitterService.subsVar.unsubscribe();
    }
  }

  get username() {
    return this.loginForm.get('a');
  }

  get password() {
    return this.loginForm.get('b');
  }

  onUpdateAuthenticationComplete(result) {
    if (result.error === false) {
      const obj = {
        location: result.data.b || '',
        employeeCode: result.data.d,
        area: result.data.c || '',
        userToken: result.data.a,
        userName: result.data.e,
        handHeld: result.data.f || ''
      };
      this.authenticationService.saveUserValue(obj);
      this.messageService.sendHeaderShowMessage(true);
      this.reset();
    } else if (result.error === true) {
      this.errorMsg = loginValidations.InvalidCredentials;
    } else if (result.message.indexOf('INVALID_CREDENTIALS') > 0) {
      this.errorMsg = loginValidations.InvalidCredentials;
    } else {
      this.errorMsg = loginValidations.NetworkError;
    }
  }

  login() {
    if (this.loginForm != undefined) {
      if (this.loginForm.invalid) {
        this.loginForm.markAllAsTouched();
      } else {
        const requestObj = {
          a: this.username.value,
          b: this.password.value
        };

        this.restService
          .post(this.webconfig.apiURL + this.apiUrl, requestObj)
          .subscribe(
            (response) => {
              this.onUpdateAuthenticationComplete(response);
            },
            (error) => {
              console.log(error);
            }
          );
      }
    }
  }

  reset() {
    this.loginForm.reset();
  }

  // onKeydownUN(event) {
  //   if (event.key === 'Enter' || event.key === 'Tab') {
  //     if (this.username.errors) {
  //       this.username.markAsTouched();
  //       event.preventDefault();
  //     } else if (event.key === 'Enter') {
  //       event.preventDefault();
  //       this.selectNextTab();
  //     }
  //   }
  // }

  // onKeydownPS(event) {
  //   if (event.key === 'Enter' || event.key === 'Tab') {
  //     if (this.password.errors) {
  //       this.password.markAsTouched();
  //       event.preventDefault();
  //     } else if (event.key === 'Enter') {
  //       event.preventDefault();
  //       this.login();
  //     }
  //   }
  // }

  // selectNextTab() {
  //   const inputs = Array.from(
  //     document.querySelectorAll('form input:not(:disabled)')
  //   );
  //   const nextInput = inputs[inputs.indexOf(document.activeElement) + 1];
  //   (nextInput as HTMLElement).focus();
  // }

  onSubmit(event) {
    this.loginForm = event;
    this.login();
  }
}
