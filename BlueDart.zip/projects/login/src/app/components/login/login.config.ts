import { LoginValidation } from "projects/vendors/src/lib/validations/login-validation";
const loginValidations = new LoginValidation();
export const loginconfig = [
  {
    type: "row",
    rows: [
      {
        type: "input",
        label: "Username",
        inputType: "text",
        name: "a",
        validations: loginValidations.userName_Validations,
        class: "col s12 m12 l12 xl2",
        tabindex: "1"
      },
      {
        type: "input",
        label: "Password",
        inputType: "password",
        name: "b",
        validations: loginValidations.password_Validations,
        class: "col s12 m12 l12 xl2",
        tabindex: "2"
      },
      {
        type: "button",
        label: "Login",
        buttonType: "submit",
        eventRef: "btnLogin",
        ApiUrl: "/usermngtservice/auth/login",
        classes: {
          buttonType: "primary-button",
        },
        class: "col s12 m12 l12 xl2",
        tabindex: "3"
      },
    ],
  }
 
];
