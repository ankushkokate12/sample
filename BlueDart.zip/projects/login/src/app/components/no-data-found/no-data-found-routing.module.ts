import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NoDataFoundComponent } from './no-data-found.component';

const routes: Routes = [{ path: '', component: NoDataFoundComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NoDataFoundRoutingModule {}
