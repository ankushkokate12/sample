import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { InScanRegEx } from 'projects/vendors/src/lib/inscan-regex';

@Component({
  selector: 'app-no-data-found',
  templateUrl: './no-data-found.component.html',
  styleUrls: ['./no-data-found.component.scss']
})
export class NoDataFoundComponent implements OnInit {
  errMSgObj = new InScanRegEx();
  erroMsg: string;
  constructor(
    private messageService: MessageService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.messageService.sendHeaderShowMessage(true);
  }

  ngOnInit(): void {
    this.erroMsg = this.errMSgObj.ERROR_IN_CONNECTION;
    const currentUser = this.authenticationService.currentUserValue;
    if (
      currentUser &&
      currentUser.location &&
      currentUser.employeeCode &&
      currentUser.userToken
    ) {
      // authorised so return true
      // return true;
    } else {
      // not logged in so redirect to login page with the return url
      this.router.navigate(['/login']);
    }
  }
}
