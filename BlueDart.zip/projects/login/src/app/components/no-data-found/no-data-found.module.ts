import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NoDataFoundRoutingModule } from './no-data-found-routing.module';
import { NoDataFoundComponent } from './no-data-found.component';

@NgModule({
  declarations: [NoDataFoundComponent],
  imports: [CommonModule, NoDataFoundRoutingModule]
})
export class NoDataFoundModule {}
