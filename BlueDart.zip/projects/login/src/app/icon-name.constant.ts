//name of the icon included in this array must be same as svg file name (present in ./assets/images folder)
export const ICONNAMEREGISTRY = [
    'inherit_icon'
]
