import { TestBed, inject } from '@angular/core/testing';
import { WebconfigService } from './webconfig.service';

describe('Service: Webconfig', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WebconfigService]
    });
  });

  it('should ...', inject([WebconfigService], (service: WebconfigService) => {
    expect(service).toBeTruthy();
  }));
});
