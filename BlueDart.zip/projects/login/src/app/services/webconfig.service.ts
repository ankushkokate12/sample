import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WebconfigService {
  public serviceURLReport: string;
  public serviceURLOBRapidValPincode: string;
  public serviceURLOBRapidValAWBNo: string;
  public serviceURLOBRapidValShippercode: string;
  public serviceURLOBRapidAWBSubmit: string;
  public serviceURLOBNormalInscan: string;
  public serviceURLAuthentication: string;
  public serviceURLRouteCode: string;

  constructor(private http: HttpClient) {}

  async loadSettings(): Promise<any> {
    const configdata = await this.http.get('assets/webconfig.json').toPromise();
    Object.assign(this, configdata);
    return configdata;
  }
}
