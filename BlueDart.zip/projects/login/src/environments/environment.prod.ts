export const environment = {
  production: true,
  baseURL: 'https://172.18.62.80:8443/poc3/'
};
