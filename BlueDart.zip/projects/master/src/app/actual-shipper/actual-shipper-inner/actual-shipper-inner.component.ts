import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogState, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { forkJoin, Observable } from 'rxjs';
import { BaseComponent } from '../../base/base.component';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { Properties } from 'projects/vendors/src/lib/bd.propertybundle';

import {
  addActShippHeader,
  addActShippConfig,
  editActShippHeader,
  saveButton,
  viewActShippHeader
} from './actual-shipper-inner.config';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';

@Component({
  selector: 'app-actual-shipper-inner',
  templateUrl: './actual-shipper-inner.component.html',
  styleUrls: ['./actual-shipper-inner.component.scss']
})
export class ActualShipperInnerComponent extends BaseComponent {
  @ViewChild(DynamicFormComponent, { static: false })
  addActShippForm: DynamicFormComponent;
  addConfig: FieldConfig[];
  featureData = [];
  packagingData = [];
  vasData = [];
  responseData: any;
  ActShippId: any;
  cloneData: any;
  submitted = false;
  checkForClone: string;
  checkForEdit: string;
  checkForCloneAPI: string;
  checkForEditAPI: string;
  subProducts: any;
  products: any;
  lblErrMsgs: any;
  errorMsg: any;
  values2Patch: any;
  @ViewChild('focus') btnFocus: ElementRef;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    protected restService: RestService,
    private webconfig: BdWebConfigService,
    protected primengMessageService: AlertService,
    private confirmationService: ConfirmationService,
    private element: ElementRef,
    protected sharedService: SharedService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private ngsk: NgShortcutService,
    private beepService: BeepService
  ) {
    super(sharedService, restService, primengMessageService);
    this.messageService.sendHeaderShowMessage(true);
  }

  ngOnInit(): void {
    this.delete();
    this.primaryKey = 'pci';
    this.screenText = this.labelConstant.LBL_ACTUAL_SHIPPER; 
    this.routerUrl = this.router.url;

    this.addConfig = JSON.parse(JSON.stringify(addActShippConfig));

    this.products = [];
    this.subProducts = [];

    this.manageConfiguration();
    this.handleEvents();

    this.handleHotkeys();
  }

  handleEvents() {

  }

  submit($event) {

  }

  manageConfiguration() {
    if (this.routerUrl.includes('/edit/')) {
      this.addConfig = [
        ...editActShippHeader,
        ...addActShippConfig,
        ...saveButton
      ];
    } else if (this.routerUrl.includes('/view/')) {
      this.addConfig = [...viewActShippHeader, ...addActShippConfig];
    } else {
      this.addConfig = [...addActShippHeader, ...addActShippConfig, ...saveButton];
    }
  }

  handleHotkeys() {
    // this.ngsk.push(new NgShortcut('s', () => this.handleSaveOnHotkey(), {
    //   preventDefault: true,
    //   ctrlKey: true
    // }));
    this.ngsk.push(new NgShortcut('c', () => {
      if (this.routerUrl.includes('/edit/') || this.routerUrl.includes('/add') || this.routerUrl.includes('/clone/')) {
        // this.btnCancelAddProdConf();
      }
    }, {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('e', () => {
      this.router.navigate(['master/product-configuration/edit/' + this.ActShippId]);
    }, {
      preventDefault: true,
      ctrlKey: true
    }));
    // this.ngsk.push(new NgShortcut('d', () => this.deletePC(), {
    //   preventDefault: true,
    //   ctrlKey: true
    // }));
    // this.ngsk.push(new NgShortcut('a', () => this.releasePC(), {
    //   preventDefault: true,
    //   ctrlKey: true
    // }));
    // this.ngsk.push(new NgShortcut('h', () => this.triggerHistory(), {
    //   preventDefault: true,
    //   ctrlKey: true
    // }));
    // this.ngsk.push(new NgShortcut('p', () => this.triggerClone(), {
    //   preventDefault: true,
    //   ctrlKey: true
    // }));
  }
}
