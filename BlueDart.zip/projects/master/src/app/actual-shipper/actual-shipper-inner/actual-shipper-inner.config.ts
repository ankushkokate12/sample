import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { actualShipperApiUrl } from '../actual-shipper.constant';
const commonValidators = new CommonValidators();

export const addActShippHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToActualShipper',
        trigerOnClick: 'true',
        eventRef: 'backToActualShipper',
        buttonType: 'button',
        tabIndex: 36,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'Add Actual Shipper',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Reset',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'resetFormDetails',
        tabIndex: 37,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s9 m2 l1 right-align'
      }
    ]
  }
];

export const editActShippHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToActShipp',
        trigerOnClick: 'true',
        eventRef: 'backToActShipp',
        tabIndex: 36,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'Edit Actual Shipper',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      }
    ]
  }
];

export const viewActShippHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToActShipp',
        trigerOnClick: 'true',
        eventRef: 'backToActShipp',
        tabIndex: 6,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'View Actual Shipper',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Edit',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'editActShipp',
        tabIndex: 1,
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'button',
        label: 'Delete',
        name: 'btnDeleteActShipp',
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 4,
        eventRef: 'btnDeleteActShipp',
        classes: {
          buttonType: 'action-button'
        }
      }
    ]
  }
];

export const addActShippConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Actual Shipper Details',
        class: 'col s12 l12 m12 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Area',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippArea',
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col wdt65 p-l-0',
                autosuggest: false,
                maxlength: 3,
                isAutoCaps: true,
                tabIndex: 1,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Shipper Code',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippShipperCode',
                validations: commonValidators.SHIPPER_CODE_VALIDATOR,
                class: 'col wdt146 p-l-0',
                autosuggest: false,
                maxlength: 6,
                isAutoCaps: true,
                tabIndex: 2,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Name',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippName',
                validations: commonValidators.SHIPPER_NAME_VALIDATOR,
                class: 'col wdt227 p-l-0',
                autosuggest: false,
                maxlength: 30,
                isAutoCaps: true,
                tabIndex: 3,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Contact Person',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippContactPerson',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt227 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 4,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Pincode',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippPincode',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt65 p-l-0',
                autosuggest: false,
                maxlength: 3,
                isAutoCaps: true,
                tabIndex: 5,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Flat, House no., Building, Company, Apartment',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippAdd1',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt517 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 6,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Area, Colony, Street, Sector, Village',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippAdd2',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt429 p-l-0',
                autosuggest: false,
                maxlength: 3,
                isAutoCaps: true,
                tabIndex: 7,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Town/City',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippAdd3',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt153 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 8,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Pickup Route',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippPickupRoute',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt146 p-l-0',
                autosuggest: false,
                maxlength: 3,
                isAutoCaps: true,
                tabIndex: 9,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Mobile No',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippMobile',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt110 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 10,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Telephone',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShipptelephone',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt146 p-l-0',
                autosuggest: false,
                maxlength: 3,
                isAutoCaps: true,
                tabIndex: 11,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Email',
                inputType: 'text',
                name: 'i',
                eventRef: 'actShippEmail',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col wdt274 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 12,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              }
            ]
          }
        ]
      }
    ]
  }
];

export const saveButton = [
  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: 'Save',
        buttonType: 'Submit',
        trigerOnClick: 'true',
        eventRef: 'addActShippSubmit',
        tabIndex: 35,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true,
          Class: 'm-t--10'
        },
        class: 'col s12 m12 l11 xl12 right-align m-b-10'
      },
      {
        type: 'button',
        label: 'Cancel',
        name: 'btnCancelAddActShipp',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnCancelAddActShipp',
        tabIndex: 37,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s3 m2 l1 right-align'
      }
    ]
  }
];
