import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActualShipperComponent } from './actual-shipper.component';
import { ActualShipperInnerComponent } from './actual-shipper-inner/actual-shipper-inner.component'

const routes: Routes = [
  { path: '', component: ActualShipperComponent },
  { path: 'add', component: ActualShipperInnerComponent },
  { path: 'view/:area/:shipperCode', component: ActualShipperInnerComponent },
  { path: 'edit/:area/:shipperCode', component: ActualShipperInnerComponent },
  { path: 'clone/:area/:shipperCode', component: ActualShipperInnerComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActualShipperRoutingModule { }
