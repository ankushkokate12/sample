import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService as AlertService } from 'primeng/api';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/grid-columns.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { BaseComponent } from '../base/base.component';
import { GRID_CONFIG, ActualShipperConfig } from './actual-shipper.config';
import { actualShipperApiUrl } from './actual-shipper.constant';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { ActualShipperMapper } from './actual-shipper.mapper';
import { Subject, Subscription } from 'rxjs';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
@Component({
  selector: 'app-actual-shipper',
  templateUrl: './actual-shipper.component.html',
  styleUrls: ['./actual-shipper.component.scss']
})
export class ActualShipperComponent extends BaseComponent implements AfterViewInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false }) addActualShipperSearchForm: DynamicFormComponent;
  regConfig: FieldConfig[];
  data: IGridColumn[];
  rows = [];
  deleteWarningMessage: string = "Do you want to delete the record?";
  private subscriptions = new Subscription();
  viewOnSingleClickSubject$ = new Subject();
  customizedEditURL: boolean = true;
  customizedEditURLSubject$ = new Subject();
  customizedViewUrl: boolean = true;
  customizedViewUrlSubject$ = new Subject();
  showGrid: boolean = false;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    protected restService: RestService,
    protected sharedService: SharedService,
    private webconfig: BdWebConfigService,
    protected alertService: AlertService,
    private ngsk: NgShortcutService,
    private element: ElementRef,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private beepService: BeepService
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = ActualShipperConfig;
    this.data = GRID_CONFIG;
    this.delete();
    this.release();
    this.showRowHistory();
    this.showHistoryPopup();
  }

  ngOnInit(): void {
    this.onView = false;
    this.setDeleteURL(actualShipperApiUrl.DELETE_ACTUAL_SHIPPER);
    this.deleteFragmentURI = [ActualShipperMapper.area, ActualShipperMapper.custmerCode];
    this.primaryKey = 'pci';
    this.screenText = this.labelConstant.LBL_ACTUAL_SHIPPER; 
    this.routerUrl = this.router.url;

    let gridTblHt = window.innerHeight - 150 - 20 - 150;
    this.tableHeight = gridTblHt + 'px';

    this.subscriptions.add(this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == 'addActualShipper') {
        this.addActualShipper();
      } else if (field.eventRef == 'txtAreaForActualShipperSearch') {
        this.validateArea();
      } else if (field.eventRef == 'actualShipperSearchReset') {
        this.resetForm();
      }
    }));

    this.ngsk.push(
      new NgShortcut('n', () => this.addActualShipper(), {
        preventDefault: true,
        altKey: true
      })
    );

    this.subscriptions.add(this.customizedViewUrlSubject$.subscribe(res => {
      this.router.navigate(['view', res[ActualShipperMapper.area], res[ActualShipperMapper.custmerCode]], { relativeTo: this.activatedRoute })
    }));

    this.subscriptions.add(this.customizedEditURLSubject$.subscribe(res => {
      this.router.navigate(['edit', res[ActualShipperMapper.area], res[ActualShipperMapper.custmerCode]], { relativeTo: this.activatedRoute })
    }));
  }

  resetForm() {
    let tempObj = {
      [ActualShipperMapper.area]: this.currentUser.area
    };

    this.addActualShipperSearchForm.form.reset(tempObj);
    this.rows.length = 0;
    this.regConfig[0].rows[1].label = "";
  }

  validateArea() {
    this.addActualShipperSearchForm.form.get(ActualShipperMapper.area).setValue(this.addActualShipperSearchForm.form.get(ActualShipperMapper.area).value.toUpperCase());
    let area = this.addActualShipperSearchForm.form.get(ActualShipperMapper.area).value || null;
    if (area != null) {
      this.subscriptions.add(this.restService
        .get(actualShipperApiUrl.VALIDATE_AREA + "a=" + area)
        .subscribe((res) => {
          if (res.error) {
            this.handleHTTPErrors(res.statusCode, ActualShipperMapper.area, this.addActualShipperSearchForm.form);
            this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            if (ActualShipperMapper.area != "") {
              this.element.nativeElement.querySelectorAll('Input').forEach((element) => {
                if (element.name == ActualShipperMapper.area) {
                  element.select();
                }
              });
            }
          }
        },
          error => {
            console.log(error);
          }
        ));
    }
  }

  ngAfterViewInit() {
    this.element.nativeElement.querySelectorAll('Input')[0].select();
    this.addActualShipperSearchForm.form.patchValue({
      [ActualShipperMapper.area]: this.currentUser.area
    });
    this.changeDetectorRef.detectChanges();
  }

  handleSubmit() {
    let area = this.addActualShipperSearchForm.form.get(ActualShipperMapper.area).value || null;
    let shipperCode = this.addActualShipperSearchForm.form.get(ActualShipperMapper.custmerCode).value || null;
    let tempObj = {
      [ActualShipperMapper.area]: area,
      [ActualShipperMapper.custmerCode]: shipperCode
    }
    if (area != null) {
      this.showGrid = true;
      this.subscriptions.add(this.restService
        .post(actualShipperApiUrl.GET_ACTUAL_SHIPPER_SEARCH_DATA, tempObj)
        .subscribe((res) => {
          if (!res.error) {
            this.rows = res.data;
            this.regConfig[0].rows[1].label =
              (res.data?.length == undefined ? '0' : res.data?.length) + this.labelConstant.LBL_ACTUAL_SHIPPER_AVAILABLE;
          } else {
            this.rows = []; 
            this.regConfig[0].rows[1].label = '0' + this.labelConstant.LBL_ACTUAL_SHIPPER_AVAILABLE;
          }
        })
      );
    }
  }

  addActualShipper() {
    this.router.navigate(['add'], { relativeTo: this.activatedRoute });
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();

    this.unsubscribeObservables$.next();
    this.unsubscribeObservables$.complete();
  }
}
