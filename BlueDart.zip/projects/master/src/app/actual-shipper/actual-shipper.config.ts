import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
const commonValidators = new CommonValidators();

import { ActualShipperMapper } from './actual-shipper.mapper';
import * as baseUrl from 'projects/login/src/assets/webconfig.json';
import { actualShipperApiUrl } from './actual-shipper.constant';

export const ActualShipperConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: 'Actual Shipper Master',
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: 'Add',
        buttonType: 'button',
        name: 'addActualShipper',
        trigerOnClick: 'true',
        eventRef: 'addActualShipper',
        tabIndex: 5,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: ActualShipperMapper.area,
        validations: commonValidators.AREA_CODE_VALIDATOR,
        class: 'col wdt65 p-l-0',
        tabIndex: 1,
        isAutoCaps: true,
        eventRef: 'txtAreaForActualShipperSearch',
        regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC,
        maxlength: "3",
        minlength: "3"
      },
      {
        type: 'input',
        label: lbl.LBL_SHIPPER_CODE,
        class: 'col wdt146 p-l-0 p-r-0',
        inputType: 'text',
        name: ActualShipperMapper.custmerCode,
        validations: commonValidators.SHIPPER_CODE_VALIDATOR_WITHOUT_REQUIRED,
        tabIndex: 2,
        isAutoCaps: true,
        eventRef: 'txtShipperCode',
        maxlength: "6",
        minlength: "6",
        regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC,
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        class: 'col ac-srch-frm-btn',
        buttonType: 'submit',
        trigerOnClick: 'true',
        id: 'rp-search-btn',
        eventRef: 'actualShipperSearch',
        tabIndex: 3,
        apiUrl: actualShipperApiUrl.GET_ACTUAL_SHIPPER_SEARCH_DATA,
        classes: {
          buttonType: 'primary-button'
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        name: 'addActualShipper',
        trigerOnClick: 'true',
        id: 'as-reset-btn',
        class: 'col ac-srch-frm-btn p-l-0',
        eventRef: 'actualShipperSearchReset',
        classes: {
          buttonType: 'action-button',
        },
        tabIndex: 4
      }
    ]
  }
];

export const GRID_CONFIG = [
  {
    field: ActualShipperMapper.custmerCode,
    header: 'Shipper Code',
    showFilter: true,
    colWidth: '90px'
  },
  {
    field: ActualShipperMapper.custmerName,
    header: 'Name',
    showFilter: true,
    colWidth: '140px'
  },
  {
    field: ActualShipperMapper.contact,
    header: 'Contact',
    showFilter: true,
    colWidth: '110px'
  },
  {
    field: ActualShipperMapper.concatedAddress,
    header: 'Address',
    showFilter: true,
    colWidth: '230px'
  },
  {
    field: ActualShipperMapper.custmerPincode,
    header: 'Pincode',
    showFilter: true,
    colWidth: '80px'
  },
  {
    field: ActualShipperMapper.custmerTelephone,
    header: 'Telephone',
    showFilter: true,
    colWidth: '90px'
  },
  {
    field: ActualShipperMapper.mobile,
    header: 'Mobile',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: ActualShipperMapper.email,
    header: 'Email',
    showFilter: true,
    colWidth: '115px'
  },
  {
    field: ActualShipperMapper.routeCode,
    header: 'Route Code',
    showFilter: true,
    colWidth: '65px'
  }
];
