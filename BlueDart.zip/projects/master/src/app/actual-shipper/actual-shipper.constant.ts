import * as baseUrl from '../../../../login/src/assets/webconfig.json';

export const actualShipperApiUrl = {
  GET_ACTUAL_SHIPPER_SEARCH_DATA: baseUrl.custServiceAPIURL + '/actual/shipper/search',
  // TODO: VALIDATE_AREA_CODE: baseUrl.custServiceAPIURL + '/products/config',
  DELETE_ACTUAL_SHIPPER: baseUrl.custServiceAPIURL + '/actual/shipper',
  VALIDATE_AREA: baseUrl.locationServiceAPIURL + '/location/awbvalidation/validateareacode?',
};
