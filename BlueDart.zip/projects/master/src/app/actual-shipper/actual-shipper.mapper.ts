export const ActualShipperMapper = {
  area: 'a',
  custmerCode: 'b',
  custmerName: 'c',
  contact: 'd',
  custmerAddress1: 'e',
  custmerAddress2: 'f',
  custmerAddress3: 'g',
  custmerPincode: 'h',
  custmerTelephone: 'i',
  email: 'j',
  mobile: 'k',
  routeCode: 'l',
  locationCode: 'm',
  concatedAddress: 'n'
};