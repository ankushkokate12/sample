import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsModule } from '../../../../tools/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActualShipperRoutingModule } from './actual-shipper-routing.module';
import { ActualShipperComponent } from './actual-shipper.component';
import { ActualShipperInnerComponent } from './actual-shipper-inner/actual-shipper-inner.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { HistoryModule } from '../history/history.module';
import { NgShortcutModule } from 'ng-shortcut';
@NgModule({
  declarations: [ActualShipperComponent, ActualShipperInnerComponent],
  providers: [MessageService, ConfirmationService],
  imports: [
    CommonModule,
    ConfirmDialogModule,
    ToastModule,
    ToolsModule,
    FormsModule,
    ReactiveFormsModule,
    ActualShipperRoutingModule,
    HistoryModule,
    NgShortcutModule.forRoot()
  ],
  exports: [HistoryModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ActualShipperModule { }
