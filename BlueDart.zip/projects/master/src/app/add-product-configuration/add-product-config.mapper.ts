export const ProductConfigMapper = {
  products: 'a',
  subProducts: 'b',
  features: 'd',
  packaging: 'e',
  vas: 'f',
  prodType: 'g',
  prodCategory: 'h',
  effectiveFromDate: 'q',
  effectiveToDate: 'r',
  productConfigKey: 'i',
  productConfigName: 'j',
  parentServiceabilityConfig: 'u',
  baggingRule: 'v',
  serviceabilityGroup: 'm',
  displayOrder: 't',
  parentProductConfigKey: 'al'
};
