import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProductConfigurationComponent } from './add-product-configuration.component';

describe('AddProductConfigurationComponent', () => {
  let component: AddProductConfigurationComponent;
  let fixture: ComponentFixture<AddProductConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddProductConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProductConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
