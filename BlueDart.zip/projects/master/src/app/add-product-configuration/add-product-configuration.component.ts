import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogState, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { forkJoin, Observable, Subject, Subscription } from 'rxjs';
import { BaseComponent } from '../base/base.component';
import { IAddProdForkJoin, IProdSubProd } from '../interfaces/misc.interface';
import { apiUrl } from '../product-configuration/product-configuration.constant';
import { BdWebConfigService } from './../../../../../projects/services/src/lib/bd-web-config.service';
import { DialogComponent } from './../../../../../projects/tools/src/lib/components/controls/dialog/dialog.component';
import { EventEmitterService } from './../../../../../projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from './../../../../../projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from './../../../../../projects/tools/src/lib/message.service';
import { RestService } from './../../../../../projects/tools/src/lib/rest.service';
import { SharedService } from './../../../../../projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from './../../../../../projects/tools/src/public-api';
import { Properties } from './../../../../../projects/vendors/src/lib/bd.propertybundle';
import { ProductConfigMapper } from './add-product-config.mapper';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';

import {
  addedByLabel,
  addProdConfigHeader,
  addProductConfigurationConfig,
  cloneProdConfigHeader,
  editProdConfigHeader,
  saveButton,
  viewProdConfigHeader
} from './add-product-configuration.config';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';
import * as moment from 'moment';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';

@Component({
  selector: 'app-add-product-configuration',
  templateUrl: './add-product-configuration.component.html',
  styleUrls: ['./add-product-configuration.component.scss']
})
export class AddProductConfigurationComponent extends BaseComponent implements AfterViewInit {
  @ViewChild(DynamicFormComponent, { static: false })
  addProductConfigForm: DynamicFormComponent;
  addProductConfig: FieldConfig[];
  featureData = [];
  packagingData = [];
  vasData = [];
  responseData: any;
  productConfigId: any;
  cloneData: any;
  submitted = false;
  checkForClone: string;
  checkForEdit: string;
  checkForCloneAPI: string;
  checkForEditAPI: string;
  subProducts: any;
  products: any;
  lblErrMsgs: any;
  errorMsg: any;
  values2Patch: any;
  @ViewChild('focus') btnFocus: ElementRef;
  subscriptions: Subscription;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    protected restService: RestService,
    private webconfig: BdWebConfigService,
    protected primengMessageService: AlertService,
    private confirmationService: ConfirmationService,
    private element: ElementRef,
    protected sharedService: SharedService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private ngsk: NgShortcutService,
    private beepService: BeepService
  ) {
    super(sharedService, restService, primengMessageService);
    this.messageService.sendHeaderShowMessage(true);
  }

  ngOnInit(): void {
    this.onView = true;
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });

    this.delete();
    this.release();
    this.showRowHistory();
    this.showHistoryPopup();
    this.setDeleteURL(this.webconfig.apiURLProductConfiguration + apiUrl.DELETE_PRODUCT_CONFIG_DETAILS);
    this.setReleaseURL(this.webconfig.apiURLProductConfiguration + apiUrl.RELEASE_PRODUCT_CONFIG_DETAILS);
    this.historyAPIURL = this.webconfig.apiURLProductConfiguration + apiUrl.GET_PRODUCT_CONFIG_HISTORY;
    this.primaryKey = 'pci';
    this.screenText = 'Product Configuration';
    this.routerUrl = this.router.url;
    this.resourceNameForHistory = "ProductConfigMaster";

    this.addProductConfig = JSON.parse(JSON.stringify(addProductConfigurationConfig));

    this.checkForClone = this.router.url.toString().split('/')[2] + '/' + this.router.url.toString().split('/')[3];
    this.checkForEdit = this.router.url.toString().split('/')[2] + '/' + this.router.url.toString().split('/')[3];
    this.productConfigId = this.activatedRouter.snapshot.params.id;
    this.checkForCloneAPI = 'clone' + '/' + this.productConfigId;
    this.checkForEditAPI = 'edit' + '/' + this.productConfigId;

    this.products = [];
    this.subProducts = [];

    this.OpenSingleSelectDialog();

    this.getProductConfigData();

    this.manageConfiguration();
    this.handleEvents();

    this.handleHotkeys();
  }

  handleHotkeys() {
    this.ngsk.push(new NgShortcut('s', () => this.handleSaveOnHotkey(), {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('c', () => {
      if (this.router.url.includes('/edit/') || this.router.url.includes('/add') || this.router.url.includes('/clone/')) {
        this.btnCancelAddProdConf();
      }
    }, {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('e', () => {
      this.router.navigate(['master/product-configuration/edit/' + this.productConfigId]);
    }, {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('d', () => this.deletePC(), {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('a', () => this.releasePC(), {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('h', () => this.triggerHistory(), {
      preventDefault: true,
      ctrlKey: true
    }));
    this.ngsk.push(new NgShortcut('p', () => this.triggerClone(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  triggerClone() {
    this.router.navigate(['master/product-configuration/clone/' + this.productConfigId]);
  }

  triggerHistory() {
    this.sharedService.setShowHistoryPopup(true);
    this.sharedService.setGridRowForHistory(this.cloneData);
  }


  deletePC() {
    this.showAlertDialog(
      'delete',
      'Do you want to delete?',
      'Record will be marked inactive. Click yes to proceed.'
    );
  }

  releasePC() {
    this.showAlertDialog(
      'release',
      'Do you want to release?',
      'Data will be transferred to live. Click yes to proceed.'
    );
  }


  handleSaveOnHotkey() {
    if (this.router.url.includes('/edit/') || this.router.url.includes('/add') || this.router.url.includes('/clone/')) {
      this.addProductConfigForm.form.markAllAsTouched();
      this.addProductConfigForm.form.updateValueAndValidity();
      if (this.addProductConfigForm.form.valid) {
        this.submitForm();
      }
      else this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
    }
  }

  manageConfiguration() {
    if (this.router.url.includes('/edit/')) {
      this.addProductConfig = [
        ...editProdConfigHeader,
        ...addProductConfigurationConfig,
        ...addedByLabel,
        ...saveButton
      ];
    } else if (this.router.url.includes('/clone/')) {
      this.addProductConfig = [...cloneProdConfigHeader, ...addProductConfigurationConfig, ...saveButton];
    } else if (this.router.url.includes('/view/')) {
      this.addProductConfig = [...viewProdConfigHeader, ...addProductConfigurationConfig];
    } else {
      this.addProductConfig = [...addProdConfigHeader, ...addProductConfigurationConfig, ...saveButton];
    }
  }

  handleEvents() {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.name == 'a' || field.name == 'b' || field.name == 'd') {
        if (!this.router.url.includes('/edit/')) {
          this.createProductConfigKey();
        }
      }

      if (field.name == 'm' || field.name == 't') {
        this.verifyDisplayOrder();
      }

      if (
        field.eventRef == Properties.BTN_CANCEL_ADD_PROD_CONF ||
        field.eventRef == Properties.BACK_TO_PRODUCT_CONFIG
      ) {
        this.btnCancelAddProdConf();
      } else if (field.eventRef == 'addProdConfSubmit') {
        this.submitForm();
      } else if (field.eventRef == 'productConfigKey') {
        this.checkOnConfigKey();
      } else if (field.eventRef == 'resetFormDetails') {
        this.resetForm();
      } else if (field.eventRef == 'btnHistoryProdConf') {
        this.sharedService.setShowHistoryPopup(true);
        this.sharedService.setGridRowForHistory(this.cloneData);
      } else if (field.eventRef == Properties.CLONE_PROD_CONF) {
        this.router.navigate(['master/product-configuration/clone/' + this.productConfigId]);
      } else if (field.eventRef == 'btnReleaseProdConf') {
        this.showAlertDialog(
          'release',
          'Do you want to release?',
          'Data will be transferred to live. Click yes to proceed.'
        );
      } else if (field.eventRef == 'btnDeleteProdConf') {
        this.showAlertDialog(
          'delete',
          'Do you want to delete?',
          'Record will be marked inactive. Click yes to proceed.'
        );
      } else if (field.eventRef == Properties.EDIT_PROD_CONF) {
        this.router.navigate(['master/product-configuration/edit/' + this.productConfigId]);
      }
    });
  }

  ngAfterViewInit() {
    if (this.router.url.includes('/view/')) {
      this.disableFormOnView();
      this.element.nativeElement.querySelectorAll('button')[1].focus();
    } else {
      this.element.nativeElement.querySelectorAll('mat-select')[0].focus();
    }
    this.cdr.detectChanges();
  }

  disableFormOnView() {
    Object.keys(this.addProductConfigForm.form.controls).forEach((field) => {
      this.addProductConfigForm.form.get(field).disable();
    });
  }

  showAlertDialog(action, title, message) {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: title,
          message: message,
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          if (action == 'release') {
            this.sharedService.setGridRowForRelease(this.cloneData);
          } else {
            this.sharedService.setGridRowForDelete(this.cloneData);
          }
          // this.router.navigate(['master/product-configuration']);
        }
      });
  }

  setEffectiveToDate() {
    this.addProductConfigForm.form
      .get(ProductConfigMapper.effectiveToDate)
      .setValue(this.addProductConfigForm.form.get(ProductConfigMapper.effectiveFromDate).value);
  }

  verifyDisplayOrder() {
    let serviceabilityGroup = this.addProductConfigForm.form.get('m').value;
    let displayOrder = this.addProductConfigForm.form.get('t').value;
    let data = {
      a: serviceabilityGroup,
      b: displayOrder
    };
    if (serviceabilityGroup && displayOrder) {
      this.restService
        .post(this.webconfig.apiURLProductConfiguration + apiUrl.VALIDATE_SERVICEABILITY_GROUP__DISPLAYORDER, data)
        .subscribe(
          (res) => {
            if (res.error) {
              this.errorMsg = this.lblErrMsgs.FORMRESET;
              this.showToastrMsg(
                'error',
                'This display order is already assigned. Following is the list of already assigned display order. ' +
                res.data.join(', '),
                ProductConfigMapper.displayOrder
              );
              this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
              this.addProductConfigForm.form.get(ProductConfigMapper.displayOrder).setErrors({ 'incorrect': true });
              this.element.nativeElement.querySelectorAll('Input').forEach((element) => {
                if (element.name == 't') {
                  element.select();
                }
              });
            } else {
              this.showToastrMsg('success', "", ProductConfigMapper.displayOrder);
            }
          },
          (err) => {
            this.showToastrMsg('error', err.error.message, ProductConfigMapper.displayOrder);
            this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          }
        );
    }
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }

    if (this.deleteSubscription) {
      this.deleteSubscription.unsubscribe();
    }
    if (this.releaseSubscription) {
      this.releaseSubscription.unsubscribe();
    }

    if (this.apiSubscription) {
      this.apiSubscription.unsubscribe();
    }
    if (this.apiSubscriptionTogglePopup) {
      this.apiSubscriptionTogglePopup.unsubscribe();
    }
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }

  }

  getName(v: string = '', arr: IProdSubProd[] = this.products) {
    return v && v != '' ? arr.filter((i) => i.b == v)[0].c : '';
  }

  createProductConfigKey() {
    let prodKey = this.addProductConfigForm.form.get('a').value ? this.addProductConfigForm.form.get('a').value : '';
    let prodName = this.getName(this.addProductConfigForm.form.get('a').value, this.products);

    let subprodKey = '';
    let subprodName = '';
    if (this.addProductConfigForm.form.get('b').value) {
      subprodKey =
        this.addProductConfigForm.form.get('b').value == null || this.addProductConfigForm.form.get('b').value == 'null'
          ? 0
          : this.addProductConfigForm.form.get('b').value;

      subprodName = this.getName(
        this.addProductConfigForm.form.get('b').value == 'null' ? null : this.addProductConfigForm.form.get('b').value,
        this.subProducts
      );
    }

    let featuresKey = '';
    let featuresName = '';
    if (this.addProductConfigForm.form.get('d').value != undefined) {
      featuresKey = this.addProductConfigForm.form
        .get('d')
        .value.map((itm) => (itm.b == null ? 0 : itm.b))
        .join('');

      featuresName = this.addProductConfigForm.form
        .get('d')
        .value.map((itm) => (itm.b == null ? '' : itm.c))
        .join(' ');
    }

    this.addProductConfigForm.form.patchValue({
      i: (prodKey + subprodKey + featuresKey).substring(0, 10),
      j: (prodName + ' ' + subprodName + ' ' + featuresName).substring(0, 50)
    });
    this.addProductConfigForm.form.get(ProductConfigMapper.productConfigKey).updateValueAndValidity()
    this.addProductConfigForm.form.get(ProductConfigMapper.productConfigName).updateValueAndValidity()
    let obj = {
      error: 'required',
      label: 'i',
      message: "",
      status: 'VALID',
      screenName: this.routerUrl
    };
    this.sharedService.setErrorMessage({ i: obj });
    this.sharedService.setErrorMessage({ j: obj });

  }

  submit(event) { }

  btnCancelAddProdConf() {
    if (this.router.url.includes('/view/')) {
      this.router.navigate(['master/product-configuration']);
    } else {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.CANCEL.TITLE,
          message: displayMsg.CANCEL.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result === true) {
          this.router.navigate(['master/product-configuration']);
        }
      });
      this.SetFocusOnYesButton();
    }
  }

  /**
   * Checks for Config Key if its already in database
   */
  checkOnConfigKey() {
    let prodConfKey = this.addProductConfigForm.form.get('i').value;
    this.restService
      .get(this.webconfig.apiURLProductConfiguration + apiUrl.VALIDATE_PRODUCT_CONFIG_KEY + '/' + prodConfKey)
      .subscribe(
        (res) => {
          if (res.error) {
            this.errorMsg = this.lblErrMsgs.FORMRESET;
            this.showToastrMsg('error', 'Product Config Key Already Exists', ProductConfigMapper.productConfigKey);
            this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.element.nativeElement.querySelectorAll('Input').forEach((element) => {
              if (element.name == 'i') {
                element.select();
              }
            });
          } else {
            this.showToastrMsg('success', '', ProductConfigMapper.productConfigKey);
          }
        },
        (err) => {
          this.showToastrMsg(
            'error',
            'There is something wrong with internet connectivity, please try after some time.', ProductConfigMapper.productConfigKey
          );
          this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      );
  }

  resetForm() {
    const confirmDialog = this.dialog.open(DialogComponent, {
      data: {
        title: displayMsg.RESET.TITLE,
        message: displayMsg.RESET.MESSAGE,
        primaryButton: displayMsg.BUTTON.YES,
        secondaryButton: displayMsg.BUTTON.NO
      }
    });
    confirmDialog.afterClosed().subscribe(result => {
      if (result) {
        this.addProductConfigForm.form.reset();
        this.element.nativeElement.querySelectorAll('mat-select')[0].focus();
        this.errorMsg = this.lblErrMsgs.FORMRESET;
        this.showToastrMsg('success', this.errorMsg);
        let values2Patch = {
          w: '2',
          h: 'B2B',
          g: '2'
        };
        this.addProductConfigForm.form.patchValue(values2Patch);
        this.element.nativeElement.querySelectorAll('mat-select')[0].focus();
      }
    });
    // this.confirmationService.confirm({
    //   message: 'Data will be cleared. Click YES to proceed.',
    //   header: 'Do you want to reset?',
    //   key: 'ConfirmPopup',
    //   accept: () => {
    //     this.addProductConfigForm.form.reset();
    //     this.element.nativeElement.querySelectorAll('mat-select')[0].focus();
    //     this.errorMsg = this.lblErrMsgs.FORMRESET;
    //     this.showToastrMsg('success', this.errorMsg);
    //     let values2Patch = {
    //       w: '2',
    //       h: 'B2B',
    //       g: '2'
    //     };
    //     this.addProductConfigForm.form.patchValue(values2Patch);
    //     this.element.nativeElement.querySelectorAll('mat-select')[0].focus();
    //   },
    //   reject: () => {
    //     return;
    //   }
    // });
    this.SetFocusOnYesButton();
  }

  public SetFocusOnYesButton() {
    if (this.btnFocus != null) {
      setTimeout(() => {
        this.btnFocus.nativeElement.focus();
      }, 5);
    }
  }
  public formatDate(dateObj: Date, dateFormat: string = 'd-m-Y') {
    let d = new Date(dateObj);
    let day = d.getDate();
    let month = d.getMonth() + 1;
    let year = d.getFullYear();

    let fomattedDate = '';

    switch (dateFormat) {
      case 'd-m-Y':
        fomattedDate = day + '-' + month + '-' + year;
        break;
      case 'm-d-Y':
        fomattedDate = month + '-' + day + '-' + year;
        break;
    }
    return fomattedDate;
  }

  /**
   * Created Common method to map JSON for ADD,CLONE and EDIT Product Config
   */
  commonMethod() {
    let FromDate =
      this.addProductConfigForm.value.q && this.addProductConfigForm.value.q != null
        ? this.formatDate(this.addProductConfigForm.value.q)
        : null;
    let ToDate =
      this.addProductConfigForm.value.r && this.addProductConfigForm.value.r != null
        ? this.formatDate(this.addProductConfigForm.value.r)
        : null;
    let ProdConfigKey = this.addProductConfigForm.value.i?.toUpperCase();
    let ParentServicibilityConfig = this.addProductConfigForm.value.u == "" ? null : this.addProductConfigForm.value.u?.toUpperCase();
    let BaggingRule = this.addProductConfigForm.value.v == "" ? null : this.addProductConfigForm.value.v?.toUpperCase();
    let parentProdConfigKey = this.addProductConfigForm.value.al == "" ? null : this.addProductConfigForm.value.al?.toUpperCase();
    let Mode = this.addProductConfigForm.value.y?.toUpperCase();
    let PackType = this.addProductConfigForm.value.z?.toUpperCase();
    return {
      a: this.addProductConfigForm.value?.a,
      b: this.addProductConfigForm.value.b == 'null' ? null : this.addProductConfigForm.value.b,
      d: this.addProductConfigForm.value.d,
      e: this.addProductConfigForm.value.e,
      f: this.addProductConfigForm.value.f,
      g: this.addProductConfigForm.value.g,
      h: this.addProductConfigForm.value.h,
      i: ProdConfigKey,
      j: this.addProductConfigForm.value.j,
      k: this.addProductConfigForm.value.k,
      l: this.addProductConfigForm.value.l,
      m: this.addProductConfigForm.value.m,
      n: this.setCheckboxValueYN(this.addProductConfigForm.value.n),
      o: this.setCheckboxValueYN(this.addProductConfigForm.value.o),
      p: this.setCheckboxValueYN(this.addProductConfigForm.value.p),
      q: FromDate,
      r: ToDate,
      s: this.setCheckboxValueYN(this.addProductConfigForm.value.s),
      t: parseInt(this.addProductConfigForm.value.t),
      u: ParentServicibilityConfig,
      v: BaggingRule,
      al: parentProdConfigKey,
      w: this.addProductConfigForm.value.w,
      x: this.addProductConfigForm.value.x,
      y: Mode,
      z: PackType,
      aa: this.setCheckboxValueYN(this.addProductConfigForm.value.aa),
      ab: this.setCheckboxValueYN(this.addProductConfigForm.value.ab),
      aj: this.setCheckboxValueYN(this.addProductConfigForm.value.aj),
      ac: 'I',
      c: this.setCheckboxValueYN(this.addProductConfigForm.value.c)
    };
  }

  setCheckboxValueYN(val: any) {
    if (val == 'Y') return 'Y';
    else if (val == 'N') return 'N';
    else if (val) return 'Y';
    else return 'N';
  }

  checkDirtyProductConfigAttributes(): Boolean {
    if (
      this.addProductConfigForm.form.get(ProductConfigMapper.products).value ==
      this.cloneData[ProductConfigMapper.products] &&
      this.addProductConfigForm.form.get(ProductConfigMapper.subProducts).value ==
      this.cloneData[ProductConfigMapper.subProducts] &&
      this.compareObjects(this.addProductConfigForm.form.get(ProductConfigMapper.features).value,
        this.cloneData[ProductConfigMapper.features]) &&
      this.compareObjects(this.addProductConfigForm.form.get(ProductConfigMapper.packaging).value,
        this.cloneData[ProductConfigMapper.packaging]) &&
      this.compareObjects(this.addProductConfigForm.form.get(ProductConfigMapper.vas).value, this.cloneData[ProductConfigMapper.vas]) &&
      this.addProductConfigForm.form.get(ProductConfigMapper.prodType).value ==
      this.cloneData[ProductConfigMapper.prodType] &&
      this.addProductConfigForm.form.get(ProductConfigMapper.prodCategory).value ==
      this.cloneData[ProductConfigMapper.prodCategory]
    ) {
      return false;
    } else {
      // dirty
      return true;
    }
  }

  compareObjects(o1: any, o2: any): boolean {
    // console.log(o1, o2, JSON.stringify(o1) == JSON.stringify(o2));
    console.log(JSON.stringify(o1) == JSON.stringify(o2));

    return JSON.stringify(o1) == JSON.stringify(o2);
  }

  submitForm() {
    this.submitted = true;
    let requestData: any = this.commonMethod();
    if (this.validateDateRange()) {
      if (this.router.url.includes('/edit/')) {
        if (this.addProductConfigForm.form.valid) {
          requestData.pci = this.productConfigId;
          requestData.i = this.cloneData.i;
          console.log(this.addProductConfigForm.form.get('u').value);
          console.log(this.cloneData.u);

          if (
            this.addProductConfigForm.form.dirty ||
            this.addProductConfigForm.form.get('u').value != this.cloneData.u ||
            this.addProductConfigForm.form.get('v').value != this.cloneData.v
          ) {
            this.updateProductConfig(requestData);
          } else {
            this.showToastrMsg('success', 'No Product Configuration updated.');
            this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          }
        } else {
          this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      } else if (this.router.url.includes('/clone/')) {
        requestData.pci = this.productConfigId;
        requestData.i != this.cloneData.i;
        if (
          this.addProductConfigForm.form.dirty ||
          this.addProductConfigForm.form.get('u').value != this.cloneData.u ||
          this.addProductConfigForm.form.get('v').value != this.cloneData.v
        ) {
          if (this.addProductConfigForm.form.valid) {
            this.saveProductConfig(requestData, 'clone');
          } else {
            this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          }
        } else {
          this.showToastrMsg('success', 'No Product Configuration updated.');
          this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      } else {
        if (this.addProductConfigForm.form.valid) {
          this.saveProductConfig(requestData);
        }
      }
    } else {
      this.addProductConfigForm.form.get(ProductConfigMapper.effectiveToDate).setErrors({ 'incorrect': true });
      this.showToastrMsg('error', 'Effective To date should always be greater than Effective From date.', ProductConfigMapper.effectiveToDate);
      this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      //this.addProductConfigForm.form.get(ProductConfigMapper.effectiveFromDate).setErrors({ 'incorrect': true });

    }
  }

  validateDateRange(): boolean {
    let fromDate = this.addProductConfigForm.form.get(ProductConfigMapper.effectiveFromDate).value;
    let toDate = this.addProductConfigForm.form.get(ProductConfigMapper.effectiveToDate).value;
    if (fromDate != null && toDate != null) {
      return this.getDifferenceInDate(fromDate, toDate) > 0 ? true : false;
    } else {
      return true;
    }
  }

  getDifferenceInDate(minDateObj, maxDateObj) {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    // Discard the time and time-zone information.
    if (typeof minDateObj == 'string') {
      minDateObj = new Date(minDateObj);
    }

    if (typeof maxDateObj == 'string') {
      maxDateObj = new Date(maxDateObj);
    }

    const minDate = moment(minDateObj) || minDateObj;
    const maxDate = moment(maxDateObj) || maxDateObj;

    //due to moment, need to change
    const utc1 = Date.UTC(minDate.year(), minDate.month(), minDate.date());
    const utc2 = Date.UTC(maxDate.year(), maxDate.month(), maxDate.date());

    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
  }

  saveProductConfig(requestData, action = 'create') {
    this.restService
      .post(this.webconfig.apiURLProductConfiguration + apiUrl.SAVE_PRODUCT_CONFIG_DETAILS, requestData)
      .subscribe(
        (res) => {
          this.errorMsg = action == 'create' ? this.lblErrMsgs.PRODCONFADD : this.lblErrMsgs.PRODCONFCLONED;
          this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 5000 });
          setTimeout(() => {
            this.router.navigate(['master/product-configuration/view/' + res.data.pci]);
          }, 5000);

          console.log(res);

        },
        (err: any) => {
          console.log(err);
          if (err.error.statusCode == "") {
            this.showToastrMsg('error', err.error.message);
            let obj = {
              error: 'api',
              label: 'error',
              message: err.error.message,
              status: 'INVALID',
              screenName: this.routerUrl
            };
            this.sharedService.setErrorMessage({ i: obj });
          } else {
            this.handleAPIValidationMsg(err);
          }

        }
      );
  }

  handleAPIValidationMsg(errorObj) {
    let errorMsg: string = "", lbl = "";
    switch (errorObj.error.statusCode) {
      case '1101':
        errorMsg = this.lblErrMsgs.INVALID_PARENT_SERVICEABILITY_CONFIG;
        lbl = ProductConfigMapper.parentServiceabilityConfig;
        this.addProductConfigForm.form.get(ProductConfigMapper.parentServiceabilityConfig).setErrors({ 'pattern': true });
        break;
      case '1102':
        errorMsg = this.lblErrMsgs.INVALID_BAGGING_RULE;
        lbl = ProductConfigMapper.baggingRule;
        this.addProductConfigForm.form.get(ProductConfigMapper.baggingRule).setErrors({ 'pattern': true });
        break;
      case '1106':
        errorMsg = errorObj.error.message;
        lbl = ProductConfigMapper.parentProductConfigKey;
        this.addProductConfigForm.form.get(ProductConfigMapper.baggingRule).setErrors({ 'pattern': true });
        break;

      case '1107':
        errorMsg = errorObj.error.message;
        lbl = ProductConfigMapper.parentProductConfigKey;
        this.addProductConfigForm.form.get(ProductConfigMapper.baggingRule).setErrors({ 'pattern': true });
        break;

      case '1108':
        errorMsg = errorObj.error.message;
        lbl = ProductConfigMapper.parentProductConfigKey;
        this.addProductConfigForm.form.get(ProductConfigMapper.baggingRule).setErrors({ 'pattern': true });
        break;
      default:
        errorMsg = errorObj.error.message;
      case '':
        errorMsg = errorObj.error.message;
        break;
    }
    this.showToastrMsg('error', errorMsg, lbl);
    this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
    if (lbl != "") {
      this.element.nativeElement.querySelectorAll('Input').forEach((element) => {
        if (element.name == lbl) {
          element.select();
        }
      });
    }
  }

  updateProductConfig(requestData) {
    console.log('in update');
    this.restService
      .put(this.webconfig.apiURLProductConfiguration + apiUrl.UPDATE_PRODUCT_CONFIG_DETAILS, requestData)
      .subscribe(
        (res) => {
          this.errorMsg = this.lblErrMsgs.PRODCONFEDIT;
          this.showToastrMsg('success', this.errorMsg);
          setTimeout(() => {
            this.router.navigate(['master/product-configuration/view/' + res.data.pci]);
          }, 5000);
        },
        (err) => {
          this.handleAPIValidationMsg(err);
        }
      );
  }

  getProductConfigData(): void {
    let getProductConfigSubscription: Observable<any> = this.restService.get(
      this.webconfig.apiURLProductConfiguration + apiUrl.GET_PRODUUCT_CONFIG_BY_ID + '/' + this.productConfigId
    );
    let getProductSubscription: Observable<any> = this.restService.get(
      this.webconfig.apiURLProductConfiguration + apiUrl.GET_PRODUCT
    );
    let getSubProductSubscription: Observable<any> = this.restService.get(
      this.webconfig.apiURLProductConfiguration + apiUrl.GET_SUB_PRODUCT
    );

    let apiObj: IAddProdForkJoin;
    if (!this.router.url.includes('/add')) {
      apiObj = {
        productConfig: getProductConfigSubscription,
        products: getProductSubscription,
        subproducts: getSubProductSubscription
      };
    } else {
      apiObj = {
        products: getProductSubscription,
        subproducts: getSubProductSubscription
      };
    }

    forkJoin(apiObj).subscribe((res: IAddProdForkJoin) => {
      this.products = res.products.data;
      this.subProducts = res.subproducts.data;
      if (!this.router.url.includes('/add')) {
        this.cloneData = res.productConfig.data;
        this.createPatchObj();
      }
    });
  }

  getDateObj(dtStr) {
    let createdDtArr = dtStr.split(' ');
    let dt1Str = createdDtArr[0].split('/');
    let timeStr = createdDtArr[1].split(':');
    let finalDate = new Date(dt1Str[2], dt1Str[1] - 1, dt1Str[0], createdDtArr[2] == 'PM' ? parseInt(timeStr[0]) + 12 : timeStr[0], timeStr[1]);
    let ISTDate1 = new Date(finalDate)
    ISTDate1.setHours(finalDate.getHours() + 5);
    ISTDate1.setMinutes(finalDate.getMinutes() + 30);
    return ISTDate1;
  }

  createPatchObj() {
    let createdDtArr = this.cloneData.ag.split(' ');
    console.log(this.cloneData.ag, new Date(this.cloneData.ag));
    let createdDateTime = this.getDateObj(this.cloneData.ag).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
    let dateTimeArr = createdDateTime.split(',');
    let createdDate = dateTimeArr[0];
    let createdTime = dateTimeArr[1];

    if (this.cloneData.b == 'Normal') {
      this.cloneData.b = null;
    }

    let values2Patch = {
      i: this.cloneData.i,
      a: this.cloneData.a,
      b: this.cloneData.b == null ? 'null' : this.cloneData.b,
      h: this.cloneData.h,
      n: this.cloneData.n == 'Y',
      o: this.cloneData.o == 'Y',
      p: this.cloneData.p == 'Y',
      w: this.cloneData.w,
      j: this.cloneData.j,
      l: this.cloneData.l,
      x: this.cloneData.x,
      y: this.cloneData.y,
      z: this.cloneData.z,
      aa: this.cloneData.aa == 'Y',
      ab: this.cloneData.ab == 'Y',
      aj: this.cloneData.aj == 'Y',
      s: this.cloneData.s == 'Y',
      t: this.cloneData.t,
      q: this.cloneData.q,
      r: this.cloneData.r,
      m: this.cloneData.m,
      k: this.cloneData.k,
      g: this.cloneData.g,
      u: this.cloneData.u,
      v: this.cloneData.v,
      al: this.cloneData.al,
      d: this.cloneData.d,
      e: this.cloneData.e,
      f: this.cloneData.f,
      c: this.cloneData.c == 'Y'
    };

    if (this.router.url.includes('/edit/')) {
      this.addProductConfig[3].rows[0].label =
        'Added on ' + createdDate + ' at ' + createdTime.toLocaleUpperCase() + ' by ' + this.cloneData.ah;
      this.addProductConfigForm.form.get(ProductConfigMapper.productConfigKey).disable();
    }

    this.addProductConfigForm.form.patchValue(values2Patch);
  }

  OpenSingleSelectDialog() {
    this.subscriptions = this.sharedService.singleSelectSuggestionTableSubject$.subscribe(field => {
      this.restService.get(field.helpApiUrl, {}).subscribe(
        (response) => {
          let rows = [];
          rows = response.data;

          const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
            disableClose: true,
            width: '600px',
            minWidth: 400,
            data: {
              title: field.label,
              rows: response.data,
              gridColumns: field.helpDialogGridColumns,
              noteText: field.disclaimer,
              helpTableDataColumn: true
            }
          });
          dialogRef.afterClosed().subscribe(res => {
            if (res) {
              this.addProductConfigForm.form.controls[field.name].setValue(res.a);
            }
          });
        },
        (error) => {
          console.log(error);
        }
      );
    });
  }
}
