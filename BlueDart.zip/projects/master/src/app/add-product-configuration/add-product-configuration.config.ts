import { CommonValidators } from '../../../../vendors/src/lib/common.validator';
import { apiUrl } from '../product-configuration/product-configuration.constant';
const commonValidators = new CommonValidators();
// let 'webApiUrl' = 'http://10.53.64.49:31008/api/productservice/';
import * as baseUrl from '../../../../login/src/assets/webconfig.json';

const gridColumns = [
  {
    field: 'a',
    header: 'Product Config Key',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'b',
    header: 'Product Config Name',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'c',
    header: 'Product',
    showFilter: true,
    colWidth: '50px'
  },
  {
    field: 'd',
    header: 'Sub Product',
    showFilter: true,
    colWidth: '70px'
  }
];

export const addProdConfigHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToProductConfiguration',
        trigerOnClick: 'true',
        eventRef: 'backToProductConfiguration',
        buttonType: 'button',
        tabIndex: 36,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'Add Product Configuration',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Reset',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'resetFormDetails',
        tabIndex: 37,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s9 m2 l1 right-align'
      },
      {
        type: 'button',
        label: 'Cancel',
        name: 'btnCancelAddProdConf',
        tabIndex: 38,
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnCancelAddProdConf',
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s3 m2 l1 right-align'
      }
    ]
  }
];

export const editProdConfigHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToProductConfiguration',
        trigerOnClick: 'true',
        eventRef: 'backToProductConfiguration',
        tabIndex: 36,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'Edit Product Configuration',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Cancel',
        name: 'btnCancelAddProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnCancelAddProdConf',
        tabIndex: 37,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s3 m2 l1 right-align'
      }
    ]
  }
];

export const cloneProdConfigHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToProductConfiguration',
        trigerOnClick: 'true',
        eventRef: 'backToProductConfiguration',
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'Clone Product Configuration',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Cancel',
        name: 'btnCancelAddProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnCancelAddProdConf',
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s3 m2 l1 right-align'
      }
    ]
  }
];

export const viewProdConfigHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToProductConfiguration',
        trigerOnClick: 'true',
        eventRef: 'backToProductConfiguration',
        tabIndex: 6,
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'View Product Configuration',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Edit',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'editProdConf',
        tabIndex: 1,
        classes: {
          buttonType: 'action-button'
        }
      },

      {
        type: 'button',
        label: 'Clone',
        name: 'btnCancelAddProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'cloneProdConf',
        tabIndex: 2,
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'button',
        label: 'Release',
        name: 'btnReleaseProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnReleaseProdConf',
        tabIndex: 3,
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'button',
        label: 'Delete',
        name: 'btnDeleteProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 4,
        eventRef: 'btnDeleteProdConf',
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'button',
        label: 'History',
        name: 'btnHistoryProdConf',
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 5,
        eventRef: 'btnHistoryProdConf',
        classes: {
          buttonType: 'action-button'
        },
        separatorBefore: true
      }
    ]
  }
];

export const addProductConfigurationConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Product Attributes',
        class: 'col s12 l6 m12 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'select',
                multiple: false,
                // ApiUrl: apiUrl.GET_PRODUCT,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_PRODUCT,
                label: 'Product',
                inputType: 'text',
                name: 'a',
                validations: commonValidators.PRODUCT,
                class: 'col s6 m5 l4 xl2 p-t-12 p-l-0',
                map: {
                  label: ['b', 'c'],
                  value: 'b'
                },
                tabIndex: 1
              },
              {
                type: 'select',
                multiple: false,
                // ApiUrl: apiUrl.GET_SUB_PRODUCT,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_SUB_PRODUCT,
                label: 'Sub Product',
                inputType: 'text',
                name: 'b',
                validations: commonValidators.SUB_PRODUCT,
                class: 'col s6 m7 l3 xl3 p-t-12 p-l-0',
                map: {
                  label: ['b', 'c'],
                  value: 'b',
                  nullAlias: 'c'
                },
                tabIndex: 2,
                handleNullValues: true
              },
              {
                type: 'select',
                multiple: true,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_FEATURES,
                label: 'Feature(s)',
                inputType: 'text',
                name: 'd',
                validations: commonValidators.FEATURE,
                class: 'col l5 xl6 s12 m12 p-t-12 p-l-0',
                map: {
                  label: 'c',
                  value: 'obj',
                  nullAlias: 'c'
                },
                disableOptionsOnNoSel: true,
                tabIndex: 3
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'selectnumber',
                multiple: true,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_PACKAGING,
                label: 'Packaging(s)',
                inputType: 'text',
                name: 'e',
                validations: commonValidators.PACKAGING,
                class: 'col s12 m6 l7 xl4 p-l-0',
                map: {
                  label: 'c',
                  value: 'obj',
                  nullAlias: 'c'
                },
                tabIndex: 4
              },
              {
                type: 'select',
                multiple: true,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_VAS,
                label: 'VAS(s)',
                inputType: 'text',
                name: 'f',
                validations: commonValidators.VAS,
                class: 'col s12 m6 l5 xl8 p-l-0',
                map: {
                  label: 'c',
                  value: 'obj',
                  nullAlias: 'c'
                },
                tabIndex: 5
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'radiobutton',
                label: 'Select DOX/DUTS/BOTH',
                options: [
                  { label: 'DOX', value: '1', tabIndex: 6 },
                  { label: 'DUTS', value: '2', tabIndex: 7 },
                  { label: 'BOTH', value: '3', tabIndex: 8 }
                ],
                value: '2',
                name: 'g',
                fGroupName: 'Radiobtns',
                class: 'col s12 m4 l5 xl3 m-t-17 p-l-0'
              },
              {
                type: 'radiobutton',
                label: 'Product Category',
                tabIndex: 9,
                options: [
                  { label: 'B2B', value: 'B2B', tabIndex: 9 },
                  { label: 'B2C', value: 'B2C', tabIndex: 10 }
                ],
                value: 'B2B',
                name: 'h',
                fGroupName: 'Radiobtns',
                validations: commonValidators.PRODUCT_CATEGORY,
                class: 'col s12 m8 l4 xl9 m-t-17 p-l-0'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Product Config Key',
                inputType: 'text',
                name: 'i',
                eventRef: 'productConfigKey',
                validations: commonValidators.PRODUCT_CONFIG_KEY,
                class: 'col s12 m5 l4 xl3 p-t-4 p-l-0',
                autosuggest: false,
                maxlength: 10,
                isAutoCaps: true,
                tabIndex: 11,
                regExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Product Config Name',
                inputType: 'text',
                name: 'j',
                validations: commonValidators.PRODUCT_CONFIG_NAME,
                class: 'col s12 m7 l8 xl7 p-t-4 p-l-0',
                autosuggest: false,
                maxlength: 50,
                tabIndex: 12,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_DOT
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: 'Control Details',
        class: 'col s12 l6 m12 p-r-0 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'checkbox',
                label: 'Allow pincode level serviceability',
                name: 's',
                // class: 'col s12 m4 l5 xl3 p-t-12 p-l-0'
                class: 'col allow-serv-chkbox p-t-12 p-l-0',
                tabIndex: 18
              },
              {
                type: 'select',
                multiple: false,
                ApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.SERVICEABILITY_GROUP,
                label: 'Serviceability Group',
                inputType: 'text',
                name: 'm',
                validations: commonValidators.SERVICEABILITY_GROUP,
                // class: 'col s12 m4 l4 xl3 p-t-12 p-l-0',
                class: 'col servGrp-ddl p-t-12 p-l-0',
                map: {
                  label: 'a',
                  value: 'a'
                },
                tabIndex: 19,
                infoIcon: true,
                tooltip:
                  'This will be used to categorize the products under certain headings during dynamic display of products on other screens.'
              },
              {
                type: 'input',
                label: 'Display Order',
                inputType: 'text',
                validations: commonValidators.DISPLAY_ORDER,
                name: 't',
                class: 'col disp-order-txt p-t-16 p-l-0',
                maxlength: 3,
                infoIcon: true,
                tabIndex: 20,
                regExp: commonValidators.regexExpressions.ONLY_NUMBER,
                tooltip:
                  'This is a display order per each custom group which will be used to display product configuration at other places like Pincode service manager'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Parent Product Config Key',
                inputType: 'text',
                disclaimer: 'Select from the below list to add Parent Product Configurations key',
                name: 'al',
                id: 'al',
                helpApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_PARENT_SERV_CONF,
                maxlength: 30,
                text: 'Select',
                HelpDialogWidth: 600,
                class: 'col s12 m6 l5 xl4 p-l-0',
                isAutoCaps: true,
                tabIndex: 21,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_COMMA,
                helpDialogGridColumns: gridColumns,
                gridOptions: {
                  isSortable: true,
                  isScrollable: true,
                  isExpandable: false,
                  isColumnFilter: false,
                  isGroupable: false,
                  isCaption: false,
                  isClickable: true,
                  tableHeight: '42vh',
                  isSelectAllRows: false,
                  selectionMode: 'single',
                  selectBtn: false,
                }
              },
              {
                type: 'input',
                label: 'Parent Serviceability Config',
                inputType: 'text',
                // validations: commonValidators.PARENT_SERVICEABILITY_CONFIG,
                disclaimer: 'Select from the below list to add Parent Serviceable Product Configurations',
                name: 'u',
                id: 'u',
                helpApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_PARENT_SERV_CONF,
                maxlength: 30,
                text: 'Select',
                HelpDialogWidth: 600,
                class: 'col s12 m6 l7 xl4 p-l-0',
                infoIcon: true,
                isAutoCaps: true,
                tabIndex: 21,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_COMMA,
                tooltip:
                  'When a product configuration is not serviceable, this defines the parent product configurations to be checked for evaluating serviceability.',
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Product Config Key',
                    showFilter: true,
                    colWidth: '100px'
                  },
                  {
                    field: 'b',
                    header: 'Product Config Name',
                    showFilter: true,
                    colWidth: '100px'
                  },
                  {
                    field: 'c',
                    header: 'Product',
                    showFilter: true,
                    colWidth: '50px'
                  },
                  {
                    field: 'd',
                    header: 'Sub Product',
                    showFilter: true,
                    colWidth: '70px'
                  }
                ],
                gridOptions: {
                  isSortable: true,
                  isScrollable: true,
                  isExpandable: false,
                  isColumnFilter: false,
                  isGroupable: false,
                  isCaption: false,
                  isClickable: true,
                  tableHeight: '42vh',
                  isSelectAllRows: true
                }
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Bagging Rule',
                inputType: 'text',
                disclaimer: 'Select from the below list to add bagging rules',
                name: 'v',
                id: 'v',
                maxlength: 30,
                text: 'Select',
                tabIndex: 22,
                // validations: commonValidators.BAGGING_RULE,
                infoIcon: true,
                tooltip: 'Define mixed bagging rules and bagging level fallback mechanism',
                helpApiUrl: baseUrl.apiURLProductConfiguration + apiUrl.GET_BAGGING_RULE,
                HelpDialogWidth: 600,
                class: 'col s12 m6 l12 xl4 p-l-0',
                isAutoCaps: true,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_COMMA,
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Product Config Key',
                    showFilter: true,
                    colWidth: '100px'
                  },
                  {
                    field: 'b',
                    header: 'Product Config Name',
                    showFilter: true,
                    colWidth: '100px'
                  },
                  {
                    field: 'c',
                    header: 'Product',
                    showFilter: true,
                    colWidth: '50px'
                  },
                  {
                    field: 'd',
                    header: 'Sub Product',
                    showFilter: true,
                    colWidth: '70px'
                  }
                ],
                gridOptions: {
                  isSortable: true,
                  isScrollable: true,
                  isExpandable: false,
                  isColumnFilter: false,
                  isGroupable: false,
                  isCaption: false,
                  isClickable: true,
                  tableHeight: '42vh',
                  isSelectAllRows: true
                }
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'checkbox',
                label: 'Display on Called Pickup Screen',
                name: 'aa',
                class: 'col s6 m6 l6 xl4 p-l-0 m-t--10',
                tabIndex: 23
              },
              {
                type: 'checkbox',
                label: 'Display on Finders - Rate Panel',
                name: 'ab',
                tabIndex: 24,
                class: 'col s6 m6 l6 xl4 p-l-0 m-t--10'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'checkbox',
                label: 'Allow RAS Configuration',
                tabIndex: 25,
                name: 'aj',
                class: 'col s6 m6 l6 xl4 p-l-0 m-t--20 m-b--13'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Activation Details',
        class: 'col s12 l6 m12 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'checkbox',
                label: 'Active on C2PC',
                name: 'n',
                class: 'col s12 m4 l4 xl3 p-l-0',
                tabIndex: 13
              },
              {
                type: 'checkbox',
                label: 'Active on Web',
                name: 'o',
                class: 'col s12 m4 l4 xl3 p-l-0',
                tabIndex: 14
              },
              {
                type: 'checkbox',
                label: 'Query on Web',
                name: 'p',
                class: 'col s12 m4 l4 xl3 p-l-0',
                tabIndex: 15
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'date',
                label: 'Effective From',
                minDate: 10,
                name: 'q',
                class: 'col s12 m6 l3 xl3 p-l-0',
                tabIndex: 16,
                id: 'effectiveFrom'
              },
              {
                type: 'date',
                label: 'Effective To',
                minDate: 10,
                name: 'r',
                class: 'col s12 m6 l3 xl3 p-l-0',
                tabIndex: 17,
                id: 'effectiveDate'
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: 'Backward Compatibility',
        class: 'col s12 l6 m12 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Product Config Alias',
                inputType: 'text',
                name: 'k',
                validations: commonValidators.PRODUCT_CONFIG_ALIAS,
                class: 'col s12 m6 l4 xl3 p-t-12 p-l-0',
                autosuggest: false,
                maxlength: 50,
                tabIndex: 26,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_DOT
              },
              {
                type: 'input',
                label: 'Sub Product Alias',
                inputType: 'text',
                validations: commonValidators.SUB_PRODUCT_ALIAS,
                name: 'l',
                class: 'col s12 m6 l4 xl3 p-t-12 p-l-0',
                autosuggest: false,
                maxlength: 25,
                tabIndex: 27,
                regExp: commonValidators.regexExpressions.ALL_ALPHANUMERIC_WITH_SPACE_DOT
              },
              {
                type: 'checkbox',
                label: 'Is Sub Product?',
                name: 'c',
                class: 'col s12 m4 l4 xl3 p-t-12 p-l-0',
                infoIcon: true,
                tabIndex: 28,
                tooltip:
                  'Check this field if the product configuration belong to an offer eg., Rakhi Express, Student Express, etc.'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'SAC Code',
                inputType: 'text',
                validations: commonValidators.SAC_CODE,
                name: 'x',
                maxlength: 6,
                tabIndex: 29,
                regExp: commonValidators.regexExpressions.ONLY_NUMBER,
                class: 'col s6 m3 l2 xl1 p-l-0'
              },
              {
                type: 'radiobutton',
                label: 'Transaction Code',
                tabIndex: 30,
                options: [
                  { label: 'Cash', value: '1', tabIndex: 30 },
                  { label: 'Credit', value: '2', tabIndex: 31 },
                  { label: 'Both', value: '3', tabIndex: 32 }
                ],
                value: '2',
                name: 'w',
                fGroupName: 'Radiobtns',
                class: 'col s12 m6 l5 xl3 m-t-17'
              },
              {
                type: 'input',
                label: 'Mode',
                inputType: 'text',
                name: 'y',
                class: 'col s6 m3 l2 xl1 p-l-0',
                validations: commonValidators.MODE,
                maxlength: 1,
                infoIcon: true,
                isAutoCaps: true,
                tooltip: 'Put the sub product code (mode) for the product configuration as per existing pack master.',
                tabIndex: 33,
                regExp: commonValidators.regexExpressions.ALL_CHARACTER,
              },
              {
                type: 'input',
                label: 'Pack Type',
                inputType: 'text,',
                validations: commonValidators.PACK_TYPE,
                name: 'z',
                class: 'col s6 m3 l3 xl1 p-l-0',
                maxlength: 1,
                infoIcon: true,
                isAutoCaps: true,
                tooltip: 'Put the Feature/Pack code for the product configuration as per existing pack master.',
                tabIndex: 34,
                regExp: commonValidators.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS
              }
            ]
          }
        ]
      }
    ]
  }
];

export const addedByLabel = [
  {
    type: 'row',
    rows: [
      {
        type: 'label',
        label: '',
        class: 'col s12 m12 l12 xl12 right-align'
      }
    ]
  }
];

export const saveButton = [
  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: 'Save',
        buttonType: 'Submit',
        trigerOnClick: 'true',
        eventRef: 'addProdConfSubmit',
        tabIndex: 35,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true,
          Class: 'm-t--10'
        },
        class: 'col s12 m12 l12 xl12 right-align m-b-10'
      }
    ]
  }
];
