import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./location/location.module').then((m) => m.LocationModule)
  },
  {
    path: 'product-configuration',
    loadChildren: () =>
      import('./product-configuration/product-configuration.module').then((m) => m.ProductConfigurationModule)
  },
  {
    path: 'pickup-route',
    loadChildren: () =>
      import('./pickup-route-master/pickup-route-master.module').then((m) => m.PickupRouteMasterModule)
  },
  {
    path: 'bulk-shipper',
    loadChildren: () => import('./bulk-shipper-mst/bulk-shipper-mst.module').then((m) => m.BulkShipperMstModule)
  },
  {
    path: 'actual-shipper',
    loadChildren: () => import('./actual-shipper/actual-shipper.module').then((m) => m.ActualShipperModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
