import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
// import { AddProductConfigurationComponent } from './add-product-configuration/add-product-configuration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule, ToolsModule } from '../../../../projects/tools/src/public-api';
//import { HistoryModule } from './history/history.module';
// import { ViewProductConfigurationComponent } from './view-product-configuration/view-product-configuration.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
@NgModule({
  declarations: [
    AppComponent
    // ViewProductConfigurationComponent,
    // AddProductConfigurationComponent,
  ],
  imports: [CommonModule, MatSnackBarModule, ToolsModule, FormsModule, ReactiveFormsModule, AppRoutingModule, MaterialModule],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
