import { Component, OnDestroy, OnInit } from '@angular/core';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { interval, of, Subject, Subscription } from 'rxjs';
import {
  map,
  switchMap,
  tap,
  throttle,
  take,
  takeUntil,
  share,
  throttleTime,
  debounceTime,
  distinctUntilChanged
} from 'rxjs/operators';
import { MessageService as AlertService } from 'primeng/api';
import { IHistory } from '../history/history.interface';
import { Router } from '@angular/router';
import { FlexAlignStyleBuilder } from '@angular/flex-layout';
import * as ErrorMessage from 'projects/login/src/assets/erroMsgsMapping.json';
import * as LabelConstant from 'projects/login/src/assets/labelDataList.json';

@Component({
  selector: 'app-base',
  template: ''
})
export class BaseComponent implements OnInit, OnDestroy {
  apiBaseUrl: string = '';
  deleteAPIURL: string = '';
  releaseAPIURL: string = '';
  historyAPIURL: string = '';
  rowHistory: IHistory[];
  showHistory: boolean = false;
  apiSubscription: Subscription;
  apiSubscriptionTogglePopup: Subscription;
  deleteSubscription: Subscription;
  releaseSubscription: Subscription;
  primaryKey: string;
  screenText: string;
  tableHeight: string;
  unsubscribeObservables$: Subject<void> = new Subject();
  protected routerUrl: any;
  protected onView: boolean = false;
  protected currentUser: any;
  protected customDeleteParams: string = null;
  protected lblErrMsgs: any;
  protected labelConstant: any;
  protected deleteFragmentURI: any = null;
  protected resourceNameForHistory: string = "";

  getAll() { }

  constructor(
    protected sharedService: SharedService,
    protected restService: RestService,
    protected alertService: AlertService
  ) {
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });
    this.restService.get('assets/labelDataList.json').subscribe((data) => {
      this.labelConstant = data;
    });
  }

  ngOnInit(): void { }

  setDeleteURL(url) {
    this.deleteAPIURL = url;
  }

  setReleaseURL(url) {
    this.releaseAPIURL = url;
  }

  handleHTTPErrors(statusCode, lbl, form) {
    let errorMsg: string = null;
    switch (statusCode) {
      case '8053':
        errorMsg = this.lblErrMsgs.AREA_METRO_CITY;
        break;
      case '1504':
        errorMsg = this.lblErrMsgs.VALIDAREACODE;
        break;
      default:
        break;
    }

    if (errorMsg != null) {
      form.get(lbl).setErrors({ pattern: true });
      this.showToastrMsg('error', errorMsg, lbl);
    }
  }

  delete() {
    this.deleteSubscription = this.sharedService
      .getGridRowForDelete()
      .pipe(takeUntil(this.unsubscribeObservables$))
      .pipe(switchMap((res1) => this.restService.deleteByURL(this.deleteAPIURL + '/' + res1[this.primaryKey])))
      .subscribe(
        (res) => {
          console.log(res);
          if (!res.error) {
            this.alertService.add({
              key: 'bc',
              severity: 'success',
              detail: this.screenText + ' is deleted successfully.'
            });
            //this.showToastrMsg('success', this.screenText + ' is deleted successfully.', 'delete');
            if (!this.onView) {
              this.getAll();
            }
          } else {
            this.alertService.add({
              key: 'bc',
              severity: 'error',
              detail: res.message
            });
            //this.showToastrMsg('error', res.message, 'delete');
          }
        },
        (err) => {
          this.alertService.add({
            key: 'bc',
            severity: 'error',
            detail: err.error.message
          });
          // this.showToastrMsg('error', err.error.message, 'delete');
        }
      );
  }

  release() {
    this.releaseSubscription = this.sharedService.gridRowReleaseSubject
      .pipe(
        map((res) => {
          return {
            a: res[this.primaryKey],
            b: res.ac || res.ac == null ? res.ac : 'D'
          };
        })
      )
      .pipe(takeUntil(this.unsubscribeObservables$))
      .pipe(switchMap((res1) => this.restService.patch(this.releaseAPIURL, res1)))
      .subscribe((res) => {
        if (!res.error) {
          this.alertService.add({
            key: 'bc',
            severity: 'success',
            detail: this.screenText + ' is Released successfully.'
          });
          // this.showToastrMsg('success', this.screenText + ' is Released successfully.', 'release');
          if (!this.onView) {
            this.getAll();
          }
        } else {
          this.alertService.add({
            key: 'bc',
            severity: 'error',
            detail: 'Operation failed, please try after some time.'
          });
          // this.showToastrMsg('error', 'Operation failed, please try after some time.', 'release');
        }
      });
  }

  ngOnDestroy() {
    if (this.deleteSubscription) {
      this.deleteSubscription.unsubscribe();
    }
    if (this.releaseSubscription) {
      this.releaseSubscription.unsubscribe();
    }

    if (this.apiSubscription) {
      this.apiSubscription.unsubscribe();
    }
    if (this.apiSubscriptionTogglePopup) {
      this.apiSubscriptionTogglePopup.unsubscribe();
    }

    this.unsubscribeObservables$.next();
    this.unsubscribeObservables$.complete();
  }

  showToastrMsg(severity: string, msg: string, lbl = '') {
    if (severity == 'success' && msg != '') {
      this.alertService.add({
        key: 'bc',
        severity: severity,
        detail: msg
      });
    }

    let obj = {
      error: 'api',
      label: lbl,
      message: msg,
      status: severity == 'success' ? 'VALID' : 'INVALID',
      screenName: this.routerUrl
    };
    this.sharedService.setErrorMessage({ [lbl]: obj });
  }

  showHistoryPopup() {
    this.apiSubscriptionTogglePopup = this.sharedService.getShowHistoryPopup().subscribe((res) => {
      this.showHistory = res;
    });
  }

  showRowHistory() {
    this.apiSubscription = this.sharedService
      .getGridRowForHistory()
      .pipe(takeUntil(this.unsubscribeObservables$))
      .pipe(tap((res) => console.log(res)))
      .pipe(map((res) => {
        return {
          a: res[this.primaryKey],
          b: this.resourceNameForHistory
        }
      }))
      .pipe(switchMap((res1) => this.showHistory ? this.restService.post(this.historyAPIURL, res1) : of(1)))
      .subscribe((res: any) => {
        this.rowHistory = res.data;
      });
  }

  closeHistoryPopup() {
    this.showHistory = false;
  }
}
