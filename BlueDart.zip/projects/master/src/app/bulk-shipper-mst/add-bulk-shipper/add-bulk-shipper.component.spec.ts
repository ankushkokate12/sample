import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBulkShipperComponent } from './add-bulk-shipper.component';

describe('AddBulkShipperComponent', () => {
  let component: AddBulkShipperComponent;
  let fixture: ComponentFixture<AddBulkShipperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddBulkShipperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBulkShipperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
