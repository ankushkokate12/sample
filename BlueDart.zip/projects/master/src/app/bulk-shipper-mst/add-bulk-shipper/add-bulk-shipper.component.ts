import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  addBulkShipperHeader,
  editBulkShipperHeader,
  addBulkShipperConfig,
  saveButton
} from './add-bulk-shipper.config';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { Properties } from 'projects/vendors/src/lib/bd.propertybundle';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { BaseComponent } from './../../base/base.component';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { AddBulkShipperMapper } from './add-bulk-shipper.mapper';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { apiUrl } from './../bulk-shipper-mst.constant';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';

@Component({
  selector: 'app-add-bulk-shipper',
  templateUrl: './add-bulk-shipper.component.html',
  styleUrls: ['./add-bulk-shipper.component.scss']
})
export class AddBulkShipperComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild(DynamicFormComponent, { static: false })
  addBulkShipperForm: DynamicFormComponent;
  addBulkShipper: FieldConfig[];
  customerCodeAndArea: { a: any; b: any };
  currentUser: any;
  areaCode: any;
  getShipperDetails: any;
  errorMsg: any;
  responseMsg: any;
  lblErrMsgs: any;
  bulkShipperId: any;
  getDetailsById: any;
  constructor(
    private router: Router,
    private eventEmitt: EventEmitterService,
    private dialog: MatDialog,
    protected sharedService: SharedService,
    protected alertService: AlertService,
    protected restService: RestService,
    private primengMessageService: AlertService,
    private webconfig: BdWebConfigService,
    private messageService: MessageService,
    private errorMsgService: SharedService,
    private element: ElementRef,
    private activatedRoute: ActivatedRoute
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });
    this.bulkShipperId = activatedRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    this.addBulkShipper = addBulkShipperConfig;
    this.messageService.sendHeaderShowMessage(true);
    this.manageConfiguration();
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == Properties.BTN_BACK || field.eventRef == Properties.BTN_CANCEL) {
        this.btnCancelAdd();
      } else if (field.eventRef == 'customerCode') {
        this.getCustomerDetailByCustomerCodeAndArea();
      } else if (field.eventRef == 'save') {
        this.saveForm();
      } else if (field.eventRef == 'resetFormDetails') {
        this.resetForm();
      }
    });
    // get Current Location
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.areaCode = this.currentUser.area;
    console.log(this.areaCode);
    this.sharedService.getPopupData().subscribe((res) => {
      if (res.data) {
        this.addBulkShipperForm.form.patchValue({
          a: res.data.a,
          ab: res.data.b
        });
      }
    });
  }
  ngAfterViewInit() {
    this.addBulkShipperForm.form.patchValue({
      a: this.areaCode
    });

    if (this.router.url.includes('/edit/')) {
      this.getBulkShipperDetailsById();
      this.element.nativeElement.querySelectorAll('Input')[0].disabled = true;
      this.element.nativeElement.querySelectorAll('Input')[2].disabled = true;
    }
  }

  getCustomerDetailByCustomerCodeAndArea() {
    const customerCodeAndArea = {
      a: this.addBulkShipperForm.form.value.a.toUpperCase(),
      b: this.addBulkShipperForm.form.value.b
    };
    this.restService
      .post(
        this.webconfig.custServiceAPIURL + apiUrl.Get_Customer_Detail_By_Customer_Code_And_Area,
        customerCodeAndArea
      )
      .subscribe(
        (res) => {
          console.log(res);
          if (res.error == false) {
            this.getShipperDetails = res.data;
            this.addBulkShipperForm.form.patchValue({
              d: this.getShipperDetails.d,
              e: this.getShipperDetails.e,
              f: this.getShipperDetails.f,
              g: this.getShipperDetails.g,
              h: this.getShipperDetails.h,
              i: this.getShipperDetails.i
            });
          }
        },
        (err) => {
          console.log(err);
          if (err.error.error == true && err.error.statusCode == '1011') {
            console.log(err.error.message);
            this.errorMsg = err.error.message;
          } else if (err.error.error == true && err.error.statusCode == '5034') {
            this.errorMsg = err.error.message;
          } else if (err.error.error == true && err.error.statusCode == '400') {
            this.errorMsg = err.error.data.map((x) => x);
          }
          this.setErrorPanel('b', this.errorMsg, 'INVALID');
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      );
  }

  /*
   * Get Bulk Shipper Details By ID
   */
  getBulkShipperDetailsById() {
    this.restService
      .get(this.webconfig.custServiceAPIURL + apiUrl.GET_BULK_SHIPPER_DETAILS_BY_ID + '/' + this.bulkShipperId)
      .subscribe(
        (res) => {
          console.log(res);
          if (res.error == false) {
            this.getDetailsById = res.data;
            let detailsToUpdate = {
              a: this.getDetailsById?.a == null ? '' : this.getDetailsById?.a,
              b: this.getDetailsById?.b == null ? '' : this.getDetailsById?.b,
              c: this.getDetailsById?.c == null ? '' : this.getDetailsById?.c,
              d: this.getDetailsById?.d == null ? '' : this.getDetailsById?.d,
              e: this.getDetailsById?.e == null ? '' : this.getDetailsById?.e,
              f: this.getDetailsById?.f == null ? '' : this.getDetailsById?.f,
              g: this.getDetailsById?.g == null ? '' : this.getDetailsById?.g,
              h: this.getDetailsById?.h == null ? '' : this.getDetailsById?.h,
              i: this.getDetailsById?.i == null ? '' : this.getDetailsById?.i,
              id: this.getDetailsById?.id
            };
            this.addBulkShipperForm.form.patchValue(detailsToUpdate);
          } else {
            console.log(res);
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  manageConfiguration() {
    if (this.router.url.includes('/add')) {
      this.addBulkShipper = [...addBulkShipperHeader, ...addBulkShipperConfig, ...saveButton];
    } else if (this.router.url.includes('/edit')) {
      this.addBulkShipper = [...editBulkShipperHeader, ...addBulkShipperConfig, ...saveButton];
    }
  }

  commonMethod() {
    return {
      a: this.addBulkShipperForm.form.value?.a.toUpperCase(),
      b: this.addBulkShipperForm.form.value?.b.toUpperCase(),
      c: this.addBulkShipperForm.form.value?.c.toUpperCase()
    };
  }

  saveForm() {
    let requestData: any = this.commonMethod();
    console.log(requestData);
    if (this.router.url.includes('/add')) {
      this.dialog
        .open(DialogComponent, {
          data: {
            title: 'This data will be saved.',
            message: 'Kindly Confirm.',
            yesno: true
          }
        })
        .afterClosed()
        .subscribe((result) => {
          if (result) {
            this.restService
              .post(this.webconfig.custServiceAPIURL + apiUrl.SAVE_BULK_SHIPPER_FORM, requestData)
              .subscribe(
                (res) => {
                  console.log(res);
                  if (res.error == false) {
                    this.responseMsg = 'Record(s) added successfully.';
                    this.primengMessageService.add({
                      key: 'bc',
                      severity: 'success',
                      detail: this.responseMsg,
                      life: 2000
                    });
                    this.addBulkShipperForm.form.reset();
                    setTimeout(() => {
                      this.router.navigate(['master/bulk-shipper/view/' + res.data.id]);
                    }, 3000);
                  } else {
                    console.log(res.error);
                  }
                },
                (err) => {
                  console.log(err);
                }
              );
          }
        });
    }
    if (this.router.url.includes('/edit')) {
      requestData.id = this.getDetailsById?.id;
      this.dialog
        .open(DialogComponent, {
          data: {
            title: 'This data will be saved.',
            message: 'Kindly Confirm.',
            yesno: true
          }
        })
        .afterClosed()
        .subscribe((result) => {
          if (result) {
            this.restService
              .put(this.webconfig.custServiceAPIURL + apiUrl.UPDATE_BULK_SHIPPER_FORM, requestData)
              .subscribe(
                (res) => {
                  console.log(res);
                  if (res.error == false) {
                    this.responseMsg = 'Record(s) updated successfully.';
                    this.primengMessageService.add({
                      key: 'bc',
                      severity: 'success',
                      detail: this.responseMsg,
                      life: 2000
                    });
                    setTimeout(() => {
                      this.router.navigate(['master/bulk-shipper']);
                      this.getAll();
                    }, 3000);
                  } else {
                    console.log(res.error);
                  }
                },
                (err) => {
                  console.log(err);
                }
              );
          }
        });
    }
  }

  btnCancelAdd() {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to cancel?',
          message: 'Unsaved data will be lost. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.router.navigate(['/master/bulk-shipper']);
        }
      });
  }

  resetForm() {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Are you sure you want to Reset the form?',
          message: 'Form will be empty. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.addBulkShipperForm.form.reset();
          this.errorMsg = this.lblErrMsgs.FORMRESET;
          this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 2000 });
        }
        this.addBulkShipperForm.form.patchValue({
          a: this.areaCode
        });
      });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: 'api',
      label: '',
      message: message,
      status: type,
      screenName: this.router.url
    };
    this.errorMsgService.setErrorMessage(errorObj);
  }

  submit(event) {}
}
