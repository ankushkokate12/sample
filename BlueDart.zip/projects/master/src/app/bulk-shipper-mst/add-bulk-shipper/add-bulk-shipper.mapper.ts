export const AddBulkShipperMapper = {
  area: 'a',
  customerCode: 'b',
  sender: 'c',
  areaName: 'ab',
  name: 'd',
  pincode: 'h',
  phone: 'i',
  address1: 'e',
  address2: 'f',
  address3: 'g'
};

export const AddBulkShipperLabels = {
  area: 'Area',
  areaName: 'Area Name',
  customerCode: 'Code',
  sender: 'Sender',
  name: 'Name',
  pincode: 'Pincode',
  address1: 'Flat, House no., Building, Company, Apartment',
  address2: 'Area, Colony, Street, Sector, Village',
  address3: 'Town/City',
  phone: 'Phone',
  cancel: 'Cancel',
  save: 'Save',
  locationCode: 'Location Code',
  locationDesc: 'Location Description'
};
