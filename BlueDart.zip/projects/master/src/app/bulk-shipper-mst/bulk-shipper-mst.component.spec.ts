import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkShipperMstComponent } from './bulk-shipper-mst.component';

describe('BulkShipperMstComponent', () => {
  let component: BulkShipperMstComponent;
  let fixture: ComponentFixture<BulkShipperMstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkShipperMstComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkShipperMstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
