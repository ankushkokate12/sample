import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig, IGridColumn } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { BaseComponent } from '../base/base.component';
import { bulkShipperHeaderConfig, bulkShipperSearchConfig, GRID_CONFIG } from './bulk-shipper-mst.config';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { apiUrl } from './bulk-shipper-mst.constant';
import { BulkShipperMapper } from './bulk-shipper.mapper';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-bulk-shipper-mst',
  templateUrl: './bulk-shipper-mst.component.html',
  styleUrls: ['./bulk-shipper-mst.component.scss']
})
export class BulkShipperMstComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild(DynamicFormComponent, { static: false })
  bulkShipperSummaryForm: DynamicFormComponent;
  regConfig: FieldConfig[];
  data: IGridColumn[];
  rows = [];
  tableHeight;
  currentUser: any;
  location: any;
  areaCode: any;
  errorMsg: any;
  lblErrMsgs: any;
  // deleteWarningMessage: string = this.labelConstant.DELETE_WARNING_NOTE;
  popupData: any;
  messageNote: string;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    protected restService: RestService,
    protected sharedService: SharedService,
    private webconfig: BdWebConfigService,
    protected alertService: AlertService,
    private dialog: MatDialog,
    private primengMessageService: AlertService
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = [...bulkShipperHeaderConfig, ...bulkShipperSearchConfig];
    this.data = GRID_CONFIG;
    this.delete();
  }

  ngOnInit(): void {
    // this.messageNote = this.labelConstant.MSG_NOTE;
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });
    let gridTblHt = window.innerHeight - 150 - 20 - 100;
    this.tableHeight = gridTblHt + 'px';
    this.primaryKey = 'id';
    this.screenText = this.labelConstant.SCREEN_TEXT_BULK_SHIPPER;

    // get Current Location
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.location = this.currentUser.location;
    this.areaCode = this.currentUser.area;
    this.setDeleteURL(this.webconfig.custServiceAPIURL + apiUrl.DELETE_BULK_SHIPPER_BY_ID);

    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == 'add') {
        this.router.navigate(['master/bulk-shipper/add']);
      } else if (field.eventRef == 'searchBulkShippers') {
        this.searchBulkShippers();
      } else if (field.eventRef == 'reset') {
        this.resetForm();
      }
    });

    this.sharedService.getPopupData().subscribe((res) => {
      this.popupData = res.data.a;
      this.bulkShipperSummaryForm.form.patchValue({
        a: this.popupData
      });
    });
  }

  ngAfterViewInit() {
    this.bulkShipperSummaryForm.form.patchValue({
      a: this.areaCode
    });
  }

  resetForm() {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Are you sure you want to Reset the form?',
          message: 'Form will be empty. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.bulkShipperSummaryForm.form.reset();
          this.errorMsg = this.lblErrMsgs.FORMRESET;
          this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 2000 });
        }
        this.bulkShipperSummaryForm.form.patchValue({
          a: this.areaCode
        });
      });
  }

  searchBulkShippers() {
    const data = {
      a: this.bulkShipperSummaryForm.form.value.a.toUpperCase(),
      b: this.bulkShipperSummaryForm.form.value.b
    };
    this.restService.post(this.webconfig.custServiceAPIURL + apiUrl.Get_All_Bulk_Shipper, data).subscribe(
      (res) => {
        console.log(res);

        if (res.error == false) {
          this.rows = res.data;
          this.regConfig[0].rows[1].label =
            (res.data?.length == undefined ? '0' : res.data?.length) + ' ' + this.labelConstant.BULK_SHIPPER_COUNT;
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getAll() {
    this.searchBulkShippers();
  }
}
