import { apiUrl } from './../../../../../projects/master/src/app/bulk-shipper-mst/bulk-shipper-mst.constant';
import { CommonValidators } from './../../../../../projects/vendors/src/lib/common.validator';
import * as baseUrl from '../../../../login/src/assets/webconfig.json';

const commonValidators = new CommonValidators();

export const bulkShipperHeaderConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: 'Bulk Shipper',
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: 'Add',
        buttonType: 'button',
        name: 'addBulkShipper',
        trigerOnClick: 'true',
        eventRef: 'add',
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'button',
        label: 'Reset',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'reset',
        // tabIndex: 5,
        separatorBefore: true,
        classes: {
          buttonType: 'action-button'
        }
      }
    ]
  }
];

export const bulkShipperSearchConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: 'Area',
        inputType: 'text',
        name: 'a',
        validations: commonValidators.PRODUCT,
        class: 'col s1 m5 l1 xl2',
        helpApiUrl: baseUrl.locationServiceAPIURL + '/' + apiUrl.GET_AREA_DETAILS,
        helpIcon: true,
        dialogTitle: 'Area',
        helpTableDataColumn: 'data',
        helpDialogWidth: 400,
        helpDialogGridColumns: [
          {
            field: 'a',
            header: 'Location Code',
            showFilter: true
          },
          {
            field: 'b',
            header: 'Location Description',
            showFilter: true
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'origin-area',
        helpId: 'help-area'
      },
      {
        type: 'input',
        label: 'Code',
        class: 'col w180 p-l-0',
        inputType: 'text',
        name: 'b',
        tabIndex: 3,
        maxlength: '6'
      },
      {
        type: 'button',
        label: 'Search',
        class: 'col w155 p-l-0',
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'rp-search-btn',
        eventRef: 'searchBulkShippers',
        tabIndex: 5,
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];

export const GRID_CONFIG = [
  {
    field: 'a',
    header: 'Code',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'c',
    header: 'Sender',
    showFilter: true,
    colWidth: '120px'
  },
  {
    field: 'd',
    header: 'Name',
    showFilter: true,
    colWidth: '120px'
  },
  {
    field: 'h',
    header: 'Pincode',
    showFilter: true,
    colWidth: '50px'
  },
  {
    field: 'e',
    header: 'Address',
    showFilter: true,
    colWidth: '200px'
  },
  {
    field: 'i',
    header: 'Phone',
    showFilter: true,
    colWidth: '80px'
  }
];
