export const apiUrl = {
  Get_All_Bulk_Shipper: '/bulk/shipper/search',
  DELETE_BULK_SHIPPER_BY_ID: '/bulk/shipper',
  GET_AREA_DETAILS: 'area/dtt/areadetails',
  Get_Customer_Detail_By_Customer_Code_And_Area: '/bulk/shipper/view/customer',
  SAVE_BULK_SHIPPER_FORM: '/bulk/shipper',
  UPDATE_BULK_SHIPPER_FORM: '/bulk/shipper',
  GET_BULK_SHIPPER_DETAILS_BY_ID: '/bulk/shipper'
};

// export const messageNote = {
//   MSG_NOTE: 'Select from the below list to have a detailed view or to take action',
//   DELETE_WARNING_NOTE: 'Record will be Permanently Deleted. Click yes to proceed.',
//   SCREEN_TEXT_BULK_SHIPPER: 'Bulk Shipper',
//   BULK_SHIPPER_COUNT: 'Bulk Shipper(s) available.'
// };
