import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BulkShipperMstComponent } from './bulk-shipper-mst.component';
import { BulkShipperRoutingModule } from './bulk-shipper-routing.module';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToolsModule } from '../../../../../projects/tools/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddBulkShipperComponent } from './add-bulk-shipper/add-bulk-shipper.component';
import { ViewBulkShipperComponent } from './view-bulk-shipper/view-bulk-shipper.component';

@NgModule({
  declarations: [BulkShipperMstComponent, AddBulkShipperComponent, ViewBulkShipperComponent],
  providers: [MessageService, ConfirmationService],
  imports: [
    CommonModule,
    BulkShipperRoutingModule,
    ConfirmDialogModule,
    ToastModule,
    ToolsModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class BulkShipperMstModule { }
