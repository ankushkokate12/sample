import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BulkShipperMstComponent } from './bulk-shipper-mst.component';
import { AddBulkShipperComponent } from './add-bulk-shipper/add-bulk-shipper.component';
import { ViewBulkShipperComponent } from './view-bulk-shipper/view-bulk-shipper.component';

const routes: Routes = [
  { path: '', component: BulkShipperMstComponent },
  { path: 'add', component: AddBulkShipperComponent },
  { path: 'edit/:id', component: AddBulkShipperComponent },
  { path: 'view/:id', component: ViewBulkShipperComponent }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, [RouterModule.forChild(routes)]],
  exports: [RouterModule]
})
export class BulkShipperRoutingModule {}
