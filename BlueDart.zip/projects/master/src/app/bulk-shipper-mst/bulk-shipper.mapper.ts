export const BulkShipperMapper = {
  area: 'a',
  customerCode: 'b',
  sender: 'c',
  customerName: 'd',
  customerAddress1: 'e',
  customerAddress2: 'f',
  customerAddress3: 'g',
  customerPinCode: 'h',
  customerPhone: 'i',
  id: 'id'
};
