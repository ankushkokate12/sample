import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBulkShipperComponent } from './view-bulk-shipper.component';

describe('ViewBulkShipperComponent', () => {
  let component: ViewBulkShipperComponent;
  let fixture: ComponentFixture<ViewBulkShipperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBulkShipperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBulkShipperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
