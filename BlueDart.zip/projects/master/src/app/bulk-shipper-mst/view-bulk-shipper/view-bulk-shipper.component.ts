import { Component, OnInit, ViewChild } from '@angular/core';
import { viewBulkShipperHeader, viewBulkShipperConfig } from './view-bulk-shipper.config';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { BaseComponent } from './../../base/base.component';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { apiUrl } from './../bulk-shipper-mst.constant';
import { Router, ActivatedRoute } from '@angular/router';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { Properties } from 'projects/vendors/src/lib/bd.propertybundle';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';

@Component({
  selector: 'app-view-bulk-shipper',
  templateUrl: './view-bulk-shipper.component.html',
  styleUrls: ['./view-bulk-shipper.component.scss']
})
export class ViewBulkShipperComponent extends BaseComponent implements OnInit {
  @ViewChild(DynamicFormComponent, { static: false })
  viewBulkShipperForm: DynamicFormComponent;
  viewBulkShipper: FieldConfig[];
  bulkShipperId: any;
  getShipperDetails: any;
  errorMsg: any;

  constructor(
    private messageService: MessageService,
    protected sharedService: SharedService,
    protected alertService: AlertService,
    protected restService: RestService,
    private webconfig: BdWebConfigService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private errorMsgService: SharedService,
    private eventEmitt: EventEmitterService,
    private dialog: MatDialog
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.bulkShipperId = activatedRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    this.viewBulkShipper = viewBulkShipperConfig;
    this.messageService.sendHeaderShowMessage(true);
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == Properties.BTN_BACK) {
        this.btnCancelAdd();
      } else if (field.eventRef == 'gotoEdit') {
        this.router.navigate(['master/bulk-shipper/edit/' + this.bulkShipperId]);
      }
    });
    this.manageConfiguration();
    this.getBulkShipperDetails();
  }

  manageConfiguration() {
    this.viewBulkShipper = [...viewBulkShipperHeader, ...viewBulkShipperConfig];
  }

  getBulkShipperDetails() {
    this.restService
      .get(this.webconfig.custServiceAPIURL + apiUrl.GET_BULK_SHIPPER_DETAILS_BY_ID + '/' + this.bulkShipperId)
      .subscribe(
        (res) => {
          console.log(res);
          if (res.error == false) {
            this.getShipperDetails = res.data;
            this.viewBulkShipperForm.form.patchValue({
              a: this.getShipperDetails.a,
              b: this.getShipperDetails.b,
              c: this.getShipperDetails.c,
              d: this.getShipperDetails.d,
              e: this.getShipperDetails.e,
              f: this.getShipperDetails.f,
              g: this.getShipperDetails.g,
              h: this.getShipperDetails.h,
              i: this.getShipperDetails.i
            });
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: 'api',
      label: '',
      message: message,
      status: type,
      screenName: this.router.url
    };
    this.errorMsgService.setErrorMessage(errorObj);
  }

  btnCancelAdd() {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to cancel?',
          message: 'Unsaved data will be lost. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.router.navigate(['/master/bulk-shipper']);
        }
      });
  }

  submit(event) {}
}
