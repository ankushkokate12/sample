import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { apiUrl } from './../bulk-shipper-mst.constant';
import * as baseUrl from 'projects/login/src/assets/webconfig.json';
import { AddBulkShipperMapper, AddBulkShipperLabels } from './../add-bulk-shipper/add-bulk-shipper.mapper';

const commonValidators = new CommonValidators();

export const viewBulkShipperHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'backToBulkShipperSummary',
        trigerOnClick: 'true',
        buttonType: 'button',
        eventRef: 'btnBACK',
        classes: {
          buttonType: 'action-button'
        },
        class: 'col s2 l1 m1'
      },
      {
        type: 'label',
        label: 'View Bulk Shipper',
        classes: {
          labelHead: true
        },
        class: 'col s10 l9 m7'
      },
      {
        type: 'button',
        label: 'Edit',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'gotoEdit',
        classes: {
          buttonType: 'action-button',
          rightAlign: false
        },
        class: 'col s9 m2 l1 right-align'
      },
      {
        type: 'button',
        label: 'Delete',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'resetFormDetails',
        classes: {
          buttonType: 'action-button',
          rightAlign: false
        },
        class: 'col s9 m2 l1 right-align'
      }
    ]
  }
];

export const viewBulkShipperConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Bulk Shipper Details',
        class: 'col s12 l12 m12 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: AddBulkShipperLabels.area,
                inputType: 'text',
                name: AddBulkShipperMapper.area,
                validations: commonValidators.PRODUCT,
                class: 'col s1 m5 l1 xl2',
                helpApiUrl: baseUrl.locationServiceAPIURL + '/' + apiUrl.GET_AREA_DETAILS,
                helpIcon: true,
                maxlength: 3,
                tabIndex: 1,
                dialogTitle: 'Area',
                helpTableDataColumn: 'data',
                helpDialogWidth: 500,
                disabled: true,
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: AddBulkShipperLabels.locationCode,
                    showFilter: true
                  },
                  {
                    field: 'b',
                    header: AddBulkShipperLabels.locationDesc,
                    showFilter: true
                  }
                ],
                gridOptions: {
                  isColumnFilter: true,
                  isClickable: true
                },
                id: 'area',
                helpId: 'help-area'
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.areaName,
                inputType: 'text',
                disabled: true,
                tabIndex: 2,
                name: AddBulkShipperMapper.areaName,
                class: 'col s2 m7 l2 xl3'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: AddBulkShipperLabels.customerCode,
                inputType: 'text',
                eventRef: 'customerCode',
                maxlength: 6,
                tabIndex: 3,
                disabled: true,
                name: AddBulkShipperMapper.customerCode,
                validations: commonValidators.PRODUCT,
                class: 'col s1 m5 l1 xl2'
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.sender,
                inputType: 'text',
                disabled: true,
                eventRef: 'sender',
                maxlength: 20,
                name: AddBulkShipperMapper.sender,
                class: 'col s3 m7 l3 xl3'
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.name,
                inputType: 'text',
                disabled: true,
                name: AddBulkShipperMapper.name,
                class: 'col s3 m7 l2 xl3'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: AddBulkShipperLabels.pincode,
                inputType: 'text',
                name: AddBulkShipperMapper.pincode,
                class: 'col s1 m5 l1 xl2',
                disabled: true
                // tabIndex: 1
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.address1,
                inputType: 'text',
                disabled: true,
                name: AddBulkShipperMapper.address1,
                class: 'col s2 m5 l5 xl3'
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.address2,
                inputType: 'text',
                disabled: true,
                name: AddBulkShipperMapper.address2,
                class: 'col s2 m7 l4 xl3'
              },
              {
                type: 'input',
                label: AddBulkShipperLabels.address3,
                inputType: 'text',
                disabled: true,
                name: AddBulkShipperMapper.address3,
                class: 'col s2 m7 l2 xl3'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: AddBulkShipperLabels.phone,
                inputType: 'text',
                disabled: true,
                name: AddBulkShipperMapper.phone,
                class: 'col s1 m5 l2 xl2'
              }
            ]
          }
        ]
      }
    ]
  }
];
