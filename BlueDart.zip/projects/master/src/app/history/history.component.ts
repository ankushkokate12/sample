import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  Renderer2,
  SimpleChanges
} from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { IHistory } from './history.interface';
import { GRID_CONFIG } from './history.config';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit, OnChanges {
  @Input() rows: IHistory[];
  @Output() handleClosePopup: EventEmitter<void> = new EventEmitter<void>();
  @Input() isDockable: boolean = false;
  showHistory: boolean = false;
  cols: any[] = [];
  tblHt: string = '300px';
  historyPinned: boolean = false;

  constructor(
    private messageService: MessageService,
    private renderer: Renderer2,
    private elem: ElementRef,
    private sharedService: SharedService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.cols = GRID_CONFIG;
  }

  ngOnInit(): void {}

  ngOnChanges(simpleObj: any) {
    console.log(simpleObj.rows);
    this.rows = simpleObj.rows.currentValue;
    console.log(this.rows);
  }

  closePopup() {
    this.handleClosePopup.emit();
    let elements = this.elem.nativeElement.parentElement.parentElement;
    let historyPopup = this.elem.nativeElement.querySelectorAll('.history-popup')[0];
    this.renderer.removeClass(elements, 'main-grid');
    this.renderer.addClass(historyPopup, 'stick-history-popup');
    this.sharedService.setShowHistoryPopup(false);
  }

  handleStickHistory() {
    let elements = this.elem.nativeElement.parentElement.parentElement;
    let historyPopup = this.elem.nativeElement.querySelectorAll('.history-popup')[0];

    if (!this.historyPinned) {
      this.renderer.addClass(elements, 'main-grid');
      this.renderer.removeClass(historyPopup, 'stick-history-popup');
    } else {
      this.renderer.removeClass(elements, 'main-grid');
      this.renderer.addClass(historyPopup, 'stick-history-popup');
    }
    this.historyPinned = !this.historyPinned;
  }
}
