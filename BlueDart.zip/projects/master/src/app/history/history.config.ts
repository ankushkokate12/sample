export const HistoryMapper = {
  columnName: 'b',
  oldValue: 'c',
  newValue: 'd',
  typeOfChange: 'e',
  location: 'f',
  modifyDate: 'h',
  modifyBy: 'g',
  id: 'a'
};

export const GRID_CONFIG = [
  {
    field: HistoryMapper.columnName,
    header: 'Column Name'
  },
  {
    field: HistoryMapper.oldValue,
    header: 'Old Value'
  },
  {
    field: HistoryMapper.newValue,
    header: 'New Value'
  },
  {
    field: HistoryMapper.typeOfChange,
    header: 'Status'
  },
  {
    field: HistoryMapper.modifyDate,
    header: 'Modified Date & Time'
  },
  {
    field: HistoryMapper.modifyBy,
    header: 'Modified By'
  },
  {
    field: HistoryMapper.location,
    header: 'Location'
  }
];
