export interface IHistory {
  columnName: string;
  oldValue: string;
  newValue: string;
  status: string;
  modifiedDate: string;
  modifiedBy: string;
  location: string;
}
