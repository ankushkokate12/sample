import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsModule } from '../../../../tools/src/public-api';
import { HistoryComponent } from './history.component';

@NgModule({
  declarations: [HistoryComponent],
  imports: [CommonModule, ToolsModule],
  exports: [HistoryComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HistoryModule {}
