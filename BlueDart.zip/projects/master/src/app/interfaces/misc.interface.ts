export interface IProdSubProd {
  a: number;
  b: string;
  c: string;
}

export interface IAddProdForkJoin {
  productConfig?: any;
  products?: any;
  subproducts?: any;
}
