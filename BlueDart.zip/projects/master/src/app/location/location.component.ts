import { Component, OnInit } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {
  constructor(private messageService: MessageService) {
    this.messageService.sendHeaderShowMessage(true);
  }

  ngOnInit(): void {}
}
