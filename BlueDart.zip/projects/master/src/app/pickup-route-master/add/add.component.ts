import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { addConfig, addConfigHeader } from './add.config';
import { FieldConfig } from './../../../../../../projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from './../../../../../../projects/tools/src/lib/message.service';
import { EventEmitterService } from './../../../../../../projects/tools/src/lib/event-emitter.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RestService } from './../../../../../../projects/tools/src/lib/rest.service';
import { DynamicFormComponent } from './../../../../../../projects/tools/src/public-api';
import { Properties } from './../../../../../../projects/vendors/src/lib/bd.propertybundle';
import { ILandmark } from '../landmark.interface';
import { BdWebConfigService } from './../../../../../../projects/services/src/lib/bd-web-config.service';
import { apiUrl } from '../pickup-route-master.constant';
import { ConfirmationService, MessageService as AlertService } from 'primeng/api';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from './../../../../../../projects/tools/src/lib/components/controls/dialog/dialog.component';
import { FileUploadService } from './../../../../../tools/src/lib/file-upload.service';
import { SharedService } from './../../../../../../projects/tools/src/lib/shared.service';
import { HttpClient } from '@angular/common/http';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { OnDestroy } from '@angular/core';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(DynamicFormComponent, { static: false })
  addPickupRouteForm: DynamicFormComponent;
  addPickupRouteConfig: FieldConfig[];
  addPickupRouteHeaderConfig: FieldConfig[];
  @ViewChildren('inputs') inputs: QueryList<any>;

  landMarks: ILandmark[] = [];
  errorMsg: any;
  lblErrMsgs: any;

  showbackArrow: boolean = false;
  backArrowObj: any;
  titleObj: any;
  subTitleObj: any;
  buttonArray: any[] = [];
  empDetailID: any;
  empUpdateDetails: any;
  empName: any;
  imgFile: any;
  dataForPayload: any;
  deleteImage: any;
  areaCode: any;
  location: any;
  currentUser: any;
  imgFileInsertReplace: any;
  imageChanged: boolean = false;
  landmarkDeleted: boolean = false;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private restService: RestService,
    private webconfig: BdWebConfigService,
    private primengMessageService: AlertService,
    private confirmationService: ConfirmationService,
    private element: ElementRef,
    private dialog: MatDialog,
    private fileUploadService: FileUploadService,
    private errorMsgService: SharedService,
    private http: HttpClient
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.addPickupRouteConfig = addConfig;
    this.addPickupRouteHeaderConfig = addConfigHeader;
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });
    this.empDetailID = activatedRoute.snapshot.params.id;
  }
  ngOnInit(): void {
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.location = this.currentUser.location;
    this.areaCode = this.currentUser.area;
    if (!this.empDetailID) {
      this.addLandmark();
    }
    if (this.empDetailID) {
      this.getEmpDetailsByID();
    }
    this.handleHeaderRow();
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == Properties.BTN_BACK || field.eventRef == Properties.BTN_CANCEL) {
        this.btnCancelAdd();
      } else if (field.eventRef == 'addSubmit') {
        this.submitForm();
      } else if (field.eventRef == 'employeeCode') {
        this.getEmpName();
      } else if (field.eventRef == 'routeCode') {
        if (this.router.url.includes('/add')) {
          this.validateRouteCode();
        }
      } else if (field.eventRef == 'serviceCentre') {
        this.validateServiceCentrePermission();
      }
    });
    this.fileUploadService.getImgFile().subscribe((res) => {
      console.log(res);
      this.imgFileInsertReplace = res;
      this.imageChanged = true;
      this.deleteImage = false;
    });

    this.fileUploadService.getDeleteFlag().subscribe((res) => {
      this.deleteImage = res;
    });
  }

  ngAfterViewInit() {
    if (this.router.url.includes('/add')) {
      this.element.nativeElement.querySelectorAll('Input')[1].focus();
      this.addPickupRouteForm.form.patchValue({
        c: this.areaCode,
        d: this.location
      });
    }
    if (this.router.url.includes('/edit/')) {
      this.element.nativeElement.querySelectorAll('Input')[1].disabled = true;
      this.element.nativeElement.querySelectorAll('Input')[2].disabled = true;
      this.element.nativeElement.querySelectorAll('Input')[3].focus();
    }
  }

  handleHeaderRow(): void {
    this.buttonArray = [];
    this.addPickupRouteHeaderConfig[0].rows.forEach((ele) => {
      if (ele.type == 'iconbutton') {
        this.showbackArrow = true;
        this.backArrowObj = ele;
      } else if (ele.type == 'label' && ele.classes.greenHead) {
        this.subTitleObj = ele;
      } else if (ele.type == 'label') {
        this.titleObj = ele;
      } else if (ele.type == 'button') {
        this.buttonArray.push(ele);
      }
    });
  }

  btnCancelAdd() {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to cancel?',
          message: 'Unsaved data will be lost. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.router.navigate(['/master/pickup-route']);
        }
      });
  }

  // get image by ID
  getImageById() {
    if (this.empUpdateDetails.i == 'Y') {
      this.restService
        .get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_IMAGE_BY_ID + '=' + this.empDetailID)
        .subscribe(
          (res) => {
            this.imgFile = res.data;
            console.log(this.imgFile);

            this.fileUploadService.setViewId(this.imgFile);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  getEmpDetailsByID() {
    // get pickup route data
    this.restService
      .get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_EMP_DETAILS_BY_ID + '/' + this.empDetailID)
      .subscribe(
        (res) => {
          this.empUpdateDetails = res.data;
          let landMark = [];
          this.empUpdateDetails.g.forEach((ele) => {
            let obj = {
              a: ele.a,
              b: ele.b,
              c: ele.c,
              d: 'U'
            };
            landMark.push(obj);
          });
          this.landMarks = landMark;
          if (this.empDetailID && this.empUpdateDetails.g.length == 0) {
            this.addLandmark();
          }
          let empUpdateDetails = {
            a: this.empUpdateDetails.a,
            b: this.empUpdateDetails.b,
            c: this.empUpdateDetails.c,
            d: this.empUpdateDetails.d,
            e: this.empUpdateDetails.e,
            f: this.empUpdateDetails.f,
            g: landMark,
            ri: this.empUpdateDetails.ri,
            ot: this.imgFile ? null : 'I'
          };
          this.addPickupRouteForm.form.patchValue(empUpdateDetails);
          this.addPickupRouteForm.form.patchValue(empUpdateDetails.f);
          this.addPickupRouteForm.form.patchValue({
            h: this.empUpdateDetails.h
          });
          this.getImageById();
        },
        (err) => {
          console.log(err);
        }
      );
  }

  addLandmark() {
    this.landMarks.push({
      a: null,
      b: null,
      c: null,
      d: 'I'
    });
    if (this.addPickupRouteForm != undefined && this.addPickupRouteForm.form.get('a').value != null) {
      let index = this.landMarks.length - 1;
      setTimeout(() => {
        this.inputs.toArray()[index].nativeElement.focus();
      }, 10);
    }
  }

  deleteLandmark(rowIndex) {
    if (this.landMarks[rowIndex].b != null) {
      this.landMarks[rowIndex].d = 'D';
      this.landmarkDeleted = true;
    } else {
      this.landMarks.splice(rowIndex, 1);
    }
    this.element.nativeElement.querySelectorAll('a')[2].focus();
  }

  getEmpName() {
    this.restService
      .get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_EMP_NAME + '/' + this.addPickupRouteForm.form.value.e)
      .subscribe(
        (res) => {
          // let errorObj = {};
          if (res.error) {
            this.errorMsg = res.message;
            this.setErrorPanel('e', this.errorMsg, 'INVALID');
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.addPickupRouteForm.form.controls['e'].setErrors({ invalid: true });
          } else {
            this.setErrorPanel('e', '', 'VALID');
          }
          this.addPickupRouteForm.form.patchValue({
            h: res.length == 0 ? '' : res.data?.a
          });
          this.empName = res.data?.a;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  validateServiceCentrePermission() {
    /*
     * Check For User Permission
     */
    let data = {
      a: 'PickupRouteMaster',
      b: 'SVC',
      c: this.addPickupRouteForm.form.value.d.toUpperCase()
    };
    this.restService
      .post(
        this.webconfig.apiURLPickupRouteMasterServiceCentrePremission + apiUrl.VALIDATE_SERVICE_CENTRE_PERMISSION,
        data
      )
      .subscribe(
        (res) => {
          /*
           * If User is Valid and Permitted
           */
          if (res.statusCode == 9000) {
            this.setErrorPanel('d', '', 'VALID');
            this.restService
              .get(this.webconfig.apiURLPickupRouteMasterGetAreaCode + apiUrl.GET_AREA_CODE + data.c)
              .subscribe(
                (res) => {
                  this.areaCode = res.data;
                  this.addPickupRouteForm.form.patchValue({
                    c: res.error == false ? res.data : ''
                  });
                },
                (err) => {
                  console.log(err);
                }
              );
          } else if (res.statusCode == 403) {
            this.setErrorPanel('d', 'You are not authorized for this service centre', 'INVALID');
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.addPickupRouteForm.form.controls['d'].setErrors({ invalid: true });
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  validateRouteCode() {
    this.restService
      .get(
        this.webconfig.apiURLPickupRouteMaster +
        apiUrl.VALIDATE_ROUTE_CODE +
        '/' +
        this.addPickupRouteForm.form.value.d.toUpperCase() +
        '/' +
        this.addPickupRouteForm.form.value.a
      )
      .subscribe(
        (res) => {
          if (res.error == true) {
            this.errorMsg = res.message;
            this.setErrorPanel('a', this.errorMsg, 'INVALID');
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.addPickupRouteForm.form.controls['a'].setErrors({ invalid: true });
          } else {
            this.setErrorPanel('a', '', 'VALID');
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  formDirtyCheck(): Boolean {
    if (
      this.addPickupRouteForm.form.get('a').value == this.empUpdateDetails.a &&
      this.addPickupRouteForm.form.get('b').value == this.empUpdateDetails.b &&
      this.addPickupRouteForm.form.get('c').value == this.empUpdateDetails.c &&
      this.addPickupRouteForm.form.get('d').value == this.empUpdateDetails.d &&
      this.addPickupRouteForm.form.get('e').value == this.empUpdateDetails.e &&
      this.addPickupRouteForm.form.get('f').value == this.empUpdateDetails.f &&
      !(this.imageChanged || this.deleteImage) &&
      !this.landmarkDeleted &&
      this.checkLandmarkDirty() // && (this.checkLandmarkDirty() || !this.landmarkDeleted)
    ) {
      return false;
    } else {
      // dirty
      return true;
    }
  }

  compareObjects(o1: any, o2: any): boolean {
    return JSON.stringify(o1) == JSON.stringify(o2);
  }

  checkLandmarkDirty() {
    if (this.empUpdateDetails.g.length == this.landMarks.length) {
      // same length
      // needs to check by object
      let tempArr = [];
      let landmarkEdited = this.landMarks.map((ele) => {
        return {
          a: ele.a,
          b: ele.b,
          c: ele.c
        };
      });

      let landmarkOriginal = this.empUpdateDetails.g.map((ele) => {
        return {
          a: ele.a,
          b: ele.b,
          c: ele.c
        };
      });

      for (let i = 0; i < this.empUpdateDetails.g.length; i++) {
        tempArr.push(this.compareObjects(landmarkEdited[i], landmarkOriginal[i]));
      }
      if (tempArr.indexOf(false) != -1) {
        // no editied landmark
        return false;
      } else {
        // having edited landmark
        return true;
      }
    } else {
      // dirty
      return false;
    }
  }

  commonMethod() {
    let landMark = this.landMarks
      .map((ele) => {
        return {
          a: ele.a == '' ? null : ele.a,
          b: ele.b,
          c: ele.c == '' ? null : ele.c,
          d: ele.d
        };
      })
      .filter((e: any) => {
        if (e.a == null && e.c == null && e.d == 'I') {
          return false;
        } else {
          return e;
        }
      });
    if (landMark.length == 0) {
      landMark = [];
    }
    return {
      a: this.addPickupRouteForm.form.value.a,
      b: this.addPickupRouteForm.form.value.b,
      c: this.router.url.includes('/add') ? this.areaCode : this.empUpdateDetails.c,
      d: this.addPickupRouteForm.form.value.d.toUpperCase(),
      e: this.addPickupRouteForm.form.value.e,
      // f: this.empName,
      f: parseFloat(this.addPickupRouteForm.form.value.f),
      g: landMark,
      ot: this.imgFileInsertReplace ? 'I' : null
    };
  }

  submitForm() {
    let requestData: any = this.commonMethod();
    if (this.empUpdateDetails) {
      requestData.ri = this.empUpdateDetails.ri;
    }
    if (this.router.url.includes('/edit')) {
      if (this.deleteImage == true) {
        requestData.ot = 'D';
      } else if (this.imageChanged == true) {
        requestData.ot = 'I';
      }
    } else if (this.router.url.includes('/add')) {
      if (this.deleteImage == true) {
        requestData.ot = null;
      } else if (this.imageChanged == true) {
        requestData.ot = 'I';
      }
    }

    const data: FormData = new FormData();
    if (this.imgFile || this.imgFileInsertReplace) {
      data.append('a', this.imgFileInsertReplace == null ? this.imgFile : this.imgFileInsertReplace);
      data.append('b', JSON.stringify(requestData));
    } else if (this.imgFile == undefined || this.imgFileInsertReplace == undefined || this.deleteImage == true) {
      data.append('b', JSON.stringify(requestData));
    }

    const httpOptions = {
      headers: new Headers({
        'Content-Type': 'multipart/form-data'
      })
    };

    /*
     * Save Add Pickup route
     **/
    if (this.router.url.includes('/add')) {
      console.log(this.empDetailID);
      this.restService
        .post(this.webconfig.apiURLPickupRouteMaster + apiUrl.ADD_PICKUP_ROUTE, data, httpOptions)
        .subscribe(
          (res) => {
            console.log(res);
            if (res.error == false) {
              this.errorMsg = this.lblErrMsgs.PICKUP_ROUTE_ADD;
              this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 2000 });
              this.addPickupRouteForm.form.reset();
              setTimeout(() => {
                this.router.navigate(['master/pickup-route/view/' + res.data.ri]);
              }, 3000);
            } else {
              console.log(res.error);
            }
          },
          (err) => {
            console.log(err);
            this.primengMessageService.add({
              key: 'bc',
              severity: 'error',
              detail: err.error.message,
              life: 3000
            });
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          }
        );
    }

    /**
     * Update Pickup Route
     */
    if (this.router.url.includes('/edit/')) {
      if (this.formDirtyCheck()) {
        this.restService
          .put(this.webconfig.apiURLPickupRouteMaster + apiUrl.UPDATE_PICKUP_ROUTE, data, httpOptions)
          .subscribe(
            (res) => {
              console.log('in update');
              console.log(res);
              if (res.error == false) {
                console.log(res.message);
                this.errorMsg = this.lblErrMsgs.PICKUP_ROUTE_UPDATE;
                this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg });
                setTimeout(() => {
                  this.router.navigate(['master/pickup-route/view/' + this.empUpdateDetails.ri]);
                }, 2000);
              } else {
                console.log(res.error);
              }
            },
            (err) => {
              console.log(err);
              this.primengMessageService.add({
                key: 'bc',
                severity: 'error',
                detail: err.error.message,
                life: 2000
              });
              BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            }
          );
      } else {
        this.errorMsg = 'No Pickup Route Updated';
        this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg });
      }
    }
  }

  submit(event) {
    console.log(event);
  }

  resetForm() {
    console.log('rest');
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Are you sure you want to Reset the form?',
          message: 'Form will be empty. Click YES to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.addPickupRouteForm.form.reset();
          this.errorMsg = this.lblErrMsgs.FORMRESET;
          this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 2000 });
          let requestData = {
            c: this.areaCode,
            d: this.location,
            g: (this.landMarks = [])
          };
          this.addLandmark();
          // (<HTMLElement>document.querySelectorAll('.actionImgLink')[1]).click();
          this.fileUploadService.setResetImageFlag(true);
          requestData = {
            c: this.areaCode,
            d: this.location,
            g: (this.landMarks = [])
          };
          this.addPickupRouteForm.form.patchValue(requestData);
          this.addLandmark();
          this.element.nativeElement.querySelectorAll('Input')[1].focus();
        }
      });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: 'api',
      label: '',
      message: message,
      status: type,
      screenName: this.router.url
    };
    this.errorMsgService.setErrorMessage(errorObj);
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
    // this.fileUploadService.fileData.unsubscribe();
    // this.fileUploadService.deleteFlag.unsubscribe();
  }
}
