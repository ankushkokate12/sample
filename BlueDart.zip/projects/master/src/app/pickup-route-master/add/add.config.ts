import { CommonValidators } from '../../../../../vendors/src/lib/common.validator';
const commonValidators = new CommonValidators();

export const addConfigHeader = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: 'arrow_back_ios',
        name: 'btnBACK',
        trigerOnClick: 'true',
        eventRef: 'btnBACK',
        tabIndex: 13,
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'label',
        label: 'Add Pickup Route',
        classes: {
          labelHead: true
        }
      },
      {
        type: 'button',
        label: 'Reset',
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 14,
        eventRef: 'resetDetails',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {
        type: 'button',
        label: 'Cancel',
        name: 'btnCancel',
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 15,
        eventRef: 'btnCancel',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  }
];

export const addConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Route Details',
        class: 'col s12 m12 l12 xl12',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Area',
                inputType: 'text',
                name: 'c',
                // value: 'BOM',
                disabled: true,
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col s6 m3 l2 xl1',
                RegExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              },
              {
                type: 'input',
                label: 'Service Centre',
                inputType: 'text',
                name: 'd',
                // value: 'ADR',
                isAutoCaps: true,
                eventRef: 'serviceCentre',
                disabled: false,
                tabIndex: '1',
                // isAutoCaps: true,
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                class: 'col s6 m6 l4 xl2',
                RegExp: commonValidators.regexExpressions.ONLY_ALPHANUMERIC
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Route Code',
                inputType: 'text',
                name: 'a',
                eventRef: 'routeCode',
                maxlength: 2,
                minlength: 2,
                tabIndex: '2',
                validations: commonValidators.ROUTE_CODE_VALIDATOR,
                class: 'col s6 m4 l3 xl2'
              },
              {
                type: 'input',
                label: 'Route Name',
                inputType: 'text',
                name: 'b',
                tabIndex: 3,
                maxlength: 35,
                validations: commonValidators.ROUTE_NAME_VALIDATOR,
                class: 'col s6 m4 l4 xl3'
              },
              {
                type: 'input',
                label: 'Average Distance',
                inputType: 'text',
                maxlength: 9,
                tabIndex: 4,
                name: 'f',
                validations: commonValidators.AVG_DISTANCE_VALIDATOR,
                class: 'col s6 m4 l4 xl2',
                RegExp: commonValidators.regexExpressions.AVG_DIST,
                postInputText: 'Kms'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Employee Code',
                inputType: 'text',
                name: 'e',
                eventRef: 'employeeCode',
                maxlength: 6,
                minlength: 5,
                tabIndex: 5,
                validations: commonValidators.EMP_CODE_VALIDATOR,
                class: 'col s6 m3 l3 xl2',
                RegExp: commonValidators.regexExpressions.ONLY_NUMBER
              },
              {
                type: 'input',
                label: 'Employee Name',
                inputType: 'text',
                disabled: true,
                name: 'h',
                tabIndex: 6,
                // value: "SANDEEP DHONDU MONDE",
                class: 'col s6 m6 l6 xl4'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'fileupload',
                label: 'Route Map',
                inputType: 'text',
                eventRef: 'imgupload',
                name: 'ot',
                tabIndex: 7,
                class: 'col s12 m6 l6 xl4'
              }
            ]
          }
        ]
      }
    ]
  },

  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: 'Save',
        buttonType: 'Submit',
        trigerOnClick: 'true',
        eventRef: 'addSubmit',
        tabIndex: 12,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        },
        class: 'col s12 m12 l12 xl12 pickUpSaveBtn'
      }
    ]
  }
];
