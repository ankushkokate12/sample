export interface ILandmark {
  a: string;
  b: string;
  c: string;
  d: string;
}
