import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PickupRouteMasterComponent } from './pickup-route-master.component';
import { AddComponent } from './add/add.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  { path: '', component: PickupRouteMasterComponent },
  { path: 'add', component: AddComponent },
  { path: 'edit/:id', component: AddComponent },
  { path: 'view/:id', component: ViewComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PickupRouteMasterRoutingModule {}
