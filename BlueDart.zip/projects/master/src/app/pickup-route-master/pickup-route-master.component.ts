import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { IGridColumn } from '../../../../tools/src/lib/interfaces/grid-columns.interface';
import { MessageService } from '../../../../tools/src/lib/message.service';
import { FieldConfig } from '../../../../tools/src/lib/interfaces/field.interface';
import { EventEmitterService } from '../../../../tools/src/lib/event-emitter.service';
import { GRID_CONFIG, pickupRouteMasterConfig } from './pickup-route-master.config';
import { Router } from '@angular/router';
import { DynamicFormComponent } from '../../../../tools/src/public-api';
import { RestService } from '../../../../tools/src/lib/rest.service';
import { apiUrl } from './pickup-route-master.constant';
import { SharedService } from '../../../../tools/src/lib/shared.service';
import { IHistory } from '../history/history.interface';
import { map, switchMap, tap } from 'rxjs/operators';
import { DialogComponent } from '../../../../tools/src/lib/components/controls/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { BdWebConfigService } from './../../../../../projects/services/src/lib/bd-web-config.service';
import { MessageService as AlertService } from 'primeng/api';
import { BaseComponent } from '../base/base.component';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-pickup-route-master',
  templateUrl: './pickup-route-master.component.html',
  styleUrls: ['./pickup-route-master.component.scss']
})
export class PickupRouteMasterComponent extends BaseComponent implements OnDestroy {
  regConfig: FieldConfig[];
  data: IGridColumn[];
  rows = [];
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  rowHistory: IHistory[];
  showHistory: boolean = false;
  apiURL: string;
  tableHeight: string;
  allSubscriptions: Subscription = new Subscription();
  deleteWarningMessage: string = 'Record will be Permanently Deleted. Click yes to proceed.';

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    protected restService: RestService,
    protected sharedService: SharedService,
    private dialog: MatDialog,
    private webconfig: BdWebConfigService,
    protected alertService: AlertService
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = pickupRouteMasterConfig;
    this.data = GRID_CONFIG;
    this.showRowHistory();
    this.showHistoryPopup();
  }

  ngOnInit(): void {
    this.getAllPickupRoute();
    this.deletePickupRoute();
    this.historyAPIURL = this.webconfig.masterServiceAPIURL + apiUrl.GET_HISTORY;
    this.primaryKey = 'a';
    this.screenText = 'Pickup Route';
    this.resourceNameForHistory = "PickupRouteMaster";

    this.showRowHistory();
    this.showHistoryPopup();
    let gridTblHt = window.innerHeight - 150 - 20 - 100;
    this.tableHeight = gridTblHt + 'px';
    // if (this.eventEmitt.subsVar == undefined) {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == 'addPickupRoute') {
        this.addPickupRoute();
      }
    });
    // }
  }

  addPickupRoute() {
    this.router.navigate(['master/pickup-route/add']);
  }

  getAllPickupRoute() {
    this.allSubscriptions.add(
      this.restService.get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_ALL).subscribe((res) => {
        if (!res.error) {
          this.rows = res.data;
          console.log(this.regConfig);
          this.regConfig[0].rows[1].label = res.data.length + ' Pickup Route(s) available.';
        } else {
          console.log(res.statusCode);
        }
      })
    );
  }

  deletePickupRoute() {
    this.allSubscriptions.add(
      this.sharedService
        .getGridRowForDelete()
        .pipe(tap((res) => console.log(res)))
        .pipe(
          switchMap((res1) =>
            this.restService.delete(
              this.webconfig.apiURLPickupRouteMaster + apiUrl.DELETE_PICKUP_ROUTE_DETAILS + res1.a
            )
          )
        )
        .subscribe((res) => {
          if (res.error == false) {
            // deleted successfully
            this.alertService.add({
              key: 'bc',
              severity: 'success',
              detail: 'Pickup route is deleted successfully.',
              life: 2000
            });
            this.getAllPickupRoute();
          } else if (res.error == true) {
            this.alertService.add({
              key: 'bc',
              severity: 'error',
              detail: 'Pickup Route can not be deleted,it is mapped with Vendor Master',
              life: 2000
            });
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            // error in deletion
          }
        })
    );
  }

  ngOnDestroy() {
    if (this.allSubscriptions) {
      this.allSubscriptions.unsubscribe();
    }
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }
}
