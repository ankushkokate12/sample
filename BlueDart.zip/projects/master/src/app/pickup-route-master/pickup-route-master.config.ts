// import { CommonValidators } from '../../../../../projects/vendors/src/lib/common.validator';
// const commonValidators = new CommonValidators();

export const pickupRouteMasterConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: 'Pickup Route Master',
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: 'Pickup Route Master',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: 'Add',
        buttonType: 'button',
        name: 'addPickupRouteMaster',
        trigerOnClick: 'true',
        eventRef: 'addPickupRoute',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  }
];

export const GRID_CONFIG = [
  {
    field: 'd',
    header: 'Area',
    showFilter: true,
    colWidth: '30px'
  },
  {
    field: 'e',
    header: 'Service Centre',
    showFilter: true,
    colWidth: '30px'
  },
  {
    field: 'b',
    header: 'Route Code',
    showFilter: true,
    colWidth: '30px'
  },
  {
    field: 'c',
    header: 'Route Name',
    showFilter: true,
    colWidth: '110px'
  },
  {
    field: 'f',
    header: 'Employee Code',
    showFilter: true,
    colWidth: '40px'
  },
  {
    field: 'g',
    header: 'Employee Name',
    showFilter: true,
    colWidth: '150px'
  },
  {
    field: 'h',
    header: 'Average Distance',
    showFilter: true,
    colWidth: '60px'
  }
];
