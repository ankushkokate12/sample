const baseURL = 'http://10.53.17.47:8087/';
// export const apiUrl = {
//   GET_ALL: 'https://run.mocky.io/v3/29844007-e6e5-4e3a-824c-bc4e36920ec1',
//   GET_PICKUP_ROUTE_BY_ID: '',

//   UPDATE_PRODUCT_CONFIG_DETAILS: '',
//   SAVE_PRODUCT_CONFIG_DETAILS: 'https://run.mocky.io/v3/62869dbc-4791-4943-98bc-887388ed59d9',
//   RELEASE_PRODUCT_CONFIG_DETAILS: '',
//   DELETE_PICKUP_ROUTE_DETAILS: '',
//   GET_HISTORY: 'https://run.mocky.io/v3/d2b38faf-3b49-40f5-9f10-31bb3d0162d1'
// };

// export const apiUrl = {
//   GET_ALL: baseURL + 'pickup-routes/ADR',
//   GET_PICKUP_ROUTE_BY_ID: '',
//   GET_PRODUCT: baseURL + 'products/prodCodes',
//   GET_SUB_PRODUCT: baseURL + 'products/subProdCodes',
//   GET_FEATURES: baseURL + 'products/features',
//   GET_PACKAGING: baseURL + 'products/packaging',
//   GET_VAS: baseURL + 'products/vas',
//   GET_BAGGING_RULE: '',
//   UPDATE_PRODUCT_CONFIG_DETAILS: '',
//   SAVE_PRODUCT_CONFIG_DETAILS: '',
//   RELEASE_PRODUCT_CONFIG_DETAILS: baseURL + 'products/config',
//   DELETE_PRODUCT_CONFIG_DETAILS: baseURL + 'products/config',
//   GET_PRODUCT_CONFIG_HISTORY: 'https://run.mocky.io/v3/b21b62da-c428-4a09-915a-28f8dc7bfbf7'
// };

export const apiUrl = {
  GET_ALL: 'pickup-routes/',
  GET_PICKUP_ROUTE_BY_ID: '',
  DELETE_PICKUP_ROUTE_DETAILS: 'pickup-routes/',
  GET_HISTORY: '/history/audit',
  ADD_PICKUP_ROUTE: 'pickup-routes/add',
  UPDATE_PICKUP_ROUTE: 'pickup-routes/update ',
  GET_EMP_NAME: 'pickup-routes/getemployee',
  GET_EMP_DETAILS_BY_ID: 'pickup-routes/details',
  GET_IMAGE_BY_ID: 'pickup-routes/routemap?a',
  DELETE_EMP_DETAILS: 'pickup-routes',
  VALIDATE_ROUTE_CODE: 'pickup-routes/validateroutecode',
  VALIDATE_SERVICE_CENTRE_PERMISSION: 'usermngt/validatepermission',
  GET_AREA_CODE: 'location/getarea?a='
};
