import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsModule } from '../../../../tools/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PickupRouteMasterRoutingModule } from './pickup-route-master-routing.module';
import { PickupRouteMasterComponent } from './pickup-route-master.component';
import { AddComponent } from './add/add.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ViewComponent } from './view/view.component';
import { HistoryModule } from '../history/history.module';
import { VendorsModule } from '../../../../vendors/src/lib/vendors.module';

@NgModule({
  declarations: [PickupRouteMasterComponent, AddComponent, ViewComponent],
  providers: [MessageService, ConfirmationService],
  imports: [
    CommonModule,
    ToastModule,
    ConfirmDialogModule,
    ToolsModule,
    FormsModule,
    ReactiveFormsModule,
    PickupRouteMasterRoutingModule,
    HistoryModule,
    VendorsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PickupRouteMasterModule { }
