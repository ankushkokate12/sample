import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { viewConfig } from './view.config';
import { EventEmitterService } from '../../../../../../projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from '../../../../../../projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from '../../../../../../projects/tools/src/lib/message.service';
import { DynamicFormComponent } from '../../../../../../projects/tools/src/public-api';
import { Properties } from '../../../../../../projects/vendors/src/lib/bd.propertybundle';
import { RestService } from '../../../../../../projects/tools/src/lib/rest.service';
import { apiUrl } from '../pickup-route-master.constant';
import { BdWebConfigService } from '../../../../../../projects/services/src/lib/bd-web-config.service';
import { ILandmark } from '../landmark.interface';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../../../../tools/src/lib/components/controls/dialog/dialog.component';
import { ConfirmationService } from 'primeng/api';
import { MessageService as AlertService } from 'primeng/api';
import { combineAll } from 'rxjs/operators';
import { FileUploadService } from '../../../../../../projects/tools/src/lib/file-upload.service';
import { BaseComponent } from './../../base/base.component';
import { SharedService } from '../../../../../../projects/tools/src/lib/shared.service';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent extends BaseComponent implements AfterViewInit {
  @ViewChild(DynamicFormComponent, { static: false })
  viewPickupRouteForm: DynamicFormComponent;
  viewPickupRouteConfig: FieldConfig[];
  viewId: any;
  landMarks: ILandmark[] = [];
  empViewDetails: any;
  lblErrMsgs: any;
  errorMsg: any;
  imgFileDetails: any;
  viewOnlyProperty: boolean = true;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    protected restService: RestService,
    private webconfig: BdWebConfigService,
    private primengMessageService: AlertService,
    private confirmationService: ConfirmationService,
    protected alertService: AlertService,
    private element: ElementRef,
    private dialog: MatDialog,
    protected sharedService: SharedService,
    private fileUploadService: FileUploadService
  ) {
    super(sharedService, restService, alertService);
    this.restService.get('assets/erroMsgsMapping.json').subscribe((data) => {
      this.lblErrMsgs = data;
    });
    this.viewId = activatedRoute.snapshot.params.id;
    console.log(this.viewId);
    this.messageService.sendHeaderShowMessage(true);
    this.viewPickupRouteConfig = viewConfig;
  }

  ngOnInit(): void {
    this.viewPickupRouteConfig = JSON.parse(JSON.stringify(viewConfig));
    console.log(this.viewPickupRouteConfig);
    this.getEmpDetails();
    this.showRowHistory();
    this.showHistoryPopup();
    this.historyAPIURL = this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_HISTORY;
    this.primaryKey = 'ri';
    this.screenText = 'Pickup Route';
    this.resourceNameForHistory = "PickupRouteMaster";
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => { });
  }

  ngAfterViewInit() {
    this.fileUploadService.setViewOnlyImageFlag(this.viewOnlyProperty);
    this.element.nativeElement.querySelectorAll('.mat-raised-button')[0].focus();
  }
  getEmpDetails() {
    if (this.viewId != undefined) {
      // get Data by ID

      this.restService
        .get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_EMP_DETAILS_BY_ID + '/' + this.viewId)
        .subscribe(
          (res) => {
            console.log(res);
            this.empViewDetails = res.data;
            let landMark = [];
            this.empViewDetails.g.forEach((ele) => {
              console.log(ele);
              let obj = {
                a: ele.a,
                b: ele.b,
                c: ele.c,
                d: ele.d
              };
              landMark.push(obj);
            });
            this.landMarks = landMark;
            if (this.empViewDetails.g.length == 0) {
              this.addLandmark();
            }
            let empViewDetails = {
              a: this.empViewDetails.a,
              b: this.empViewDetails.b,
              c: this.empViewDetails.c,
              d: this.empViewDetails.d,
              e: this.empViewDetails.e,
              h: this.empViewDetails.h,
              f: this.empViewDetails.f == null ? '' : parseFloat(this.empViewDetails.f),
              i: this.empViewDetails.i,
              g: landMark
            };
            if (this.viewId) {
              let empViewDetails = {
                ri: this.empViewDetails.ri
              };
            }
            this.viewPickupRouteForm.form.patchValue(empViewDetails);
            this.getImageById();
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  addLandmark() {
    this.landMarks.push({
      a: null,
      b: null,
      c: null,
      d: 'I'
    });
  }
  // get Image by ID
  getImageById() {
    if (this.empViewDetails.i == 'Y') {
      console.log('in img');
      this.restService
        .get(this.webconfig.apiURLPickupRouteMaster + apiUrl.GET_IMAGE_BY_ID + '=' + this.viewId)
        .subscribe(
          (res) => {
            this.imgFileDetails = res.data;
            this.fileUploadService.setViewId(this.imgFileDetails);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  getHistory() {
    this.sharedService.setShowHistoryPopup(true);
    this.sharedService.setGridRowForHistory(this.empViewDetails);
  }

  gotoEditScreen(id) {
    this.router.navigate(['/master/pickup-route/edit/' + id]);
  }

  btnBackPickupRoute() {
    this.router.navigate(['/master/pickup-route']);
  }

  deletePickUpRouteEmpDetails(id) {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to delete?',
          message: 'Record will be Permanently Deleted. Click yes to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.restService
            .delete(this.webconfig.apiURLPickupRouteMaster + apiUrl.DELETE_EMP_DETAILS + '/' + id)
            .subscribe(
              (res) => {
                console.log(res);
                if (res.error == false) {
                  this.errorMsg = this.lblErrMsgs.DELETE_RECORD;
                  this.primengMessageService.add({ key: 'bc', severity: 'success', detail: this.errorMsg, life: 2000 });
                  setTimeout(() => {
                    this.router.navigate(['/master/pickup-route']);
                  }, 3000);
                } else if (res.error == true) {
                  this.errorMsg = 'Pickup Route can not be deleted,it is mapped with Vendor Master';
                  this.primengMessageService.add({ key: 'bc', severity: 'error', detail: this.errorMsg, life: 2000 });
                  BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
                }
              },
              (err) => {
                console.log(err);
              }
            );
        }
      });
  }

  submit(event) { }

  ngOnDestroy() {
    // this.fileUploadService.fileData.unsubscribe();
    // this.fileUploadService.viewId.unsubscribe();
  }
}
