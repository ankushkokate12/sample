import { CommonValidators } from '../../../../../vendors/src/lib/common.validator';
const commonValidators = new CommonValidators();

export const viewConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: 'Route Details',
        class: 'col s12 m12 l12 xl12',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Area',
                inputType: 'text',
                name: 'c',
                validations: commonValidators.AREA_CODE_VALIDATOR,
                // value: 'BOM',
                disabled: true,
                class: 'col s6 m3 l2 xl1'
              },
              {
                type: 'input',
                label: 'Service Centre',
                inputType: 'text',
                name: 'd',
                // value: 'ADR',
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                disabled: true,
                class: 'col s6 m6 l4 xl2'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Route Code',
                inputType: 'text',
                name: 'a',
                validations: commonValidators.ROUTE_CODE_VALIDATOR,
                class: 'col s6 m4 l3 xl2',
                disabled: true
              },
              {
                type: 'input',
                label: 'Route Name',
                inputType: 'text',
                name: 'b',
                class: 'col s6 m4 l4 xl3',
                validations: commonValidators.ROUTE_NAME_VALIDATOR,
                disabled: true
              },
              {
                type: 'input',
                label: 'Average Distance',
                inputType: 'text',
                name: 'f',
                class: 'col s6 m4 l4 xl2',
                validations: commonValidators.AVG_DISTANCE_VALIDATOR,
                postInputText: 'Kms',
                disabled: true
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: 'Employee Code',
                inputType: 'text',
                name: 'e',
                eventRef: 'employeeCode',
                class: 'col s6 m3 l3 xl2',
                validations: commonValidators.EMP_CODE_VALIDATOR,
                disabled: true
              },
              {
                type: 'input',
                label: 'Employee Name',
                inputType: 'text',
                disabled: true,
                name: 'h',
                class: 'col s6 m6 l6 xl4'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'fileupload',
                label: 'Route Map',
                inputType: 'text',
                disabled: true,
                class: 'col s12 m6 l6 xl4'
              }
            ]
          }
        ]
      }
    ]
  }
];
