import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductConfigurationComponent } from '../add-product-configuration/add-product-configuration.component';
import { ProductConfigurationComponent } from './product-configuration.component';

const routes: Routes = [
  { path: '', component: ProductConfigurationComponent },
  { path: 'add', component: AddProductConfigurationComponent },
  { path: 'view/:id', component: AddProductConfigurationComponent },
  { path: 'edit/:id', component: AddProductConfigurationComponent },
  { path: 'clone/:id', component: AddProductConfigurationComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductConfigurationRoutingModule {}
