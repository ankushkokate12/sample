import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService as AlertService } from 'primeng/api';
import { BdWebConfigService } from 'projects/services/src/lib/bd-web-config.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/grid-columns.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { BaseComponent } from '../base/base.component';
import { GRID_CONFIG, productConfigurationConfig } from './product-configuration.config';
import { apiUrl } from './product-configuration.constant';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';

@Component({
  selector: 'app-product-configuration',
  templateUrl: './product-configuration.component.html',
  styleUrls: ['./product-configuration.component.scss']
})
export class ProductConfigurationComponent extends BaseComponent {
  regConfig: FieldConfig[];
  data: IGridColumn[];
  rows = [];

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    protected restService: RestService,
    protected sharedService: SharedService,
    private webconfig: BdWebConfigService,
    protected alertService: AlertService,
    private ngsk: NgShortcutService
  ) {
    super(sharedService, restService, alertService);
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = productConfigurationConfig;
    this.data = GRID_CONFIG;
    this.delete();
    this.release();
    this.showRowHistory();
    this.showHistoryPopup();
  }

  ngOnInit(): void {
    this.onView = false;
    this.getAll();
    this.setDeleteURL(this.webconfig.apiURLProductConfiguration + apiUrl.DELETE_PRODUCT_CONFIG_DETAILS);
    this.setReleaseURL(this.webconfig.apiURLProductConfiguration + apiUrl.RELEASE_PRODUCT_CONFIG_DETAILS);
    this.historyAPIURL = this.webconfig.masterServiceAPIURL + apiUrl.GET_PRODUCT_CONFIG_HISTORY;
    this.primaryKey = 'pci';
    this.screenText = 'Product Configuration';
    this.routerUrl = this.router.url;
    this.resourceNameForHistory = "ProductConfigMaster";

    let gridTblHt = window.innerHeight - 150 - 20 - 100;
    this.tableHeight = gridTblHt + 'px';

    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: any) => {
      if (field.eventRef == 'add') {
        this.addProductConfiguration();
      }
    });

    this.ngsk.push(
      new NgShortcut('n', () => this.addProductConfiguration(), {
        preventDefault: true,
        altKey: true
      })
    );
  }

  getAll() {
    this.apiSubscription = this.restService
      .get(this.webconfig.apiURLProductConfiguration + apiUrl.GET_ALL)
      .subscribe((res) => {
        if (!res.error) {
          this.rows = res.data;
          this.regConfig[0].rows[1].label =
            (res.data?.length == undefined ? '0' : res.data?.length) + ' Product Configuration(s) available.';
        } else {
          console.log(res.statusCode);
        }
      });
  }

  addProductConfiguration() {
    this.router.navigate(['master/product-configuration/add']);
  }

  ngOnDestroy() {
    if (this.deleteSubscription) {
      this.deleteSubscription.unsubscribe();
    }
    if (this.releaseSubscription) {
      this.releaseSubscription.unsubscribe();
    }

    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }

    if (this.apiSubscription) {
      this.apiSubscription.unsubscribe();
    }

    if (this.apiSubscription) {
      this.apiSubscription.unsubscribe();
    }
    if (this.apiSubscriptionTogglePopup) {
      this.apiSubscriptionTogglePopup.unsubscribe();
    }

    this.unsubscribeObservables$.next();
    this.unsubscribeObservables$.complete();
  }
}
