// import { CommonValidators } from '../../../../../projects/vendors/src/lib/common.validator';
// const commonValidators = new CommonValidators();

export const productConfigurationConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: 'Product Configuration',
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: 'Product Configuration',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: 'Add',
        buttonType: 'button',
        name: 'addProductConfiguration',
        trigerOnClick: 'true',
        eventRef: 'add',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  }
];

export const GRID_CONFIG = [
  {
    field: 'a', //'productConfigKey',
    header: 'Product Config Key',
    showFilter: true,
    colWidth: '80px'
  },
  {
    field: 'b', //productConfigName',
    header: 'Product Config Name',
    showFilter: true,
    colWidth: '140px'
  },
  {
    field: 'c', //products',
    header: 'Product',
    showFilter: true,
    colWidth: '50px'
  },
  {
    field: 'd', //subProducts',
    header: 'Sub Product',
    showFilter: true,
    colWidth: '50px'
  },
  {
    field: 'e', //features',
    header: 'Feature(s)',
    showFilter: true,
    colWidth: '160px'
  },
  {
    field: 'f', //packaging',
    header: 'Pack Type',
    showFilter: true,
    colWidth: '150px'
  },
  {
    field: 'g', //vas',
    header: 'VAS',
    showFilter: true,
    colWidth: '150px'
  },
  {
    field: 'h', //operationType',
    header: 'Status',
    showFilter: true,
    filterDD: [
      { label: 'Draft Add', value: 'Draft Add' },
      { label: 'Draft Edit', value: 'Draft Edit' },
      { label: 'Draft Delete', value: 'Draft Delete' },
      { label: 'Released', value: 'Released' }
    ],
    multiSelect: true,
    colWidth: '97px'
  },
  {
    field: 'i', //modifiedBy',
    header: 'Modified By',
    showFilter: true,
    colWidth: '80px'
  },
  {
    field: 'j', //modifiedDate',
    header: 'Modified Date',
    showFilter: true,
    colWidth: '80px'
  }
];
