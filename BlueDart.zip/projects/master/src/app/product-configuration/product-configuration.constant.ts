// export const apiUrl = {
//   GET_ALL: 'https://run.mocky.io/v3/2058c4ff-917e-430e-8fb2-cc93f571473e',
//   GET_PRODUUCT_CONFIG_BY_ID: '',
//   GET_PRODUCT: 'https://run.mocky.io/v3/0f559b89-efb5-4947-9f11-cd2cd6c6a66f',
//   GET_SUB_PRODUCT: 'https://run.mocky.io/v3/64bca916-c97a-45b4-9ea9-16c2a0a1376c',
//   GET_FEATURES: 'https://run.mocky.io/v3/4b946eab-6a4f-434b-9252-ac7c0d72f170',
//   GET_PACKAGING: 'https://run.mocky.io/v3/4b946eab-6a4f-434b-9252-ac7c0d72f170',
//   GET_VAS: 'https://run.mocky.io/v3/4b946eab-6a4f-434b-9252-ac7c0d72f170',
//   GET_BAGGING_RULE: '',
//   UPDATE_PRODUCT_CONFIG_DETAILS: '',
//   SAVE_PRODUCT_CONFIG_DETAILS: 'https://run.mocky.io/v3/62869dbc-4791-4943-98bc-887388ed59d9',
//   RELEASE_PRODUCT_CONFIG_DETAILS: '',
//   DELETE_PRODUCT_CONFIG_DETAILS: '',
//   GET_PRODUCT_CONFIG_HISTORY: 'https://run.mocky.io/v3/d2b38faf-3b49-40f5-9f10-31bb3d0162d1'
// };

export const apiUrl = {
  GET_ALL: 'products/config',
  GET_PRODUUCT_CONFIG_BY_ID: 'products/config',
  GET_PRODUCT: 'products/codes',
  GET_SUB_PRODUCT: 'products/subcodes',
  GET_FEATURES: 'products/features',
  GET_PACKAGING: 'products/packaging',
  GET_VAS: 'products/vas',
  GET_BAGGING_RULE: 'products/config/live',
  GET_PARENT_SERV_CONF: 'products/config/live',
  UPDATE_PRODUCT_CONFIG_DETAILS: 'products/config',
  SAVE_PRODUCT_CONFIG_DETAILS: 'products/config',
  RELEASE_PRODUCT_CONFIG_DETAILS: 'products/config',
  DELETE_PRODUCT_CONFIG_DETAILS: 'products/config',
  GET_PRODUCT_CONFIG_HISTORY: '/history/audit',
  VALIDATE_PRODUCT_CONFIG_KEY: 'products/config/validate',
  SERVICEABILITY_GROUP: 'products/serviceGroups',
  VALIDATE_SERVICEABILITY_GROUP__DISPLAYORDER: 'products/config/validate/displayOrder'
};
