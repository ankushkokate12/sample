import { Component, OnInit, ViewChild } from '@angular/core';
import { DynamicGridComponent } from 'projects/tools/src/lib/components/controls/dynamic-grid/dynamic-grid.component';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/grid-columns.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { DynamicFormComponent } from '../../../../tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../../../tools/src/lib/interfaces/field.interface';
import { EventEmitterService } from '../../../../tools/src/lib/event-emitter.service';
import { productconfig } from './product.config';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  data: IGridColumn[];
  rows = [];

  constructor(private messageService: MessageService) {
    this.messageService.sendHeaderShowMessage(true);

    this.data = [
      {
        field: 'productCode',
        header: 'Product Code'
      },
      {
        field: 'description',
        header: 'Description'
      },
      {
        field: 'group',
        header: 'Group'
      },
      {
        field: 'serviceTax',
        header: 'Service Tax'
      },
      {
        field: 'dssOrder',
        header: 'DSS Order'
      },
      {
        field: 'educationCess',
        header: 'Education Cess %'
      },
      {
        field: 'status',
        header: 'Status'
      },
      {
        field: 'modifiedBy',
        header: 'Modified By'
      },
      {
        field: 'modifiedDate',
        header: 'Modified Date'
      },
      {
        field: 'action',
        header: 'Action'
      }
    ];
    this.rows = [
      {
        productCode: 'D',
        description: 'International Outbound',
        group: 'X',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'A',
        description: 'Dart Apex',
        group: 'A',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Released',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'B',
        description: 'Invision Consignee',
        group: 'B',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'C',
        description: 'Coloader',
        group: 'C',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'C',
        description: 'Coloader',
        group: 'C',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'C',
        description: 'Coloader',
        group: 'C',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'C',
        description: 'Coloader',
        group: 'C',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      },
      {
        productCode: 'C',
        description: 'Coloader',
        group: 'C',
        serviceTax: '18:00',
        dssOrder: '12',
        educationCess: '0.00',
        status: 'Draft Edit',
        modifiedBy: 'bluedart/99532',
        modifiedDate: '15/11/2016',
        action: 'Edit'
      }
    ];
  }
  ngOnInit(): void {}
}
