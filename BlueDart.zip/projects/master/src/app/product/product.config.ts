import { Validators } from '@angular/forms'; 
 
export const productconfig = [  
    {
        type: 'label',
        label: 'Regular Search',  
        width: 1100
      },
    {
        type: 'button',
        label: 'Add',
        buttonType: 'button',
        name:'addRegularPK',
        trigerOnClick: 'true',
        eventRef: 'addPickupRoute', 
        classes: {
            buttonType: 'action-button',
            rightAlign: true
        } 
    } 
];








