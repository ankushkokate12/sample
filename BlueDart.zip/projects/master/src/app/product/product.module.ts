import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsModule } from 'projects/tools/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductRoutingModule } from './product-routing.module';
import { ProductComponent } from './product.component';



@NgModule({
  declarations: [ProductComponent],
  imports: [
    CommonModule,
    ToolsModule,
    FormsModule,
    ReactiveFormsModule, 
    ProductRoutingModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ProductModule { }
