import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'projects/services/src/lib/auth-guard.service';

const routes: Routes = [

  {
    path: 'pickup',
    loadChildren: () =>
      import('./regular/regular.module').then(
        (m) => m.RegularModule
      ),
    // canActivate: [AuthGuardService]
  },
  {
    path: 'called-pickup',
    loadChildren: () =>
      import('./called-pickup/called-pickup.module').then(
        (m) => m.CalledPickupModule
      ),
    //canActivate: [AuthGuardService]
  },
  {
    path: 'message',
    loadChildren: () =>
      import('./message/message.module').then(
        (m) => m.MessageModule
      ),
    //canActivate: [AuthGuardService]
  },
  {
    path: 'master-query',
    loadChildren: () =>
      import('./master-query/master-query.module').then(
        (m) => m.MasterQueryModule
      ),
    //canActivate: [AuthGuardService]
  },
  {
    path: 'finders',
    loadChildren: () =>
      import('./finders/finders.module').then(
        (m) => m.FindersModule
      ),
    // canActivate: [AuthGuardService]
  },
  {
    path: 'sc-operations',
    loadChildren: () =>
      import('./sc-operations/sc-operations.module').then(
        (m) => m.ScOperationsModule
      ),
    // canActivate: [AuthGuardService]
  }
  // { path: 'inscanModule', redirectTo: 'inscan-shipment' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
