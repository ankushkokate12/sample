import * as lbl from 'projects/login/src/assets/labelDataList.json';

export const rrPickupList = [
  {
    field: "a",
    header: lbl.SERVICE_CENTER,
    showFilter: true,
    colWidth: "80px"
  },
  {
    field: "e",
    header: lbl.SERIAL_NO,
    showFilter: true,
    colWidth: "80px"
  },
  {
    field: "b",
    header: lbl.CLIENT_NAME,
    showFilter: true
  },
  {
    field: "c",
    header: lbl.ADDRESS,
    showFilter: true
  },
  {
    field: "d",
    header: lbl.PICKUP_TIME,
    showFilter: true,
    colWidth: "80px"
  }
];

export const pickupRouteList = [
  {
    field: "b",
    header: lbl.ROUTE_CODE,
    showFilter: true
  },
  {
    field: "c",
    header: lbl.ROUTE_NAME,
    showFilter: true
  }
];

export const rPickupTimeList = [
  {
    field: "a",
    header: lbl.ADDRESS_LINE1,
    showFilter: true
  },
  {
    field: "b",
    header: lbl.ADDRESS_LINE2,
    showFilter: true
  },
  {
    field: "c",
    header: lbl.ADDRESS_LINE3,
    showFilter: true
  },
  {
    field: "d",
    header: lbl.PICKUP_TIME,
    showFilter: true
  },
  {
    field: "e",
    header: lbl.PICKUP_DAYS,
    showFilter: true
  }
];

export const landmarkPopupCols = [
  {
    field: "a",
    header: lbl.LANDMARK,
    showFilter: true
  },
  {
    field: "b",
    header: lbl.PINCODE,
    showFilter: true,
    colWidth: "100px"
  },
  {
    field: "c",
    header: lbl.ROUTE_CODE,
    showFilter: true,
    colWidth: "90px"
  }
];

