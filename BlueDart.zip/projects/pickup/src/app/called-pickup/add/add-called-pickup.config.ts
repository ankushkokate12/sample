import { Validators } from '@angular/forms';
import { CommonValidators } from '../../../../../vendors/src/lib/common.validator';
import * as lbl from '../../../../../login/src/assets/labelDataList.json';
import { apiUrl } from '../../pickup-module-api.constant';

const addCalledPickupRegEx = new CommonValidators();
export const helpIconFieldFormData = [
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        class: 'col s6 m5 l1 xl2 p-l-0',
        inputType: 'text',
        maxlength: '3',
        name: 'area',
        eventRef: 'txtFCArea',
        apiURLs: [apiUrl.VALIDATE_CALLED_AREA_CODE],
        validations: addCalledPickupRegEx.AREA_CODE_VALIDATOR,
        value: JSON.parse(sessionStorage.getItem('currentUser'))
          ? JSON.parse(sessionStorage.getItem('currentUser')).area
          : ''
      },
      {
        type: 'input',
        label: lbl.CLIENT_NAME,
        class: 'col s6 m5 l2 xl2 p-l-0',
        name: 'clientName',
        maxlength: '30',
        inputType: 'text',
        validations: addCalledPickupRegEx.CLIENT_NAME_PATTERN_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.CONTACT_PERSON,
        class: 'col s6 m5 l2 xl2 p-l-0',
        inputType: 'text',
        maxlength: '30',
        name: 'contactPerson',
        validations: addCalledPickupRegEx.CONTACT_PERSON_PATTERN_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.TELEPHONE,
        class: 'col s6 m5 l2 xl2 p-l-0',
        inputType: 'number',
        name: 'telephone',
        maxlength: '15',
        validations: addCalledPickupRegEx.TELEPHONE_PATTERN_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.MOBILE_NO,
        class: 'col s6 m5 l2 xl2 p-l-0',
        inputType: 'number',
        name: 'mobile',
        maxlength: '15',
        validations: addCalledPickupRegEx.MOBILE_PATTERN_VALIDATOR
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        class: 'col s6 m5 l1 xl2 p-l-0 w-130',
        buttonType: 'button',
        classes: {
          buttonType: 'primary-button',
        },
        eventRef: 'btnClientCodeSearch',
        height: 34
      }
    ]
  }
];
export const addCalledPickupConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: lbl.ARROW_BACK_IOS,
        name: 'backCalledPickupSearch',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'backCalledPickupSearch',
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'label',
        label: lbl.ADD_CALLED_PICKUP,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'reset',
        trigerOnClick: 'true',
        rightAlign: true,
        eventRef: 'resetDetails',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {
        type: 'button',
        label: lbl.CANCEL,
        buttonType: 'button',
        trigerOnClick: 'true',
        rightAlign: true,
        eventRef: 'btnCancelAdd',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.DEMOGRAPHIC_DETAILS,
        class: 'col s12 l6 m12 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.AREA,
                class: 'col s6 m5 l2 xl2 p-l-0',
                inputType: 'text',
                name: 'area',
                eventRef: 'txtDArea',
                maxlength: '3',
                validations: addCalledPickupRegEx.AREA_CODE_VALIDATOR,
                value: JSON.parse(sessionStorage.getItem('currentUser'))
                  ? JSON.parse(sessionStorage.getItem('currentUser')).area
                  : '',
                apiUrl: apiUrl.VALIDATE_CALLED_AREA_CODE,
                tabIndex: 1
              },
              {
                type: 'input',
                label: lbl.CLIENT_CODE,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'clientCode',
                eventRef: 'txtDClientCode',
                apiUrl: apiUrl.VALIDATE_CUST_CLIENT_CODE,
                helpIcon: true,
                matIconClass: 'account_box',
                maxlength: '6',
                dialogTitle: 'Frequently Calling Clients',
                helpDialogWidth: 1000,
                helpApiUrl: apiUrl.FREQUENTLY_CALLED_CUSTOMERS,
                validations: addCalledPickupRegEx.CLIENT_CODE_VALIDATOR,
                tabIndex: 2,
                helpDialogFormData: helpIconFieldFormData,
                errorMessage: {
                  noRecordsMessage: 'No records found',
                  searchCriteriaMessage: 'Please enter search criteria'
                },
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Area'
                  },
                  {
                    field: 'b',
                    header: 'Customer Name'
                  },
                  {
                    field: 'c',
                    header: 'Contact Person'
                  },
                  {
                    field: 'd',
                    header: 'Address 1'
                  },
                  {
                    field: 'e',
                    header: 'Address 2'
                  },
                  {
                    field: 'f',
                    header: 'Address 3'
                  },
                  {
                    field: 'g',
                    header: 'Pincode'
                  },
                  {
                    field: 'h',
                    header: 'Telephone'
                  },
                  {
                    field: 'j',
                    header: 'Mobile No'
                  }
                ],
                formGridMapping: [
                  {
                    controlName: 'clientCode',
                    gridColumnName: 'z'
                  },
                  {
                    controlName: 'area',
                    gridColumnName: 'a'
                  },
                  {
                    controlName: 'contactPerson',
                    gridColumnName: 'c'
                  },
                  {
                    controlName: 'address1',
                    gridColumnName: 'd'
                  },
                  {
                    controlName: 'address2',
                    gridColumnName: 'e'
                  },
                  {
                    controlName: 'address3',
                    gridColumnName: 'f'
                  },
                  {
                    controlName: 'pincode',
                    gridColumnName: 'g'
                  },
                  {
                    controlName: 'telephone',
                    gridColumnName: 'h'
                  },
                  {
                    controlName: 'clientName',
                    gridColumnName: 'b'
                  },
                  {
                    controlName: 'mobileNo',
                    gridColumnName: 'j'
                  }
                ],
                gridOptions: {
                  isSortable: true,
                  isScrollable: true,
                  isExpandable: false,
                  isColumnFilter: false,
                  isGroupable: false,
                  isCaption: false,
                  isClickable: true,
                  tableHeight: '42vh',
                  isSelectAllRows: false
                }
              },
              {
                type: 'checkbox',
                label: lbl.CASH,
                class: 'col s6 m5 l2 xl2 p-l-0 pl-20',
                eventRef: 'cashChk',
                name: 'cashChk',
                tabIndex: 3
              },
              {
                type: 'input',
                label: lbl.PINCODE,
                class: 'col s6 m5 l2 xl2 p-l-0',
                inputType: 'number',
                maxlength: '6',
                name: 'pincodeDemographic',
                eventRef: 'dpincode',
                validations: addCalledPickupRegEx.PINCODE_VALIDATOR,
                disabled: true,
                tabIndex: 4
              },
              {
                type: 'input',
                label: lbl.MOBILE_NO,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'number',
                name: 'mobileNoDemographic',
                eventRef: 'dmobile',
                validations: addCalledPickupRegEx.MOBILE_NUMBER_VALIDATOR,
                disabled: true,
                tabIndex: 5
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.PRODUCT_DETAILS,
        alignRight: true,
        class: 'col s12 l6 m12 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.PIECES,
                class: 'col s6 m5 l2 xl2 p-l-0',
                inputType: 'number',
                name: 'pieces',
                validations: addCalledPickupRegEx.PIECES_VALIDATOR,
                eventRef: 'numPieces',
                tabIndex: 23
              },
              {
                type: 'input',
                label: lbl.ACTUAL_WT,
                class: 'col s6 m5 l2 xl2 p-l-0',
                inputType: 'text',
                name: 'actWeight',
                eventRef: 'txtActWeight',
                isConditional: false,
                tabIndex: 24
              },
              {
                type: 'input',
                label: lbl.VOLUME_WT,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'volumeWt',
                volIcon: 'launch',
                validations: addCalledPickupRegEx.ACTUAL_WEIGHT_VALIDATOR,
                tabIndex: 25
              },
              {
                type: 'input',
                label: lbl.SERVICE_CENTER,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'serviceCenter',
                maxlength: '3',
                helpIcon: true,
                submitValue: 'ServiceCenter',
                helpApiUrl: 'https://run.mocky.io/v3/9f4cb6e2-affb-4686-a671-e7a3b5763f9d',
                validations: addCalledPickupRegEx.SERVICE_CENTER_CODE_VALIDATOR,
                helpDialogWidth: 600,
                tabIndex: 26,
                dialogTitle: 'Service Center Data',
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Service Center',
                    showFilter: true
                  },
                  {
                    field: 'b',
                    header: 'Service Center Name',
                    showFilter: true
                  }
                ],
                formGridMapping: [
                  {
                    controlName: 'serviceCenter',
                    gridColumnName: 'a'
                  }
                ],
                gridOptions: {
                  isColumnFilter: true,
                  isClickable: true,
                  isSelectAllRows: false
                }
              },
              {
                type: 'input',
                label: lbl.PICKUP_ROUTE,
                class: 'col s6 m5 l2 xl2 p-l-0',
                inputType: 'text',
                name: 'pickupRoute',
                helpIcon: true,
                submitValue: 'RouteCode',
                helpApiUrl: 'https://run.mocky.io/v3/187e68fc-26e8-4ae8-b323-de63636936e0',
                tabIndex: 27,
                validations: addCalledPickupRegEx.PICKUP_ROUTE_VALIDATOR,
                helpDialogWidth: 600,
                dialogTitle: 'Help on route landmarks',
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Landmark',
                    showFilter: true
                  },
                  {
                    field: 'b',
                    header: 'Pincode',
                    showFilter: true
                  },
                  {
                    field: 'c',
                    header: 'RouteCode',
                    showFilter: true
                  }
                ],
                formGridMapping: [
                  {
                    controlName: 'pickupRoute',
                    gridColumnName: 'c'
                  }
                ],
                gridOptions: {
                  isColumnFilter: true,
                  isClickable: true,
                  isSelectAllRows: false
                }
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.REGISTER_ON_AWB,
                class: 'col s6 m5 l4 xl2 p-l-0',
                inputType: 'text',
                name: 'regOnAWB',
                maxlength: '11',
                validation: addCalledPickupRegEx.AWB_VALIDATOR,
                tabIndex: 28,
                disabled: true
              },
              {
                type: 'input',
                label: lbl.PRODUCT_CODE,
                class: 'col s6 m5 l4 xl2 p-l-0',
                name: 'productCode',
                maxlength: '1',
                helpIcon: true,
                inputType: 'text',
                submitValue: 'productcode',
                helpApiUrl: 'https://run.mocky.io/v3/4a647bf5-ff24-4717-bdbf-c052ae51d580',
                tabIndex: 29,
                validations: addCalledPickupRegEx.PRODUCT_CODE_VALIDATOR,
                dialogTitle: 'Product Code Data',
                helpDialogWidth: 600,
                eventRef: 'productCode',
                triggerEvent: true,
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Product Code',
                    showFilter: true
                  },
                  {
                    field: 'b',
                    header: 'Product Description',
                    showFilter: true
                  }
                ],
                formGridMapping: [
                  {
                    controlName: 'productCode',
                    gridColumnName: 'a'
                  }
                ],
                gridOptions: {
                  isColumnFilter: true,
                  isClickable: true,
                  isSelectAllRows: false
                }
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'textarea',
                label: lbl.FEATURES,
                class: 'col s6 m5 l12 xl2 p-l-0',
                name: 'features',
                tabIndex: 30,
                height: 100
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.CLIENTS_DETAILS,
        changeAddressLink: true,
        class: 'col s12 l6 m12 mt10 p-l-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.CLIENT_NAME,
                class: 'col s6 m5 l5 xl2 p-l-0',
                inputType: 'text',
                name: 'clientName',
                validations: addCalledPickupRegEx.CLIENT_NAME_VALIDATOR,
                tabIndex: 6
              },
              {
                type: 'date',
                label: lbl.PICKUP_DATE,
                class: 'col s6 m5 l4 xl2 p-l-0',
                name: 'pickupDate',
                enableDateDays: 14,
                validations: addCalledPickupRegEx.PICKUP_DAYS_VALIDATOR,
                tabIndex: 7
              },
              {
                type: 'checkbox',
                label: lbl.TO_PAY,
                class: 'col s6 m5 l3 xl2 p-l-0',
                name: 'chkToPay',
                eventRef: 'chkBoxToPay',
                tabIndex: 8
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.PINCODE,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'number',
                maxlength: '6',
                name: 'pincode',
                validations: addCalledPickupRegEx.PINCODE_VALIDATOR,
                eventRef: 'txtPincode',
                apiUrl: apiUrl.VALIDATE_CALLED_PICKUP_PINCODE,
                tabIndex: 9
              },
              {
                type: 'input',
                label: lbl.ADDRESS1,
                class: 'col s6 m5 l9 xl2 p-l-0',
                inputType: 'text',
                name: 'address1',
                validations: addCalledPickupRegEx.SECONDARY_ADDRESS_VALIDATOR,
                tabIndex: 10
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.ADDRESS2,
                class: 'col s6 m5 l9 xl2 p-l-0',
                inputType: 'text',
                name: 'address2',
                validations: addCalledPickupRegEx.SECONDARY_ADDRESS_VALIDATOR,
                tabIndex: 11
              },
              {
                type: 'input',
                label: lbl.ADDRESS3,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'address3',
                validations: addCalledPickupRegEx.SECONDARY_ADDRESS_VALIDATOR,
                tabIndex: 12
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.MOBILE_NO,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'number',
                maxlength: '15',
                name: 'mobileNo',
                validations: addCalledPickupRegEx.MOBILE_NUMBER_VALIDATOR,
                tabIndex: 13
              },
              {
                type: 'input',
                label: lbl.TELEPHONE,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'number',
                name: 'telephone',
                validations: addCalledPickupRegEx.MOBILE_NUMBER_VALIDATOR,
                tabIndex: 14
              },
              {
                type: 'input',
                label: lbl.EMAIL,
                class: 'col s6 m5 l5 xl2 p-l-0',
                inputType: 'email',
                name: 'email',
                maxlength: '50',
                validations: addCalledPickupRegEx.EMAIL_PATTERN_VALIDATOR,
                tabIndex: 15
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.CONTACT_PERSON,
                class: 'col s6 m5 l4 xl2 p-l-0',
                inputType: 'text',
                name: 'contactPerson',
                maxlength: '30',
                validations: addCalledPickupRegEx.CONTACT_PERSON_REQUIRED_VALIDATOR,
                tabIndex: 16
              },
              {
                type: 'input',
                label: lbl.CALLER_NAME,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'callerName',
                maxlength: '30',
                validations: addCalledPickupRegEx.CALLER_NAME_PATTERN_VALIDATOR,
                tabIndex: 17
              },
              {
                type: 'input',
                label: lbl.CALLER_PHONE,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'callerPhone',
                maxlength: '15',
                validations: addCalledPickupRegEx.CALLER_PHONE_VALIDATOR,
                tabIndex: 18
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'timepicker',
                label: lbl.PICKUP_READY_TIME,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'pickupReadyTime',
                validations: addCalledPickupRegEx.PICKUP_TIME_VALIDATOR,
                eventRef: 'timePUReadyTime',
                format: 24,
                tabIndex: 19
              },
              {
                type: 'timepicker',
                label: lbl.OFFICE_CLOSE_TIME,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'officeCloseTime',
                validations: addCalledPickupRegEx.PICKUP_TIME_VALIDATOR,
                eventRef: 'timeOfficeCloseTime',
                format: 24,
                tabIndex: 20
              },

              {
                type: 'select',
                label: lbl.GSTINVOICEREQUIRED,
                class: 'col s6 m5 l3 xl2 p-l-0',
                name: 'gstInvoiceRequired',
                multiple: false,
                eventRef: 'ddGstInvoice',
                map: {
                  label: 'label',
                  value: 'value'
                },
                options: [
                  {
                    label: 'Required',
                    value: 'required'
                  },
                  {
                    label: 'Not Required',
                    value: 'notRequired'
                  }
                ],
                tabIndex: 21
              },
              {
                type: 'input',
                label: lbl.GST_NO,
                class: 'col s6 m5 l3 xl2 p-l-0',
                inputType: 'text',
                name: 'gstNo',
                maxlength: '30',
                validations: addCalledPickupRegEx.GST_PAN_VALIDATOR,
                tabIndex: 22
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.REMARKS,
        class: 'col s12 l6 m12 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.REMARKS,
                class: 'col s6 m5 l12 xl2',
                inputType: 'text',
                name: 'remarks',
                validations: addCalledPickupRegEx.REMARK_VALIDATOR,
                tabIndex: 31
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.REMINDERS,
                class: 'col s6 m5 l12 xl2',
                inputType: 'text',
                name: 'reminders',
                validations: addCalledPickupRegEx.REMARK_VALIDATOR,
                tabIndex: 32,
                disabled: true
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.REFERENCE_NO,
                class: 'col s6 m5 l3 xl2',
                inputType: 'text',
                name: 'referenceNo',
                maxlength: '20',
                validations: addCalledPickupRegEx.REFERENE_NO_ALL_ALPHANUMERIC_VALIDATOR,
                tabIndex: 33
              }
            ]
          }
        ]
      }
    ]
  },
  {
    type: 'row',
    class: 'df',
    rows: [
      {
        type: 'button',
        label: lbl.SAVE,
        buttonType: 'Submit',
        trigerOnClick: 'true',
        alignRight: true,
        eventRef: 'btnAddCalledPickup',
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        },
        class: 'col s3 m12 l12 xl12 right-align',
        tabIndex: 34
      }
    ]
  }
];
