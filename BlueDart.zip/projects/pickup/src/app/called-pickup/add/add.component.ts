import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { addCalledPickupConfig } from './add-called-pickup.config';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { Router } from '@angular/router';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { BdCalledPickupService } from 'projects/services/src/lib/bd.called-pickup.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { Validators } from '@angular/forms';
import { RegexExpressions } from 'projects/vendors/src/lib/bd.regex';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackBarComponent } from 'projects/tools/src/lib/components/controls/snack-bar/snack-bar.component';
import * as lbl from '../../../../../login/src/assets/labelDataList.json';
import { SharedService } from 'projects/tools/src/lib/shared.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  addCalledPickupForm: DynamicFormComponent;
  regConfig: FieldConfig[];
  rowData = {};
  clientCodeValue: string;
  previousValue: string;
  message = {
    code: false,
    message: ''
  };
  regexExpressions = new RegexExpressions();

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private calledPickupService: BdCalledPickupService,
    private dialog: MatDialog,
    private restService: RestService,
    public snackBar: MatSnackBar,
    private sharedService: SharedService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = addCalledPickupConfig;
  }

  ngOnInit(): void {
    this.calledPickupService.subscribeToEvents().subscribe((result) => {
      this.rowData = result;
    });
    this.sharedService.getPopupData().subscribe((result: any) => {
      result.field?.formGridMapping?.forEach(element => {
        this.addCalledPickupForm.form.controls[element['controlName']].setValue(result.data[element['gridColumnName']]);
      });
    });
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((control: string) => {
      switch (control['eventRef']) {
        case 'txtDArea':
          this.validateAreaCode(control);
          break;
        case 'txtDClientCode':
          this.validateClientCode(control);
          break;
        case 'backCalledPickupSearch':
          this.deleteConfirmationDialog();
          break;
        case 'btnCancelAdd':
          this.deleteConfirmationDialog();
          break;
        case 'btnAddCalledPickup':
          this.saveCalledPickup();
          break;
        case 'ddGstInvoice':
          this.enableGSTNo();
          break;
        case 'radioBDoxnDuts':
          this.actualWeightValidator();
          break;
        case 'chkBoxToPay':
          this.setRemarksValue();
          break;
        case 'txtPincode':
          this.validatePincode(control);
          break;
        case 'cashChk':
          this.enableDisableFields();
          break;
        case 'dpincode':
          this.updateValueOfPincode();
          break;
        case 'dmobile':
          this.updateValueOfMobileNo();
          break;
        case 'txtPincode':
          this.validatePincode(control);
          break;
        case 'timePUReadyTime':
        case 'timeOfficeCloseTime':
          this.timeValidation();
          break;
        case 'txtActWeight':
          this.actualWeightValidator();
          break;
        case 'productCode':
          this.getFeatures(control);
          break;
      }
    });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  submit(event) {
    console.log(event);
  }

  get cashCheckbox() {
    return this.addCalledPickupForm.form.get('cashChk');
  }

  get demograpicPincode() {
    return this.addCalledPickupForm.form.get('pincodeDemographic');
  }

  get pincode() {
    return this.addCalledPickupForm.form.get('pincode');
  }

  get demograpicMobile() {
    return this.addCalledPickupForm.form.get('mobileNoDemographic');
  }

  get clientCode() {
    return this.addCalledPickupForm.form.get('clientCode');
  }

  get mobileNo() {
    return this.addCalledPickupForm.form.get('mobileNo');
  }

  updateValueOfPincode() {
    this.pincode.setValue(this.demograpicPincode.value);
  }

  updateValueOfMobileNo() {
    this.mobileNo.setValue(this.demograpicMobile.value);
  }

  deleteConfirmationDialog() {
    const confirmDialog = this.dialog.open(DialogComponent, {
      data: {
        title: 'Do you want to cancel?',
        message: 'Unsaved data will be lost. Click yes to proceed.',
        redirectUrl: '/called-pickup'
      }
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        // this.deleteRegularPickup(field);
        console.log(result);
        confirmDialog.close();
        if (result) {
          this.router.navigate(['/called-pickup']);
        }
      }
    });
  }

  enableDisableFields() {
    if (this.clientCode.value != '000000') {
      this.previousValue = this.clientCode.value;
    }
    if (this.cashCheckbox.value) {
      this.demograpicPincode.enable();
      this.demograpicMobile.enable();
      this.clientCode.setValue('000000');
      let formControl = this.addCalledPickupForm.form;
      //client details
      formControl.get('clientName').setValue(null);
      formControl.get('address1').setValue(null);
      formControl.get('address2').setValue(null);
      formControl.get('address3').setValue(null);
      formControl.get('pincode').setValue(null);
      formControl.get('telephone').setValue(null);
      formControl.get('mobileNo').setValue(null);
      //formControl.get('cType').setValue('Cash');
      formControl.get('contactPerson').setValue(null);
      //pieces and customer type pending
      //Product Code details
      formControl.get('serviceCenter').setValue(null);
      formControl.get('pickupRoute').setValue(null);

      //pickupdate
      formControl.get('pickupDate').setValue(null);
    } else {
      this.demograpicPincode.disable();
      this.demograpicMobile.disable();
      this.demograpicPincode.setValue(null);
      this.demograpicMobile.setValue(null);
      this.clientCode.setValue(this.previousValue);
    }
  }

  clearCashSelection() {
    if (this.clientCode.value != '000000') {
      this.cashCheckbox.setValue(false);
      this.demograpicPincode.disable();
      this.demograpicMobile.disable();
    }
  }

  validateAreaCode(control) {
    let requestMapping = {
      a: 'area'
    };
    let responseMapping = {
      a: 'isError',
      b: 'errorMessage',
      c: 'apiTime',
      d: 'destinationAreaCode'
    };
    if (this.addCalledPickupForm.form.get('area').valid) {
      let requestBody = {
        a: this.addCalledPickupForm.form.get('area').value
      };
      requestBody['spinner'] = 'no';
      this.restService.post(control['apiUrl'], requestBody).subscribe(
        (response) => {
          if (!response['a']) {
            this.addCalledPickupForm.form.get('area').setValue(response['d']);
          } else {
            //show error message
            this.snackBar.openFromComponent(SnackBarComponent, {
              data: {
                code: false,
                message: 'Invalid Area Code'
              },

              ...{ duration: 2000, panelClass: ['error'] }
            });
            this.addCalledPickupForm.form.get('area').setErrors({ incorrect: true, message: 'Invalid Area Code' });
          }
        },
        (error) => {
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      );
    }
  }

  validateClientCode(control) {
    let requestMapping = {
      a: 'area',
      b: 'clientCode',
      c: 'serviceCenter'
    };
    let requsteB = {};

    for (let map in requestMapping) {
      if (
        this.addCalledPickupForm.form.get(requestMapping[map]) &&
        this.addCalledPickupForm.form.get(requestMapping[map]).value
      ) {
        requsteB[map] = this.addCalledPickupForm.form.get(requestMapping[map]).value;
      }
    }
    requsteB['spinner'] = 'no';
    // API integration
    if (
      this.addCalledPickupForm.form.get('clientCode').value &&
      this.addCalledPickupForm.form.get('clientCode').value !== '000000'
    ) {
      this.restService.post(control['apiUrl'], requsteB).subscribe(
        (response) => {
          console.log(response, response['d']);
          if (!response['c']) {
            let formControl = this.addCalledPickupForm.form;
            //client details
            formControl.get('clientName').setValue(response['s']);
            formControl.get('address1').setValue(response['t']);
            formControl.get('address2').setValue(response['u']);
            formControl.get('address3').setValue(response['v']);
            formControl.get('pincode').setValue(response['p']);
            formControl.get('telephone').setValue(response['q']);
            formControl.get('mobileNo').setValue(response['w']);
            //formControl.get('cType').setValue('Cash');
            //pieces and customer type pending
            //Product Code details
            formControl.get('serviceCenter').setValue(response['d']);
            formControl.get('pickupRoute').setValue(response['e']);

            //pickupdate
            formControl.get('pickupDate').setValue(new Date());
            // formControl.get('pickupReadyTime').setValue(response['f']);
            //  formControl.get('pickupDate').setValue(response['b']);
          } else {
            //show error message
            this.snackBar.openFromComponent(SnackBarComponent, {
              data: {
                code: false,
                message: 'Invalid Client Code'
              },

              ...{ duration: 2000, panelClass: ['error'] }
            });
            this.addCalledPickupForm.form
              .get('clientCode')
              .setErrors({ incorrect: true, message: 'Invalid Client Code' });
          }
        },
        (error) => {
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      );
    }
  }

  validatePincode(control) {
    let requestMapping = {
      a: 'area',
      m: 'pincode'
    };
    let requsteB = {};
    for (let map in requestMapping) {
      if (
        this.addCalledPickupForm.form.get(requestMapping[map]) &&
        this.addCalledPickupForm.form.get(requestMapping[map]).value
      ) {
        requsteB[map] = this.addCalledPickupForm.form.get(requestMapping[map]).value;
      }
    }
    requsteB['spinner'] = 'no';
    this.restService.post(control['apiUrl'], requsteB).subscribe(
      (response) => {
        if (!response['c']) {
          let formControl = this.addCalledPickupForm.form;
          formControl.get('serviceCenter').setValue(response['e']);
        }
      },
      (error) => {
        this.addCalledPickupForm.form.get('serviceCenter').setValue(null);
        if (error['error']['statusCode'] === '503') {
          //show error message
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: error['error']['message']
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
          this.addCalledPickupForm.form
            .get('pincode')
            .setErrors({ incorrect: true, message: error['error']['message'] });
        } else {
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      }
    );
  }

  // cancelAddPickup() {
  //   this.router.navigateByUrl('/called-pickup');
  // }

  saveCalledPickup() {
    if (this.addCalledPickupForm.form.valid) {
      if (!this.addCalledPickupForm.form.get('gstInvoiceRequired').value) {
        //set error message
        this.addCalledPickupForm.form
          .get('gstInvoiceRequired')
          .setErrors({ incorrect: true, message: 'Please select GST Invoice required' });
      } else if (
        this.addCalledPickupForm.form.get('gstInvoiceRequired').value === 'required' &&
        !this.addCalledPickupForm.form.get('gstNo').value
      ) {
        this.addCalledPickupForm.form.get('gstNo').setErrors({ incorrect: true, message: 'Please enter GST No.' });
      } else if (
        (this.addCalledPickupForm.form.get('gstInvoiceRequired').value === 'required' &&
          this.addCalledPickupForm.form.get('gstNo').value) ||
        this.addCalledPickupForm.form.get('gstInvoiceRequired').value === 'notRequired'
      ) {
        this.snackBar.openFromComponent(SnackBarComponent, {
          data: {
            code: true,
            message: 'Record added successfully'
          },
          ...{ panelClass: ['success'] }
        });
      }
    }
  }

  enableGSTNo() {
    if (
      this.addCalledPickupForm.form.get('gstInvoiceRequired') &&
      this.addCalledPickupForm.form.get('gstInvoiceRequired').value === 'required'
    ) {
      this.addCalledPickupForm.form.get('gstNo').enable();
    } else this.addCalledPickupForm.form.get('gstNo').disable();
  }

  actualWeightValidator() {
    let doxndutsValue;
    let required = this.addCalledPickupForm.fields.filter((x) => x.label === lbl.PRODUCT_DETAILS);
    required = required[0]?.section?.filter((x) => x.label === lbl.ACTUAL_WT);
    this.addCalledPickupForm.form
      .get('actWeight')
      .setValidators([Validators.pattern(this.regexExpressions.ACTUAL_WEIGHT)]);
    //when change in selection and get selected value
    this.addCalledPickupForm.form.get('doxnduts').valueChanges.subscribe((value) => {
      doxndutsValue = value;
      console.log(doxndutsValue, value);
      this.setError(doxndutsValue, required);
    });
    //when no change in radio button selection
    this.setError(this.addCalledPickupForm.form.get('doxnduts').value, required);
  }

  setError(doxndutsValue, required) {
    if (doxndutsValue == 'ndox') {
      this.addCalledPickupForm.form
        .get('actWeight')
        .setValidators([Validators.required, Validators.pattern(this.regexExpressions.ACTUAL_WEIGHT)]);
      this.addCalledPickupForm.form.get('actWeight').updateValueAndValidity();
      required[0].isConditional = true;
    } else if (doxndutsValue == 'dox') {
      this.addCalledPickupForm.form
        .get('actWeight')
        .setValidators([Validators.pattern(this.regexExpressions.ACTUAL_WEIGHT)]);
      this.addCalledPickupForm.form.get('actWeight').updateValueAndValidity();
      required[0].isConditional = false;
    }
    if (this.addCalledPickupForm.form.get('actWeight').hasError('required')) {
      this.addCalledPickupForm.form.get('actWeight').setErrors({ required: true, message: 'Act Wt cannot be blank.' });
    } else if (this.addCalledPickupForm.form.get('actWeight').hasError('pattern')) {
      this.addCalledPickupForm.form.get('actWeight').setErrors({ pattern: true, message: 'Invalid Weight' });
    } else {
      this.addCalledPickupForm.form.get('actWeight').setErrors(null);
    }
  }
  setRemarksValue() {
    if (this.addCalledPickupForm.form.get('chkToPay').value) {
      let area = this.addCalledPickupForm.form.get('clientCode').value
        ? this.addCalledPickupForm.form.get('area').value
        : '';
      let clientCode = this.addCalledPickupForm.form.get('clientCode').value
        ? this.addCalledPickupForm.form.get('clientCode').value
        : '';
      let clientName = this.addCalledPickupForm.form.get('clientName').value
        ? this.addCalledPickupForm.form.get('clientName').value
        : '';
      this.addCalledPickupForm.form.get('remarks').setValue(area + '/' + clientCode + ' ' + clientName);
    }
  }

  timeValidation() {
    let puReadyTime = this.addCalledPickupForm.form.get('pickupReadyTime').value;
    let officeCloseTime = this.addCalledPickupForm.form.get('officeCloseTime').value;

    if (puReadyTime && officeCloseTime) {
      puReadyTime = new Date(parseInt(puReadyTime)).getTime();
      officeCloseTime = new Date(parseInt(officeCloseTime)).getTime();
      if (puReadyTime > officeCloseTime) {
        this.addCalledPickupForm.form
          .get('officeCloseTime')
          .setErrors({ incorrect: true, message: 'Office Close Time cannot be less than Pickup Time' });
      }
    }
  }

  getFeatures(control) {
    if (this.addCalledPickupForm.form.get('productCode').value) {
      let productCode = this.addCalledPickupForm.form.get('productCode').value;
      let requsteB = {};
      this.restService.get(control['apiUrl'], requsteB).subscribe(
        (response) => {
          if (!response['b']) {
            let formControl = this.addCalledPickupForm.form;
            let features = response['data'].filter((x) => x.a === productCode);
            formControl.get('features').setValue(features);
          }
        },
        (error) => {
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      );
    }
  }
}
