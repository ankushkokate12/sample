import { Validators } from '@angular/forms';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from '../../../../login/src/assets/labelDataList.json';
import { apiUrl } from '../pickup-module-api.constant';

const rapidRegEx = new CommonValidators();
export const calledPickupSearchConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.CALLED_PICKUP,
        classes: {
          labelHead: true
        },
        message: 'Pickup available',
        name: 'count'
      },
      {
        type: 'button',
        label: lbl.ADD,
        alignRight: true,
        buttonType: 'button',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        },
        eventRef: 'btnAddCalledPickup',
        height: 34
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.PUR_NO,
        class: 'col w150 p-l-0',
        inputType: 'text',
        name: 'purno',
        maxlength: '8',
        validations: rapidRegEx.ALL_NUMBER_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.AREA,
        class: 'col w90 p-l-0',
        inputType: 'text',
        maxlength: '3',
        name: 'area',
        validations: rapidRegEx.AREA_CODE_VALIDATOR,
        eventRef: 'txtCSearchArea'
      },
      {
        type: 'date',
        label: lbl.PICKUP_DATE,
        class: 'col w150 p-l-0',
        name: 'pickupdate',
        minDate: 30,
        maxlength: '11',
        validations: [
          {
            name: 'matDatepickerMin',
            message: 'Invalid Min date'
          },
          {
            name: 'matDatepickerMax',
            message: 'Invalid Max date'
          }
        ]
      },
      {
        type: 'input',
        label: lbl.CLIENT_CODE,
        class: 'col w150 p-l-0',
        inputType: 'text',
        maxlength: '6',
        name: 'clientcode',
        validations: rapidRegEx.CLIENT_CODE_ALL_ALPHANUMERIC_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.REFERENCE_NO,
        inputType: 'text',
        name: 'referenceno',
        class: 'col w150 p-l-0',
        maxlength: '20',
        validations: rapidRegEx.REFERENE_NO_ALL_ALPHANUMERIC_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.MOBILE_NO,
        class: 'col w150 p-l-0',
        inputType: 'number',
        name: 'mobileNo',
        maxlength: '20',
        validations: rapidRegEx.MOBILE_NUMBER_VALIDATOR
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'submit',
        classes: {
          buttonType: 'primary-button',
        },
        eventRef: 'btnSearch',
        class: 'col w155 plr-2-8',
        apiUrl: apiUrl.CALLED_SEARCH
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'reset',
        classes: {
          buttonType: 'action-button',
        },
        eventRef: 'btnReset',
        class: 'col w70 plr-2-8',
      }
    ]
  }
];
