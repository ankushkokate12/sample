import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalledPickupComponent } from './called-pickup.component';

describe('CalledPickupComponent', () => {
  let component: CalledPickupComponent;
  let fixture: ComponentFixture<CalledPickupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CalledPickupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CalledPickupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
