import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/grid-columns.interface';
import { DynamicGridComponent } from 'projects/tools/src/public-api';
import { Router } from '@angular/router';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { BdCalledPickupService } from 'projects/services/src/lib/bd.called-pickup.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SnackBarComponent } from 'projects/tools/src/lib/components/controls/snack-bar/snack-bar.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';
import { calledPickupSearchConfig } from './called-pickup-search.config';

@Component({
  selector: 'app-called-pickup',
  templateUrl: './called-pickup.component.html',
  styleUrls: ['./called-pickup.component.scss'],
  providers: [DatePipe]
})
export class CalledPickupComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  calledPickupForm: DynamicFormComponent;
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  regConfig: FieldConfig[];
  data: IGridColumn[];
  rows = [];
  isTableVisible = false;
  errorMessage: string;
  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private calledPickupService: BdCalledPickupService,
    private restService: RestService,
    public snackBar: MatSnackBar,
    private datepipe: DatePipe
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = calledPickupSearchConfig;
    this.data = [
      {
        field: 'a',
        header: 'PUR No'
      },
      {
        field: 'b',
        header: 'Product Code'
      },
      {
        field: 'c',
        header: 'Area'
      },
      {
        field: 'd',
        header: 'Service Center'
      },
      {
        field: 'e',
        header: 'Reg.Date'
      },
      {
        field: 'f',
        header: 'Client Code'
      },
      {
        field: 'g',
        header: 'Client Name'
      },
      {
        field: 'h',
        header: 'Address'
      },
      {
        field: 'i',
        header: 'Pickup Date'
      },
      {
        field: 'j',
        header: 'Pickup Time'
      },
      {
        field: 'k',
        header: 'Route Code'
      }
    ];
  }

  ngOnInit(): void {
    this.todayDate();
    this.eventEmitt.subsVar = this.eventEmitt.
      invokeCommonComponentFunction.subscribe((control: string) => {
        switch (control['eventRef']) {
          case 'btnSearch': this.searchCalledPickup(control);
            break;
          case 'btnAddCalledPickup': this.addCalledPickup();
            break;
          case 'btnReset': this.resetForm();
            break;
        }
      });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  todayDate() {
    let today = new Date();
    // const dd = String(today.getDate()).padStart(2, '0');
    // const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    // const yyyy = today.getFullYear();

    // today = mm + '/' + dd + '/' + yyyy;
    console.log(today, this.calledPickupForm);
    //this.pickupDate.setValue(today);
  }

  resetForm() {
    this.isTableVisible = false;
    this.rows = [];
  }

  getRowData(event) {
    this.calledPickupService.sendUpdateEvent(event);
    this.router.navigateByUrl('called-pickup/addCalledPickup');
  }

  get areaCode() {
    return this.calledPickupForm.form.get('area');
  }

  get pickupDate() {
    return this.calledPickupForm.form.get('pickupdate');
  }

  searchCalledPickup(control) {
    console.log('clicked', this.areaCode.value);
    if (this.calledPickupForm.form.invalid) {
      return;
    }
    else {
      let mapping = {
        'a': 'purno',
        'b': 'area',
        'c': 'pickupdate',
        'd': 'clientcode',
        'e': 'referenceno',
        'f': 'mobileNo'
      }

      let response = {
        'a': 'token',
        'b': 'productCode',
        'c': 'area',
        'd': 'serviceCenter',
        'e': 'regDate',
        'f': 'clientCode',
        'g': 'customerName',
        'h': 'clientName',
        'i': 'pickupDate',
        'j': 'pickupTime',
        'k': 'routeCode'
      }
      let requsteB = {}
      if (!this.calledPickupForm.form.get('pickupdate').value) this.calledPickupForm.form.get('pickupdate').setValue(new Date())
      for (let map in mapping) {
        if (this.calledPickupForm.form.get(mapping[map]) && this.calledPickupForm.form.get(mapping[map]).value) {
          if (map == 'c') requsteB[map] = this.datepipe.transform(this.calledPickupForm.form.get('pickupdate').value, 'dd/MM/yyyy')
          else requsteB[map] = this.calledPickupForm.form.get(mapping[map]).value;
        }
      }
      // requsteB['spinner'] = 'yes';
      this.restService
        .post(control['apiUrl'], requsteB)
        .subscribe(
          (response) => {
            //If values of enetered fields are correct and fetched result
            if (!response['c']) {
              if (response['l'] != 0) {
                this.rows = response['data'];
                this.isTableVisible = true;
                // this.calledPickupForm.form.get('count').setValue(response['l'])
              }
              if (response['l'] == 0) {
                this.isTableVisible = false;
                // this.calledPickupForm.form.get('count').setValue(null)
                this.snackBar.openFromComponent(SnackBarComponent, {
                  data: {
                    code: false,
                    message: response['a']
                  },
                  ...{ duration: 2000, panelClass: ['error'] }
                });
              }
            }
            else {
              //if there any field errors
              if (response.error) {
                this.isTableVisible = false;
                this.snackBar.openFromComponent(SnackBarComponent, {
                  data: {
                    code: false,
                    message: response['message']
                  },
                  ...{ duration: 2000, panelClass: ['error'] }
                });
              }
            }
          },
          (error) => {
            this.snackBar.openFromComponent(SnackBarComponent, {
              data: {
                code: false,
                message: "There is some error. Please try again."
              },
              ...{ duration: 2000, panelClass: ['error'] }
            });
            console.log(error);
          }
        );
    }
  }

  validateAreaCode(control) {
    let requestMapping = {
      'a': 'area'
    }
    let responseMapping = {
      'a': 'isError',
      'b': 'errorMessage',
      'c': 'apiTime',
      'd': 'destinationAreaCode'
    }
    if (this.calledPickupForm.form.get('area').valid) {
      let requestBody = {
        'a': this.calledPickupForm.form.get('area').value
      }
      requestBody['spinner'] = 'no';
      this.restService
        .post(control['apiUrl'], requestBody)
        .subscribe(
          (response) => {
            if (!response['a']) {
              this.calledPickupForm.form.get('area').setValue(response['d'])
            }
            else {
              //show error message
              this.snackBar.openFromComponent(SnackBarComponent, {
                data: {
                  code: false,
                  message: response['b']
                },
                ...{ duration: 2000, panelClass: ['error'] }
              });
              // this.calledPickupForm.form.get('area').setErrors({ 'incorrect': true, message: 'Invalid Area Code' });
            }
          },
          (error) => {
            this.snackBar.openFromComponent(SnackBarComponent, {
              data: {
                code: false,
                message: "There is some error. Please try again."
              },
              ...{ duration: 2000, panelClass: ['error'] }
            });
            console.log(error);
          }
        );
    }
  }

  addCalledPickup() {
    this.router.navigate(['called-pickup/addCalledPickup']);
  }

}
