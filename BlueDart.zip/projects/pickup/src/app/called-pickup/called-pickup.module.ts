import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalledPickupRoutingModule } from './called-pickup-routing.module';
import { CalledPickupComponent } from './called-pickup.component';
import { ToolsModule } from 'projects/tools/src/public-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddComponent } from './add/add.component';



@NgModule({
  declarations: [CalledPickupComponent, AddComponent],
  imports: [
    CommonModule,
    CalledPickupRoutingModule,
    ToolsModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CalledPickupModule { }
