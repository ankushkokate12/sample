import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConveyPickupComponent } from './convey-pickup.component';

const routes: Routes = [
  {
    path: "",
    component: ConveyPickupComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConveyPickupRoutingModule { }
