import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConveyPickupComponent } from './convey-pickup.component';

describe('ConveyPickupComponent', () => {
  let component: ConveyPickupComponent;
  let fixture: ComponentFixture<ConveyPickupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConveyPickupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConveyPickupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
