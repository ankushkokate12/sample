import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { FieldConfig, IGridColumn } from 'projects/tools/src/lib/interfaces/field.interface';
import { conveyPickupConfig } from './convey-pickup.config';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { apiUrl } from '../pickup-module-api.constant';

@Component({
  selector: 'app-convey-pickup',
  templateUrl: './convey-pickup.component.html',
  styleUrls: ['./convey-pickup.component.scss']
})
export class ConveyPickupComponent implements OnInit, OnDestroy {
  conveyPickupConfig: FieldConfig[];
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  data: IGridColumn[];
  rows =  [ { a: '10', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '12', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '14', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '16', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '23', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '67', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'},
  { a: '90', b: 'Mixed Route', c: '9', d: '6', e: '-', f: '3', g: '9', h: '6',i: '-',j: '3',k: '-',l: '-',m: '-'}
  ];
  get sCenterCode() {
    return this.form.form.get('txtServiceCenter');
  }
  constructor(
    private restService: RestService,
    private messageService: MessageService,
    private eventEmitt: EventEmitterService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.conveyPickupConfig = conveyPickupConfig;
    this.data = [
      {
        field: 'a',
        header: 'Route Code',
        showFilter: false
      },
      {
        field: 'b',
        header: 'Route Name',
        showFilter: false
      },
      {
        field: 'c',
        header: 'All',
        showFilter: false
      },
      {
        field: 'd',
        header: 'Normal',
        showFilter: false
      },
      {
        field: 'e',
        header: 'ETail RVP',
        showFilter: false
      },
      {
        field: 'f',
        header: 'ETail Frwd',
        showFilter: false
      },  {
        field: 'g',
        header: 'All',
        showFilter: false
      },
      {
        field: 'h',
        header: 'Normal',
        showFilter: false
      },
      {
        field: 'i',
        header: 'ETail RVP',
        showFilter: false
      },
      {
        field: 'j',
        header: 'ETail Frwd',
        showFilter: false
      },
      {
        field: 'k',
        header: 'Total Reminders',
        showFilter: false
      },
      {
        field: 'l',
        header: 'Pending Reminders',
        showFilter: false
      },
      {
        field: 'm',
        header: 'Pending Messages',
        showFilter: false
      },
    ];
  }

  ngOnInit(): void {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'searchConveyPickup':
          this.getConveyPickupData();
          break;
      }
    });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  submit(evt) {
  }
  getConveyPickupData(){
    /* const payload = {
      "a": this.sCenterCode.value
    };
      this.restService.get(apiUrl.HOLIDAY_LIST, '', payload).subscribe(
        (res) => {
          if (res) {
             this.data = res;
          }
        },
        (err) => { }); */
  }
}
