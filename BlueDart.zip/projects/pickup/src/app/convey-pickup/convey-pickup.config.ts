import * as lbl from '../../../../login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator.ts';
import { apiUrl } from '../pickup-module-api.constant';
const commonValidators = new CommonValidators();

export const conveyPickupConfig = [
  
  {
  type: 'row',
  rows: [ 
    {
      type: 'label',
      label: 'Convey Pickup Dashboard',
      name: 'HeadLabel',
      class: 'col s6 m5 l3 xl3 plr-8', 
      classes: {
        labelHead: true
      }
    },
    {
      type: 'label',
      label: '| 15 Routes available',
      name: 'labelCount',
      class: 'col s6 m5 l3 xl3 plr-8',  
    },
    {
      type: 'button',
      label: lbl.SEARCH,
      buttonType: 'button',
      trigerOnClick: 'true',
      eventRef: 'searchConveyPickup',
      tabIndex: 2,  
      newLine: true,
      classes: {
        buttonType: 'primary-button'
      },
      class: 'col s3 m12 l1 xl12 rtop btn-right w-130', 
       
    },
    {
      type: 'input',
      label: 'Service Centre',
      inputType: 'text',
      name: 'txtServiceCenter',
      class: 'col s3 m12 l2 xl12 rtop btn-right w-180', 
      tabIndex: 1,
      validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
      maxlength: "3"
    }
    ]
  }
];
