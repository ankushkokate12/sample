import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConveyPickupRoutingModule } from './convey-pickup-routing.module';
import { ConveyPickupComponent } from './convey-pickup.component';
import { ToolsModule } from 'projects/tools/src/public-api';


@NgModule({
  declarations: [
    ConveyPickupComponent
  ],
  imports: [
    CommonModule,
    ToolsModule,
    ConveyPickupRoutingModule
  ]
})
export class ConveyPickupModule { }
