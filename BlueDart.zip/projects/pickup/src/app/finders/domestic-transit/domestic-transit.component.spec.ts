import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DomesticTransitComponent } from './domestic-transit.component';

describe('DomesticTransitComponent', () => {
  let component: DomesticTransitComponent;
  let fixture: ComponentFixture<DomesticTransitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DomesticTransitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DomesticTransitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
