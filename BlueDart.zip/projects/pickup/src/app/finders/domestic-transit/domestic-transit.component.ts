import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';
import { MessageService as AlertService } from 'primeng/api';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import * as msgs from 'projects/pickup/src/assets/messages.json';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { API_ERROR_STATUS, EDLFLAG, PRODUCTLIST, PRODUCTSUBPRODUCTLIST } from '../finders-module.constant';
import { domesticTransit, infoLabelConfig } from './domestic-transit.config';
@Component({
  selector: 'app-domestic-transit',
  templateUrl: './domestic-transit.component.html',
  styleUrls: ['./domestic-transit.component.scss']
})
export class DomesticTransitComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  domesticTransit: DynamicFormComponent;
  datewiseTTMessage: string;
  domesticConfig: FieldConfig[];
  isShowGrid: boolean = false;
  isShowCal: boolean = false;
  isShowFullCal: boolean = false;
  originServiceCenterList = [];
  destinationServiceCenterList = [];
  dttdestinationArea: string;
  startDateString: string;
  endDateString: string;
  fields: any;

  list = [];
  data = [
    {
      field: 'a',
      header: lbl.PRODUCT_CODE,
      showFilter: true,
      colWidth: '46px'

    },
    {
      field: 'b',
      header: lbl.SUB_PRODUCT_CODE,
      showFilter: true,
      colWidth: '65px'
    },
    {
      field: 'c',
      header: lbl.DEST_AREA,
      showFilter: true,
      colWidth: '45px'
    },
    {
      field: 'd',
      header: lbl.DEST_NAME,
      showFilter: true,
      colWidth: '90px'
    },
    {
      field: 'e',
      header: lbl.DEST_SC,
      showFilter: true,
      colWidth: '55px'
    },
    {
      field: 'f',
      header: lbl.CUTOFF_TIME,
      colWidth: '48px'
    },
    {
      field: 'g',
      header: lbl.MON,
      colWidth: '29px'
    },
    {
      field: 'h',
      header: lbl.TUE,
      colWidth: '28px'
    },
    {
      field: 'i',
      header: lbl.WED,
      colWidth: '29px'
    },
    {
      field: 'j',
      header: lbl.THU,
      colWidth: '28px'
    },
    {
      field: 'k',
      header: lbl.FRI,
      colWidth: '28px'
    },
    {
      field: 'l',
      header: lbl.SAT,
      colWidth: '28px'
    },
    {
      field: 'o',
      header: lbl.PAD,
      colWidth: '35px'
    },
    {
      field: 'n',
      header: lbl.PODD_DELAY,
      colWidth: '40px'
    },
    {
      field: 'p',
      header: lbl.CID,
      colWidth: '40px'
    },
    {
      field: 'r',
      header: lbl.LOGIN_ID,
      colWidth: '40px'
    },
    {
      field: 'q',
      header: lbl.LOC,
      colWidth: '30px'
    },
    {
      field: 's',
      header: lbl.HANDHELD,
      colWidth: '56px'
    }
  ];
  calendarOptions;
  rows = [];
  options: any;
  messages: any;
  currentUser: any;
  isStaticMessage: boolean = false;

  constructor(private eventEmitterService: EventEmitterService,
    private restService: RestService,
    public dialog: MatDialog,
    private datepipe: DatePipe,
    private sharedService: SharedService,
    private authenticationService: AuthenticationService,
    private elementRef: ElementRef,
    private router: Router,
    private alertService: AlertService,
    private ngsk: NgShortcutService,
    private element: ElementRef) {
    this.eventEmitterService.subsVar = this.eventEmitterService.
      invokeCommonComponentFunction.subscribe((control: string) => {
        switch (control['eventRef']) {
          case 'btnDatewiseTT': this.searchDatewiseTT(control);
            break;
          case 'btnDTTSearch': this.searchDTT(control)
            break;
          case 'txtOriginArea': this.getOriginAreaCode(control);
            break;
          case 'txtoriginServiceCenter': this.getOriginServiceCenter(control);
            break;
          case 'txtOriginPincode': this.getOriginPincode(control)
            break;
          case 'txtdestinationServiceCenter': this.getDestinationServiceCenter(control);
            break;
          case 'txtdestinationArea': this.getDestinationAreaCode(control);
            break;
          case 'txtdestinationPincode': this.getDestinationPincode(control);
            break;
          case 'ddDttProduct': this.getProductList();
            break;
        }
      });
    this.sharedService.getPopupData().subscribe(result => {
      if (result.data) {
        this.isStaticMessage = true;
        result.field?.formGridMapping?.forEach(element => {
          this.domesticTransit.form.controls[element['controlName']].setValue(result.data[element['gridColumnName']]);
          if (result.field.name == 'originArea') {
            this.getOriginAreaCode(result.field);
          }
          if (result.field.name == 'destinationArea') {
            this.getDestinationAreaCode(result.field);
          }
        });
      }
    })
    this.messages = msgs['default'];
    //shortcut key to perform DTT search
    ngsk.push( new NgShortcut( 'f', () => this.element.nativeElement.querySelector('#dtt-search')?.click(), {
      preventDefault: true,
      ctrlKey: true
    } ) );
    ngsk.push( new NgShortcut( 'F', () => this.element.nativeElement.querySelector('#dtt-search')?.click(), {
      preventDefault: true,
      ctrlKey: true
    } ) );
    //shortcut key to perform datewise TT search
    ngsk.push( new NgShortcut( 't', () => this.element.nativeElement.querySelector('#dtt-datewise-search')?.click(), {
      preventDefault: true,
      altKey: true
    } ) );
    ngsk.push( new NgShortcut( 'T', () => this.element.nativeElement.querySelector('#dtt-datewise-search')?.click(), {
      preventDefault: true,
      altKey: true
    } ) );
    //shortcut keys for Help popups
    ngsk.push( new NgShortcut( 'h', () =>
    {
      this.openHelpPopup();
    }, {
      preventDefault: true,
      altKey: true
    } ) );
    ngsk.push( new NgShortcut( 'H', () =>
    {
      this.openHelpPopup();
    }, {
      preventDefault: true,
      altKey: true
    } ) );
  }
//open help popups when alt+h key pressed
  openHelpPopup() {
    if (document.activeElement === this.element.nativeElement.querySelector('#origin-area')) {
      this.element.nativeElement.querySelector('#help-area')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#origin-service-centre')) {
      this.element.nativeElement.querySelector('#help-service-centre')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#destination-area')) {
      this.element.nativeElement.querySelector('#help-dest-area')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#destination-service-centre')) {
      this.element.nativeElement.querySelector('#help-dest-sc')?.click();
    }
  }
  //get form values
  get productList() {
    return this.domesticTransit.form.get('dttProduct');
  }

  get subProductList() {
    return this.domesticTransit.form.get('dttSubProduct');
  }

  get originArea() {
    return this.domesticTransit.form.get('originArea');
  }

  get originServiceCenter() {
    return this.domesticTransit.form.get('originServiceCenter');
  }

  get destinationServiceCenter() {
    return this.domesticTransit.form.get('destinationServiceCenter');
  }

  get destinationArea() {
    return this.domesticTransit.form.get('destinationArea');
  }

  get originPincode() {
    return this.domesticTransit.form.get('originPincode');
  }

  get destinationPicode() {
    return this.domesticTransit.form.get('destinationPincode');
  }

  get pickupDate() {
    return this.domesticTransit.form.get('pickupdate');
  }

  get pickupTime() {
    return this.domesticTransit.form.get('dttPickuptime');
  }

  get dttEDL() {
    return this.domesticTransit.form.get('dttEDL');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.domesticConfig = domesticTransit;
    this.fields = infoLabelConfig;
  }


  ngAfterViewInit() {
    setTimeout(() => {
      this.domesticTransit.form.get('originArea')?.setValue(this.currentUser['area']);
      this.setFocus();
    })
  }

  //search datewise TT
  searchDatewiseTT(control) {
    this.isShowFullCal = false;
    this.isShowCal = false;
    let productLisError = this.messages.TRANSITTIMEERROR;
    this.isShowGrid = false;
    this.isShowCal = false;
    this.showError('search', '', VALIDATION_STATUS.VALID);
    this.showError('datewiseSearch', '', VALIDATION_STATUS.VALID);
    if (this.productList.value == PRODUCTLIST.PRODUCTALL) {
      this.showToasterMessage(productLisError);
    } else if (!this.destinationServiceCenter.value) {
      this.destinationServiceCenter.markAsTouched();
      this.showError('destinationServiceCenter', this.messages.DESTINATIONSCERROR);
      this.destinationServiceCenter.setErrors({ 'pattern': true });
    }
    else if (!this.pickupTime.value) {
      this.pickupTime.markAsTouched();
      this.showError('dttPickuptime', this.messages.PICKUPTIMEERROR );
      this.pickupTime.setErrors({ 'pattern': true });
    }
    else if (!this.originServiceCenter.value) {
      this.originServiceCenter.markAsTouched();
      this.showError('originServiceCenter', this.messages.ORIGINSCRROR );
      this.originServiceCenter.setErrors({ 'pattern': true });
    }
    else if (!this.pickupDate.value) {
      this.pickupDate.markAsTouched();
      this.showError('pickupdate', this.messages.DATEERROR );
      this.pickupDate.setErrors({ 'pattern': true });
    }
    else if(this.originArea.valid &&
      this.pickupDate.valid &&
      this.originServiceCenter.valid &&
      this.destinationArea.valid &&
      this.destinationServiceCenter.valid &&
      this.pickupTime.valid &&
      this.destinationPicode.valid){
      let formValues = {
        'a': this.originArea.value,
        'b': this.originServiceCenter.value,
        'c': this.productList.value,
        'd': this.destinationArea.value,
        'e': this.destinationServiceCenter.value,
        'f': this.datepipe.transform(this.pickupDate.value, 'dd/MM/yyyy'),
        'g': this.pickupTime.value,
        'h': null,
        'i': this.subProductList.value || null,
        'j': this.destinationPicode.value,
      }
      let pickupDate = this.getInitialDate(formValues['f']);
      this.restService
        .post(control['apiUrl'], formValues)
        .subscribe(
          (response) => {
            let events = []
            if (!response['c']) {
              let holidays = response['j'];
              response['j']?.forEach(element => {
                events.push(
                  {
                    title: element['d'],
                    date: this.getInitialDate(element['c']),
                    className: element['a'] != 'M' ? 'red-holiday' : 'green-holiday',
                  }
                )
              });
              this.calendarOptions = {
                initialView: 'dayGrid',
                headerToolbar: false,
                titleFormat: { year: 'numeric', month: 'long' },
                initialDate: pickupDate, //start week
                firstDay: new Date(pickupDate)?.getDay(),
                duration: { weeks: 2 },
                events: events,
                fixedWeekCount: false,
                height: 200,
              };
              this.isShowFullCal = true;
              this.dttdestinationArea = this.destinationArea.value;
              this.setStartEndDay(formValues['f'].split('/'));
              //show delivery info if status is valid else show error defined in response
              if(response['b'] == API_ERROR_STATUS.VALID) this.datewiseTTMessage = this.messages.DATEWISETTTITLTE + response['d'];
              else {
                this.datewiseTTMessage ='';
                this.showToasterMessage(response['b']);
              }
            }
            else {
              this.isShowCal = false;
              this.isShowFullCal = false;
              this.isShowGrid = false;
              this.showToasterMessage(response['b']);
            }
          },
          (error) => {
            this.showError('datewiseSearch',this.messages.GLOBALAPIERROR);
          }
        );

    }
  }

  getInitialDate(initialDate) {
    let pDate = initialDate.split('/');
    return this.datepipe.transform(pDate[2] + '/' + pDate[1] + '/' + pDate[0], 'yyyy-MM-dd')
  }

  showError(key: string, message: string, type: string= VALIDATION_STATUS.INVALID) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: key,
      message: message,
      status: type,
      screenName: this.router.url
    }
    this.sharedService.setErrorMessage(errorObj);
  }
  //search for DTT details, get details in grid and two weeks holiday calendar
  searchDTT(control) {
    this.isShowFullCal = false;
    this.isShowCal = false;
    this.isShowGrid =false;
    this.showError('datewiseSearch', '', VALIDATION_STATUS.VALID);
    this.showError('dttProduct', '', VALIDATION_STATUS.VALID);
    this.showError('search', '', VALIDATION_STATUS.VALID);
    if (!this.pickupDate.value) {
      this.pickupDate.markAsTouched();
      this.showError('pickupdate', this.messages.DATEERROR );
      this.pickupDate.setErrors({ 'pattern': true});
    }
    else if(this.originArea.valid &&
      this.pickupDate.valid &&
      this.originServiceCenter.valid &&
      this.destinationArea.valid &&
      this.destinationServiceCenter.valid &&
      this.destinationPicode.valid &&
      this.originPincode.valid){
    let formValues = {
      'a': this.productList.value == PRODUCTLIST.PRODUCTALL ? '*' : this.productList.value,
      'b': this.subProductList.value || null,
      'c': this.originArea.value,
      'd': this.destinationArea.value,
      'e': this.originServiceCenter.value,
      'f': this.destinationServiceCenter.value,
      'g': this.originPincode.value,
      'h': this.destinationPicode.value,
      'i': this.datepipe.transform(this.pickupDate.value, 'dd/MM/yyyy'),
      'j': this.currentUser['employeeCode'],
      'k': this.currentUser['location'],
      'l': this.currentUser['handHeld']
    }
    let requestBody = {};
    if (this.originArea.value) {
      requestBody = this.getRequestParam(formValues)
      this.restService
        .post(apiUrl.SEARCH_DTT, requestBody)
        .subscribe(
          (response) => {
            if (!response['c']) {
              this.dttdestinationArea = this.destinationArea.value;
              this.isShowGrid = true;
              this.isShowCal = true
              this.rows = response["dttChartQueryNm"];
              if (response['holidays']?.length != 0) {
                let holidays = response['holidays'];
                this.getCalendar(holidays);
              }
            }
            else {
              this.isShowCal = false;
              this.isShowFullCal = false;
              this.isShowGrid = false;
              this.showToasterMessage(response['b']);
            }
          },
          (error) => {
            this.showError('search', this.messages.GLOBALAPIERROR);
          }
        );
    }
  }
  }

  getCalendar(holidays) {
    let pickupDate = this.datepipe.transform(this.pickupDate.value, 'dd/MM/yyyy');
    let calFormat = this.getInitialDate(pickupDate);
    let events = [];
    this.list = [];
    holidays?.forEach(element => {
      let formatDate = element['c'].split('/')
      this.list.push({
        date: this.datepipe.transform(formatDate[2] + '/' + formatDate[1] + '/' + formatDate[0], 'MMMM dd, EEEE'),
        name: element['d'],
        type: element['a']
      })
      events.push(
        {
          date: this.getInitialDate(element['c']),
          className: element['a'] != 'M' ? 'total-holiday' : 'market-holiday',
          display: 'background'
        }
      )
    });
    this.calendarOptions = {
      initialView: 'dayGrid',
      headerToolbar: false,
      titleFormat: { year: 'numeric', month: 'long' },
      initialDate: calFormat,//start week
      firstDay: new Date(calFormat)?.getDay(),
      duration: { weeks: 2 },
      events: events,
      fixedWeekCount: false,
      height: 110,
    };
    this.setStartEndDay(pickupDate.split('/'));
    this.getDayColor(events);
  }

  getDayColor(holidays) {
    if (holidays && holidays.length != 0) {
    let self = this;
        setTimeout( function() {
        holidays.forEach(element => {
          let d = element.date;
            let ele = self.element.nativeElement.querySelector('#miniCal')?.querySelector("[data-date='" + d + "']")?.querySelector('.fc-daygrid-day-number')
            ele.classList.add('day-color')
        }); }, 0);
    }
  }

  setStartEndDay(holidayData) {
    let hdate = new Date(holidayData[1] + '/' + holidayData[0] + '/' + holidayData[2])
    var StartDate = new Date(hdate);
    var EndDate = new Date(hdate.setDate(StartDate.getDate()+ 13)); // only two weeks dates will be shown in calendar.
    this.startDateString = this.datepipe.transform(StartDate, 'MMM dd')
    this.endDateString = this.datepipe.transform(EndDate, 'MMM dd, yyyy')
  }

  getOriginAreaCode(control) {
    if (this.originArea.value) {
      let payload = {
        'a': this.originArea.value,
        'b': true
      }
      let setValueOf = this.originArea;
      this.validateArea(payload, setValueOf, control);
    }
  }

  getDestinationAreaCode(control) {
    if (this.destinationArea.value) {
      let payload = {
        'a': this.destinationArea.value,
        'b': false
      }
      let setValueOf = this.destinationArea;
      this.validateArea(payload, setValueOf, control);
    }
  }

  validateArea(payload, setValueOf, control) {
    let requestBody = payload;
    this.restService
      .get(control['apiUrl'], '',{'a': requestBody['a'], 'b': requestBody['b']})
      .subscribe(
        (response) => {
          if (!response['c']) {
            this.showError(control['name'], '', VALIDATION_STATUS.VALID)
            if (payload['b']) {
              this.originServiceCenterList = response['data'];
            }
            else this.destinationServiceCenterList = response['data']
          }
          else {
            setValueOf.setErrors({ 'pattern': true });
            this.showError(control['name'], this.messages.INVALIDAREACODE);
          }
        },
        (error) => {
          this.showError(control['name'], this.messages.GLOBALAPIERROR);
        }
      );
  }

  getOriginServiceCenter(control) {
    if (control['helpEventRef']) {
      let payload = {
        'a': this.originArea.value,
        'b': true
      }
      this.showHelpDialog(payload, control)
    }
    else {
      if (this.originServiceCenter.value) {
        let payload = {
          'a': this.originServiceCenter.value,
          'b': this.originArea.value,
          'c': true
        }
        let setValueOf = this.originArea;
        this.validateSC(payload, setValueOf, control);
      }
    }
  }

  getDestinationServiceCenter(control) {
    if (control['helpEventRef']) {
      let payload = {
        'a': this.destinationArea.value,
        'b': false
      }
      this.showHelpDialog(payload, control)
    }
    else {
      if (this.destinationServiceCenter.value) {
        let payload = {
          'a': this.destinationServiceCenter.value,
          'b': this.destinationArea.value,
          'c': false
        }
        let setValueOf = this.destinationArea;
        this.validateSC(payload, setValueOf, control);
      }
    }
  }

  validateSC(payload, setValueOf, control) {
    let requestBody = this.getRequestParam(payload);
    this.restService
      .get(control['apiUrl'], '', requestBody)
      .subscribe(
        (response) => {
          if (!response['c']) {
            this.showError(control['name'], '', VALIDATION_STATUS.VALID)
            setValueOf.setValue(response['d']);
          }
          else {
            this.domesticTransit.form.controls[control.name].setErrors({ 'pattern': true })
            let message = payload['c'] ? this.messages.INVALIDORIGINSC : this.messages.INVALIDDESTINATIONSC;
            this.showError(control['name'], message)
          }
        },
        (error) => {
          this.showError(control['name'], this.messages.GLOBALAPIERROR);
        }
      );
  }

  getOriginPincode(control) {
    if (this.originPincode.value) {
      let payload = {
        'a': this.originPincode.value,
        'b': this.originArea.value || null
      }
      let setValueOf = [this.originServiceCenter, this.originArea];
      this.validatePincode(payload, setValueOf, control);
    }
  }

  getDestinationPincode(control) {
    if (this.destinationPicode.value) {
      let payload = {
        'a': this.destinationPicode.value,
        'b': this.destinationArea.value || null
      }
      let setValueOf = [this.destinationServiceCenter, this.destinationArea, this.dttEDL];
      this.validatePincode(payload, setValueOf, control);
    }
  }

  validatePincode(payload, setValueOf, control) {
    payload['spinner'] = 'no';
    payload = this.getRequestParam(payload)
    this.restService
      .get(control['apiUrl'], '', payload)
      .subscribe(
        (response) => {
          if (!response['c']) {
            this.showError(control['name'], '', VALIDATION_STATUS.VALID)
            setValueOf[0].setValue(response['e']);
            setValueOf[1].setValue(response['d']);
            if (setValueOf[2]) {
              if (response['g'].indexOf('EDL') != -1) {
                setValueOf[2].setValue(EDLFLAG.YES);
              } else setValueOf[2].setValue(EDLFLAG.NO);
            }
          }
          else {
            this.domesticTransit.form.controls[control.name].setErrors({ 'pattern': true })
            this.showError(control['name'], this.messages.INVALIDPICODE)
            setValueOf[0].setErrors({ 'invalid': true, message: this.messages.INVALIDPICODE });
          }
        },
        (error) => {
          this.showError(control['name'], this.messages.GLOBALAPIERROR);
        }
      );
  }

  showHelpDialog(payload, field) {
    const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
      width: '' + field.helpDialogWidth + 'px',
      minWidth: field.helpDialogWidth ? field.helpDialogWidth : 400,
      data: {
        title: field.dialogTitle,
        heading: field.dialogTitle,
        helpTableDataColumn: field.helpTableDataColumn ? field.helpTableDataColumn : null,
        payload: payload,
        apiurl: field.helpApiUrl,
        noteText: lbl.SELECT_NOTE_TEXT+field.label,
        gridColumns: field.helpDialogGridColumns ? field.helpDialogGridColumns : null,
      }
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        this.isStaticMessage = true;
        field.formGridMapping.forEach(element => {
          this.domesticTransit.form.controls[element['controlName']].setValue(res[element['gridColumnName']])
        });
      }
    });
  }

  getProductList() {
    let product = this.productList.value;
    let list;
    this.subProductList.enable();
    switch (product) {
      case PRODUCTLIST.PRODUCTA:
        list = PRODUCTSUBPRODUCTLIST.A
        break
      case PRODUCTLIST.PRODUCTD:
        list = PRODUCTSUBPRODUCTLIST.D
        break
      case PRODUCTLIST.PRODUCTE:
        list = PRODUCTSUBPRODUCTLIST.E
        break
      case PRODUCTLIST.PRODUCTG:
        list = PRODUCTSUBPRODUCTLIST.G
        break
      case PRODUCTLIST.PRODUCTALL:
        list = []
        this.subProductList.disable();
        this.subProductList.reset();
        break
    }
    let optionList = {
      options: list,
      targetName: 'dttSubProduct'
    }
    this.sharedService.setSubSelectValues(optionList);
  }

  getRequestParam(formValues) {
    let requestBody = {}
    for (let value in formValues) {
      //payload also contains boolean values hence checking for null and undefined
      if (formValues[value] !== undefined && formValues[value] !== null) requestBody[value] = formValues[value];
    }
    return requestBody;
  }

  setFocus() {
    this.elementRef.nativeElement.querySelector('[name="originArea"]').focus();
  }

  ngOnDestroy() {
    this.domesticTransit.form.reset();
    if (this.eventEmitterService.subsVar) {
      this.eventEmitterService.subsVar.unsubscribe();
    }
  }

  showToasterMessage(message){
    BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND)
    this.alertService.add({
      key: 'bc',
      severity: 'error',
      detail: message,
      life: NOTIFICATIONS.life
    });
  }
}
