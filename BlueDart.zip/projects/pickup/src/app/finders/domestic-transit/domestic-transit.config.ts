import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from 'projects/login/src/assets/labelDataList.json'
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { PRODUCTLIST } from 'projects/pickup/src/app/finders/finders-module.constant';

const domesticTransitValidator = new CommonValidators();
export const domesticTransit = [
    {
        type: 'row',
        rows: [
            {
                class: 'col w85 plr-4',
                type: 'select',
                label: lbl.DTTPRODUCT,
                name: 'dttProduct',
                multiple: false,
                eventRef: 'ddDttProduct',
                options: [
                    {
                        "label": PRODUCTLIST.PRODUCTA,
                        "value": PRODUCTLIST.PRODUCTA
                    },
                    {
                        "label": PRODUCTLIST.PRODUCTD,
                        "value": PRODUCTLIST.PRODUCTD
                    },
                    {
                        "label": PRODUCTLIST.PRODUCTE,
                        "value": PRODUCTLIST.PRODUCTE
                    }, {
                        "label": PRODUCTLIST.PRODUCTG,
                        "value": PRODUCTLIST.PRODUCTG
                    },
                    {
                        "label": PRODUCTLIST.PRODUCTALL,
                        "value": PRODUCTLIST.PRODUCTALL
                    }
                ],
                map: {
                    "label": "label",
                    "value": "value"
                },
                validations: domesticTransitValidator.PRODUCT_REQUIRED_VALIDATOR,
                value: 'ALL',
                updateTargetDropdownName: 'dttSubProduct',
                tabIndex: 1,
            },
            {
                class: 'col w115 plr-4',
                type: 'select',
                label: lbl.DTTSUBPRODUCT,
                name: 'dttSubProduct',
                multiple: false,
                eventRef: 'ddDttSubProduct',
                disabled: true,
                map: {
                    "label": "label",
                    "value": "value"
                },
                tabIndex: 2
            },
            {
                class: 'col w160 p-l-30-r-4',
                type: 'input',
                label: lbl.ORIGINAREA,
                inputType: 'text',
                name: 'originArea',
                validations: domesticTransitValidator.ORIGIN_AREA_REQUIRED_VALIDATOR,
                eventRef: 'txtOriginArea',
                helpApiUrl: apiUrl.DTT_AREA_LIST,
                maxlength: "3",
                helpIcon: true,
                apiUrl: apiUrl.VALIDATE_DTT_AREA_CODE,
                dialogTitle: lbl.HELP_AREA_CODE,
                helpTableDataColumn: 'data',
                helpDialogWidth: 400,
                helpDialogGridColumns: [{
                    field: 'a',
                    header: lbl.AREA_CODE,
                    showFilter: true
                },
                {
                    field: 'b',
                    header: lbl.AREA_NAME,
                    showFilter: true
                }],
                formGridMapping: [
                    {
                        controlName: 'originArea',
                        gridColumnName: 'a'
                    }
                ],
                gridOptions: {
                    isColumnFilter: true,
                    isClickable: true
                },
                id: 'origin-area',
                helpId: 'help-area',
                tabIndex: 3
            },
            {
                class: 'col w135 plr-4',
                type: 'input',
                label: lbl.ORIGINSERVICECENTER,
                inputType: 'text',
                name: 'originServiceCenter',
                validations: domesticTransitValidator.ORIGIN_SERVICE_CENTER_PATTERN_VALIDATOR,
                eventRef: 'txtoriginServiceCenter',
                helpApiUrl: apiUrl.VALIDATE_DTT_AREA_CODE,
                dialogTitle: lbl.HELP_SERVICE_CENTRE,
                helpTableDataColumn: 'data',
                apiUrl: apiUrl.VALIDATE_DTT_SC,
                helpIconComp: true,
                maxlength: "3",
                helpDialogWidth: 500,
                helpDialogGridColumns: [{
                    field: 'a',
                    header: lbl.SERVICE_CENTRE_CODE,
                    showFilter: true
                },
                {
                    field: 'b',
                    header: lbl.SERVICE_CENTRE_NAME,
                    showFilter: true

                }],
                formGridMapping: [
                    {
                        controlName: 'originServiceCenter',
                        gridColumnName: 'a'
                    }
                ],
                gridOptions: {
                    isColumnFilter: true,
                    isClickable: true
                },
                id: 'origin-service-centre',
                helpId: 'help-service-centre',
                tabIndex: 4
            },
            {
                class: 'col w135 plr-4',
                type: 'input',
                label: lbl.ORIGINPINCODE,
                inputType: 'text',
                name: 'originPincode',
                validations: domesticTransitValidator.PINCODE_LENGTH_VALIDATOR,
                eventRef: 'txtOriginPincode',
                apiUrl: apiUrl.VALIDATE_DTT_PINCODE,
                volIcon: 'launch',
                maxlength: "6",
                isNumberField: true,
                tabIndex: 5
            },
            {
                class: 'col w170 p-l-30-r-4',
                type: 'input',
                label: lbl.DESTINATIONAREA,
                inputType: 'text',
                name: 'destinationArea',
                validations: domesticTransitValidator.AREA_CODE_PATTERN_VALIDATOR,
                eventRef: 'txtdestinationArea',
                helpApiUrl: apiUrl.DTT_AREA_LIST,
                apiUrl: apiUrl.VALIDATE_DTT_AREA_CODE,
                helpIcon: true,
                helpTableDataColumn: 'data',
                dialogTitle: lbl.HELP_AREA_CODE,
                maxlength: "3",
                helpDialogWidth: 400,
                helpDialogGridColumns: [{
                    field: 'a',
                    header: lbl.AREA_CODE,
                    showFilter: true
                },
                {
                    field: 'b',
                    header: lbl.AREA_NAME,
                    showFilter: true

                }],
                formGridMapping: [
                    {
                        controlName: 'destinationArea',
                        gridColumnName: 'a'
                    }
                ],
                gridOptions: {
                    isColumnFilter: true,
                    isClickable: true
                },
                id: 'destination-area',
                helpId: 'help-dest-area',
                tabIndex: 6
            },
            {
                class: 'col w145 plr-4',
                type: 'input',
                label: lbl.DESTINATIONSERVICECENTER,
                inputType: 'text',
                name: 'destinationServiceCenter',
                validations: domesticTransitValidator.DESTINATION_SERVICE_CENTER_PATTERN_VALIDATOR,
                eventRef: 'txtdestinationServiceCenter',
                helpApiUrl: apiUrl.VALIDATE_DTT_AREA_CODE,
                helpIconComp: true,
                maxlength: "3",
                helpIconType: 'self',
                apiUrl: apiUrl.VALIDATE_DTT_SC,
                dialogTitle: lbl.HELP_SERVICE_CENTRE,
                helpTableDataColumn: 'data',
                helpDialogWidth: 500,
                helpDialogGridColumns: [{
                    field: 'a',
                    header: lbl.SERVICE_CENTRE_CODE,
                    showFilter: true
                },
                {
                    field: 'b',
                    header: lbl.SERVICE_CENTRE_NAME,
                    showFilter: true

                }],
                formGridMapping: [
                    {
                        controlName: 'destinationServiceCenter',
                        gridColumnName: 'a'
                    }
                ],
                gridOptions: {
                    isColumnFilter: true,
                    isClickable: true
                },
                id: 'destination-service-centre',
                helpId: 'help-dest-sc',
                tabIndex: 7
            },
            {
                class: 'col w160 plr-4',
                type: 'input',
                label: lbl.DESTINATIONPINCODE,
                inputType: 'text',
                name: 'destinationPincode',
                validations: domesticTransitValidator.PINCODE_LENGTH_VALIDATOR,
                eventRef: 'txtdestinationPincode',
                apiUrl: apiUrl.VALIDATE_DTT_PINCODE,
                volIcon: 'launch',
                maxlength: "6",
                isNumberField: true,
                tabIndex: 8
            }],
    },
    {
        type: 'row',
        rows: [
            {
                type: 'empty',
                class: 'col w550 plr-4',
            }
        ]
    },
    {
        type: 'row',
        rows: [
            {
                class: 'col w55 plr-4',
                type: 'input',
                label: lbl.EDL,
                inputType: 'text',
                name: 'dttEDL',
                disabled: true,
                maxlength: "3",
                tabIndex: 9
            },
            {
                class: 'col w130 plr-4',
                type: 'date',
                label: lbl.PICKUP_DATE,
                name: 'pickupdate',
                enablePrevNextYear: true,
                value: new Date(),
                showSelectedDate: true,
                validations: [
                    {
                        name: 'matDatepickerMin',
                        message: 'Invalid Min date'
                    },
                    {
                        name: 'matDatepickerMax',
                        message: 'Invalid Max date'
                    }
                ],
                tabIndex: 10
            },
            {
                class: 'col w85 plr-4',
                type: 'time',
                label: lbl.PICKUPTIME,
                validations: domesticTransitValidator.PICKUP_TIME_PATTERN,
                inputType: 'text',
                name: 'dttPickuptime',
                tabIndex: 11,
                eventRef: 'timeDttPUTime'
            },
            {
                class: 'col w165 p-l-30-r-4',
                type: 'button',
                label: lbl.SEARCH,
                buttonType: 'button',
                classes: {
                    buttonType: 'primary-button',
                },
                eventRef: 'btnDTTSearch',
                apiUrl: apiUrl.SEARCH_DTT,
                id: 'dtt-search',
                tabIndex: 12
            },
            {
                class: 'col w140 plr-4',
                type: 'button',
                label: lbl.DATEWISETT,
                buttonType: 'button',
                classes: {
                    buttonType: 'primary-button',
                },
                eventRef: 'btnDatewiseTT',
                apiUrl: apiUrl.DTT_DATEWISE_SEARCH,
                width: 130,
                id: 'dtt-datewise-search',
                tabIndex: 13
            }]
    }
]

export const infoLabelConfig = {
    height: 40,
    infoLabel: {
        class: 'label-small',
        type: 'static',
    }
}
