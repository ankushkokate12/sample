export const PRODUCTLIST = {
  PRODUCTA: 'A',
  PRODUCTE: 'E',
  PRODUCTR: 'R',
  PRODUCTG: 'G',
  PRODUCTO: 'O',
  PRODUCTP: 'P',
  PRODUCTL: 'L',
  PRODUCTD: 'D',
  PRODUCTI: 'I',
  PRODUCTJ: 'J',
  PRODUCTK: 'K',
  PRODUCTALL: 'ALL'
};

export const EDLFLAG = {
  YES: 'Yes',
  NO: 'No'
};

export const SUBPRODUCTLIST = {
  TCL: 'TCL', //T
  NOSUB: 'No Sub', //empty value
  PREPAID: 'PREPAID', //P
  DARTPLUS: 'DART PLUS', //L
  APEXLITE: 'Apex LITE', //E
  DSP: 'DSP' //R
};

export const PRODUCTSUBPRODUCTLIST = {
  A: [
    {
      label: SUBPRODUCTLIST.TCL,
      value: 'T'
    },
    {
      label: SUBPRODUCTLIST.NOSUB,
      value: ''
    },

    {
      label: SUBPRODUCTLIST.PREPAID,
      value: 'P'
    },
    {
      label: SUBPRODUCTLIST.DARTPLUS,
      value: 'L'
    },
    {
      label: SUBPRODUCTLIST.APEXLITE,
      value: 'E'
    }
  ],
  D: [
    {
      label: SUBPRODUCTLIST.NOSUB,
      value: ''
    }
  ],
  E: [
    {
      label: SUBPRODUCTLIST.DSP,
      value: 'R'
    },
    {
      label: SUBPRODUCTLIST.NOSUB,
      value: ''
    },

    {
      label: SUBPRODUCTLIST.PREPAID,
      value: 'P'
    }
  ],
  G: [
    {
      label: SUBPRODUCTLIST.NOSUB,
      value: ''
    }
  ]
};

export const UNITS = {
  CENTIMETER: "Centimeter",
  METER: "Meter",
  FEET: "Feet",
  MILIMETER: "Milimeter",
  INCHES: "Inches"
}

export const API_ERROR_STATUS = {
  INVALID: "Invalid",
  VALID: "Valid"
}