import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DomesticTransitComponent } from './domestic-transit/domestic-transit.component';

import { FindersComponent } from './finders.component';
import { InternationalTransitComponent } from './international-transit/international-transit.component';
import { PincodeViewComponent } from './pincode-view/pincode-view.component';
import { RatePanelComponent } from './rate-panel/rate-panel.component';
import { VolumetricCalculatorComponent } from './volumetric-calculator/volumetric-calculator.component';

const routes: Routes = [{
  path: '', component: FindersComponent,
  children: [
    { path: '', redirectTo: 'pincode-view', pathMatch: 'full' },
    {
      path: "pincode-view",
      component: PincodeViewComponent
    },
    {
      path: "domestic-transit",
      component: DomesticTransitComponent
    },
    {
      path: "international-transit",
      component: InternationalTransitComponent
    },
    {
      path: "rate-panel",
      component: RatePanelComponent
    },
    {
      path: "volumetric-calculator",
      component: VolumetricCalculatorComponent
    }
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FindersRoutingModule { }
