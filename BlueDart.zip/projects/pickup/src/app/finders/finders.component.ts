import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { PRODUCTLIST } from './finders-module.constant';
import { findersConfig } from './finders.config';
import * as msgs from 'projects/pickup/src/assets/messages.json';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';

@Component({
  selector: 'app-finders',
  templateUrl: './finders.component.html',
  styleUrls: ['./finders.component.scss']
})
export class FindersComponent implements OnInit, OnDestroy {
  findersConfig: FieldConfig[];
  @ViewChild('activeComponent')
  activeComponent: RouterOutlet;
  currentUser: any;

  constructor(private messageService: MessageService, private eventEmitterService: EventEmitterService,
    private router: Router, private authenticationService: AuthenticationService,
    private elementRef: ElementRef, private sharedService: SharedService,
    private dialog: MatDialog, private ngsk: NgShortcutService) {
    this.messageService.sendHeaderShowMessage(true);
    this.findersConfig = findersConfig
    this.eventEmitterService.subsVar = this.eventEmitterService.
      invokeCommonComponentFunction.subscribe((control: string) => {
        switch (control['eventRef']) {
          case 'btnReset': this.resetForm();
            break;
        }
      });
    //shortcut keys for resetForm
    ngsk.push(new NgShortcut('r', () => this.resetForm(), {
      preventDefault: true,
      ctrlKey: true
    }));
    ngsk.push(new NgShortcut('R', () => this.resetForm(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
  }

  ngOnDestroy() {
    if (this.eventEmitterService.subsVar) {
      this.eventEmitterService.subsVar.unsubscribe();
    }
  }

  resetForm() {
    //reset domestic transit time fields
    if (this.router.url.includes('/domestic-transit')) {
      let component = this.activeComponent['component'];
      let formData = component['domesticTransit']
      if (formData['form']?.touched) {
        const confirmDialog = this.openConfirmationDialog();
        confirmDialog.afterClosed().subscribe(result => {
          if (result) {
            component['isShowGrid'] = false;
            component['isShowFullCal'] = false;
            component['isShowCal'] = false;
            let originPincode = formData['form'].get('originPincode').value;

            formData['form'].reset();
            formData['form'].get('dttProduct').setValue(PRODUCTLIST.PRODUCTALL);
            formData['form'].get('pickupdate').setValue(new Date())
            formData['form'].get('dttSubProduct').disable();
            formData['form'].get('originArea').setValue(this.currentUser['area']);
            formData['form'].get('originPincode').setValue(originPincode);

            this.setFocus('originArea');

            this.showError('search', '', VALIDATION_STATUS.VALID);
            this.showError('datewiseSearch', '', VALIDATION_STATUS.VALID);
          }
        });
      }
    }
    //reset international transit time fields
    if (this.router.url.includes('/international-transit')) {
      let component = this.activeComponent['component'];
      let formData = component['internationalTransitForm']
      if (formData['form']?.touched) {
        const confirmDialog = this.openConfirmationDialog();
        confirmDialog.afterClosed().subscribe(result => {
          if (result) {
            formData['form'].reset();
            formData['form'].get('ittIndiaOrigin').setValue(this.currentUser['area'])
            formData['form'].get('ittPickupdate').setValue(new Date());

            component['isShowGrid'] = false;
            component['datewiseTTMessage'] = '';

            this.setFocus('ittIndiaOrigin');
            this.showError('datewiseTT', '', VALIDATION_STATUS.VALID);
            this.showError('search', '', VALIDATION_STATUS.VALID);
          }
        });
      }
    }
    //reset volumetric calculator fields
    if (this.router.url.includes('/volumetric-calculator')) {
      let component = this.activeComponent['component'];
      let formData = component['volumetricForm']
      if (formData['form']?.touched) {
        const confirmDialog = this.openConfirmationDialog();
        confirmDialog.afterClosed().subscribe(result => {
          if (result) {
            formData['form'].reset();
            component['rows'] = [];
            component['totalVolWeight'] = 0;
            formData['form'].get('vcProduct').reset();
            formData['form'].get('units').setValue('Centimeter');
            formData['form'].get('pieces').enable();
            formData['form'].get('rateInKgs').disable();
            formData['form'].get('customerArea').disable();
            formData['form'].get('customerCode').disable();
            component['isToShowTotalWeight'] = false;
            component['group'] = '';
            this.elementRef.nativeElement.querySelector('#vc-product').focus();
            this.showError('pieces', '', VALIDATION_STATUS.VALID);
          }
        });
      }
    }
  }
  //open confirmation popup on click of reset
  openConfirmationDialog() {
    return this.dialog.open(DialogComponent, {
      data: {
        title: msgs.RESET.TITLE,
        message: msgs.RESET.MESSAGE,
        primaryButton: msgs.BUTTON.YES,
        secondaryButton: msgs.BUTTON.NO
      }
    });
  }
  //set focus on fields
  setFocus(name) {
    this.elementRef.nativeElement.querySelector(`[name=${name}]`).focus();
  }

  //set error messages on error panel
  showError(key: string, message: string, type: string = VALIDATION_STATUS.INVALID) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: key,
      message: message,
      status: type,
      screenName: this.router.url
    }
    this.sharedService.setErrorMessage(errorObj);
  }

  onTabChange(tabname) {
    const tabMap = {
      "pincode-view": "finders/pincode-view",
      "domestic-transit": "finders/domestic-transit",
      "international-transit": "finders/international-transit",
      "rate-panel": "finders/rate-panel",
      "volumetric-calculator": "finders/volumetric-calculator"
    }

    this.router.navigate([tabMap[tabname]]);
    // TODO: To restore conditional routereuse
    // this.router.navigate([tabMap[tabname]], { queryParams: { showSnap: "YES" } });
  }

}
