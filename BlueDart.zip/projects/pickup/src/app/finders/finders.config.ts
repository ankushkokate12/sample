import * as lbl from '../../../../login/src/assets/labelDataList.json';

export const findersConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.FINDERS,
        classes: {
          labelHead: true
        }
      },
      {
        class: 'col w130 plr-4',
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        classes: {
          buttonType: 'action-button',
        },
        eventRef: 'btnReset',
      }
    ]
  }
];
