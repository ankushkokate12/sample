import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ToolsModule } from 'projects/tools/src/public-api';
import { DomesticTransitComponent } from './domestic-transit/domestic-transit.component';
import { FindersRoutingModule } from './finders-routing.module';
import { FindersComponent } from './finders.component';
import { InternationalTransitComponent } from './international-transit/international-transit.component';
import { PincodeViewComponent } from './pincode-view/pincode-view.component';
import { RatePanelComponent } from './rate-panel/rate-panel.component';
import { VolumetricCalculatorComponent } from './volumetric-calculator/volumetric-calculator.component';
import { NgShortcutModule } from 'ng-shortcut';

@NgModule({
  declarations: [FindersComponent, DomesticTransitComponent, PincodeViewComponent, InternationalTransitComponent, VolumetricCalculatorComponent, RatePanelComponent],
  imports: [
    CommonModule,
    FindersRoutingModule,
    ToolsModule,
    ToastModule,
    NgShortcutModule.forRoot()
  ],
  providers: [DatePipe, MessageService]
})
export class FindersModule { }
