import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InternationalTransitComponent } from './international-transit.component';

describe('InternationalTransitComponent', () => {
  let component: InternationalTransitComponent;
  let fixture: ComponentFixture<InternationalTransitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InternationalTransitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InternationalTransitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
