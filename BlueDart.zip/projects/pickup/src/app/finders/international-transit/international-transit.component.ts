import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import * as msgs from 'projects/pickup/src/assets/messages.json';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { inforLabelConfig, internationalTransit } from './international-transit.config';
import { MessageService as AlertService } from 'primeng/api';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';

@Component({
  selector: 'app-international-transit',
  templateUrl: './international-transit.component.html',
  styleUrls: ['./international-transit.component.scss']
})
export class InternationalTransitComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  internationalTransitForm: DynamicFormComponent;
  internationalTransit: FieldConfig[];
  isShowGrid: boolean = false;
  pincodeData = [
    {
      field: 'c',
      header: lbl.CITY,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'd',
      header: lbl.SUB_CITY,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'b',
      header: lbl.CITYNAME,
      colWidth: '55px',
      showFilter: true
    },
    {
      field: 'e',
      header: lbl.PINCODE_FROM,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'f',
      header: lbl.PINCODE_TO,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'i',
      header: lbl.ON_FWD_LOC,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'g',
      header: lbl.ADD_DAYS,
      colWidth: '40px',
      showFilter: true
    },
    {
      field: 'k',
      header: lbl.WEEKLY_HOLIDAYS,
      colWidth: '40px',
      showFilter: true
    },
    {
      field: 'l',
      header: lbl.GATEWAY,
      colWidth: '45px',
      showFilter: true
    },
    {
      field: 'h',
      header: lbl.RAS_SERVICE,
      colWidth: '45px',
      showFilter: true
    }
  ];
  transitData = [
    {
      field: 'k',
      header: lbl.CUTOFF_TIME,
      colWidth: '50px',
      showFilter: true
    },
    {
      field: 'l',
      header: lbl.PICKUP_DAY,
      colWidth: '48px',
      showFilter: true
    },
    {
      field: 'j',
      header: lbl.DESTN_AREA,
      colWidth: '48px',
      showFilter: true
    },
    {
      field: 'b',
      header: lbl.MON,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'c',
      header: lbl.TUE,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'd',
      header: lbl.WED,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'e',
      header: lbl.THU,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'f',
      header: lbl.FRI,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'g',
      header: lbl.SAT,
      colWidth: '39px',
      showFilter: true
    },
    {
      field: 'h',
      header: lbl.SUN,
      colWidth: '38px',
      showFilter: true
    }
  ];
  pincodeDetails = [];
  transitTimeDetails = [];
  messages: any;
  isRowClicked: boolean = false;
  filteredData = [];
  fields: any;
  datewiseTTMessage: string;
  currentUser: any;
  tableHeight: string = '46vh';
  isStaticMessage: boolean = false;
  validateCityCodeControl: any;

  constructor(private eventEmitterService: EventEmitterService,
    private restService: RestService,
    private sharedService: SharedService,
    public dialog: MatDialog,
    private datepipe: DatePipe,
    private authenticationService: AuthenticationService,
    private elementRef: ElementRef,
    private router: Router,
    private alertService: AlertService,
    private ngsk: NgShortcutService,
    private element: ElementRef) {

    this.eventEmitterService.subsVar = this.eventEmitterService.
      invokeCommonComponentFunction.subscribe((control: string) => {
        switch (control['eventRef']) {
          case 'txtITTIndiaOrigin': this.validateArea(control);
            break;
          case 'txtIttCountryCode': this.validateCountryCode(control)
            break;
          case 'btnITTSearch': this.searchITT(control);
            break;
          case 'btnITTDatewiseTT': this.searchDatewiseITT(control);
            break;
          case 'txtIttCityCode': this.validateCityCode(control);
            this.validateCityCodeControl = control;
            break;
          case 'txtIttCityName': this.validateCityName(control);
            break;
          case 'txtIttCityPincode': this.validateCityPincode(control);
            break;
        }
      });

    this.sharedService.getPopupData().subscribe(result => {
      if (result.data) {
        this.isStaticMessage = true;
        result.field?.formGridMapping?.forEach(element => {
          this.internationalTransitForm.form.controls[element['controlName']].setValue(result.data[element['gridColumnName']]);
        });
      }
    })
    this.messages = msgs['default'];
    this.messages = msgs['default'];
    //shortcut keys search ITT
    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#itt-search')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#itt-search')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
    //shortcut keys for datewiseTT search
    ngsk.push(new NgShortcut('t', () => this.element.nativeElement.querySelector('#itt-datewise-search')?.click(), {
      preventDefault: true,
      altKey: true
    }));
    ngsk.push(new NgShortcut('T', () => this.element.nativeElement.querySelector('#itt-datewise-search')?.click(), {
      preventDefault: true,
      altKey: true
    }));
    //Shortcutkeys to open help popup
    ngsk.push(new NgShortcut('h', () => {
      this.openHelpPopups();
    }, {
      preventDefault: true,
      altKey: true
    }));
    ngsk.push(new NgShortcut('H', () => {
      this.openHelpPopups();
    }, {
      preventDefault: true,
      altKey: true
    }));
  }
  //open help popups when alt+h key pressed
  openHelpPopups() {
    if (document.activeElement === this.element.nativeElement.querySelector('#itt-origin')) {
      this.element.nativeElement.querySelector('#help-origin')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#itt-country-code')) {
      this.element.nativeElement.querySelector('#help-country-code')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#itt-country-name')) {
      this.element.nativeElement.querySelector('#help-country-name')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#itt-city-code')) {
      this.element.nativeElement.querySelector('#help-city-code')?.click();
    } else if (document.activeElement === this.element.nativeElement.querySelector('#itt-city-name')) {
      this.element.nativeElement.querySelector('#help-city-name')?.click();
    }
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.internationalTransit = internationalTransit;
    this.fields = inforLabelConfig;
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.internationalTransitForm.form.get('ittIndiaOrigin')?.setValue(this.currentUser['area'])
      this.setFocus();
    })
  }

  //get Value
  get ittIndiaOrigin() {
    return this.internationalTransitForm.form.get('ittIndiaOrigin');
  }

  get ittCountryCode() {
    return this.internationalTransitForm.form.get('ittCountryCode');
  }

  get ittCountryName() {
    return this.internationalTransitForm.form.get('ittCountryName');
  }

  get ittCityCode() {
    return this.internationalTransitForm.form.get('ittCityCode');
  }

  get ittCityName() {
    return this.internationalTransitForm.form.get('ittCityName');
  }

  get ittCityPincode() {
    return this.internationalTransitForm.form.get('ittCityPincode');
  }

  get ittPickupdate() {
    return this.internationalTransitForm.form.get('ittPickupdate');
  }

  get ittPickuptime() {
    return this.internationalTransitForm.form.get('ittPickuptime');
  }

  get ittShipmentDate() {
    return this.internationalTransitForm.form.get('ittShipmentDate');
  }

  validateArea(control) {
    let requestBody = {
      'a': this.ittIndiaOrigin.value
    };
    requestBody['spinner'] = 'no';
    if (this.ittIndiaOrigin.valid && this.ittIndiaOrigin.value) {
      this.restService
        .get(control['apiUrl'] + `?a=${this.ittIndiaOrigin.value}&b=true`)
        .subscribe(
          (response) => {
            if (response['c']) {
              this.ittIndiaOrigin.setErrors({ 'pattern': true });
              this.showError(control['name'], this.messages.INVALIDAREACODE);
            }
          },
          (error) => {
            this.showError(control['name'], this.messages.GLOBALAPIERROR);
          }
        );
    }
  }

  validateCountryCode(control) {
    let requestBody = {};
    requestBody['spinner'] = 'no';
    if (this.ittCountryCode.valid && this.ittCountryCode.value) {
      this.restService
        .get(control['apiUrl'] + `?countrycode=${this.ittCountryCode.value}`, requestBody)
        .subscribe(
          (response) => {
            if (response['d']) {
              this.ittCountryName.setValue(response['d']);
            }
            else {
              this.ittCountryCode.setErrors({ 'pattern': true });
              this.showError(control['name'], this.messages.INVALID_COUNTRY_CODE);
            }
          },
          (error) => {
            if (error["error"]["statusCode"] === '2101') {
              this.showError(control['name'], error["error"]["message"]);
            }
            else {
              this.showError(control['name'], this.messages.GLOBALAPIERROR);
            }
          }
        );
    }
  }

  validateCityCode(control, searchControl = '') {
    //citycode, countrycode, country name, cityname
    //if country code is there, get city code list as per country code, else all
    //if selected from popup, next time when clicked should have only citycode of selected country code
    if (control['helpEventRef']) {
      let formValues = {
        'countrycode': this.ittCountryCode.value || '',
      };
      let requestBody = this.getRequestParam(formValues);
      this.showHelpDialog(requestBody, control)
    }
    else {
      if (this.ittCityCode.valid && this.ittCityCode.value) {
        let formValues = {
          'a': this.ittCityCode.value,
          'b': this.ittCountryCode.value || ''
        };
        this.restService
          .get(control['apiUrl'], '', formValues)
          .subscribe(
            (response) => {
              if (!response['c']) {
                if (searchControl) {
                  this.datewiseITT(searchControl);
                } else {
                  if (!this.ittCountryCode.value) this.ittCountryCode.setValue(response['d']);
                  this.ittCityName.setValue(response['i']);
                  if (this.ittCountryName.value !== response['f']) {
                    this.ittCountryName.setValue(response['f']);
                  }
                }
              }
              else {
                this.ittCityCode.setErrors({ 'pattern': true });
                this.showError(control['name'], response['b']);
              }
            },
            (error) => {
              this.showError(control['name'], this.messages.GLOBALAPIERROR);
            }
          );
      }
    }
  }

  validateCityName(control) {
    let formValues = {
      'countrycode': this.ittCountryCode.value
    };
    let requestBody = this.getRequestParam(formValues);
    if (control['helpEventRef']) {
      this.showHelpDialog(requestBody, control)
    }
  }

  validateCityPincode(control) {
    let requestBody = {
      'a': this.ittCityPincode.value
    };
    requestBody['spinner'] = 'no';
    if (this.ittCityPincode.valid && this.ittCityPincode.value) {
      let countryCode = this.ittCountryCode.value ? this.ittCountryCode.value : ''
      this.restService
        .get(control['apiUrl'] + `?a=${this.ittCityPincode.value}&b=${countryCode}`)
        .subscribe(
          (response) => {
            if (response['c']) {
              this.ittCityPincode.setErrors({ 'pattern': true });
              this.showError(control['name'], this.messages.INVALIDPICODE);
            }
          },
          (error) => {
            this.showError(control['name'], this.messages.GLOBALAPIERROR);
          }
        );
    }
  }

  searchITT(control) {
    this.datewiseTTMessage = '';
    this.isShowGrid = false;
    this.ittPickuptime.setErrors(null);
    if (this.ittIndiaOrigin.value) {
      let isValidData = this.ittCityCode.value || this.ittCountryCode.value || this.ittCityName.value || this.ittCityPincode.value;
      let formValues = {
        'a': this.ittIndiaOrigin.value,
        'b': this.ittCountryCode.value,
        'c': this.ittCityCode.value,
        'd': this.ittCityName.value,
        'e': this.ittCityPincode.value
      }
      this.showError('datewiseTT', '', VALIDATION_STATUS.VALID);
      this.showError('search', '', VALIDATION_STATUS.VALID);
      this.showError('ittCityCode', '', VALIDATION_STATUS.VALID);
      this.ittCityCode.setErrors(null);
      this.showError('ittPickuptime', '', VALIDATION_STATUS.VALID);

      if (isValidData &&
        this.ittIndiaOrigin.valid &&
        this.ittCityCode.valid &&
        this.ittCityName.valid &&
        this.ittCityPincode.valid &&
        this.ittPickupdate.valid &&
        this.ittCountryCode.valid) {
        let requestBody = this.getRequestParam(formValues);
        this.restService
          .post(control['apiUrl'], requestBody)
          .subscribe(
            (response) => {
              if (!response['c']) {
                if (response['data1'] && response['data2']) {
                  this.isShowGrid = true;
                  this.isRowClicked = false;
                  this.pincodeDetails = response['data1'];
                  this.transitTimeDetails = response['data2'];
                } else this.showToasterMessage(response['b']);
              }
              else {
                this.isShowGrid = false;
                this.datewiseTTMessage = "";
                this.showError('search', response['b']);
              }
            },
            (error) => {
              this.showError('search', error["error"]["message"]);
            }
          );
      }
      else if (!isValidData) this.showError('search', this.messages.ITTFIELDREQUIREDERROR);
    }
  }

  searchDatewiseITT(control) {
    this.datewiseTTMessage = '';
    this.ittCityCode.setErrors(null);
    this.showError(control['name'], '', VALIDATION_STATUS.VALID);
    if (this.ittCityCode.value) this.validateCityCode(this.validateCityCodeControl, control)
    else this.datewiseITT(control)
  }

  datewiseITT(control) {
    this.isShowGrid = false;
    this.showError('datewiseTT', '', VALIDATION_STATUS.VALID);
    this.showError('search', '', VALIDATION_STATUS.VALID);
    if (!this.ittIndiaOrigin.value) {
      this.ittIndiaOrigin.markAsTouched();
      this.showError('ittIndiaOrigin', this.messages.AREACODEERROR);
      this.ittIndiaOrigin.setErrors({ 'pattern': true });
    }
    else if (!this.ittCityCode.value) {
      this.ittCityCode.markAsTouched();
      this.showError('ittCityCode', this.messages.CITYCODEERROR);
      this.ittCityCode.setErrors({ 'pattern': true });
    }
    else if (!this.ittPickuptime.value) {
      this.ittPickuptime.markAsTouched();
      this.showError('ittPickuptime', this.messages.PICKUPDATEERROR);
      this.ittPickuptime.setErrors({ 'pattern': true });
    }
    else if (!this.ittPickupdate.value) {
      this.ittPickupdate.markAsTouched();
      this.showError('ittPickupdate', this.messages.DATEERROR);
      this.ittPickupdate.setErrors({ 'pattern': true });
    }
    else if (this.ittIndiaOrigin.valid &&
      this.ittCountryCode.valid &&
      this.ittCountryName.valid &&
      this.ittCityName.valid &&
      this.ittCityPincode.valid &&
      this.ittCityCode.valid &&
      this.ittPickupdate.valid &&
      this.ittPickuptime.valid) {
      let requestBody = {
        'a': this.ittIndiaOrigin.value,
        'b': this.ittCityCode.value,
        'c': this.datepipe.transform(this.ittPickupdate.value, 'dd/MM/yyyy'),
        'd': this.ittPickuptime.value
      }
      this.restService
        .post(control['apiUrl'], requestBody)
        .subscribe(
          (response) => {
            if (!response['c']) {
              this.datewiseTTMessage = this.messages.DATEWISETTTITLTE + response['d'];
            }
            else {
              this.isShowGrid = false;
              this.datewiseTTMessage = "";
              this.showToasterMessage(response['b']);
            }
          },
          (error) => {
            this.showError('datewiseTT', error["error"]["message"]);
          }
        );
    }
  }

  showError(key: string, message: string, type: string = VALIDATION_STATUS.INVALID) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: key,
      message: message,
      status: type,
      screenName: this.router.url
    }
    this.sharedService.setErrorMessage(errorObj);
  }

  showHelpDialog(payload, field) {
    const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
      width: '' + field.helpDialogWidth + 'px',
      minWidth: field.helpDialogWidth ? field.helpDialogWidth : 400,
      data: {
        title: field.dialogTitle,
        heading: field.dialogTitle,
        helpTableDataColumn: field.helpTableDataColumn ? field.helpTableDataColumn : null,
        payload: payload,
        apiurl: field.helpApiUrl,
        noteText: lbl.SELECT_NOTE_TEXT + field.label,
        gridColumns: field.helpDialogGridColumns ? field.helpDialogGridColumns : null,
      }
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        this.isStaticMessage = true;
        field.formGridMapping.forEach(element => {
          this.internationalTransitForm.form.controls[element['controlName']].setValue(res[element['gridColumnName']])
        });
        if (field.name == "ittCityCode" || field.name == "ittCityName") {
          this.validateCountryCode(this.internationalTransitForm.fields[0].rows[1]);
        }
      }
    });
  }

  getRequestParam(formValues) {
    let requestBody = {}
    for (let value in formValues) {
      if (formValues[value]) requestBody[value] = formValues[value];
    }
    return requestBody;
  }

  getTransitTimeTabelRow(pincodeData) {
    this.filteredData = this.transitTimeDetails.filter(element => pincodeData['c'] === element['j']);
    this.isRowClicked = true;
  }

  setFocus() {
    this.elementRef.nativeElement.querySelector('[name="ittIndiaOrigin"]').focus();
  }

  showToasterMessage(message) {
    BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
    this.alertService.add({
      key: 'bc',
      severity: 'error',
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  ngOnDestroy() {
    this.internationalTransitForm.form.reset();
    if (this.eventEmitterService.subsVar) {
      this.eventEmitterService.subsVar.unsubscribe();
    }
  }
}
