import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';

const internationalTransitValidator = new CommonValidators();
export const internationalTransit = [
  {
    type: 'row',
    rows: [
      {
        class: 'col w120 plr-4',
        type: 'input',
        label: lbl.INDIAORIGIN,
        inputType: 'text',
        name: 'ittIndiaOrigin',
        validations: internationalTransitValidator.AREA_CODE_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        tabIndex: 1,
        eventRef: 'txtITTIndiaOrigin',
        apiUrl: apiUrl.VALIDATE_DTT_AREA_CODE,
        maxlength: "3",
        helpIcon: true,
        helpApiUrl: apiUrl.ITT_AREA_LIST,
        dialogTitle: lbl.HELP_AREA_CODE,
        helpTableDataColumn: 'data',
        helpDialogWidth: 400,
        helpDialogGridColumns: [{
          field: 'a',
          header: lbl.AREA_CODE,
          showFilter: true
        },
        {
          field: 'b',
          header: lbl.AREA_NAME,
          showFilter: true

        }],
        formGridMapping: [
          {
            controlName: 'ittIndiaOrigin',
            gridColumnName: 'a'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'itt-origin',
        helpId: 'help-origin'
      },
      {
        class: 'col w155 p-l-30-r-4',
        type: 'input',
        label: lbl.COUNTRYCODE,
        inputType: 'text',
        name: 'ittCountryCode',
        tabIndex: 2,
        eventRef: 'txtIttCountryCode',
        validations: internationalTransitValidator.COUNTRY_CODE_PATTERN_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        apiUrl: apiUrl.VALIDATE_COUNTRY_CODE,
        helpIcon: true,
        maxlength: "2",
        helpApiUrl: apiUrl.ITT_COUNTRY_LIST,
        dialogTitle: lbl.HELP_COUNTRY_CODE,
        helpTableDataColumn: 'data',
        helpDialogWidth: 400,
        helpDialogGridColumns: [{
          field: 'b',
          header: lbl.COUNTRYNAME,
          showFilter: true
        },
        {
          field: 'a',
          header: lbl.COUNTRYCODE,
          showFilter: true
        },],
        formGridMapping: [
          {
            controlName: 'ittCountryCode',
            gridColumnName: 'a'
          },
          {
            controlName: 'ittCountryName',
            gridColumnName: 'b'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'itt-country-code',
        helpId: 'help-country-code'
      },
      {
        class: 'col w140 plr-4',
        type: 'input',
        label: lbl.COUNTRYNAME,
        inputType: 'text',
        name: 'ittCountryName',
        validations: internationalTransitValidator.COUNTRY_NAME_PATTERN_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        tabIndex: 3,
        eventRef: 'txtIttCountryName',
        helpIcon: true,
        maxlength: "20",
        helpApiUrl: apiUrl.ITT_COUNTRY_LIST,
        dialogTitle: lbl.HELP_COUNTRY_NAME,
        helpTableDataColumn: 'data',
        helpDialogWidth: 400,
        helpDialogGridColumns: [
          {
            field: 'b',
            header: lbl.COUNTRYNAME,
            showFilter: true
          },
          {
            field: 'a',
            header: lbl.COUNTRYCODE,
            showFilter: true
          }],
        formGridMapping: [
          {
            controlName: 'ittCountryCode',
            gridColumnName: 'a'
          },
          {
            controlName: 'ittCountryName',
            gridColumnName: 'b'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'itt-country-name',
        helpId: 'help-country-name'
      },
      {
        class: 'col w110 plr-4',
        type: 'input',
        label: lbl.CITYCODE,
        inputType: 'text',
        name: 'ittCityCode',
        validations: internationalTransitValidator.CITY_CODE_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        tabIndex: 4,
        eventRef: 'txtIttCityCode',
        apiUrl: apiUrl.ITT_VALIDATE_CITY_CODE,
        helpIconComp: true,
        maxlength: "3",
        minlength: "3",
        helpApiUrl: apiUrl.ITT_CITY_CODE_LIST,
        dialogTitle: lbl.HELP_CITY_CODE,
        helpTableDataColumn: 'data',
        helpDialogWidth: 500,
        helpDialogGridColumns: [{
          field: 'a',
          header: lbl.CITYNAME,
          showFilter: true
        },
        {
          field: 'b',
          header: lbl.CITYCODE,
          showFilter: true

        },
        {
          field: 'c',
          header: lbl.COUNTRYCODE,
          showFilter: true

        }],
        formGridMapping: [
          {
            controlName: 'ittCityCode',
            gridColumnName: 'b'
          },
          {
            controlName: 'ittCountryName',
            gridColumnName: 'd'
          },
          {
            controlName: 'ittCountryCode',
            gridColumnName: 'c'
          },
          {
            controlName: 'ittCityName',
            gridColumnName: 'a'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'itt-city-code',
        helpId: 'help-city-code'
      },
      {
        class: 'col w140 plr-4',
        type: 'input',
        label: lbl.CITYNAME,
        inputType: 'text',
        name: 'ittCityName',
        validations: internationalTransitValidator.CITY_NAME_PATTERN_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        tabIndex: 5,
        eventRef: 'txtIttCityName',
        helpIconComp: true,
        maxlength: "40",
        helpApiUrl: apiUrl.ITT_CITY_CODE_LIST,
        dialogTitle: lbl.HELP_CITY_NAME,
        helpTableDataColumn: 'data',
        helpDialogWidth: 500,
        helpDialogGridColumns: [{
          field: 'a',
          header: lbl.CITYNAME,
          showFilter: true
        },
        {
          field: 'b',
          header: lbl.CITYCODE,
          showFilter: true

        },
        {
          field: 'c',
          header: lbl.COUNTRYCODE,
          showFilter: true

        }],
        formGridMapping: [
          {
            controlName: 'ittCityCode',
            gridColumnName: 'b'
          },
          {
            controlName: 'ittCountryName',
            gridColumnName: 'd'
          },
          {
            controlName: 'ittCountryCode',
            gridColumnName: 'c'
          },
          {
            controlName: 'ittCityName',
            gridColumnName: 'a'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        id: 'itt-city-name',
        helpId: 'help-city-name'
      },
      {
        class: 'col w110 plr-4',
        type: 'input',
        label: lbl.CITYPINCODE,
        inputType: 'text',
        name: 'ittCityPincode',
        validations: internationalTransitValidator.CITY_PINCODE_VALIDATOR,
        regExp: internationalTransitValidator.regexExpressions.ALL_CHARACTERS_WITH_NUMBERS,
        tabIndex: 6,
        eventRef: 'txtIttCityPincode',
        apiUrl: apiUrl.ITT_VALIDATE_PINCODE,
        maxlength: "10"
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'empty',
        class: 'col w550 plr-4',
      }
    ]
  },
  {
    type: 'row',
    class: 'col plr-4',
    rows: [
      {
        class: 'col w130 plr-4 ',
        type: 'date',
        label: lbl.PICKUP_DATE,
        name: 'ittPickupdate',
        enablePrevNextYear: true,
        value: new Date(),
        showSelectedDate: true,
        validations: [
          {
            name: 'matDatepickerMin',
            message: 'Invalid Min date'
          },
          {
            name: 'matDatepickerMax',
            message: 'Invalid Max date'
          }
        ],
        tabIndex: 7
      },
      {
        class: 'col w85 plr-4',
        type: 'time',
        label: lbl.PICKUPTIME,
        validations: internationalTransitValidator.PICKUP_TIME_PATTERN,
        inputType: 'text',
        name: 'ittPickuptime',
        eventRef: 'timeIttPUTime',
        tabIndex: 8
      },
      {
        class: 'col w165 p-l-30-r-4',
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        classes: {
          buttonType: 'primary-button',
        },
        eventRef: 'btnITTSearch',
        tabIndex: 9,
        apiUrl: apiUrl.ITT_SEARCH,
        id: 'itt-search'
      },
      {
        class: 'col w140 plr-4',
        type: 'button',
        label: lbl.DATEWISETT,
        buttonType: 'button',
        classes: {
          buttonType: 'primary-button',
        },
        eventRef: 'btnITTDatewiseTT',
        tabIndex: 10,
        apiUrl: apiUrl.ITT_DATEWISE_SEARCH,
        width: 130,
        id: 'itt-datewise-search'
      }
    ]
  }
];

export const inforLabelConfig = {
  height: 40,
  infoLabel: {
    class: 'label-small',
    type: 'static',
  }
}
