import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pincode-view',
  templateUrl: './pincode-view.component.html',
  styleUrls: ['./pincode-view.component.scss']
})
export class PincodeViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
