import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rate-panel',
  templateUrl: './rate-panel.component.html',
  styleUrls: ['./rate-panel.component.scss']
})
export class RatePanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
