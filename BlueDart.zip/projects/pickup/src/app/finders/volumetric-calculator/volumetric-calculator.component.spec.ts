import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VolumetricCalculatorComponent } from './volumetric-calculator.component';

describe('VolumetricCalculatorComponent', () => {
  let component: VolumetricCalculatorComponent;
  let fixture: ComponentFixture<VolumetricCalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VolumetricCalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VolumetricCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
