import { Component, ElementRef, OnInit, ViewChild, OnDestroy, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import * as msgs from 'projects/pickup/src/assets/messages.json';
import { VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { PRODUCTLIST, UNITS } from '../finders-module.constant';
import { calculateBtnConfig, volumetricCalculatorConfig } from './volumetric-calculator.config';

@Component({
  selector: 'app-volumetric-calculator',
  templateUrl: './volumetric-calculator.component.html',
  styleUrls: ['./volumetric-calculator.component.scss']
})
export class VolumetricCalculatorComponent implements OnInit, OnDestroy {
  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if (event.key == 'Enter' || event.key == "Tab") {
      this.selectNextTab(false);
    }
  } //When user press enter/tab from radio buuton, he will be navigated to VC dimensions grid textbox

  @ViewChild(DynamicFormComponent, { static: false })
  volumetricForm: DynamicFormComponent;
  volumetricCalulator: FieldConfig[];
  calculateButton: FieldConfig[];
  resetButton: FieldConfig[];
  pieces: any;
  calculateVTotalWeight = false;
  group: any;
  fields = {
    height: 59,
    infoLabel: {
      class: 'label-large w-100 text-center',
      type: 'dynamic',
      displayMessage: 'Total Volumetric Weight is '
    }
  };
  data = [
    {
      field: 'a',
      header: msgs.PIECES,
      showTextbox: true
    },
    {
      field: 'b',
      header: msgs.HEIGHT,
      showTextbox: true
    },
    {
      field: 'c',
      header: msgs.LENGTH,
      showTextbox: true
    },
    {
      field: 'd',
      header: msgs.WIDTH,
      showTextbox: true
    },
    {
      field: 'e',
      header: msgs.VOLUMETRIC_WEIGHT,
      actionColumn: true
    }
  ];

  rows = [];
  header = msgs.HEADERTEXT;
  displayValue = msgs.DISPLAYVALUE;
  totalVolWeight = 0;
  disableCalculate = true;
  isMeasurementSelected = false;
  isToShowTotalWeight = false;
  messages: any;
  radioCount: number = 0;

  constructor(
    private eventEmitterService: EventEmitterService,
    private restService: RestService,
    private sharedService: SharedService,
    private router: Router,
    private dialog: MatDialog,
    private ngsk: NgShortcutService,
    private element: ElementRef
  ) {
    this.eventEmitterService.subsVar = this.eventEmitterService.invokeCommonComponentFunction.subscribe(
      (control: string) => {
        switch (control['eventRef']) {
          case 'txtVCPieces':
            this.getPackagingGrid();
            break;
          case 'ddVCProduct':
            this.enableFields();
            break;
          case 'txtCustomerArea':
            this.validateCustomerArea(control);
            break;
          case 'txtCustomerCode':
            this.validateCustomerCode(control);
            break;
          case 'txtrateInKgs':
            this.disableCustomerCodeAndArea();
            break;
        }
      }
    );
    //shortcut keys to calculate Volumetric Weight
    ngsk.push(new NgShortcut('g', () => this.element.nativeElement.querySelector('#calculate-weight')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
    ngsk.push(new NgShortcut('G', () => this.element.nativeElement.querySelector('#calculate-weight')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  get getPieces() {
    return this.volumetricForm.form.get('pieces');
  }

  get productCode() {
    return this.volumetricForm.form.get('vcProduct');
  }

  get rate() {
    return this.volumetricForm.form.get('rateInKgs');
  }

  get customerArea() {
    return this.volumetricForm.form.get('customerArea');
  }

  get customerCode() {
    return this.volumetricForm.form.get('customerCode');
  }

  get unit() {
    return this.volumetricForm.form.get('units');
  }

  ngOnInit(): void {
    this.volumetricCalulator = volumetricCalculatorConfig;
    this.calculateButton = calculateBtnConfig;
    this.rows = [];
    this.messages = msgs['default'];
    this.sharedService.getClearAllEvent().subscribe((res) => {
      if (res) {
        this.isToShowTotalWeight = false;
        this.totalVolWeight = 0;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(res => {
      this.element.nativeElement.querySelector('#vc-product').focus();
      this.unit.valueChanges.subscribe((res) => {
        this.displayValue = this.header + '(In ' + res + ')';
        if (this.rows && this.rows.length > 0) {
          if (this.rows[0].a !== '' && this.rows[0].b !== '' && this.rows[0].c !== '' && this.rows[0].d !== '') {
            this.sendRequestBody(res, true);
          }
        }
      });
    });
  }

  selectNextTab(flag) {
    if (flag) {
      //When product code selected and pieces filed is disable move focus based on the product selected wither to ratnkg or to unit section
      if (this.getPieces.disabled && this.rate.enabled) {
        this.element.nativeElement.querySelector('#rate-in-kgs').focus();
      } else if (this.getPieces.disabled && this.rate.disabled) {
        this.element.nativeElement.querySelector('[type="radio"]').focus();
      }
    }
    else {
      //if user tabs out from product code dropdown without selecting value show error message
      //on Select component this is not handled so adding it on component level
      if (document.activeElement == this.element.nativeElement.querySelector('#vc-product')) {
        if (!this.productCode.value) {
          this.showError('vcProduct', this.messages.PRODUCTCODEERROR);
        }
      }
      //if Focus is on unit section then move focus to grid
      if (document.activeElement?.getAttribute('value')) {
        let radioButtons = Array.from(this.element.nativeElement.querySelectorAll('[type="radio"]'));
        if (radioButtons.length != this.radioCount)
          this.element.nativeElement.querySelectorAll('[type="radio"]')[this.radioCount++].focus();
        else {
          this.radioCount = 0;
          this.element.nativeElement.querySelectorAll('[type="number"]')[1].focus();
        }
      }
    }
  }

  sendRequestBody(unitValue, isMeasurement) {
    let tempRowData = [];
    this.rows.forEach((row) => {
      if(row.a && row.b && row.c && row.d) {
      if (unitValue === UNITS.CENTIMETER) {
        let requestData = {
          a: row.a,
          b: row.b,
          c: row.c,
          d: row.d
        };
        tempRowData.push(requestData);
      } else if (unitValue === UNITS.INCHES) {
        let requestData = {
          a: row.a,
          b: row.b * 2.54,
          c: row.c * 2.54,
          d: row.d * 2.54
        };
        tempRowData.push(requestData);
      } else if (unitValue === UNITS.METER) {
        let requestData = {
          a: row.a,
          b: row.b * 100,
          c: row.c * 100,
          d: row.d * 100
        };
        tempRowData.push(requestData);
      } else if (unitValue === UNITS.MILIMETER) {
        let requestData = {
          a: row.a,
          b: row.b * 0.1,
          c: row.c * 0.1,
          d: row.d * 0.1
        };
        tempRowData.push(requestData);
      } else if (unitValue === UNITS.FEET) {
        let requestData = {
          a: row.a,
          b: row.b * 30.48,
          c: row.c * 30.48,
          d: row.d * 30.48
        };
        tempRowData.push(requestData);
      }
    }
    });
    this.calculateVTotalWeight = true;
    this.isMeasurementSelected = isMeasurement;
    this.calculateVolWeight(tempRowData, 0);
  }

  volCalculation(event) {
    let sum = 0;
    this.rows.forEach((element) => {
      if (element.a !== '') {
        sum = sum + parseInt(element.a);
      }
    });
    for (let row in event.rowData) {
      if (row === event.field) {
        event.rowData[row] = event.inputValue;
      }
    }

    if (
      event.rowData['a'] !== '' &&
      event.rowData['b'] !== '' &&
      event.rowData['c'] !== '' &&
      event.rowData['d'] !== ''
    ) {
      this.calculateVTotalWeight = false;
      if (sum <= this.getPieces.value) {
        this.sendRequestBody(this.unit.value, true);
      }
    } else {
      event.rowData['e'] = '';
    }
    if (event.rowData['a'] == '0') {
      this.showError('pieces', this.messages.PIECESNUMS);
    } else if (sum > this.getPieces.value) {
      this.showError('pieces', this.messages.VCPIECESERROR);
    } else {
      this.showError('pieces', '', VALIDATION_STATUS.VALID);
    }
    if (event.rowData['b'] == '0') {
      this.showError('vcHeight', this.messages.HEIGHTNUMS);
    } else {
      this.showError('vcHeight', '', VALIDATION_STATUS.VALID);
    }
    if (event.rowData['c'] == '0') {
      this.showError('vcLength', this.messages.LENGHTNUMS);
    }else {
      this.showError('vcLength', '', VALIDATION_STATUS.VALID);
    }
    if (event.rowData['d'] == '0') {
      this.showError('vcWidth', this.messages.WIDTHNUMS);
    }else {
      this.showError('vcWidth', '', VALIDATION_STATUS.VALID);
    }
  }

  calculateVolWeight(rowData, i) {
    const volApiUrl = apiUrl.VOLUMETRIC_CALCULATION;
    let requestBody;
    if (this.productCode.value === 'E') {
      requestBody = {
        a: this.productCode.value,
        b: this.rate.value,
        c: this.customerArea.value ? this.customerArea.value : '',
        d: this.customerCode.value ? this.customerCode.value : '000000',
        e: this.calculateVTotalWeight ? this.getValue(rowData, 'b') : [parseFloat(rowData.b).toFixed(2)],
        f: this.calculateVTotalWeight ? this.getValue(rowData, 'c') : [parseFloat(rowData.c).toFixed(2)],
        g: this.calculateVTotalWeight ? this.getValue(rowData, 'd') : [parseFloat(rowData.d).toFixed(2)],
        h: this.calculateVTotalWeight ? this.getValue(rowData, 'a') : [Number(rowData.a)]
      };
    } else {
      requestBody = {
        a: this.productCode.value,
        b: 0,
        c: '',
        d: '000000',
        e: this.calculateVTotalWeight ? this.getValue(rowData, 'b') : [parseFloat(rowData.b).toFixed(2)],
        f: this.calculateVTotalWeight ? this.getValue(rowData, 'c') : [parseFloat(rowData.c).toFixed(2)],
        g: this.calculateVTotalWeight ? this.getValue(rowData, 'd') : [parseFloat(rowData.d).toFixed(2)],
        h: this.calculateVTotalWeight ? this.getValue(rowData, 'a') : [Number(rowData.a)]
      };
    }
    if (!this.productCode.value) {
      this.productCode.markAsTouched();
      this.productCode.setErrors({ pattern: true });
      this.isToShowTotalWeight = false;
      this.showError('vcProduct', this.messages.PRODUCTCODEERROR);
    } else {
      let a = requestBody['e'].some((element) => {
        return !element;
      });
      this.restService.post(volApiUrl, requestBody).subscribe(
        (response) => {
          if (response['a'] === '0') {
            if (this.calculateVTotalWeight && this.isMeasurementSelected) {
              let i=0;
              this.rows.forEach((row) => {
                if(row.a && row.b && row.c && row.d){
                  row.e = response.f[i];
                  i=i+1
                }
                this.totalVolWeight = response['d'];
                this.group = this.totalVolWeight + ' Kg.';
                this.showError('pieces', '', VALIDATION_STATUS.VALID);
              });
            } else {
              this.rows[i].e = response['d'];
            }
          }
        },
        (error) => {
          this.showError('pieces', this.messages.GLOBALAPIERROR);
        }
      );
    }
  }

  calculateTotalWeight() {
      this.showError('pieces', '', VALIDATION_STATUS.VALID);
    if (this.rows && this.rows.length > 1) {
      this.calculateVTotalWeight = true;
    } else {
      this.calculateVTotalWeight = false;
    }
    let sum = 0;
    this.rows.forEach((element) => {
      if (element.a !== '') {
        sum = sum + parseInt(element.a);
      }
    });
    if (sum > this.getPieces.value || sum < this.getPieces.value) {
      this.showError('pieces', this.messages.VCPIECESERROR);
    } else {
      this.sendRequestBody(this.unit.value, true);
      this.isToShowTotalWeight = true;
    }
    if(sum <= this.getPieces.value) {
    this.rows.forEach((element) => {
      if(element.a) {
      if (element.b == '') {
        this.showError('vc1Height', this.messages.HEIGHTBLANK);
        this.isToShowTotalWeight = false;
      }else if (element.b !== ''){
         this.showError('vc1Height', '', VALIDATION_STATUS.VALID);
         }
      if (element.c == '') {
           this.showError('vcLength', this.messages.LENGHTBLANK);
           this.isToShowTotalWeight = false;
       }else if (element.c ! == ''){
          this.showError('vcLength', '', VALIDATION_STATUS.VALID);
          }
       if (element.d == '') {
        this.showError('vcWidth', this.messages.WIDTHBLANK);
        this.isToShowTotalWeight = false;
        } else if (element.d !== ''){
          this.showError('vcWidth', '', VALIDATION_STATUS.VALID);
          }
        }
      });
    }
  }

  getValue(rowData, value) {
    let requestParams = [];
    rowData.forEach((row) => {
      for (let r in row) {
        if (r === value) {
          if (r !== 'a' && row[r]) {
            requestParams.push(parseFloat(row[r]).toFixed(2));
          } else if (r === 'a' && row[r]) {
            requestParams.push(Number(row[r]));
          }
        }
      }
    });
    return requestParams;
  }

  enableFields() {
    if (this.productCode.value === PRODUCTLIST.PRODUCTE) {
      this.rate.enable();
      this.customerArea.enable();
      this.rate.setValue('10.00');
    } else {
      this.rate.disable();
      this.customerArea.disable();
      this.customerCode.disable();
      this.rate.setValue('');
      this.customerArea.setValue('');
      this.customerCode.setValue('');
    }
    this.selectNextTab(true);
  }

  getPackagingGrid() {
    if (this.getPieces.value && this.getPieces.value != 0) {
      this.getPieces.disable();
    } else {
      this.getPieces.enable();
    }
    this.pieces = this.getPieces.value ? parseInt(this.getPieces.value) : '';
    this.displayValue = this.header + '(In ' + this.unit.value + ')';
    this.rows = [];
    for (let i = 0; i < this.getPieces.value; i++) {
      this.rows.push({
        a: '',
        b: '',
        c: '',
        d: ''
      });
    }
  }

  validateCustomerArea(control) {
    if (this.customerArea.value !== null) {
      let requestBody = {
        a: this.volumetricForm.form.get('customerArea').value
      };
      requestBody['spinner'] = 'no';
      this.restService.get(control['apiUrl'] + '?a=' + requestBody.a).subscribe(
        (response) => {
          if (response['a'] === '0') {
            this.showError(control['name'], '', 'VALID');
            this.volumetricForm.form.get('customerArea').setValue(response['d']);
            this.customerCode.enable();
          } else {
            this.customerCode.disable();
            this.showError(control['name'], this.messages.INVALIDCUSTOMERAREA);
            this.volumetricForm.form
              .get('customerArea')
              .setErrors({ pattern: true });
          }
        },
        (error) => {
          this.customerCode.disable();
          this.showError(control['name'], this.messages.GLOBALAPIERROR);
        }
      );
    }
  }

  validateCustomerCode(control) {
    let requestMapping = {
      a: 'customerArea',
      b: 'customerCode'
    };
    let requsteB = {
      a: '',
      b: ''
    };

    for (let map in requestMapping) {
      if (
        this.volumetricForm.form.get(requestMapping[map]) &&
        this.volumetricForm.form.get(requestMapping[map]).value
      ) {
        requsteB[map] = this.volumetricForm.form.get(requestMapping[map]).value;
      }
    }
    if (this.volumetricForm.form.get('customerCode').value) {
      this.restService.get(control['apiUrl'] + '?a=' + requsteB.a + '&b=' + requsteB.b).subscribe(
        (response) => {
          if (response['a'] === '0') {
            this.rate.setValue(response['d']);
            this.rate.disable();
          } else {
            this.showError('customerCode', this.messages.INVALIDCUSTOMERCODE);
            this.volumetricForm.form
              .get('customerCode')
              .setErrors({ pattern: true });
          }
        },
        (error) => {
          this.showError('customerCode', this.messages.GLOBALAPIERROR);
        }
      );
    }
  }

  disableCustomerCodeAndArea() {
    if (this.rate.value === '10.00' || this.rate.value === '10' || this.rate.value === '10.0') {
      this.customerArea.enable();
      this.customerCode.enable();
    } else {
      this.customerCode.disable();
      this.customerArea.disable();
    }
  }
  //TODO: Take 'INVALID' status from constant file
  showError(key: string, message: string, type: string = "INVALID") {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: key,
      message: message,
      status: type,
      screenName: this.router.url
    }
    this.sharedService.setErrorMessage(errorObj);
  }

  ngOnDestroy() {
    this.volumetricForm.form.reset();
    if (this.eventEmitterService.subsVar) {
      this.eventEmitterService.subsVar.unsubscribe();
    }
    this.showError('vcProduct', '', VALIDATION_STATUS.VALID);
  }
}
