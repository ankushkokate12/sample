import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { PRODUCTLIST } from '../finders-module.constant';

const volumetricCalculatorValidator = new CommonValidators();
export const volumetricCalculatorConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.VCSHIPMENTDETAILS,
        class: 'col s12 l12 m12 shipment-details-block',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'select',
                label: lbl.DTTPRODUCT,
                name: 'vcProduct',
                multiple: false,
                eventRef: 'ddVCProduct',
                class: 'col s6 m5 l3  plr-8',
                validations: volumetricCalculatorValidator.PRODUCT_CODE_VALIDATOR,
                map: {
                  label: 'label',
                  value: 'value'
                },
                options: [
                  {
                    label: 'A',
                    value: PRODUCTLIST.PRODUCTA
                  },
                  {
                    label: 'E',
                    value: PRODUCTLIST.PRODUCTE
                  },
                  {
                    label: 'R',
                    value: PRODUCTLIST.PRODUCTR
                  },
                  {
                    label: 'O',
                    value: PRODUCTLIST.PRODUCTO
                  },
                  {
                    label: 'P',
                    value: PRODUCTLIST.PRODUCTP
                  },
                  {
                    label: 'L',
                    value: PRODUCTLIST.PRODUCTL
                  },
                  {
                    label: 'D',
                    value: PRODUCTLIST.PRODUCTD
                  },
                  {
                    label: 'I',
                    value: PRODUCTLIST.PRODUCTI
                  },
                  {
                    label: 'G',
                    value: PRODUCTLIST.PRODUCTG
                  },
                  {
                    label: 'K',
                    value: PRODUCTLIST.PRODUCTK
                  }
                ],
                tabIndex: 1,
                id: 'vc-product'
              },

              {
                type: 'input',
                label: lbl.PIECES,
                inputType: 'text',
                eventRef: 'txtVCPieces',
                class: 'col s6 m5 l2  plr-8',
                maxlength: 5,
                name: 'pieces',
                isNumberField: true,
                validations: volumetricCalculatorValidator.PIECES_VALIDATOR,
                tabIndex: 2,
                regExp: volumetricCalculatorValidator.regexExpressions.ONLY_NUMBER
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.VCRATEINKGS,
                inputType: 'text',
                maxlength: '5',
                name: 'rateInKgs',
                eventRef: 'txtrateInKgs',
                class: 'col s6 m5 l4  plr-8',
                disabled: true,
                tabIndex: 3,
                id: 'rate-in-kgs',
                regExp: volumetricCalculatorValidator.regexExpressions.TWO_DECIMALS
              },
              {
                type: 'input',
                label: lbl.CUSTOMERAREA,
                inputType: 'text',
                name: 'customerArea',
                eventRef: 'txtCustomerArea',
                apiUrl: apiUrl.VALIDATE_VOLUMETRIC_CUSTOMER_AREA,
                class: 'col s6 m5 l3  plr-8',
                disabled: true,
                tabIndex: 4
              },
              {
                type: 'input',
                label: lbl.CUSTOMERCODE,
                inputType: 'text',
                name: 'customerCode',
                eventRef: 'txtCustomerCode',
                apiUrl: apiUrl.VALIDATE_VOLUMETRIC_CUSTOMER_CODE,
                disabled: true,
                class: 'col s6 m5 l2  plr-8',
                tabIndex: 5
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'radiobutton',
                label: lbl.UNIT,
                options: [
                  { label: 'Centimeter', value: 'Centimeter', tabIndex: 6 },
                  { label: 'Inches', value: 'Inches', tabIndex: 7 },
                  { label: 'Meter', value: 'Meter', tabIndex: 8 },
                  { label: 'Milimeter', value: 'Milimeter', tabIndex: 9 },
                  { label: 'Feet', value: 'Feet', tabIndex: 10 }
                ],
                name: 'units',
                value: 'Centimeter',
                eventRef: 'radioBUnits',
                width: 500,
              }
            ]
          }
        ]
      }
    ]
  }
];

export const calculateBtnConfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: lbl.CALCULATE,
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'btnCalculate',
        disabled: true,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        },
        width: 120,
        tabIndex: 34
      }
    ]
  }
];

