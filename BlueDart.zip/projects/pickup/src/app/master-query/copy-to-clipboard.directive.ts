import { Directive, Input, Output, EventEmitter, HostListener } from "@angular/core";

@Directive({
    selector: '[copyToClipboard]'
})
export class copyToClipboard {

    @Input("copyToClipboard")
    public payload: string;

    @HostListener("click", ["$event"])

    public onClick(event: MouseEvent): void {
        event.preventDefault();
        if (!this.payload)
            return;
        let listener = (e: ClipboardEvent) => {
            let clipboard = e.clipboardData || window["clipboardData"];
            clipboard.setData("text", this.payload.toString());
            e.preventDefault();
        };
        document.addEventListener("copy", listener, false)
        document.execCommand("copy");
        document.removeEventListener("copy", listener, false);
    }
}
