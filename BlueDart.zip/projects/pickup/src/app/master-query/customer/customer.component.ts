import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { customerDataConfig } from './customer.config';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import { IGridColumn, FieldConfig, IGridOptions, IOptions } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant'
import { DETAILS, SELECT_FROM_LIST } from 'projects/login/src/assets/labelDataList.json'
import { gridCols, detailsMap } from '../customer/customer.constant'
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { Router } from '@angular/router';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { MessageService as AlertService } from 'primeng/api';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})

export class CustomerComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;

  customerConfig: FieldConfig[];

  gridCols: IGridColumn[] = gridCols;
  detailsMap: IGridOptions[] = detailsMap;
  custDetails: IOptions[];
  rows = [];
  totalRecords = [];
  selectedCustomerRecord = {};
  detailsLabel = DETAILS;
  selectFromListLabel = SELECT_FROM_LIST;
  currentUser: any;

  isTableVisible: boolean;
  showDetails: boolean;

  fields = {
    height: 40,
    infoLabel: {
      class: 'label-small',
      type: 'static',
    }
  }

  creditLabel: string = "";
  tableHeight: string;

  constructor(
    private eventEmitt: EventEmitterService,
    private messageService: MessageService,
    private restService: RestService,
    private sharedService: SharedService,
    private router: Router,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    private ngsk: NgShortcutService,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.customerConfig = customerDataConfig;

    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#customer-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#customer-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#customer-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('R', () => this.element.nativeElement.querySelector('#customer-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

  }

  get custCode() {
    return this.form.form.get('txtCustomerCode');
  }

  get custName() {
    return this.form.form.get('txtCustomerName');
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  ngOnInit(): void {
    let gridTblHt = window.innerHeight - 150 - 20 - 125;
    this.tableHeight = gridTblHt + 'px';
    this.currentUser = this.authenticationService.currentUserValue;
    this.sharedService.getGridRowForHistory().subscribe(record => {
      this.formatDetails(this.getSelectedRecordFromList(record));
    });

    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'txtAreaCodeForCustData':
          this.validateAreaCode(field);
          break;
        case 'searchCustData':
          this.searchCustData(field);
          break;
        case 'resetCustForm':
          this.resetForm();
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      setTimeout(() => {
        const ele = this.element.nativeElement.querySelector('#cdata-area-code')
        ele?.focus();
      }, 0);
    })
    this.populateAreaServiceCode();
  }

  populateAreaServiceCode() {
    this.form.form.controls['txtArea']?.setValue(this.currentUser.area);
  }

  getSelectedRecordFromList(record) {
    this.selectedCustomerRecord = record;
    return this.totalRecords.find(ele => {
      return ele.a == record['a'] && ele.b == record['b']
        && ele.c == record['c'] && ele.d == record['d']
    })
  }

  formatDetails(selectedCust) {
    this.custDetails = this.detailsMap.map(ele => {
      if (ele.field === 'cd') {
        return { label: ele.header, value: selectedCust['c'] + '/' + selectedCust['d'] }
      }
      return { label: ele.header, value: selectedCust[ele.field] ? selectedCust[ele.field] : '-' }
    })
    this.creditLabel = selectedCust['v'] == "1" ? "Codified Cash" : selectedCust['v'] == "2" ? "Credit" : "";
  }

  searchCustData(field) {
    this.setErrorPanel(field.id, "", VALIDATION_STATUS.VALID);
    if (this.area.valid && ((this.custCode.valid && this.custCode.value) || (this.custName.valid && this.custName.value))) {
      const payload = {
        "a": this.area.value,
        "b": this.custCode.value || "",
        "c": this.custName.value || ""
      };

      this.restService.get(field['apiUrl'], '', payload).subscribe(
        (res) => {
          if (res.a) {
            this.resetGridView();
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(res.b);
            //this.setErrorPanel(field.id, res.b, VALIDATION_STATUS.INVALID);
          }
          else if (res.c && res.c.length) {
            this.totalRecords = res.c;
            this.rows = this.initializeTableData(res.c);
            this.formatDetails(this.getSelectedRecordFromList(this.rows[0]));
            this.showDetails = true;
            this.isTableVisible = true;
            this.setCountLabel(res.c.length);
          }
          else {
            this.resetGridView();
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            //this.setErrorPanel(field.id, displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          this.showToaster(err.error.b);
          //this.setErrorPanel(field.id, err.error.b, VALIDATION_STATUS.INVALID);
        })
    }
    else {
      this.setErrorPanel(field.id, displayMsg.CUSTOMERDATA_NOSEARCH_SELECTION, VALIDATION_STATUS.INVALID);
    }
  }

  setCountLabel(count: number = 0) {
    this.customerConfig[0].rows[1].label = count ? count + ' Customer(s) available' : '';
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  showDetailsGrid() {
    this.showDetails = true;
  }

  submit(evt) {
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  resetForm() {
    this.setErrorPanel('customer-search-btn', "", VALIDATION_STATUS.VALID);
    this.form.form.reset();
    this.resetGridView();
  }

  resetGridView() {
    this.rows = [];
    this.custDetails = [];
    this.totalRecords = [];
    this.setCountLabel();
    this.isTableVisible = false;
    this.showDetails = false;
  }

  initializeTableData(data) {
    return data.map(ele => {
      return {
        "a": ele.a,
        "b": ele.b,
        "c": ele.c,
        "d": ele.d,
        "e": ele.k,
        "f": ele.l,
        "g": ele.m,
        "h": ele.n,
        "i": ele.o,
        "j": ele.p,
        "k": ele.q,
        "l": ele.r,
        "m": ele.s,
        "n": ele.t,
        "o": ele.u
      }
    })
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.valid) {
      let payload = {
        "a": this.area.value,   //areaCode
        "b": ""  //serviceCenter
      };

      if (payload) {
        this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
          (res: any) => {
            if (res.a) {
              this.form.form.controls[field.name].setErrors({ 'pattern': true });
              this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
            }
          },
          (err) => {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
          }
        );
      }
    }
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }

    this.resetForm(); // todo: need to remove when we will implement state management
  }

}
