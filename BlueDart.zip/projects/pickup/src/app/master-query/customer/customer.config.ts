import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator.ts';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
const commonValidators = new CommonValidators();

export const customerDataConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.CUSTOMER_DATA,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'customer-reset-btn',
        eventRef: 'resetCustForm',
        tabIndex: 4,
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: 'txtArea',
        eventRef: 'txtAreaCodeForCustData',
        apiUrl: apiUrl.VALIDATE_AREA_CODE,
        validations: commonValidators.AREA_CODE_VALIDATOR,
        class: 'col w90 p-l-0',
        tabIndex: 1,
        maxlength: "3",
        id: 'cdata-area-code'
      },
      {
        type: 'input',
        label: lbl.CUSTOMER_CODE,
        inputType: 'text',
        name: 'txtCustomerCode',
        class: 'col w160 p-l-0',
        tabIndex: 1,
        maxlength: "6"
      },
      {
        type: 'input',
        label: lbl.CUSTOMER_NAME,
        inputType: 'text',
        name: 'txtCustomerName',
        class: 'col w160 p-l-0',
        tabIndex: 2,
        maxlength: "64"
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'customer-search-btn',
        eventRef: 'searchCustData',
        tabIndex: 3,
        class: 'col w150 p-l-0',
        apiUrl: apiUrl.CUSTOMER_DATA_SEARCH,
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];
