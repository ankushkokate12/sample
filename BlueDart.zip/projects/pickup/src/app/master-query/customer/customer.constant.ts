export const gridCols = [
  {
    field: 'a',
    header: 'Cust Code',
    showFilter: true,
    colWidth: '70px'
  },
  {
    field: 'b',
    header: 'Customer Name',
    showFilter: true,
    colWidth: '200px'
  },
  {
    field: 'c',
    header: 'Area',
    showFilter: true,
    colWidth: '50px'
  },
  {
    field: 'd',
    header: 'Service Centre',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'e',
    header: 'Off Credit',
    showFilter: true
  },
  {
    field: 'f',
    header: 'TDD',
    showFilter: true
  },
  {
    field: 'g',
    header: 'Critical Express',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'h',
    header: 'EDL',
    showFilter: true
  },
  {
    field: 'i',
    header: 'FOD',
    showFilter: true
  },
  {
    field: 'j',
    header: 'DOD',
    showFilter: true
  },
  {
    field: 'k',
    header: 'IMP. EXP',
    showFilter: true
  },
  {
    field: 'l',
    header: 'FOV',
    showFilter: true
  }, {
    field: 'm',
    header: 'TCL',
    showFilter: true
  }, {
    field: 'n',
    header: 'P2P',
    showFilter: true
  }, {
    field: 'o',
    header: 'COD',
    showFilter: true
  }
];

export const detailsMap = [
  {
    field: 'a',
    header: 'Customer Code'
  },
  {
    field: 'e',
    header: 'Address'
  },
  {
    field: 'f',
    header: ' '
  },
  {
    field: 'g',
    header: ' '
  },
  {
    field: 'h',
    header: 'Pincode'
  },
  {
    field: 'b',
    header: 'Customer Name'
  },
  {
    field: 'i',
    header: 'Contact Person'
  },
  {
    field: 'cd',
    header: 'Area/SC'
  },
  {
    field: 'j',
    header: 'Telephone'
  }
];
