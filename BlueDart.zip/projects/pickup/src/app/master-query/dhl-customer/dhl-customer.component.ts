import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DhlCustDataConfig } from './dhl-customer.config';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { MessageService as AlertService } from 'primeng/api';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant'
import { SELECT_FROM_LIST } from 'projects/login/src/assets/labelDataList.json'
import { data } from '../dhl-customer/dhl-customer.constant'
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { Router } from '@angular/router';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';

@Component({
  selector: 'app-dhl-customer',
  templateUrl: './dhl-customer.component.html',
  styleUrls: ['./dhl-customer.component.scss']
})

export class DhlCustomerComponent implements OnInit, OnDestroy {
  dhlCustDataConfig;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;

  data: IGridColumn[] = data;
  rows = [];
  isTableVisible = false;
  selectFromListLabel = SELECT_FROM_LIST;
  tableHeight: string;

  constructor(
    private eventEmitt: EventEmitterService,
    private messageService: MessageService,
    private restService: RestService,
    private router: Router,
    private sharedService: SharedService,
    private element: ElementRef,
    private ngsk: NgShortcutService,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.dhlCustDataConfig = DhlCustDataConfig;
    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#dhl-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#dhl-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#dhl-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('R', () => this.element.nativeElement.querySelector('#dhl-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  get custCode() {
    return this.form.form.get('txtCustomerCode');
  }

  get custName() {
    return this.form.form.get('txtCustomerName');
  }

  ngOnInit(): void {
    let gridTblHt = window.innerHeight - 150 - 20 - 125;
    this.tableHeight = gridTblHt + 'px';
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'searchDhlCustData':
          this.searchCustomers(field);
          break;
        case 'resetDhlCustForm':
          this.resetForm();
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      setTimeout(() => {
        const ele = this.element.nativeElement.querySelector('#dhl-customer-code')
        ele?.focus();
      }, 0);
    });

  }

  submit(evt) {
  }

  initializeTableData(data) {
    return data.map(ele => {
      return {
        "a": ele.a,
        "b": ele.b,
        "c": ele.c,
        "d": ele.d,
        "e": ele.e,
        "f": ele.f,
        "g": ele.g
      }
    })
  }

  setCountLabel(count: number = 0) {
    this.dhlCustDataConfig[0].rows[1].label = count ? count + ' Customer(s) available' : '';
  }

  searchCustomers(field) {
    this.setErrorPanel(field.id, "", VALIDATION_STATUS.VALID);
    if ((this.custCode.value && this.custCode.valid) || (this.custName.value && this.custName.valid)) {
      const payload = {
        "a": this.custCode.value || "",
        "b": this.custName.value?.toUpperCase() || ""
      };

      this.restService.get(field['apiUrl'], '', payload).subscribe(
        (res) => {
          if (res && res.length) {
            this.isTableVisible = true;
            this.rows = this.initializeTableData(res);
            this.setCountLabel(this.rows.length);
          }
          else {
            this.resetGridView();
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
           //this.setErrorPanel(field.id, displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.resetGridView();
          this.showToaster(err.error.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.id, err.error.b, VALIDATION_STATUS.INVALID);
        });
    } else {
      this.setErrorPanel(field.id, displayMsg.ONE_SEARCH_CRITERIA, VALIDATION_STATUS.INVALID);
    }
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  resetForm() {
    this.setErrorPanel('dhl-search-btn', "", VALIDATION_STATUS.VALID);
    this.form.form.reset();
    this.resetGridView();
  }

  resetGridView() {
    this.isTableVisible = false;
    this.setCountLabel();
    this.rows = [];
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }

    this.resetForm(); // todo: need to remove when we will implement state management
  }
}
