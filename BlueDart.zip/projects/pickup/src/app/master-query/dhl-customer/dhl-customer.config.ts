import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator.ts';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant.js';
const commonValidators = new CommonValidators();

export const DhlCustDataConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.DHL_CUSTOMER_DATA,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'dhl-reset-btn',
        eventRef: 'resetDhlCustForm',
        tabIndex: 4,
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.CUSTOMER_CODE,
        inputType: 'text',
        name: 'txtCustomerCode',
        validations: commonValidators.CUSTOMER_CODE_VALIDATOR,
        class: 'col w160 p-l-0',
        tabIndex: 1,
        maxlength: "9",
        id: 'dhl-customer-code'
      },
      {
        type: 'input',
        label: lbl.CUSTOMER_NAME,
        inputType: 'text',
        name: 'txtCustomerName',
        class: 'col w160 p-l-0',
        tabIndex: 2,
        maxlength: "45"
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'dhl-search-btn',
        eventRef: 'searchDhlCustData',
        tabIndex: 3,
        class: 'col w150 p-l-0',
        apiUrl: apiUrl.DHL_CUSTOMER_DATA_SEARCH,
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];
