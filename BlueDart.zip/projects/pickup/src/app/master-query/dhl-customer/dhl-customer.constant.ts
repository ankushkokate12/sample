export const data = [
  {
    field: 'a',
    header: 'DHL Code',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'b',
    header: 'Customer Name',
    showFilter: true,
    colWidth: '210px'
  },
  {
    field: 'c',
    header: 'Contact',
    showFilter: true,
    colWidth: '170px'
  },
  {
    field: 'd',
    header: 'Address',
    showFilter: true
  },
  {
    field: 'e',
    header: 'City',
    showFilter: true,
    colWidth: '140px'
  },
  {
    field: 'f',
    header: 'State',
    showFilter: true,
    colWidth: '160px'
  },
  {
    field: 'g',
    header: 'Telephone',
    showFilter: true,
    colWidth: '150px'
  }
];
