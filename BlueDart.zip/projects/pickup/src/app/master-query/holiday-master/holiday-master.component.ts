import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CalendarOptions } from '@fullcalendar/angular';
import { MessageService as AlertService } from 'primeng/api';
import { AUDIO_SETTINGS, MONTH_NAMES, NOTIFICATIONS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers.js';
import * as displayMsg from '../../../assets/messages.json';
import { apiUrl } from '../../pickup-module-api.constant';
import { holidayMasterConfig } from './holiday-master.config';

@Component({
  selector: 'app-holiday-master',
  templateUrl: './holiday-master.component.html',
  styleUrls: ['./holiday-master.component.scss']
})

export class HolidayMasterComponent implements OnInit, AfterViewInit, OnDestroy {
  holidayConfig: FieldConfig[];
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  isCalenderVisible = true;
  calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: '',
      center: 'prev title next',
      right: ''
    },
    titleFormat: { year: 'numeric', month: 'long' },
    fixedWeekCount: false,
    height: 'auto',
    contentHeight: "auto"
  };
  dt = new Date();
  nextOneMonth = this.dt.getMonth() + 1;
  nextTwoMonth = this.dt.getMonth() + 2;
  year = this.dt.getFullYear();
  monthNames = MONTH_NAMES;
  calendarOptionsSmallOne: CalendarOptions = {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: '',
      center: 'title',
      right: ''
    },
    titleFormat: { year: 'numeric', month: 'long' },
    validRange: {
      start: new Date(this.year, this.nextOneMonth),
      end: null
    },
    fixedWeekCount: false,
    height: 'auto',
    aspectRatio: 3,
    showNonCurrentDates: false
  };

  calendarOptionsSmallTwo: CalendarOptions = {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: '',
      center: 'title',
      right: ''
    },
    titleFormat: { year: 'numeric', month: 'long' },
    validRange: {
      start: new Date(this.year, this.nextTwoMonth),
      end: null
    },
    fixedWeekCount: false,
    height: 'auto',
    aspectRatio: 3,
    showNonCurrentDates: false
  };
  smallCalRes: any;
  get locationCode() {
    return this.form.form.get('txtLocation');
  }

  constructor(
    private restService: RestService,
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private datepipe: DatePipe,
    private element: ElementRef,
    private sharedService: SharedService,
    private router: Router,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.holidayConfig = holidayMasterConfig;
  }

  ngOnInit(): void {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      if (field["eventRef"] == 'searchHolidayList')
        this.getHolidayList();
    });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  ngAfterViewInit() {
    var self = this;
    Promise.resolve().then(() => {
      setTimeout(() => {
        const ele = this.element.nativeElement.querySelector('#hf-location')
        ele?.focus();
      }, 0);
    })
    var elements = document.getElementsByClassName("fc-next-button");
    Array.from(elements).forEach(function (element) {
      element.addEventListener('click', self.calenderNav.bind(self, 'next'));
    });

    var elements = document.getElementsByClassName("fc-prev-button");
    Array.from(elements).forEach(function (element) {
      element.addEventListener('click', self.calenderNav.bind(self, 'prev'));
    });
  }

  calenderNav(type, arg) {
    let currentMonth;
    let currentYear;
    if (arg) {
      let currentMonthText = arg.currentTarget.parentElement.innerText;
      const monthYearArr = currentMonthText.split(' ');
      currentYear = monthYearArr[1];

      let index = this.monthNames.indexOf(monthYearArr[0]);
      if (type === 'prev') {
        currentMonth = index + 1;
        this.calendarOptionsSmallOne.validRange = {
          start: null,
          end: new Date(currentYear, currentMonth + 1)
        }
        this.calendarOptionsSmallTwo.validRange = {
          start: null,
          end: new Date(currentYear, currentMonth + 2)
        }
        this.getDayColor();
      }
      else if (type === 'next') {
        currentMonth = index + 1;
        this.calendarOptionsSmallOne.validRange = {
          start: new Date(currentYear, currentMonth),
          end: null
        }
        this.calendarOptionsSmallTwo.validRange = {
          start: new Date(currentYear, currentMonth + 1),
          end: null
        }
        this.getDayColor();
      }
    }
  }

  getDayColor() {
    if (this.smallCalRes && this.smallCalRes.length != 0) {
      let self = this
      setTimeout(function () {
        let smalCal1 = self.getMonthOfCal(self, '#smallCal1');
        let smalCal2 = self.getMonthOfCal(self, '#smallCal2');
        self.smallCalRes.forEach(element => {
          let d = element.date;
          if ((parseInt(d.split('-')[1]) == smalCal1?.month + 1) && d.split('-')[0] == smalCal1?.year) {
            let ele = self.element.nativeElement.querySelector('#smallCal1')?.querySelector("[data-date='" + d + "']")?.querySelector('.fc-daygrid-day-number')
            ele.classList.add('day-color')
          }
          if ((parseInt(d.split('-')[1]) == smalCal2?.month + 1) && d.split('-')[0] == smalCal2?.year) {
            let ele = self.element.nativeElement.querySelector('#smallCal2')?.querySelector("[data-date='" + d + "']")?.querySelector('.fc-daygrid-day-number')
            ele.classList.add('day-color')
          }
        });
      }, 0)
    }
  }

  getMonthOfCal(self, id) {
    let smalCal1 = self.element.nativeElement.querySelector(id)?.querySelector('.fc-toolbar-title')?.innerText;
    let monthArray1 = smalCal1.split(' ');
    let index1 = this.monthNames.indexOf(monthArray1[0]);
    return { month: index1, year: monthArray1[1] }
  }

  submit(evt) {
  }

  getHolidayList() {
    //this.setErrorPanel("holiday", "", VALIDATION_STATUS.VALID);
    if (this.locationCode.valid) {
      const payload = {
        "a": this.locationCode.value.toUpperCase()
      };
      this.restService.get(apiUrl.HOLIDAY_LIST, '', payload).subscribe(
        (res) => {
          if (res.c && res.c.length != 0) {
            this.calendarOptions.events = this.holidayDataMap(res.c);
            this.calendarOptionsSmallOne.events = this.holidayDataMapSmall(res.c);
            this.calendarOptionsSmallTwo.events = this.holidayDataMapSmall(res.c);
            this.isCalenderVisible = true;
            this.smallCalRes = this.holidayDataMapSmall(res.c);
            this.getDayColor();
          } else {
            this.isCalenderVisible = true;
            this.calendarOptions.events = this.holidayDataMap([]);
            this.calendarOptionsSmallOne.events = this.holidayDataMapSmall([]);
            this.calendarOptionsSmallTwo.events = this.holidayDataMapSmall([]);
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            //this.setErrorPanel("holiday", displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.isCalenderVisible = true;
          this.calendarOptions.events = this.holidayDataMap([]);
          this.calendarOptionsSmallOne.events = this.holidayDataMapSmall([]);
          this.calendarOptionsSmallTwo.events = this.holidayDataMapSmall([]);
          this.showToaster(displayMsg.NO_RECORDS_FOUND);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel("holiday", displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
        }
      )
    }
  }

  holidayDataMap(res) {
    return res.map(ele => {
      return {
        "title": ele.d,
        "date": this.datepipe.transform(new Date(this.formatDate(ele.a)), 'yyyy-MM-dd'),
        "className": this.getClassColor(ele.c)
      }
    })

  }
  getClassColor(c) {
    if (c == 'M') {
      return 'green-holiday'
    } else if (c == 'T') {
      return 'red-holiday'
    } else if (c == 'S') {
      return 'skele-holiday'
    }
  }
  holidayDataMapSmall(res) {
    return res.map(ele => {
      return {
        "title": '',
        "date": this.datepipe.transform(new Date(this.formatDate(ele.a)), 'yyyy-MM-dd'),
        "className": this.getClassColorSmall(ele.c),
        "display": 'background'
      }
    })
  }
  getClassColorSmall(c) {
    if (c == 'M') {
      return 'market-color'
    } else if (c == 'T') {
      return 'total-color'
    } else if (c == 'S') {
      return 'skele-color'
    }
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  formatDate(str) {
    let fDate = str.split('/');
    let newDate = fDate[1] + '-' + fDate[0] + '-' + fDate[2];
    return newDate;
  }
}
