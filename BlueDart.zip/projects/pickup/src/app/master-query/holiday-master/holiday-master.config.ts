import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator.ts';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
const commonValidators = new CommonValidators();

export const holidayMasterConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.HOLIDAY_FINDERS,
        classes: {
          labelHead: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.LOCATION,
        inputType: 'text',
        name: 'txtLocation',
        eventRef: 'txtLocationValidate',
        class: 'col s6 m5 l2 xl2 p-l-0',
        tabIndex: 1,
        validations: commonValidators.LOCATION_CODE_VALIDATOR,
        maxlength: "3",
        id: 'hf-location'
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'searchHolidayList',
        tabIndex: 2,
        class: 'col s6 m5 l1 xl2 w-130 p-l-0',
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];
