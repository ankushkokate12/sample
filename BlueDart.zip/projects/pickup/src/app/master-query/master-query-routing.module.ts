import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { DhlCustomerComponent } from './dhl-customer/dhl-customer.component';
import { ServiceCentreListComponent } from './service-centre-list/service-centre-list.component';
import { HolidayMasterComponent } from './holiday-master/holiday-master.component';

const routes: Routes = [
  {
    path: "",
    redirectTo: ""
  },
  {
    path: "holiday",
    component: HolidayMasterComponent
  },
  {
    path: "customer",
    component: CustomerComponent
  },
  {
    path: "dhl-customer",
    component: DhlCustomerComponent
  },
  {
    path: "service-centre-list",
    component: ServiceCentreListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterQueryRoutingModule { }
