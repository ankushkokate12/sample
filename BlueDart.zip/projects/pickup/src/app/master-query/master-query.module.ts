import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { CustomerComponent } from './customer/customer.component';
import { DhlCustomerComponent } from './dhl-customer/dhl-customer.component';
import { ServiceCentreListComponent } from './service-centre-list/service-centre-list.component';
import { MasterQueryRoutingModule } from './master-query-routing.module';
import { ToolsModule } from 'projects/tools/src/public-api';
import { HolidayMasterComponent } from './holiday-master/holiday-master.component';
import { copyToClipboard } from './copy-to-clipboard.directive';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { NgShortcutModule } from 'ng-shortcut';

@NgModule({
  declarations: [
    CustomerComponent,
    DhlCustomerComponent,
    ServiceCentreListComponent,
    HolidayMasterComponent,
    copyToClipboard
  ],
  imports: [
    CommonModule,
    ToolsModule,
    ToastModule,
    MasterQueryRoutingModule,
    NgShortcutModule.forRoot()
  ],
  providers: [DatePipe, MessageService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class MasterQueryModule { }
