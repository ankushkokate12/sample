import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceCentreListComponent } from './service-centre-list.component';

describe('ServiceCentreListComponent', () => {
  let component: ServiceCentreListComponent;
  let fixture: ComponentFixture<ServiceCentreListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceCentreListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceCentreListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
