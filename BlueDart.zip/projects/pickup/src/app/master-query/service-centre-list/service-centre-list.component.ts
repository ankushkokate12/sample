import { Component, OnInit, ViewChild } from '@angular/core';
import { serviceCentreListConfig } from './service-centre-list.config';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import { IGridColumn, FieldConfig, IOptions, IGridOptions } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { DETAILS, SELECT_FROM_LIST } from 'projects/login/src/assets/labelDataList.json'
import { gridCols, detailsMap } from '../service-centre-list/service-centre-list.constant'
import { Router } from '@angular/router';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { MessageService as AlertService } from 'primeng/api';

@Component({
  selector: 'app-service-centre-list',
  templateUrl: './service-centre-list.component.html',
  styleUrls: ['./service-centre-list.component.scss']
})

export class ServiceCentreListComponent implements OnInit {
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;

  serviceCentresConfig: FieldConfig[];
  gridCols: IGridColumn[] = gridCols;
  detailsMap: IGridOptions[] = detailsMap;
  centreDetails: IOptions[];
  rows = [];
  totalSCList = [];

  isTableVisible: boolean;
  showDetails: boolean;
  copyData: string;
  selectedSC: {};
  detailsLabel = DETAILS;
  selectFromListLabel = SELECT_FROM_LIST;
  tableHeight: string;

  constructor(
    private messageService: MessageService,
    private restService: RestService,
    private router: Router,
    private sharedService: SharedService,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.serviceCentresConfig = serviceCentreListConfig;
  }

  ngOnInit(): void {
    let gridTblHt = window.innerHeight - 150 - 20 - 125;
    this.tableHeight = gridTblHt + 'px';
    this.setCountLabel();
    this.sharedService.getGridRowForHistory().subscribe(res =>
      this.getServiceCentreDetails(this.findRecordFromSCList(res).g)
    );

    this.getServiceCentres();
  }

  getServiceCentres() {
   //this.setErrorPanel("serviceCentre", "", VALIDATION_STATUS.VALID);
    this.restService.get(apiUrl.SERVICE_CENTRE_LIST).subscribe(
      (res) => {
        if (res.a) {
          //this.setErrorPanel("serviceCentre", res.b, VALIDATION_STATUS.INVALID);
          this.showToaster(res.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
        else if (res.c && res.c.length) {
          this.totalSCList = res.c;
          this.rows = this.initializeTableData(res.c);
          const sc = this.findRecordFromSCList(this.rows[0]);
          this.getServiceCentreDetails(sc.g);
          this.isTableVisible = true;
          this.setCountLabel(this.rows.length);
        }
        else {
          this.showToaster(displayMsg.NO_RECORDS_FOUND);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel("serviceCentre", displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
        }
      },
      (err) => { });
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setCountLabel(count: number = 0) {
    this.serviceCentresConfig[0].rows[1].label = count ? count + ' Centre(s) available' : '';
  }

  showDetailsGrid() {
    this.showDetails = true;
  }

  getServiceCentreDetails(code: number) {
   //this.setErrorPanel("serviceCentreDetails", "", VALIDATION_STATUS.VALID);
    this.restService.get(apiUrl.SERVICE_CENTRE_DETAILS, '', { "a": code }).subscribe(
      (res) => {
        if (res.a) {
          //this.setErrorPanel("serviceCentreDetails", res.b, VALIDATION_STATUS.INVALID);
          this.showToaster(res.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
        else if (res.c && res.c.length) {
          this.formatDetails(res.c[0]);
          this.prepareCopyData();
          this.showDetails = true;
        }
        else {
          this.centreDetails = [];
          this.showDetails = false;
        }
      },
      (err) => { }
    )
  }

  formatDetails(selectedCentre) {
    this.centreDetails = this.detailsMap.map(ele => {
      return { label: ele.header, value: selectedCentre[ele.field] ? selectedCentre[ele.field] : '-' }
    })
  }

  findRecordFromSCList(serviceCentre) {
    this.selectedSC = serviceCentre;
    return this.totalSCList.find((sc) => {
      if (sc.a == serviceCentre.c && sc.c == serviceCentre.e)
        return sc;
    })
  }

  submit(evt) {
  }

  initializeTableData(data) {
    return data.map(ele => {
      return {
        "a": ele.h,
        "b": ele.j,
        "c": ele.a,
        "d": ele.b,
        "e": ele.c,
        "f": ele.d,
        "g": ele.e,
        "h": ele.f,
        "i": ele.k,
        "j": ele.l
      }
    })
  }

  prepareCopyData() {
    this.copyData = "";
    const headers = ['Address', ' ', 'Pincode', 'Telephone', 'Email ID 1', 'Email ID 2', 'District', 'Taluka'];
    headers.forEach(head => {
      const elements = this.centreDetails.filter(ele => ele.label === head)
      if (elements.length) {
        elements.forEach(ele => {
          this.copyData = this.copyData + (head != ' ' ? (head + ' : ') : '          ') + ele.value + "\n";
        })
      }
    })
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }
}
