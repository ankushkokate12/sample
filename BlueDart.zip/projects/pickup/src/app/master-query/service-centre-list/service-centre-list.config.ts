import * as lbl from 'projects/login/src/assets/labelDataList.json';

export const serviceCentreListConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.SERVICE_CENTRE_LIST,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      }
    ]
  }
];
