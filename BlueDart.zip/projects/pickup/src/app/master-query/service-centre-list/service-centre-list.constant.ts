export const gridCols = [
  {
    field: 'a',
    header: 'Location Type',
    showFilter: true,
    colWidth: '130px'
  },
  {
    field: 'b',
    header: 'Sub-loc Type',
    showFilter: true,
    colWidth: '80px'
  },
  {
    field: 'c',
    header: 'Location Code',
    showFilter: true,
    colWidth: '70px'
  },
  {
    field: 'd',
    header: 'Location Name',
    showFilter: true,
    colWidth: '120px'
  },
  {
    field: 'e',
    header: 'Area',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'f',
    header: 'Area Name',
    showFilter: true,
    colWidth: '140px'
  },
  {
    field: 'g',
    header: 'Branch',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'h',
    header: 'Region',
    showFilter: true,
    colWidth: '80px'
  },
  {
    field: 'i',
    header: 'Is Embargo?',
    showFilter: true
  },
  {
    field: 'j',
    header: 'Is Closed?',
    showFilter: true
  }
];

export const detailsMap = [
  {
    field: 'a',
    header: 'Address'
  },
  {
    field: 'b',
    header: ' '
  },
  {
    field: 'c',
    header: ' '
  },
  {
    field: 'e',
    header: ' '
  },
  {
    field: 'd',
    header: 'Pincode'
  },
  {
    field: 'p',
    header: 'District'
  },
  {
    field: 'q',
    header: 'Taluka'
  },
  {
    field: 'e',
    header: 'State'
  },
  {
    field: 'h',
    header: 'Telephone'
  },
  {
    field: 'f',
    header: 'Contact Person'
  },
  {
    field: 'n',
    header: 'Email ID 1'
  },
  {
    field: 'o',
    header: 'Email ID 2'
  },
  {
    field: 'i',
    header: 'STD Code'
  },
  {
    field: 'k',
    header: 'RSP'
  },
  {
    field: 'l',
    header: 'Embargo'
  },
  {
    field: 'r',
    header: 'Closed'
  }
];
