import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MessageService as AlertService } from 'primeng/api';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent } from 'projects/tools/src/public-api';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { RestService } from 'projects/tools/src/lib/rest.service';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { addConfig, editConfig, viewConfig } from './entry.config';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { landmarkPopupCols } from 'projects/pickup/src/app/app.constant';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';

@Component({
  selector: 'app-entry',
  templateUrl: './entry.component.html',
  styleUrls: ['./entry.component.scss']
})
export class EntryComponent implements OnInit, OnDestroy {
  entryConfig;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  currentUser: any;

  constructor(
    private router: Router,
    private eventEmitt: EventEmitterService,
    private restService: RestService,
    private messageService: MessageService,
    public dialog: MatDialog,
    private sharedService: SharedService,
    private datepipe: DatePipe,
    private alertService: AlertService,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    private ngsk: NgShortcutService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    if (this.router.url.includes('/edit')) {
      this.entryConfig = editConfig;
      ngsk.push(new NgShortcut('s', () => this.element.nativeElement.querySelector('#msg-edit-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('c', () => this.element.nativeElement.querySelector('#msg-edit-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('S', () => this.element.nativeElement.querySelector('#msg-edit-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('C', () => this.element.nativeElement.querySelector('#msg-edit-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));
    }
    else if (this.router.url.includes('/add')) {
      this.entryConfig = addConfig;
      ngsk.push(new NgShortcut('s', () => this.element.nativeElement.querySelector('#msg-add-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#msg-add-reset-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('c', () => this.element.nativeElement.querySelector('#msg-add-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('l', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#msg-add-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('h', () => {
        if (document.activeElement == this.element.nativeElement.querySelector('#msg-add-pickup-route')) {
          this.element.nativeElement.querySelector('#msg-add-pickup-route-help')?.click();
        }
        else if (document.activeElement == this.element.nativeElement.querySelector('#msg-add-service-centre')) {
          this.element.nativeElement.querySelector('#msg-add-service-centre-help')?.click();
        }
      }, {
        preventDefault: true,
        altKey: true
      }));

      ngsk.push(new NgShortcut('S', () => this.element.nativeElement.querySelector('#msg-add-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('R', () => this.element.nativeElement.querySelector('#msg-add-reset-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('C', () => this.element.nativeElement.querySelector('#msg-add-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('L', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#msg-add-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('H', () => {
        if (document.activeElement == this.element.nativeElement.querySelector('#msg-add-pickup-route')) {
          this.element.nativeElement.querySelector('#msg-add-pickup-route-help')?.click();
        }
        else if (document.activeElement == this.element.nativeElement.querySelector('#msg-add-service-centre')) {
          this.element.nativeElement.querySelector('#msg-add-service-centre-help')?.click();
        }
      }, {
        preventDefault: true,
        altKey: true
      }));
    }
    else if (this.router.url.includes('/view')) {
      this.entryConfig = viewConfig;
      ngsk.push(new NgShortcut('e', () => {
        if (!this.element.nativeElement.querySelector('#msg-view-edit-btn')?.disabled)
          this.element.nativeElement.querySelector('#msg-view-edit-btn')?.click()
      }, {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('E', () => {
        if (!this.element.nativeElement.querySelector('#msg-view-edit-btn')?.disabled)
          this.element.nativeElement.querySelector('#msg-view-edit-btn')?.click()
      }, {
        preventDefault: true,
        ctrlKey: true
      }));
    }
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCentre');
  }

  get pickupRoute() {
    return this.form.form.get('txtPURouteCode');
  }

  get regDate() {
    return this.form.form.get('txtRegistrationDate');
  }

  get message() {
    return this.form.form.get('txtMessage');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'backToSearch':
          this.cancelConfirmation();
          break;
        case 'txtAreaCodeForMessage':
          this.validateAreaCode(field);
          break;
        case 'txtServiceCentreForMessage':
          field['helpEventRef'] ? this.openHelpDialogForServiceCentre(field) : this.validateServiceCentreCode(field);
          break;
        case 'txtPURouteCodeForMessageEntry':
          field["helpEventRef"] ? this.openHelpDialogForRouteCode(field) : this.validatePickupRoute(field);
          break;
        case 'editMessageEntry':
          this.editMessageEntry(field);
          break;
        case 'resetMessageForm':
          this.resetForm();
          break;
        case 'backToSearchForView':
          this.backToSearch();
          break;
        case 'cancelEntry':
          this.cancelConfirmation();
          break;
        case 'saveMessageEntryForEdit':
          this.updateMessage(field);
          break;
        case 'saveMessageEntryForAdd':
          this.saveMessage(field);
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      if (this.router.url.includes('/edit')) {
        this.populateForm();
        this.disableForm();
        this.enableMessageText();
        this.setMessageNumberLabel();
      } else if (this.router.url.includes('/add')) {
        this.setFocusAndValue();
      } else if (this.router.url.includes('/view')) {
        this.populateForm();
        this.disableForm();
        this.checkEditStatus();
        this.setMessageNumberLabel();
      }
    });
  }

  setFocusAndValue() {
    setTimeout(() => {
      const ele = this.element.nativeElement.querySelector('#area-code')
      ele?.focus();
    }, 0);
    this.form.form.controls["txtRegistrationDate"]?.setValue(new Date());
    this.form.form.controls['txtArea']?.setValue(this.currentUser.area);
    this.form.form.controls['txtServiceCentre']?.setValue(this.currentUser.location);
  }

  setMessageNumberLabel() {
    this.entryConfig[0].rows[2].label = this.sharedService.getData()['messageNo'] ? "Msg No: " + this.sharedService.getData()['messageNo'] : null;
  }

  populateForm() {
    const data = this.sharedService.getData();
    const control = this.form.form.controls;
    control['txtArea']?.setValue(data['areaCode']);
    control['txtServiceCentre']?.setValue(data['serviceCentre']);
    control['txtPURouteCode']?.setValue(data['routeCode']);
    control['txtRegistrationDate']?.setValue(data['registrationDate']);
    control['txtMessage']?.setValue(data['message']);
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  openLandmarkDetailsPopup() {
    if (this.serviceCentre.value) {
      const payload = {
        "a": this.serviceCentre.value
      };

      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '600px',
        minWidth: 400,
        data: {
          title: displayMsg.LANDMARK_DETAILS,
          apiurl: apiUrl.LANDMARK_DETAILS,
          gridColumns: landmarkPopupCols,
          payload: payload,
          fieldname: "Route Code",
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls["txtPURouteCode"].setValue(ress);
        }
      });
    }
  }

  openHelpDialogForServiceCentre(field) {
    if (this.area.value && !this.serviceCentre.disabled) {
      let payload = {
        "a": this.area.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: field.dialogTitle,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          helpTableDataColumn: field.helpTableDataColumn,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.SERVICE_CENTRE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls[field.name]?.setValue(ress);
        }
      });
    }
  }

  editMessageEntry(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    const payload = {
      "a": this.sharedService.getData()['messageNo'],
      "b": this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy')
    }

    this.restService.get(field['validateEditApi'], '', payload).subscribe(
      (res) => {
        if (res.c) {
          this.setErrorPanel(field.name, res.b, VALIDATION_STATUS.INVALID);
        } else {
          this.router.navigate(['message/edit']);
        }
      },
      (err) => {
        this.setErrorPanel(field.name, err.error.b, VALIDATION_STATUS.INVALID);
      }
    )
  }

  cancelConfirmation() {
    const isDataAvailable = Object.keys(this.form.form.value).some(k => !!this.form.form.value[k])
    if (isDataAvailable) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.CANCEL.TITLE,
          message: displayMsg.CANCEL.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result === true) {
          this.backToSearch();
        }
      });
    } else {
      this.backToSearch();
    }
  }

  backToSearch() {
    this.router.navigate(['/message']);
  }

  submit(evt) {
    console.log(evt);
  }

  resetForm() {
    if (this.form.form.dirty || this.form.form.touched) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.RESET.TITLE,
          message: displayMsg.RESET.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.form.form.reset();
          this.setFocusAndValue();
        }
      });
    }
  }

  disableForm() {
    this.form.form.disable();
  }

  checkEditStatus() {
    const regDate = this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy');
    const todayDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
    this.entryConfig[0].rows[3]['disabled'] = (regDate !== todayDate);
  }

  enableMessageText() {
    this.form.form.controls['txtMessage'].enable();
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.area.valid) {
      const payload = {
        "a": this.area.value,   //areaCode
        "b": this.serviceCentre.value  //serviceCentre
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateServiceCentreCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.serviceCentre.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          ;
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePickupRoute(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.value && this.pickupRoute.value && this.pickupRoute.valid) {
      const payload = {
        "a": this.pickupRoute.value,
        "b": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res) => {
          if (res.c) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  openHelpDialogForRouteCode(field) {
    if (this.serviceCentre.value && !this.pickupRoute.disabled) {
      const payload = {
        "a": this.serviceCentre.value
      };

      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_ROUTE_TITLE,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          helpTableDataColumn: field.helpTableDataColumn,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(value => {
        if (value) {
          this.form.form.controls[field.name]?.setValue(value);
          let errorObj = {};
          errorObj[field.name] = {
            error: "required",
            label: "",
            message: "",
            status: VALIDATION_STATUS.VALID,
            screenName: this.router.url
          }
          this.sharedService.setErrorMessage(errorObj);
        }
      });
    }
  }

  saveMessage(field) {
    if (this.form.form.valid) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.SAVE.TITLE,
          message: displayMsg.SAVE.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.saveMessageData(field)
        }
      });
    } else this.form.validateAllFormFields(this.form.form);
  }

  saveMessageData(field) {
    const payload = {
      "a": this.area.value,
      "b": this.serviceCentre.value,
      "c": this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy'),
      "d": "",
      "e": this.pickupRoute.value,
      "f": this.message.value,
      "g": ""     //employeeCode
    };

    this.restService.post(field['apiUrl'], JSON.stringify(payload)).subscribe(
      (res) => {
        if (res.a) {
          this.showToaster(res.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        } else {
          this.showToaster(res.b, 'success');
          const dataToSend = {
            'areaCode': res.d[0].a,
            'registrationDate': new Date(res.d[0].b.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3")),
            'serviceCentre': res.d[0].c,
            'messageNo': res.d[0].e,
            'routeCode': res.d[0].d,
            'message': res.d[0].f
          }

          this.sharedService.setData(dataToSend);
          setTimeout(() => this.router.navigate(['message/view']), 1000);
        }
      },
      (err) => {
        if (err.error.a) {
          this.showToaster(err.error.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      })
  }

  updateMessage(field) {
    if (this.form.form.valid) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.SAVE.TITLE,
          message: displayMsg.SAVE.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.updateMessageData(field)
        }
      });
    } else this.form.validateAllFormFields(this.form.form);
  }

  updateMessageData(field) {
    const payload = {
      "a": this.area.value,
      "b": this.serviceCentre.value,
      "c": this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy'),
      "d": this.sharedService.getData()['messageNo'],
      "e": this.pickupRoute.value,
      "f": this.message.value,
      "g": ""     //employeeCode
    };

    this.restService.put(field['apiUrl'], JSON.stringify(payload)).subscribe(
      (res) => {
        if (res.a) {
          this.showToaster(res.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        } else {
          this.showToaster(res.b, 'success');
          const dataToSend = {
            'areaCode': this.area.value,
            'registrationDate': this.regDate.value,
            'serviceCentre': this.serviceCentre.value,
            'messageNo': this.sharedService.getData()['messageNo'],
            'routeCode': this.pickupRoute.value,
            'message': this.message.value
          }

          this.sharedService.setData(dataToSend);
          setTimeout(() => this.router.navigate(['message/view']), 1000);
        }
      },
      (err) => {
        if (err.error.a) {
          this.showToaster(err.error.b);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      })
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }
}
