import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { pickupRouteList } from 'projects/pickup/src/app/app.constant';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant.js';
const commonValidators = new CommonValidators();

export const addConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: lbl.ARROW_BACK_IOS,
        name: 'backToSearch',
        trigerOnClick: 'true',
        eventRef: 'backToSearch',
        buttonType: 'button',
        tabIndex: 9,
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'label',
        label: lbl.MESSAGE_ADD,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        name: 'addMessageEntry',
        trigerOnClick: 'true',
        id: 'msg-add-reset-btn',
        tabIndex: 8,
        eventRef: 'resetMessageForm',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.PRIMARY_DETAILS,
        class: 'col s12 l6 m12 xl6 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.AREA,
                inputType: 'text',
                name: 'txtArea',
                tabIndex: 1,
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col s6 m5 l2 xl2 p-l-0',
                eventRef: 'txtAreaCodeForMessage',
                apiUrl: apiUrl.VALIDATE_AREA_CODE,
                maxlength: "3",
                id: 'area-code'
              },
              {
                type: 'input',
                label: lbl.SERVICE_CENTER,
                inputType: 'text',
                name: 'txtServiceCentre',
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 2,
                eventRef: 'txtServiceCentreForMessage',
                apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
                maxlength: "3",
                id: 'msg-add-service-centre',
                helpId: 'msg-add-service-centre-help',
                helpIconComp: true,
                helpEventRef: false,
                submitValue: 'Service Centre',
                helpDialogWidth: 600,
                dialogTitle: 'Service Centre Data',
                helpTableDataColumn: 'c',
                helpDialogGridColumns: [
                  {
                    field: 'a',
                    header: 'Service Centre',
                    showFilter: true
                  },
                  {
                    field: 'b',
                    header: 'Service Centre Name',
                    showFilter: true
                  }
                ],
                formGridMapping: [
                  {
                    controlName: 'serviceCentre',
                    gridColumnName: 'a'
                  }
                ],
                gridOptions: {
                  isColumnFilter: true,
                  isClickable: true
                },
                helpApiUrl: apiUrl.SERVICE_CENTRES_LIST
              },
              {
                type: 'date',
                label: lbl.REGISTRATION_DATE,
                name: 'txtRegistrationDate',
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 3,
                enableDateDays: 3,
                validations: commonValidators.REG_DATE_VALIDATOR,
              },
              {
                type: 'input',
                label: lbl.PICKUP_ROUTE,
                inputType: 'text',
                name: 'txtPURouteCode',
                id: 'msg-add-pickup-route',
                validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
                helpId: 'msg-add-pickup-route-help',
                helpIconComp: true,
                submitValue: 'Route Code',
                helpDialogWidth: 500,
                helpDialogGridColumns: pickupRouteList,
                helpApiUrl: apiUrl.ROUTE_CODES,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 4,
                eventRef: 'txtPURouteCodeForMessageEntry',
                apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
                maxlength: "2"
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.MESSAGE,
        class: 'col s12 l6 m12 xl6 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'textarea',
                label: lbl.MESSAGE,
                inputType: 'text',
                name: 'txtMessage',
                class: 'col s12 m12 l12 xl12 p-l-0 p-r-0 m-b-xs',
                validations: commonValidators.MESSAGE_VALIDATOR,
                tabIndex: 5,
                rows: 5
              }
            ]
          }
        ]
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: lbl.CANCEL,
        tabIndex: 7,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'msg-add-cancel-btn',
        eventRef: 'cancelEntry',
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      },
      {
        type: 'button',
        label: lbl.SAVE,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'msg-add-save-btn',
        eventRef: 'saveMessageEntryForAdd',
        tabIndex: 6,
        apiUrl: apiUrl.SAVE_MESSAGE,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        }
      }
    ]
  }
]


export const editConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: lbl.ARROW_BACK_IOS,
        name: 'backToSearch',
        buttonType: 'button',
        tabIndex: 8,
        trigerOnClick: 'true',
        eventRef: 'backToSearch',
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'label',
        label: lbl.MESSAGE_EDIT,
        classes: {
          labelHead: true
        }
      },
      {
        class: 'col s6 m5 l6 xl1 p-l-0',
        label: '',
        type: 'infoLabel',
        height: 40,
        infoLabel: {
          class: 'label-small header',
          type: 'static',
        },
        infoLabelControl: true
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.PRIMARY_DETAILS,
        class: 'col s12 l6 m12 xl6 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.AREA,
                inputType: 'text',
                name: 'txtArea',
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col s6 m5 l2 xl2 p-l-0',
                tabIndex: 1,
                eventRef: 'txtAreaCodeForMessage',
                apiUrl: apiUrl.VALIDATE_AREA_CODE,
                maxlength: "3"
              },
              {
                type: 'input',
                label: lbl.SERVICE_CENTER,
                inputType: 'text',
                name: 'txtServiceCentre',
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 2,
                helpIconComp: true,
                eventRef: 'txtServiceCentreForMessage',
                apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
                maxlength: "3"
              },
              {
                type: 'date',
                label: lbl.REGISTRATION_DATE,
                name: 'txtRegistrationDate',
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 3,
                enableDateDays: 1,
                validations: commonValidators.REG_DATE_VALIDATOR
              },
              {
                type: 'input',
                label: lbl.PICKUP_ROUTE,
                inputType: 'text',
                name: 'txtPURouteCode',
                validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
                helpIconComp: true,
                submitValue: 'Route Code',
                helpDialogWidth: 500,
                helpTableHead: pickupRouteList,
                helpApiUrl: apiUrl.ROUTE_CODES,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 4,
                eventRef: 'txtPURouteCodeForMessageEntry',
                apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
                maxlength: "2"
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.MESSAGE,
        class: 'col s12 l6 m12 xl6 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'textarea',
                label: lbl.MESSAGE,
                inputType: 'text',
                name: 'txtMessage',
                validations: commonValidators.MESSAGE_VALIDATOR,
                class: 'col s12 m12 l12 xl12 p-l-0 p-r-0 m-b-xs',
                tabIndex: 5,
                rows: 5
              }
            ]
          }
        ]
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'button',
        label: lbl.CANCEL,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'msg-edit-cancel-btn',
        eventRef: 'cancelEntry',
        tabIndex: 7,
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      },
      {
        type: 'button',
        label: lbl.SAVE,
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'saveMessageEntryForEdit',
        id: 'msg-edit-save-btn',
        tabIndex: 6,
        newLine: true,
        apiUrl: apiUrl.SAVE_MESSAGE,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        }
      }
    ]
  }
]

export const viewConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: lbl.ARROW_BACK_IOS,
        buttonType: 'button',
        name: 'backToSearch',
        trigerOnClick: 'true',
        tabIndex: 7,
        eventRef: 'backToSearchForView',
        classes: {
          buttonType: 'action-button'
        }
      },
      {
        type: 'label',
        label: lbl.MESSAGE_VIEW,
        classes: {
          labelHead: true
        }
      },
      {
        class: 'col s6 m5 l6 xl1 p-l-0',
        label: '',
        type: 'infoLabel',
        height: 40,
        infoLabel: {
          class: 'label-small header',
          type: 'static',
        },
        infoLabelControl: true
      },
      {
        type: 'button',
        label: lbl.EDIT,
        buttonType: 'button',
        name: 'editMessageEntry',
        id: 'msg-view-edit-btn',
        trigerOnClick: 'true',
        tabIndex: 6,
        eventRef: 'editMessageEntry',
        validateEditApi: apiUrl.IS_EDIT_MESSAGE_ALLOWED,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.PRIMARY_DETAILS,
        class: 'col s12 l6 m12 xl6 p-l-0 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'input',
                label: lbl.AREA,
                inputType: 'text',
                name: 'txtArea',
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col s6 m5 l2 xl2 p-l-0',
                tabIndex: 1,
                eventRef: 'txtAreaCodeForMessage',
                apiUrl: apiUrl.VALIDATE_AREA_CODE,
                maxlength: "3"
              },
              {
                type: 'input',
                label: lbl.SERVICE_CENTER,
                inputType: 'text',
                name: 'txtServiceCentre',
                helpIconComp: true,
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 2,
                eventRef: 'txtServiceCentreForMessage',
                apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
                maxlength: "3"
              },
              {
                type: 'date',
                label: lbl.REGISTRATION_DATE,
                name: 'txtRegistrationDate',
                tabIndex: 3,
                class: 'col s6 m5 l3 xl3 p-l-0',
                enableDateDays: 3,
                validations: commonValidators.REG_DATE_VALIDATOR
              },
              {
                type: 'input',
                label: lbl.PICKUP_ROUTE,
                inputType: 'text',
                name: 'txtPURouteCode',
                validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
                helpIconComp: true,
                submitValue: 'Route Code',
                helpDialogWidth: 500,
                helpTableHead: pickupRouteList,
                helpApiUrl: apiUrl.ROUTE_CODES,
                class: 'col s6 m5 l3 xl3 p-l-0',
                tabIndex: 4,
                eventRef: 'txtPURouteCodeForMessageEntry',
                apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
                maxlength: "2"
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          },
          {
            type: 'row',
            rows: [
              {
                type: 'empty',
                class: 'col s12 m12 l12 xl12'
              }
            ]
          }
        ]
      },
      {
        type: 'section',
        label: lbl.MESSAGE,
        class: 'col s12 l6 m12 xl6 p-r-0',
        section: [
          {
            type: 'row',
            rows: [
              {
                type: 'textarea',
                label: lbl.MESSAGE,
                newLine: true,
                inputType: 'text',
                name: 'txtMessage',
                validations: commonValidators.MESSAGE_VALIDATOR,
                class: 'col s12 m12 l12 xl12 p-l-0 p-r-0 m-b-xs',
                tabIndex: 5,
                rows: 5
              }
            ]
          }
        ]
      }
    ]
  }
]
