import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { EntryComponent } from './entry/entry.component';
import { MessageComponent } from './message.component';
const routes: Routes = [
  { path: "", component: MessageComponent },
  { path: "add", component: EntryComponent },
  { path: "edit", component: EntryComponent },
  { path: "view", component: EntryComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MessageRoutingModule { }
