import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/field.interface';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import * as label from 'projects/login/src/assets/labelDataList.json';
import { RestService } from 'projects/tools/src/lib/rest.service';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { messageConfig } from './message.config';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { MessageService as AlertService } from 'primeng/api';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss']
})

export class MessageComponent implements OnInit, OnDestroy {
  messageConfig;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;

  data: IGridColumn[];
  rows = [];
  isTableVisible = false;
  currentUser: any;
  tableHeight: string;

  constructor(private eventEmitt: EventEmitterService,
    private messageService: MessageService,
    private router: Router,
    private restService: RestService,
    private dialog: MatDialog,
    private sharedService: SharedService,
    private datepipe: DatePipe,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    private ngsk: NgShortcutService,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.messageConfig = messageConfig;
    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#msg-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#msg-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('n', () => this.element.nativeElement.querySelector('#msg-add-btn')?.click(), {
      preventDefault: false,
      altKey: true
    }));

    ngsk.push(new NgShortcut('h', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#msg-search-service-centre')) {
        this.element.nativeElement.querySelector('#msg-search-service-centre-help')?.click();
      }
    }, {
      preventDefault: true,
      altKey: true
    }));

    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#msg-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('R', () => this.element.nativeElement.querySelector('#msg-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('N', () => this.element.nativeElement.querySelector('#msg-add-btn')?.click(), {
      preventDefault: false,
      altKey: true
    }));

    ngsk.push(new NgShortcut('H', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#msg-search-service-centre')) {
        this.element.nativeElement.querySelector('#msg-search-service-centre-help')?.click();
      }
    }, {
      preventDefault: true,
      altKey: true
    }));

    this.data = [
      {
        field: 'a',
        header: label.SERVICE_CENTER,
        colWidth: '110px'
      },
      {
        field: 'b',
        header: label.ROUTE_CODE,
        colWidth: '90px'
      },
      {
        field: 'c',
        header: label.MESSAGE_NUMBER,
        colWidth: '90px'
      },
      {
        field: 'd',
        header: label.MESSAGE
      }
    ];
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCentre');
  }

  get regDate() {
    return this.form.form.get('txtRegistrationDate');
  }

  get msgNo() {
    return this.form.form.get('txtMessageNumber');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    let gridTblHt = window.innerHeight - 295;
    this.tableHeight = gridTblHt + 'px';
    this.setCountLabel();
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'addMessageEntry':
          this.addMessage();
          break;
        case 'txtAreaCodeForMessage':
          this.validateAreaCode(field);
          break;
        case 'txtServiceCentreForMessage':
          field['helpEventRef'] ? this.openHelpDialog(field) : this.validateServiceCenterCode(field);
          break;
        case 'messageNumberForSearch':
          this.validateMessageNumber(field);
          break;
        case 'searchMessageList':
          this.searchMessage(field);
          break;
        case 'resetMessageForm':
          this.resetForm();
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      this.setFocusAndValue();
    });
  }

  setFocusAndValue() {
    setTimeout(() => {
      const ele = this.element.nativeElement.querySelector('#area-code')
      ele?.focus();
    }, 0);
    this.form.form.controls["txtRegistrationDate"]?.setValue(new Date());
    this.form.form.controls['txtArea']?.setValue(this.currentUser.area);
    this.form.form.controls['txtServiceCentre']?.setValue(this.currentUser.location);
  }

  getRowData(data) {
    const dataToSend = {
      'areaCode': this.area.value,
      'registrationDate': this.regDate.value,
      'serviceCentre': data.a,
      'messageNo': data.c,
      'routeCode': data.b,
      'message': data.d
    }

    this.sharedService.setData(dataToSend);
    this.router.navigate(['message/view']);
  }

  submit(evt) {
  }

  addMessage() {
    this.setCountLabel();
    this.router.navigate(['message/add']);
  }

  resetForm() {
    if (this.form.form.dirty || this.form.form.touched) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.RESET.TITLE,
          message: displayMsg.RESET.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.form.form.reset();
          this.setFocusAndValue();
          this.isTableVisible = false;
          this.rows = [];
          this.setCountLabel();
        }
      });
    }
  }

  setCountLabel(count: number = 0) {
    this.messageConfig[0].rows[1].label = count ? count + ' messages available' : '';
  }

  initializeTableData(data) {
    return data.map(ele => {
      return {
        "a": ele.c,
        "b": ele.d,
        "c": ele.e,
        "d": ele.f
      }
    })
  }

  searchMessage(field) {
    this.rows = [];
    this.isTableVisible = false;
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.form.form.valid) {
      const payload = {
        "a": this.area.value.toUpperCase(),
        "b": this.serviceCentre.value || "",
        "c": this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy'),
        "d": this.msgNo.value || ""
      };

      this.restService.post(field['apiUrl'], JSON.stringify(payload)).subscribe(
        (res) => {
          if (res.a) {
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(res.b);
          }
          else if (res.d && res.d.length) {
            this.rows = this.initializeTableData(res.d);
            if (res.d.length == 1)
              this.getRowData(this.rows[0]);
            else {
              this.setCountLabel(res.d.length);
              this.isTableVisible = true;
            }
          }
          else {
            this.setCountLabel();
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
          }
        },
        (err) => {
          this.setCountLabel();
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          this.showToaster(err.error.b);
        }
      )
    } else {
      this.setCountLabel();
      this.setErrorPanel(field.name, displayMsg.MISSING_FIELDS, VALIDATION_STATUS.INVALID);
    }
  }

  openHelpDialog(field) {
    if (this.area.value && this.area.valid) {
      const payload = {
        "a": this.area.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: field.dialogTitle,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          helpTableDataColumn: field.helpTableDataColumn,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.SERVICE_CENTRE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(res => {
        if (res) {
          this.form.form.controls[field.name].setValue(res);
        }
      });
    }
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    const payload = {
      "a": this.area.value,
      "b": this.serviceCentre.value
    };

    this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
      (res: any) => {
        if (res.a) {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
        }
      },
      (err) => {
        this.form.form.controls[field.name].setErrors({ 'pattern': true });
        this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
      }
    );
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateMessageNumber(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.msgNo.value) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value,
        "c": this.datepipe.transform(this.regDate.value, 'dd/MM/yyyy'),
        "d": this.msgNo.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, res.b, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }
}
