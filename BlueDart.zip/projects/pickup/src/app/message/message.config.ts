import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator.ts';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant.js';
const commonValidators = new CommonValidators();

export const messageConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.MESSAGE_ENTRY,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: lbl.ADD,
        buttonType: 'button',
        name: 'addMessageEntry',
        trigerOnClick: 'true',
        id: 'msg-add-btn',
        eventRef: 'addMessageEntry',
        tabIndex: 6,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'resetMessageForm',
        id: 'msg-reset-btn',
        tabIndex: 7,
        class: 'col w90 p-l-0',
        separatorBefore: true,
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: 'txtArea',
        validations: commonValidators.AREA_CODE_VALIDATOR,
        class: 'col w90 p-l-0',
        tabIndex: 1,
        eventRef: 'txtAreaCodeForMessage',
        apiUrl: apiUrl.VALIDATE_AREA_CODE,
        maxlength: "3",
        id: 'area-code'
      },
      {
        type: 'input',
        label: lbl.SERVICE_CENTER,
        inputType: 'text',
        name: 'txtServiceCentre',
        validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR_NOT_REQUIRED,
        class: 'col w160 p-l-0',
        tabIndex: 2,
        eventRef: 'txtServiceCentreForMessage',
        apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
        maxlength: "3",
        helpIconComp: true,
        helpEventRef: false,
        id: 'msg-search-service-centre',
        helpId: 'msg-search-service-centre-help',
        submitValue: 'Service Centre',
        helpDialogWidth: 600,
        tabindex: 26,
        dialogTitle: 'Service Centre Data',
        helpTableDataColumn: 'c',
        helpDialogGridColumns: [
          {
            field: 'a',
            header: 'Service Centre',
            showFilter: true
          },
          {
            field: 'b',
            header: 'Service Centre Name',
            showFilter: true
          }
        ],
        formGridMapping: [
          {
            controlName: 'serviceCentre',
            gridColumnName: 'a'
          }
        ],
        gridOptions: {
          isColumnFilter: true,
          isClickable: true
        },
        helpApiUrl: apiUrl.SERVICE_CENTRES_LIST
      },
      {
        type: 'date',
        label: lbl.REGISTRATION_DATE,
        name: 'txtRegistrationDate',
        class: 'col w140 p-l-0',
        tabIndex: 3,
        enableDateDays: 1,
        minDate: 116200,
        validations: commonValidators.REG_DATE_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.MESSAGE_NUMBER,
        inputType: 'text',
        name: 'txtMessageNumber',
        validations: commonValidators.MESSAGE_NUMBER_VALIDATOR,
        class: 'col w110 p-l-0',
        eventRef: 'messageNumberForSearch',
        apiUrl: apiUrl.VALIDATE_MESSAGE_NUMBER,
        tabIndex: 4,
        maxlength: "4"
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'msg-search-btn',
        eventRef: 'searchMessageList',
        tabIndex: 5,
        class: 'col p-l-0',
        apiUrl: apiUrl.ALL_MESSAGES,
        classes: {
          buttonType: 'primary-button',
          class: 'm-l-0'
        }
      }
    ]
  }

  
]
