import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MessageComponent } from './message.component';
import { MessageRoutingModule } from './message-routing.module';
import { from } from 'rxjs';
import { ToolsModule } from 'projects/tools/src/public-api';
import { EntryComponent } from './entry/entry.component';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { NgShortcutModule } from 'ng-shortcut';

@NgModule({
  declarations: [
    MessageComponent,
    EntryComponent
  ],
  imports: [
    CommonModule,
    ToolsModule,
    MessageRoutingModule,
    ToastModule,
    NgShortcutModule.forRoot()
  ],
  providers: [
    DatePipe, 
    MessageService
  ]
})
export class MessageModule { }
