import { Component, Input, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { addPickupConfig, editPickupConfig, viewPickupConfig } from './addpickup.config';
import { Router } from '@angular/router';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { MessageService as AlertService } from 'primeng/api';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { landmarkPopupCols } from 'projects/pickup/src/app/app.constant';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';

@Component({
  selector: 'app-addpickup',
  templateUrl: './addpickup.component.html',
  styleUrls: ['./addpickup.component.scss']
})
export class AddpickupComponent implements OnInit, OnDestroy {
  @Input() name: string;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  regConfig: FieldConfig[];
  rp;
  currentUser: any;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    public dialog: MatDialog,
    private restService: RestService,
    private alertService: AlertService,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    private sharedService: SharedService,
    private ngsk: NgShortcutService
  ) {
    this.messageService.sendHeaderShowMessage(true);

    ngsk.push(new NgShortcut('h', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-serial-no')) {
        this.element.nativeElement.querySelector('#rp-entry-serial-no-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
        this.element.nativeElement.querySelector('#rp-entry-pickup-route-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-pickup-time')) {
        this.element.nativeElement.querySelector('#rp-entry-pickup-time-help')?.click();
      }
      }, {
        preventDefault: true,
        altKey: true
      }));

    ngsk.push(new NgShortcut('H', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-serial-no')) {
        this.element.nativeElement.querySelector('#rp-entry-serial-no-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
        this.element.nativeElement.querySelector('#rp-entry-pickup-route-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#rp-entry-pickup-time')) {
        this.element.nativeElement.querySelector('#rp-entry-pickup-time-help')?.click();
      }
    }, {
        preventDefault: true,
        altKey: true
      }));

    if (this.router.url.includes('/add')) {
      this.regConfig = addPickupConfig;
      ngsk.push(new NgShortcut('s', () => this.element.nativeElement.querySelector('#addpu-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#addpu-reset-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('c', () => this.element.nativeElement.querySelector('#addpu-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('l', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
        preventDefault: false,
        altKey: true
        }));

      ngsk.push(new NgShortcut('S', () => this.element.nativeElement.querySelector('#addpu-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('R', () => this.element.nativeElement.querySelector('#addpu-reset-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('C', () => this.element.nativeElement.querySelector('#addpu-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('L', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
          preventDefault: false,
          altKey: true
        }));
    }
    else if (this.router.url.includes('/edit')) {
      this.regConfig = editPickupConfig;
      ngsk.push(new NgShortcut('s', () => this.element.nativeElement.querySelector('#editpu-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('c', () => this.element.nativeElement.querySelector('#editpu-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('l', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
          preventDefault: false,
          altKey: true
        }));

      ngsk.push(new NgShortcut('S', () => this.element.nativeElement.querySelector('#editpu-save-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('C', () => this.element.nativeElement.querySelector('#editpu-cancel-btn')?.click(), {
        preventDefault: false,
        altKey: true
      }));

      ngsk.push(new NgShortcut('L', () => {
        if (document.activeElement === this.element.nativeElement.querySelector('#rp-entry-pickup-route')) {
          this.openLandmarkDetailsPopup()
        }
      }, {
          preventDefault: false,
          altKey: true
        }));
    }
    else if (this.router.url.includes('/view')) {
      this.regConfig = viewPickupConfig;
      ngsk.push(new NgShortcut('d', () => this.element.nativeElement.querySelector('#viewpu-delete-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('e', () => this.element.nativeElement.querySelector('#viewpu-edit-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('D', () => this.element.nativeElement.querySelector('#viewpu-delete-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));

      ngsk.push(new NgShortcut('E', () => this.element.nativeElement.querySelector('#viewpu-edit-btn')?.click(), {
        preventDefault: true,
        ctrlKey: true
      }));
    }
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCenter');
  }

  get clientCode() {
    return this.form.form.get('txtClientCode');
  }

  get serialNo() {
    return this.form.form.get('txtSerialNumber');
  }

  get pickupRoute() {
    return this.form.form.get('txtPURouteCode');
  }

  get pincode() {
    return this.form.form.get('txtPincode');
  }

  get clientName() {
    return this.form.form.get('txtClientName');
  }

  get txnCode() {
    return this.form.form.get('txtTransactionCode');
  }

  get address1() {
    return this.form.form.get('txtAddress1');
  }

  get address2() {
    return this.form.form.get('txtAddress2');
  }

  get address3() {
    return this.form.form.get('txtAddress3');
  }

  get telephone() {
    return this.form.form.get('txtTelephone');
  }

  get mobileNo() {
    return this.form.form.get('txtMobile');
  }

  get contactPerson() {
    return this.form.form.get('txtContactPerson');
  }

  get puTime() {
    return this.form.form.get('txtPUTime');
  }

  get puDays() {
    return this.form.form.get('txtPickupDays');
  }

  get remarks() {
    return this.form.form.get('txtRemark');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.eventEmitt.subsVar = this.eventEmitt.
      invokeCommonComponentFunction.subscribe((field: string) => {
        switch (field["eventRef"]) {
          case 'backToPickupSearchFromView':
            this.btnCancelAdd();
            break;
          case 'btnCancelAddForRP':
          case 'backToPickupSearch':
            this.cancelConfirmation('add');
            break;
          case 'txtAreaForRP':
            this.validateAreaCode(field);
            break;
          case 'txtServiceCenterForRP':
            this.validateServiceCenterCode(field);
            break;
          case 'txtClientCodeForRP':
            this.validateClientCode(field);
            break;
          case 'txtSerialNumberForRP':
            field["helpEventRef"] ? this.helpForSerialNumber(field) : this.validatePickupSerialNumber(field);
            break;
          case 'txtPincodeForRP':
            this.validatePincode(field);
            break;
          case 'btnEditForRP':
            this.onEditPickupRecord();
            break;
          case 'txtPURouteCodeForRP':
            field["helpEventRef"] ? this.openDialogHelpRC(field) : this.validatePickupRoute(field);
            break;
          case 'btnDeleteForRP':
            this.deleteConfirm(field);
            break;
          case 'btnCancelEditForRP':
            this.cancelConfirmation('edit');
            break;
          case 'SubmitForUpdateRP':
            this.confirmSaveEditRecord(field, 'edit');
            break;
          case 'SubmitForAddRP':
            this.confirmSaveEditRecord(field, 'add');
            break;
          case 'btnResetForRP':
            this.resetPickupForm();
            break;
          case 'txtPUtimeRP':
            field["helpEventRef"] ? this.openDialogHelpPU(field) : this.puTimehelp();
            break;
        }
      });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      if (this.router.url.includes('/add')) {
        this.disableTxnCode();
        this.populateAreaServiceCode();
        this.setFocusOnNodeByName('txtClientCode');
      }
      else if (this.router.url.includes('/edit')) {
        this.populatePickupForm();
        this.enableControls();
        this.disableDemographicDetails();
        this.disableTxnCode();
        this.setFocusOnNodeByName('txtClientName');
      }
      else if (this.router.url.includes('/view')) {
        this.populatePickupForm();
        this.disableControls();
      }
    });
  }

  setFocusOnNodeByName(name = "") {
    const nodes = this.element.nativeElement.querySelectorAll('Input');
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i]["name"] == name) {
        nodes[i].focus();
        break;
      }
    }
  }

  populateAreaServiceCode() {
    this.form.form.controls['txtArea'].setValue(this.currentUser.area);
    this.form.form.controls['txtServiceCenter'].setValue(this.currentUser.location);
  }
  btnCancelAdd() {
    this.navigateTo(['/pickup/search']);
  }

  submit(event) {
    console.log(event);
  }

  helpForSerialNumber(field) {
    if (this.clientCode.value && this.area.value && this.serviceCentre.value) {
      let payload = {
        "a": this.clientCode.value,
        "b": this.area.value,
        "c": this.serviceCentre.value,
        "i1": "0",
        "i2": "100"
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.CLIENT_DETAILS_TITLE, apiurl: field.helpApiUrl, gridColumns: field.helpDialogGridColumns, fieldname: field.submitValue, payload: payload,
          noteText: displayMsg.PICKUP_SRNO_NOTE
        }
      });
    }
  }

  openDialogHelpRC(field) {
    if (this.serviceCentre.value) {
      let payload = {
        "a": this.serviceCentre.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_ROUTE_TITLE, apiurl: field.helpApiUrl, gridColumns: field.helpDialogGridColumns, fieldname: field.submitValue, payload: payload,
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls[field.name].setValue(ress);
        }
      });
    }
  }

  openDialogHelpPU(field) {
    if (this.serviceCentre.value && this.pickupRoute.value) {
      let payload = {
        "a": this.serviceCentre.value,
        "b": this.pickupRoute.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_TIME_TITLE, apiurl: field.helpApiUrl, gridColumns: field.helpDialogGridColumns, fieldname: field.submitValue, payload: payload,
          noteText: displayMsg.PICKUP_TIME_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls[field.name].setValue(ress);
        }
      });
    }
  }

  puTimehelp() {
  }

  onEditPickupRecord() {
    this.navigateTo(['pickup/edit']);
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.area.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.serviceCentre.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateClientCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.clientCode.value && this.clientCode.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.clientCode.value,
        "c": this.serviceCentre.value,
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.b) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.INVALID, VALIDATION_STATUS.INVALID);
          }
          else {
            let invalidCustomer = res.n.find(ele => ele.errorCode === 1001)
            if (invalidCustomer) {
              this.form.form.controls[field.name].setErrors({ 'pattern': true });
              this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.OFF_CREDITED_CUSTOMER, VALIDATION_STATUS.INVALID);
              return;
            }

            invalidCustomer = res.n.find(ele => ele.errorCode === 1005)
            if (invalidCustomer) {
              this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.NOT_BELONG_WARNING, VALIDATION_STATUS.WARNING);
            }
            else {
              this.setErrorPanel(field.name, "", VALIDATION_STATUS.NO_WARNING);
            }
            const control = this.form.form.controls;
            control['txtClientName'].setValue(res.c);
            control['txtTransactionCode'].setValue(res.o);
            control['txtPincode'].setValue(res.d);
            control['txtAddress1'].setValue(res.f);
            control['txtAddress2'].setValue(res.g);
            control['txtAddress3'].setValue(res.h);
            control['txtContactPerson'].setValue(res.i);
            control['txtTelephone'].setValue(res.e);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.INVALID, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePickupSerialNumber(field) {
    if (this.area.value && this.serviceCentre.value && this.clientCode.value && this.serialNo.value && this.serialNo.valid) {
      const payload = {
        "a": this.clientCode.value,
        "b": this.area.value,
        "c": this.serialNo.value,
        "d": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'invalid': true, 'message': '' });
            this.setErrorPanel(field.name, displayMsg.PICKUP_SERIAL_MSG.ALREADY_EXISTS, VALIDATION_STATUS.INVALID);
          } else {
            this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.PICKUP_SERIAL_MSG.INVALID, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePincode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.pincode.value && this.pincode.valid) {
      const payload = {
        "a": this.pincode.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (!res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_PINCODE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_PINCODE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePickupRoute(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.value && this.pickupRoute.value && this.pickupRoute.valid) {
      const payload = {
        "a": this.pickupRoute.value,
        "b": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res.c) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  populatePickupForm() {
    this.rp = this.sharedService.getData();
    const control = this.form.form.controls;
    control['txtArea'].setValue(this.rp.areaCode);
    control['txtServiceCenter'].setValue(this.rp.serviceCenterCode);
    control['txtClientCode'].setValue(this.rp.clientCode);
    control['txtSerialNumber'].setValue(this.rp.pickUpSerialNumber);
    control['txtPURouteCode'].setValue(this.rp.pickupRoute);
    control['txtPUTime'].setValue(this.rp.pickupTime);
    control['txtPickupDays'].setValue(this.addComma(this.rp.pickupDays));
    control['txtClientName'].setValue(this.rp.clientName);
    control['txtTransactionCode'].setValue(this.rp.transactionCode);
    control['txtPincode'].setValue(this.rp.pincode);
    control['txtAddress1'].setValue(this.rp.a1);
    control['txtAddress2'].setValue(this.rp.a2);
    control['txtAddress3'].setValue(this.rp.a3);
    control['txtMobile'].setValue(this.rp.mobile);
    control['txtTelephone'].setValue(this.rp.telephone);
    control['txtContactPerson'].setValue(this.rp.contactPerson);
    control['txtRemark'].setValue(this.rp.remark);
  }

  disableControls() {
    this.form.form.disable();
  }

  disableTxnCode() {
    this.form.form.controls['txtTransactionCode'].disable();
  }

  enableControls() {
    this.form.form.enable();
  }

  resetPickupForm() {
    if (this.form.form.dirty || this.form.form.touched) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.RESET.TITLE,
          message: displayMsg.RESET.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.form.form.reset();
          this.populateAreaServiceCode();
          this.setFocusOnNodeByName('txtClientCode');
        }
      });
    }
  }

  deleteConfirm(field) {
    const confirmDialog = this.dialog.open(DialogComponent, {
      data: {
        title: displayMsg.DELETE.TITLE,
        message: displayMsg.DELETE.MESSAGE,
        primaryButton: displayMsg.BUTTON.YES,
        secondaryButton: displayMsg.BUTTON.NO
      }
    });
    confirmDialog.afterClosed().subscribe(result => {
      if (result) {
        this.deleteRegularPickup(field);
      }
    });
  }

  deleteRegularPickup(field) {
    //this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    const payload = {
      "a": this.area.value,
      "s": this.serviceCentre.value,
      "c": this.clientCode.value,
      "n": this.serialNo.value,
    };

    this.restService.delete(field["apiUrl"], '', payload).subscribe(
      (res: any) => {
        if (res.a) {
          this.showToaster(displayMsg.ERROR);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.name, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
        }
        else {
          this.showToaster(res.d, 'success');
          setTimeout(() => {
            this.navigateTo(['/pickup/search']);
          }, 1000);
        }
      },
      (err) => {
        this.showToaster(displayMsg.ERROR);
        BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        //this.setErrorPanel(field.name, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
      }
    );
  }

  addRegularPickup(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.form.form.valid) {
      const payload = {
        "a": this.area.value.toUpperCase(),
        "b": this.clientCode.value,
        "c": this.serviceCentre.value.toUpperCase(),
        "d": this.serialNo.value,
        "e": this.pickupRoute.value,
        "f": this.clientName.value,
        "g": this.address1.value,
        "h": this.address2.value,
        "i": this.address3.value,
        "j": this.telephone.value,
        "k": this.mobileNo.value,
        "l": this.contactPerson.value,
        "m": this.txnCode.value,
        "n": this.pickupRoute.value,
        "o": this.convertTime12to24(this.puTime.value),
        "p": this.removeComma(this.puDays.value),
        "q": this.remarks.value,
        "r": "",
        "s": this.pincode.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.c) {
            this.showToaster(displayMsg.ERROR);
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            //this.setErrorPanel(field.name, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
          }
          else {
            //this.showSuccessPanel(res.d);
            this.showToaster(res.d, 'success');
            this.sharedService.setData(this.dataToSave());
            setTimeout(() => this.cancelEditPickup(), 1000);
          }
        },
        (err) => {
          this.showToaster(err.error.data[0]);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.name, err.error.data[0], VALIDATION_STATUS.INVALID);
        });
    } else this.form.validateAllFormFields(this.form.form);
  }

  dataToSave() {
    return {
      "areaCode": this.area.value,
      "clientCode": this.clientCode.value,
      "serviceCenterCode": this.serviceCentre.value,
      "pickUpSerialNumber": this.serialNo.value,
      "pickupRoute": this.pickupRoute.value,
      "clientName": this.clientName.value,
      "a1": this.address1.value,
      "a2": this.address2.value,
      "a3": this.address3.value,
      "telephone": this.telephone.value,
      "mobile": this.mobileNo.value,
      "contactPerson": this.contactPerson.value,
      "transactionCode": this.txnCode.value,
      "pickupTime": this.puTime.value,
      "pickupDays": this.removeComma(this.puDays.value),
      "remark": this.remarks.value,
      "pincode": this.pincode.value
    }
  }

  confirmSaveEditRecord(field, action) {
    if (this.form.form.valid) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.SAVE.TITLE,
          message: displayMsg.SAVE.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          if (action == 'edit')
            this.updateRegularPickup(field);
          else
            this.addRegularPickup(field);
        }
      });
    }
  }

  updateRegularPickup(field) {
    //this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    const payload = {
      "a": this.area.value.toUpperCase(),
      "b": this.clientCode.value,
      "c": this.serviceCentre.value.toUpperCase(),
      "d": this.serialNo.value,
      "e": this.pickupRoute.value,
      "f": this.clientName.value,
      "g": this.address1.value,
      "h": this.address2.value,
      "i": this.address3.value,
      "j": this.telephone.value,
      "k": this.mobileNo.value,
      "l": this.contactPerson.value,
      "m": this.txnCode.value,
      "n": this.pickupRoute.value,
      "o": this.convertTime12to24(this.puTime.value),
      "p": this.removeComma(this.puDays.value),
      "q": this.remarks.value,
      "r": "",
      "s": this.pincode.value
    };

    this.restService.put(field["apiUrl"], JSON.stringify(payload)).subscribe(
      (res: any) => {
        if (res.c) {
          this.showToaster(displayMsg.ERROR);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.name, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
        }
        else {
          this.showToaster(res.d, 'success');
          this.sharedService.setData(this.dataToSave());
          setTimeout(() => this.cancelEditPickup(), 1000);
        }
      },
      (err) => {
        this.showToaster(err.error.data[0]);
        BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        //this.setErrorPanel(field.name, err.error.data[0], VALIDATION_STATUS.INVALID);
      }
    );
  }

  cancelConfirmation(action) {
    const isDataAvailable = Object.keys(this.form.form.value).some(k => !!this.form.form.value[k])
    if (isDataAvailable) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.CANCEL.TITLE,
          message: displayMsg.CANCEL.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result === true) {
          if (action == 'add')
            this.btnCancelAdd();
          else if (action == 'edit')
            this.cancelEditPickup();
        }
      });
    } else {
      if (action == 'add')
        this.btnCancelAdd();
      else if (action == 'edit')
        this.cancelEditPickup();
    }
  }

  openLandmarkDetailsPopup() {
    if (this.serviceCentre.value) {
      const payload = {
        "a": this.serviceCentre.value
      };

      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '600px',
        minWidth: 400,
        data: {
          title: displayMsg.LANDMARK_DETAILS,
          apiurl: apiUrl.LANDMARK_DETAILS,
          gridColumns: landmarkPopupCols,
          payload: payload,
          fieldname: "Route Code",
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls["txtPURouteCode"].setValue(ress);
        }
      });
    }
  }

  cancelEditPickup() {
    this.navigateTo(['pickup/view']);
  }

  navigateTo(url: Array<string>, params: any = {}) {
    this.router.navigate(url, { queryParams: params });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  convertTime12to24(time12) {
    if (time12) {
      const [hours, minutes] = time12.split(':');
      return `${hours}${minutes}`;
    }
    return null;
  }

  convertTime24to12(time24) {
    if (time24) {
      const [sHours, minutes] = time24.match(/([0-9]{1,2})([0-9]{2})/).slice(1);
      return `${sHours}:${minutes}`;
    }
    return null;
  }

  removeComma(str) {
    return str ? str.join("") : "";
  }

  addComma(str) {
    return str ? str.split("") : "";
  }

  disableDemographicDetails() {
    const control = this.form.form.controls;
    control['txtArea'].disable();
    control['txtServiceCenter'].disable();
    control['txtClientCode'].disable();
    control['txtSerialNumber'].disable();
  }

  showToaster(message, type='error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }
}
