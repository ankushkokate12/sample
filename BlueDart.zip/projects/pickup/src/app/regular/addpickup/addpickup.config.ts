import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { pickupRouteList, rPickupTimeList, rrPickupList } from 'projects/pickup/src/app/app.constant';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { SEVEN_WEEKDAYS } from 'projects/tools/src/lib/constants/constant';

const commonValidators = new CommonValidators();

const backIconConfigAddEdit = {
  type: 'iconbutton',
  label: lbl.ARROW_BACK_IOS,
  name: 'backPickupSearchBack',
  buttonType: 'button',
  trigerOnClick: 'true',
  eventRef: 'backToPickupSearch',
  classes: {
    buttonType: 'action-button',
  }
};

const demographicDetailsConfig = {
  type: 'section',
  label: lbl.DEMOGRAPHIC_DETAILS,
  class: 'col s12 l6 m12 p-l-0',
  section: [{
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: 'txtArea',
        validations: commonValidators.AREA_CODE_VALIDATOR,
        class: 'col s2 m2 l2 xl2 p-l-0',
        eventRef: 'txtAreaForRP',
        tabIndex: 1,
        apiUrl: apiUrl.VALIDATE_AREA_CODE,
        maxlength: "3"
      },
      {
        type: 'input',
        label: lbl.SERVICE_CENTER,
        inputType: 'text',
        name: 'txtServiceCenter',
        validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
        class: 'col s3 m3 l3 xl3 p-l-0',
        tabIndex: 2,
        eventRef: 'txtServiceCenterForRP',
        apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
        maxlength: "3"
      },
      {
        type: 'input',
        label: lbl.CLIENT_CODE,
        inputType: 'text',
        name: 'txtClientCode',
        validations: commonValidators.CLIENT_CODE_VALIDATOR,
        class: 'col s3 m3 l3 xl3 p-l-0',
        tabIndex: 3,
        eventRef: 'txtClientCodeForRP',
        apiUrl: apiUrl.VALIDATE_CUSTOMER_CODE,
        maxlength: "6"
      },
      {
        type: 'input',
        label: lbl.PICKUP_SERIAL_NO,
        inputType: 'text',
        name: 'txtSerialNumber',
        id: 'rp-entry-serial-no',
        helpId: 'rp-entry-serial-no-help',
        validations: commonValidators.PICKUP_SERIAL_NO_VALIDATOR,
        helpIconComp: true,
        submitValue: 'Serial No',
        helpApiUrl: apiUrl.REGISTERED_REGULAR_PICKUP,
        helpDialogGridColumns: rrPickupList,
        class: 'col s4 m4 l4 xl4 p-l-0',
        tabIndex: 4,
        eventRef: 'txtSerialNumberForRP',
        apiUrl: apiUrl.VALIDATE_SERIAL_NO,
        maxlength: "2"
      }
    ]
  }
  ]
};

const pickupRouteDetailsConfig = {
  type: 'section',
  label: lbl.PICKUP_DETAILS,
  class: 'col s12 l6 m12 p-l-0 p-r-0',
  section: [
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.PICKUP_ROUTE,
          inputType: 'text',
          name: 'txtPURouteCode',
          id: 'rp-entry-pickup-route',
          helpId: 'rp-entry-pickup-route-help',
          validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
          helpIconComp: true,
          submitValue: 'Route Code',
          helpDialogWidth: 500,
          helpDialogGridColumns: pickupRouteList,
          helpApiUrl: apiUrl.ROUTE_CODES,
          class: 'col s3 m3 l3 xl3 p-l-0',
          tabIndex: 14,
          eventRef: 'txtPURouteCodeForRP',
          apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
          maxlength: '2'
        },
        {
          type: 'time',
          label: lbl.PICKUP_TIME,
          inputType: 'text',
          name: 'txtPUTime',
          id: 'rp-entry-pickup-time',
          helpId: 'rp-entry-pickup-time-help',
          validations: commonValidators.PICKUP_TIME_VALIDATOR,
          helpIconComp: true,
          submitValue: 'Pickup Time',
          helpDialogGridColumns: rPickupTimeList,
          helpApiUrl: apiUrl.REGULAR_PICKUP_TIMING,
          eventRef: 'txtPUtimeRP',
          class: 'col s3 m3 l3 xl3 p-l-0',
          tabIndex: 15,
          maxlength: '8'
        },
        {
          type: 'select',
          label: lbl.PICKUP_DAYS,
          multiple: true,
          enableSelectTrigger: true,
          options: SEVEN_WEEKDAYS,
          map: {
            label: 'label',
            value: 'value',
            selectTriggerValue: 'displayValue'
          },
          name: 'txtPickupDays',
          eventRef: 'txtPickupDaysSort',
          validations: commonValidators.PICKUP_DAYS_VALIDATOR,
          class: 'col s3 m3 l3 xl3 p-l-0',
          height: 200,
          tabIndex: 16
        }
      ]
    }
  ]
};

const clientDetailsConfig = {
  type: 'section',
  label: lbl.CLIENT_DETAILS,
  class: 'col s12 l6 m12 p-l-0',
  section: [
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.CLIENT_NAME,
          inputType: 'text',
          name: 'txtClientName',
          validations: commonValidators.CLIENT_NAME_VALIDATOR,
          class: 'col s7 m7 l7 xl7 p-l-0',
          tabIndex: 5,
          maxlength: "30"
        },
        {
          type: 'input',
          label: lbl.TRANSACTION_CODE,
          inputType: 'text',
          name: 'txtTransactionCode',
          validations: commonValidators.TRANSACTION_CODE_VALIDATOR,
          class: 'col s3 m3 l3 xl3 p-l-0',
          tabIndex: 6
        }
      ]
    },
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.PINCODE,
          inputType: 'number',
          name: 'txtPincode',
          maxlength: "6",
          validations: commonValidators.PINCODE_LENGTH_VALIDATOR,
          class: 'col s4 m2 l2 xl2 p-l-0',
          tabIndex: 7,
          eventRef: 'txtPincodeForRP',
          apiUrl: apiUrl.VALIDATE_PINCODE,
        },
        {
          type: 'input',
          label: lbl.ADDRESS1,
          inputType: 'text',
          name: 'txtAddress1',
          validations: commonValidators.PRIMARY_ADDRESS_VALIDATOR,
          class: 'col s8 m10 l10 xl10 p-l-0',
          tabIndex: 8,
          maxlength: "30"
        }
      ]
    },
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.ADDRESS2,
          inputType: 'text',
          name: 'txtAddress2',
          validations: commonValidators.PRIMARY_ADDRESS_VALIDATOR,
          class: 'col s6 m5 l12 xl2 p-l-0',
          tabIndex: 9,
          maxlength: "30"
        }
      ]
    },
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.ADDRESS3,
          inputType: 'text',
          name: 'txtAddress3',
          validations: commonValidators.SECONDARY_ADDRESS_VALIDATOR,
          class: 'col s6 m7 l7 xl7 p-l-0',
          tabIndex: 10,
          maxlength: "30"
        }
      ]
    },
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.MOBILE_NO,
          inputType: 'number',
          minlength: "10",
          maxlength: "15",
          name: 'txtMobile',
          validators: commonValidators.MOBILE_NUMBER_VALIDATOR,
          class: 'col s3 m3 l3 xl3 p-l-0',
          tabIndex: 11
        },
        {
          type: 'input',
          label: lbl.TELEPHONE,
          inputType: 'number',
          name: 'txtTelephone',
          class: 'col s3 m3 l3 xl3 p-l-0',
          tabIndex: 12,
          maxlength: "15"
        },
        {
          type: 'input',
          label: lbl.CONTACT_PERSON,
          inputType: 'text',
          name: 'txtContactPerson',
          class: 'col s6 m6 l6 xl6 p-l-0',
          tabIndex: 13,
          maxlength: "30"
        }
      ]
    }
  ]
};

const remarkDetailsConfig = {
  type: 'section',
  label: lbl.REMARKS,
  class: 'col s12 l6 m12 p-l-0 p-r-0',
  section: [
    {
      type: 'row',
      rows: [
        {
          type: 'input',
          label: lbl.REMARKS,
          inputType: 'text',
          name: 'txtRemark',
          class: 'col s6 m5 l12 xl12 p-l-0',
          tabIndex: 17,
          maxlength: "60"
        }
      ]
    }
  ]
};

export const addPickupConfig = [
  {
    type: 'header',
    rows: [
      backIconConfigAddEdit,
      {
        type: 'label',
        label: lbl.ADD_REGULAR_PICKUP,
        classes: {
          labelHead: true
        },
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        name: 'btnResetAddRP',
        id: 'addpu-reset-btn',
        trigerOnClick: 'true',
        eventRef: 'btnResetForRP',
        tabIndex: 20,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      demographicDetailsConfig,
      pickupRouteDetailsConfig,
    ]
  },
  {
    type: 'row',
    rows: [
      clientDetailsConfig,
      remarkDetailsConfig,
      {
        type: 'button',
        label: lbl.CANCEL,
        name: 'btnCancelAddRP',
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'addpu-cancel-btn',
        tabIndex: 19,
        eventRef: 'btnCancelAddForRP',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {

        type: 'button',
        label: lbl.SAVE,
        buttonType: 'button',
        id: 'addpu-save-btn',
        apiUrl: apiUrl.REGULAR_PICKUP,
        trigerOnClick: 'true',
        alignRight: true,
        eventRef: 'SubmitForAddRP',
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        },
        tabIndex: 18
      }
    ]
  }
];

export const viewPickupConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'iconbutton',
        label: lbl.ARROW_BACK_IOS,
        name: 'backPickupSearch',
        buttonType: 'button',
        trigerOnClick: 'true',
        eventRef: 'backToPickupSearchFromView',
        classes: {
          buttonType: 'action-button',
        }
      },
      {
        type: 'label',
        label: lbl.VIEW_REGULAR_PICKUP,
        classes: {
          labelHead: true
        },
      },
      {
        type: 'button',
        label: lbl.EDIT,
        name: 'btnEditRP',
        buttonType: 'button',
        id: 'viewpu-edit-btn',
        trigerOnClick: 'true',
        eventRef: 'btnEditForRP',
        tabIndex: 18,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {
        type: 'button',
        label: lbl.DELETE,
        name: 'btnDeleteRP',
        buttonType: 'button',
        id: 'viewpu-delete-btn',
        trigerOnClick: 'true',
        eventRef: 'btnDeleteForRP',
        tabIndex: 19,
        apiUrl: apiUrl.REGULAR_PICKUP,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      demographicDetailsConfig,
      pickupRouteDetailsConfig,
      clientDetailsConfig,
      remarkDetailsConfig
    ]
  }
];

export const editPickupConfig = [
  {
    type: 'header',
    rows: [
      backIconConfigAddEdit,
      {
        type: 'label',
        label: lbl.EDIT_REGULAR_PICKUP,
        classes: {
          labelHead: true
        },
      }
    ]
  },
  {
    type: 'row',
    rows: [
      demographicDetailsConfig,
      pickupRouteDetailsConfig,
      clientDetailsConfig,
      remarkDetailsConfig,
      {
        type: 'button',
        label: lbl.CANCEL,
        name: 'btnCancelEditRP',
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'editpu-cancel-btn',
        eventRef: 'btnCancelEditForRP',
        tabIndex: 19,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      },
      {
        type: 'button',
        label: lbl.SAVE,
        buttonType: 'button',
        id: 'editpu-save-btn',
        trigerOnClick: 'true',
        alignRight: true,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        },
        eventRef: 'SubmitForUpdateRP',
        apiUrl: apiUrl.REGULAR_PICKUP,
        tabIndex: 18
      }
    ]
  }
];
