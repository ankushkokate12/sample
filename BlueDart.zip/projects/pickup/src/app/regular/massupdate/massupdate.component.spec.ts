import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MassupdateComponent } from './massupdate.component';

describe('MassupdateComponent', () => {
  let component: MassupdateComponent;
  let fixture: ComponentFixture<MassupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MassupdateComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MassupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
