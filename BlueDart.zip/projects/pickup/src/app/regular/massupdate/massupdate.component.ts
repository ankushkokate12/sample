import { Component, Input, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { massupdateconfig } from './massupdate.config';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { Router } from '@angular/router';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import * as displayMsg from '../../../assets/messages.json';
import { MessageService as AlertService } from 'primeng/api';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';

@Component({
  selector: 'app-massupdate',
  templateUrl: './massupdate.component.html',
  styleUrls: ['./massupdate.component.scss']
})
export class MassupdateComponent implements OnInit, OnDestroy {
  @Input() name: string;
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  regConfig: FieldConfig[];
  isShown: boolean;
  rowsdata = [];
  areaCd;
  currentUser: any;
  constructor(private messageService: MessageService,
    private router: Router,
    private restService: RestService,
    private eventEmitt: EventEmitterService,
    private sharedService: SharedService,
    private element: ElementRef,
    private ngsk: NgShortcutService,
    private authenticationService: AuthenticationService,
    public dialog: MatDialog,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.regConfig = massupdateconfig;

    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#mu-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('h', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#mu-pickup-route')) {
        this.element.nativeElement.querySelector('#mu-pickup-route-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#mup-pickup-route')) {
        this.element.nativeElement.querySelector('#mup-pickup-route-help')?.click();
      }
    }, {
        preventDefault: true,
        altKey: true
      }));

    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#mu-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('H', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#mu-pickup-route')) {
        this.element.nativeElement.querySelector('#mu-pickup-route-help')?.click();
      }
      else if (document.activeElement == this.element.nativeElement.querySelector('#mup-pickup-route')) {
        this.element.nativeElement.querySelector('#mup-pickup-route-help')?.click();
      }
    }, {
        preventDefault: true,
        altKey: true
      }));
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCode');
  }

  get pickupRoute() {
    return this.form.form.get('txtMassUpdatePURouteCode');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'serachMassUpdate':
          this.massUpdatePanel(field);
          break;
        case 'resetmassupdate':
          this.resetMassUpdate();
          break;
        case 'txtAreaForMassUpdate':
          this.validateAreaCode(field);
          break;
        case 'txtServiceCenterForMassUpdate':
          this.validateServiceCenterCode(field);
          break;
        case 'txtMassUpdatePURouteCode':
          field["helpEventRef"] ? this.openDialogHelp(field) : this.validatePickupRoute(field);
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      this.setFocusOnNodeByName('txtMassUpdatePURouteCode');
      this.populateAreaServiceCode();
    });
  }

  setFocusOnNodeByName(name = "") {
    const nodes = this.element.nativeElement.querySelectorAll('Input');
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i]["name"] == name) {
        nodes[i].focus();
        break;
      }
    }
  }
  submit(event) {
    console.log(event);
  }

  populateAreaServiceCode() {
    this.form.form.controls['txtArea'].setValue(this.currentUser.area);
    this.form.form.controls['txtServiceCode'].setValue(this.currentUser.location);
  }

  openDialogHelp(field) {
    if (this.serviceCentre.value && this.serviceCentre.valid) {
      let payload = {
        "a": this.serviceCentre.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_ROUTE_TITLE,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(res => {
        if (res) {
          this.form.form.controls[field.name].setValue(res);
          this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
        }
      });
    }
  }

  massUpdatePanel(field) {
    //this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.form.form.valid) {
      this.isShown = false;
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value,
        "c": this.pickupRoute.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res && res.length) {
            this.sharedService.setData(res);
            this.areaCd = this.area.value;
            this.isShown = true;
          } else {
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            //this.setErrorPanel(field.name, displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.showToaster(err.error.data[0]);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.name, err.error.data[0], VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  navigateTo(url: Array<string>, params: any = {}) {
    this.router.navigate(url, { queryParams: params });
  }

  resetMassUpdate() {
    if (this.form.form.dirty || this.form.form.touched) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.RESET.TITLE,
          message: displayMsg.RESET.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.form.form.reset();
          this.populateAreaServiceCode();
          this.isShown = false;
          this.setFocusOnNodeByName('txtMassUpdatePURouteCode');
        }
      });
    }
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.valid && this.area.value) {
      const payload = {
        "a": this.area.value,   //areaCode
        "b": this.serviceCentre.value  //serviceCenter
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.serviceCentre.valid) {
      const payload = {
        "a": this.area.value,           //areaCode
        "b": this.serviceCentre.value   //serviceCode
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePickupRoute(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.pickupRoute.valid && this.pickupRoute.value) {
      const payload = {
        "a": this.pickupRoute.value,
        "b": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res.c) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  showToaster(message, type = "error") {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  ngOnDestroy() {
    this.form.form.reset();
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }
}
