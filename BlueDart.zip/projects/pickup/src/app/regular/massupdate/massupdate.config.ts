import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { pickupRouteList } from 'projects/pickup/src/app/app.constant'; 
const commonValidators = new CommonValidators(); 

export const massupdateconfig = [ 
  {
    type: 'row',
    rows: [
              {
                type: 'input',
                label: lbl.AREA,
                inputType: 'text',
                name: 'txtArea',
                validations: commonValidators.AREA_CODE_VALIDATOR,
                class: 'col w90 p-l-0',
                tabIndex: 1,
                eventRef: 'txtAreaForMassUpdate',
                apiUrl: apiUrl.VALIDATE_AREA_CODE,
                maxlength: "3"
              },
              {
                type: 'input',
                label: lbl.SERVICE_CENTER,
                inputType: 'text',
                name: 'txtServiceCode',
                validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
                class: 'col w180 p-l-0',
                tabIndex: 2,
                eventRef: 'txtServiceCenterForMassUpdate',
                apiUrl:  apiUrl.VALIDATE_SERVICE_CENTERS,
              maxlength: "3"
              },
              {
                type: 'input',
                label: lbl.PICKUP_ROUTE,
                inputType: 'text',
                name: 'txtMassUpdatePURouteCode',
                validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
                helpIconComp: true,
                id: 'mu-pickup-route',
                helpId: 'mu-pickup-route-help',
                submitValue: 'Route Code',
                helpDialogWidth:500,
                helpDialogGridColumns: pickupRouteList,
                helpApiUrl: apiUrl.ROUTE_CODES,  
                class: 'col w180 p-l-0',
                tabIndex: 3,
                eventRef: 'txtMassUpdatePURouteCode',
                apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
                maxlength: "2"
              },
              {
                type: 'button',
                label: lbl.SEARCH,
                buttonType: 'button',
                trigerOnClick: 'true',
                eventRef: 'serachMassUpdate',
                tabIndex: 4,
                id: 'mu-search-btn',
                class: 'col w155 p-l-0',
                apiUrl:  apiUrl.ALL_REGULAR_PICKUP,
                classes: {
                  buttonType: 'primary-button'
                }
              }
            ]
      }
];
