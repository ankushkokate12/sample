import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MassupdatepanelComponent } from './massupdatepanel.component';

describe('MassupdatepanelComponent', () => {
  let component: MassupdatepanelComponent;
  let fixture: ComponentFixture<MassupdatepanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MassupdatepanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MassupdatepanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
