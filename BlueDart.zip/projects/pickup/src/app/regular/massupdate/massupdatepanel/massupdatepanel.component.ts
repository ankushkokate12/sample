import { Component, OnInit, ViewChild, AfterViewInit, Input, ElementRef, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { newDemoDconfig } from '../massupdatepanel/newdemod.config';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { IGridColumn } from 'projects/tools/src/lib/interfaces/grid-columns.interface';
import { DynamicGridComponent } from 'projects/tools/src/public-api';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { Router } from '@angular/router';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { MessageService as AlertService } from 'primeng/api';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';

@Component({
  selector: 'app-massupdatepanel',
  templateUrl: './massupdatepanel.component.html',
  styleUrls: ['./massupdatepanel.component.scss']
})

export class MassupdatepanelComponent implements OnInit, OnDestroy {
  @Input() areaCd: string;
  @Input() name: string;
  gridCaption: string = displayMsg.MASS_UPDATE_PICKUP_GRID_CAPTION;
  ELEMENT_DATA: any = [];
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  regConfig: FieldConfig[];
  regDemoD: FieldConfig[];
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  data: IGridColumn[];
  rows = {};
  scrollHeight: string = "40vh";
  isSortable = true;
  selectedRecordsToUpdate: any = [];
  originalSearchData: any = [];
  columnData = [
    {
      field: "d",
      header: lbl.SERIAL_NO,
      colWidth: "30px"
    },
    {
      field: "e",
      header: lbl.CLIENT_NAME,
      colWidth: "50px"
    },
    {
      field: "fgh",
      header: lbl.ADDRESS,
      colWidth: "100px"
    },
    {
      field: "i",
      header: lbl.PINCODE,
      colWidth: "38px"
    },
    {
      field: "j",
      header: lbl.TELEPHONE,
      colWidth: "50px"
    },
    {
      field: "k",
      header: lbl.MOBILE_NUMBER,
      colWidth: "50px"
    },
    {
      field: "aa",
      header: lbl.TRANSACTION_CODE,
      colWidth: "45px"
    },
    {
      field: "n",
      header: lbl.PICKUP_TIME,
      colWidth: "34px"
    },
    {
      field: "o",
      header: lbl.PICKUP_DAYS,
      colWidth: "50px"
    }
  ];

  constructor(
    private messageService: MessageService,
    private router: Router,
    private restService: RestService,
    private eventEmitt: EventEmitterService,
    private sharedService: SharedService,
    public dialog: MatDialog,
    private alertService: AlertService,
    private element: ElementRef,
    private ngsk: NgShortcutService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.regDemoD = newDemoDconfig;
    ngsk.push(new NgShortcut('s', () => this.element.nativeElement.querySelector('#massupdate-save-btn').click(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCodeForMassUpdate');
  }

  get pickupRoute() {
    return this.form.form.get('txtPURouteCodeForMassUpdate');
  }

  ngOnInit(): void {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'updateBulkRegularPickup':
          this.updateBulkRegularPickup(field);
          break;
        case 'newServiceCenterForMassUpdate':
          this.validateServiceCenterCode(field);
          break;
        case 'newPURouteCodeForMassUpdate':
          field["helpEventRef"] ? this.openDialogHelp(field) : this.validatePickupRoute(field);
          break;
      }
    });

    this.originalSearchData = this.sharedService.getData();
    this.ELEMENT_DATA = this.initializeTableData([...this.originalSearchData]);
  }

  ngAfterViewInit() {
    this.setFocusOnNodeByName('txtServiceCodeForMassUpdate');
  }

  setFocusOnNodeByName(name = "") {
    const nodes = this.element.nativeElement.querySelectorAll('Input');
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i]["name"] == name) {
        nodes[i].focus();
        break;
      }
    }
  }

  initializeTableData(data) {
    return data.map(ele => {
      let record = { ...ele };
      const temp = [record['f'], record['g'], record['h']];
      const address = temp.join();
      record['fgh'] = address;
      record.n = this.convertTime24to12(record.n);
      record.o = this.addComma(record.o);
      return record;
    })
  }

  submit(event) {
  }

  getSelectedRow(evt) {
    this.selectedRecordsToUpdate = evt;
    this.setErrorPanel('mu-grid-update', "", VALIDATION_STATUS.VALID);
  }

  openDialogHelp(field) {
    if (this.serviceCentre.value && this.serviceCentre.valid) {
      let payload = {
        "a": this.serviceCentre.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_ROUTE_TITLE,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.MASS_UPDATE_ROUTE_DATA
        }
      });

      dialogRef.afterClosed().subscribe(res => {
        if (res) {
          this.form.form.controls[field.name].setValue(res);
          this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
        }
      });
    }
  }

  removeUpdatedRecordFromGrid() {
    this.selectedRecordsToUpdate.forEach(ele => {
      const index = this.ELEMENT_DATA.indexOf(ele);
      if (index > -1) {
        this.ELEMENT_DATA.splice(index, 1);
      }
    })
    this.selectedRecordsToUpdate = [];
    this.form.form.reset();
  }

  getActualRecord(data) {
    return data.map(ele => {
      let temp = { ...ele };
      delete temp['fgh'];
      temp.n = this.convertTime12to24(temp['n']);
      temp.o = this.removeComma(temp['o']);
      return temp;
    })
  }

  updateBulkRegularPickup(field) {
    //this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.form.form.valid) {
      if (this.selectedRecordsToUpdate.length) {
        let payload = {
          "a": this.serviceCentre.value,
          "b": this.pickupRoute.value,
          "c": "1",
          "d": this.getActualRecord([...this.selectedRecordsToUpdate])
        };

        if (payload) {
          this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
            (res: any) => {
              if (!res.a) {
                this.removeUpdatedRecordFromGrid();
                this.showToaster(res.b, 'success');
                if (this?.ELEMENT_DATA?.length === 0) {
                  var elements = document.getElementsByClassName("routeUpdateSection");
                  Array.from(elements).forEach(function (element) {
                    element.setAttribute('hidden', 'true');
                  });
                }
                this.navigateTo(['/pickup/regular/massupdate']);
                this.element.nativeElement.querySelector('#mup-service-centre')?.focus();
              }
              else {
                this.showToaster(res.b);
                BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
                //this.setErrorPanel(field.name, res.b, VALIDATION_STATUS.INVALID);
              }
            },
            (err) => {
              this.showToaster(err.error.b);
              BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
              //this.setErrorPanel(field.name, err.error.b, VALIDATION_STATUS.INVALID);
            }
          );
        }
      } else {
        this.setErrorPanel('mu-grid-update', displayMsg.MASS_UPDATE_EMPTY_SELECTION, VALIDATION_STATUS.INVALID);
      }
    } else this.form.validateAllFormFields(this.form.form);
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.valid && this.serviceCentre.value) {
      let payload = {
        "a": this.areaCd,           //areaCode
        "b": this.serviceCentre.value   //serviceCode
      };

      if (payload) {
        this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
          (res: any) => {
            if (res.a) {
              this.form.form.controls[field.name].setErrors({ 'pattern': true });
              this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
            }
          },
          () => {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        );
      }
    }
  }

  validatePickupRoute(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.value && this.pickupRoute.valid && this.pickupRoute.value) {
      let payload = {
        "a": this.pickupRoute.value,
        "b": this.serviceCentre.value
      };

      if (payload) {
        this.restService.get(field["apiUrl"], '', payload).subscribe(
          (res: any) => {
            if (res.c) {
              this.form.form.controls[field.name].setErrors({ 'pattern': true });
              this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
            }
          },
          (err) => {
            this.setErrorPanel(field.name, err.error.b, VALIDATION_STATUS.INVALID);
          }
        );
      }
    }
  }

  showToaster(message, type='error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  navigateTo(url: Array<string>, params: any = {}) {
    this.router.navigate(url, { queryParams: params });
  }

  convertTime12to24(time12) {
    if (time12) {
      const [hours, minutes] = time12.split(':');
      return `${hours}${minutes}`;
    }
    return null;
  }

  convertTime24to12(time24) {
    if (time24) {
      const [sHours, minutes] = time24.match(/([0-9]{1,2})([0-9]{2})/).slice(1);
      return `${sHours}:${minutes}`;
    }
    return null;
  }

  removeComma(str) {
    return str ? str.split(",").join("") : "";
  }

  addComma(str) {
    if (str != null) {
      str = str.trim();
      return str.split("").join(",")
    }
  }

  ngOnDestroy() {
    this.form.form.reset();
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }
}
