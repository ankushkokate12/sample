import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import * as lbl from 'projects//login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app//pickup-module-api.constant';
import { pickupRouteList } from 'projects/pickup/src/app/app.constant';
const commonValidators = new CommonValidators();

export const newDemoDconfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'section',
        label: lbl.NEW_DEMOGRAPHIC_DETAILS,
        alignRight: true,
        class: 'col p-r-0',
        section: [{
          type: 'row',
          rows: [
            {
              type: 'input',
              label: lbl.SERVICE_CENTER,
              id: 'mup-service-centre',
              inputType: 'text',
              name: 'txtServiceCodeForMassUpdate',
              validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
              class: 'col w180 plr-8',
              tabIndex: 6,
              eventRef: 'newServiceCenterForMassUpdate',
              apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
              maxlength: "3"
            },
            {
              type: 'empty',
              class:'col w150'
            },
            {
              type: 'input',
              label: lbl.ROUTE_CODE,
              inputType: 'text',
              name: 'txtPURouteCodeForMassUpdate',
              validations: commonValidators.PICKUP_ROUTE_VALIDATOR,
              helpIconComp: true,
              id: 'mup-pickup-route',
              helpId: 'mup-pickup-route-help',
              submitValue: 'Route Code',
              helpDialogWidth: 500,
              helpDialogGridColumns: pickupRouteList,
              helpApiUrl: apiUrl.ROUTE_CODES,
              class: 'col w180 plr-8',
              tabIndex: 7,
              eventRef: 'newPURouteCodeForMassUpdate',
              apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
              maxlength: "2"
            }
          ]
        }],
      }
    ]
  },
  {
    type: 'row',
    rows: [
    //TODO: Need to add below code when Cancel button is finalized in the screen
      //{
      //  type: 'button',
      //  label: lbl.CANCEL,
      //  buttonType: 'button',
      //  trigerOnClick: 'true',
      //  id: 'massupdate-cancel-btn',
      //  tabIndex: 9,
      //  eventRef: 'cancelBulkRegularPickup',
      //  classes: {
      //    buttonType: 'action-button',
      //    rightAlign: true
      //  }
      //},
      {
        type: 'button',
        label: lbl.SAVE,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'massupdate-save-btn',
        tabIndex: 8,
        eventRef: 'updateBulkRegularPickup',
        apiUrl: apiUrl.BULK_REGULAR_PICKUP,
        classes: {
          buttonType: 'primary-button',
          rightAlign: true
        }
      }
    ]
  }
];
