import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { MassupdateComponent } from './massupdate/massupdate.component';
import { RegularComponent } from './regular.component';
import { RegularsearchComponent } from './regularsearch/regularsearch.component';
import { AddpickupComponent } from './addpickup/addpickup.component';
 
const routes: Routes = [
  { path: "", redirectTo: "regular"},
  {
    path: "regular",
    component: RegularComponent,
    children: [
      { path: '', redirectTo: 'search', pathMatch: 'full' },
      {
        path: "search",
        component: RegularsearchComponent
      },
      {
        path: "massupdate",
        component: MassupdateComponent
      }
    ]
  },
  {
    path: "add",
    component: AddpickupComponent
  },
  {
    path: "edit",
    component: AddpickupComponent
  },
  {
    path: "view",
    component: AddpickupComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegularRoutingModule {}
