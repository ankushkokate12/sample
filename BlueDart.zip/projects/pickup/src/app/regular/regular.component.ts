import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { regularconfigWithAdd, regularconfigWithoutAdd } from './regular.config';
import { Router } from '@angular/router';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';

@Component({
  selector: 'app-regular',
  templateUrl: './regular.component.html',
  styleUrls: ['./regular.component.scss']
})
export class RegularComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;
  regConfig: FieldConfig[];
  isShown = true;
  tabs = displayMsg.REGULAR_TABS;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private ngsk: NgShortcutService,
    private element: ElementRef,
    private router: Router
  ) {
    this.messageService.sendHeaderShowMessage(true);

    ngsk.push(new NgShortcut('r', () => {
      if (this.router.url.includes('search'))
        this.element.nativeElement.querySelector('#rp-reset-btn')?.click();
      else {
        this.element.nativeElement.querySelector('#mu-reset-btn')?.click();
      }
    }, {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('R', () => {
      if (this.router.url.includes('search'))
        this.element.nativeElement.querySelector('#rp-reset-btn')?.click();
      else {
        this.element.nativeElement.querySelector('#mu-reset-btn')?.click();
      }
    }, {
      preventDefault: true,
      ctrlKey: true
      }));

    ngsk.push(new NgShortcut('U', () => this.onTabChange('massupdate'), {
      preventDefault: false,
      altKey: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('u', () => this.onTabChange('massupdate'), {
      preventDefault: false,
      altKey: true,
      ctrlKey: true
    }));
  }

  ngOnInit(): void {
    this.regConfig = (this.router.url.includes('search')) ? regularconfigWithAdd : regularconfigWithoutAdd;
    this.eventEmitt.subsVar = this.eventEmitt.
      invokeCommonComponentFunction.subscribe((field: string) => {
        if (field["eventRef"] == 'addPickupRoute')
          this.addPickupRoute();
      });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  addPickupRoute() {
    this.router.navigate(['pickup/add']);
  }

  onTabChange(tabname) {
    const tabUrlMap = {
      search: 'pickup/search',
      massupdate: 'pickup/massupdate'
    }
    this.regConfig = tabname == 'search' ? regularconfigWithAdd : regularconfigWithoutAdd;
    this.router.navigate([tabUrlMap[tabname]]);
    // TODO: To restore conditional routereuse
    // this.router.navigate([tabUrlMap[tabname]], { queryParams: { showSnap: "YES" } });
  }
}
