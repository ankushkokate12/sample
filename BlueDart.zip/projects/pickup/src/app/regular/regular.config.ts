import * as lbl from 'projects/login/src/assets/labelDataList.json';

export const regularconfigWithAdd = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.REGULAR_PICKUP,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'button',
        label: lbl.ADD,
        name: 'addRegularPK',
        eventRef: 'addPickupRoute',
        alignRight: true,
        buttonType: 'button',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        },
        height: 34,
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'rp-reset-btn',
        eventRef: 'resetForRPSearch',
        tabIndex: 6,
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        },
        height: 34,
        separatorBefore: true
      }
    ]
  }
];



export const regularconfigWithoutAdd = [ 
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.REGULAR_PICKUP,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        tabIndex: 5,
        id: 'mu-reset-btn',
        height: 34,
        eventRef: 'resetmassupdate',
        classes: {
          buttonType: 'action-button',
          rightAlign: true
        }
      }
    ]
  }
  
];
