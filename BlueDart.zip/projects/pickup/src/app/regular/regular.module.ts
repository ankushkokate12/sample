import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegularComponent } from './regular.component';
import { RegularRoutingModule } from './regular-routing.module';
import { RegularsearchComponent } from './regularsearch/regularsearch.component';
import { MassupdateComponent } from './massupdate/massupdate.component';
import { ToolsModule } from '../../../../tools/src/public-api'; 
import { AddpickupComponent } from './addpickup/addpickup.component';
import { MassupdatepanelComponent } from './massupdate/massupdatepanel/massupdatepanel.component';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { NgShortcutModule } from 'ng-shortcut';

@NgModule({
  declarations: [RegularComponent, RegularsearchComponent, MassupdateComponent, AddpickupComponent, MassupdatepanelComponent],
  providers: [MessageService],
  imports: [
    CommonModule,
    ToolsModule,
    ToastModule,
    RegularRoutingModule,
    NgShortcutModule.forRoot()
  ]
})
export class RegularModule { }
