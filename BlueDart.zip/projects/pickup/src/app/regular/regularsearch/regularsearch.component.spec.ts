import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularsearchComponent } from './regularsearch.component';

describe('RegularsearchComponent', () => {
  let component: RegularsearchComponent;
  let fixture: ComponentFixture<RegularsearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegularsearchComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
