import { Component, Input, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { regularsearchconfig } from './regularsearch.config';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { Router } from '@angular/router';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import * as displayMsg from '../../../assets/messages.json';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import { NgShortcutService, NgShortcut } from 'ng-shortcut';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { MessageService as AlertService } from 'primeng/api';

@Component({
  selector: 'app-regularsearch',
  templateUrl: './regularsearch.component.html',
  styleUrls: ['./regularsearch.component.scss']
})

export class RegularsearchComponent implements OnInit, OnDestroy {
  @Input() name: string;
  regConfig: FieldConfig[];
  @ViewChild(DynamicFormComponent, { static: false }) form: DynamicFormComponent;
  currentUser: any;

  constructor(
    private messageService: MessageService,
    private eventEmitt: EventEmitterService,
    private router: Router,
    private restService: RestService,
    private sharedService: SharedService,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    public dialog: MatDialog,
    private ngsk: NgShortcutService,
    private alertService: AlertService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    ngsk.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#rp-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('n', () => this.addPickupRoute(), {
      preventDefault: false,
      altKey: true
    }));

    ngsk.push(new NgShortcut('h', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#rp-serial-no')) {
        this.element.nativeElement.querySelector('#rp-serial-no-help')?.click();
      }
    }, {
        preventDefault: true,
        altKey: true
      }));

    ngsk.push(new NgShortcut('F', () => this.element.nativeElement.querySelector('#rp-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    ngsk.push(new NgShortcut('N', () => this.addPickupRoute(), {
      preventDefault: false,
      altKey: true
    }));

    ngsk.push(new NgShortcut('H', () => {
      if (document.activeElement == this.element.nativeElement.querySelector('#rp-serial-no')) {
        this.element.nativeElement.querySelector('#rp-serial-no-help') ?.click();
      }
    }, {
        preventDefault: true,
        altKey: true
      }));
  }

  addPickupRoute() {
    this.router.navigate(['pickup/add']);
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCenter');
  }

  get clientCode() {
    return this.form.form.get('txtClientCode');
  }

  get serialNo() {
    return this.form.form.get('txtSerialNumber');
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.currentUserValue;
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'viewPickupForRPSearch':
          this.viewPickupRoute(field);
          break;
        case 'resetForRPSearch':
          this.resetSearch();
          break;
        case 'txtAreaForRPSearch':
          this.validateAreaCode(field);
          break;
        case 'txtServiceCenterForRPSearch':
          this.validateServiceCenterCode(field);
          break;
        case 'txtClientCodeForRPSearch':
          this.validateClientCode(field);
          break;
        case 'txtSerialNumberForRPSearch':
          field["helpEventRef"] ? this.helpForSerialNumber(field) : this.validatePickupSerialNumber(field);
          break;
      }
    });
    this.regConfig = regularsearchconfig;
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      setTimeout(() => this.setFocusOnNodeByName('txtClientCode'), 0);
      this.populateAreaServiceCode();
    });
  }

  setFocusOnNodeByName(name = "") {
    const nodes = this.element.nativeElement.querySelectorAll('Input');
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i]["name"] == name) {
        nodes[i].focus();
        break;
      }
    }
  }

  submit(event) {
    console.log(event);
  }

  populateAreaServiceCode() {
    this.form.form.controls['txtArea'].setValue(this.currentUser.area);
    this.form.form.controls['txtServiceCenter'].setValue(this.currentUser.location);
  }

  dataToSave(record) {
    return {
      "areaCode": record.a,
      "serviceCenterCode": record.b,
      "clientCode": record.c,
      "clientName": record.d,
      "a1": record.e,
      "a2": record.f,
      "a3": record.g,
      "pincode": record.h,
      "telephone": record.i,
      "contactPerson": record.j,
      "transactionCode": record.k,
      "pickupTime": this.convertTime24to12(record.l),
      "remark": record.m,
      "pickupRoute": record.n,
      "pickUpSerialNumber": record.p,
      "pickupDays": record.q,
      "mobile": record.r
    }
  }

  viewPickupRoute(field) {
    //this.setErrorPanel(field.id, "", VALIDATION_STATUS.VALID);
    if (this.form.form.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.clientCode.value,
        "c": this.serviceCentre.value,
        "d": this.serialNo.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res) {
            this.sharedService.setData(this.dataToSave(res));
            this.router.navigate(['pickup/view']);
          } else {
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            //this.setErrorPanel(field.id, displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.showToaster(displayMsg.ERROR);
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          //this.setErrorPanel(field.id, displayMsg.ERROR, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  helpForSerialNumber(field) {
    if (this.clientCode.value && this.clientCode.valid && this.area.value && this.area.valid && this.serviceCentre.value && this.serviceCentre.valid) {
      let payload = {
        "a": this.clientCode.value,
        "b": this.area.value,
        "c": this.serviceCentre.value,
        "i1": "0",
        "i2": "100"
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.CLIENT_DETAILS_TITLE,
          apiurl: field.helpApiUrl,
          gridColumns: field.helpDialogGridColumns,
          fieldname: field.submitValue,
          payload: payload,
          noteText: displayMsg.PICKUP_SRNO_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress != false && ress != '' && ress != undefined) {
          this.form.form.controls[field.name].setValue(ress);
        }
      });
    }
  }

  validateAreaCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.area.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_AREA, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.serviceCentre.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validateClientCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.clientCode.value && this.clientCode.valid) {
      const payload = {
        "a": this.area.value,
        "b": this.clientCode.value,
        "c": this.serviceCentre.value,
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.b) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.INVALID, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.RP_CLIENT_CODE_MSG.INVALID, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  validatePickupSerialNumber(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.area.value && this.serviceCentre.value && this.clientCode.value && this.serialNo.value && this.serialNo.valid) {
      const payload = {
        "a": this.clientCode.value,
        "b": this.area.value,
        "c": this.serialNo.value,
        "d": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (!res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.PICKUP_SERIAL_MSG.INVALID, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.PICKUP_SERIAL_MSG.INVALID, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  resetSearch() {
    if (this.form.form.dirty || this.form.form.touched) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: displayMsg.RESET.TITLE,
          message: displayMsg.RESET.MESSAGE,
          primaryButton: displayMsg.BUTTON.YES,
          secondaryButton: displayMsg.BUTTON.NO
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.form.form.reset();
          this.populateAreaServiceCode();
          this.setFocusOnNodeByName('txtClientCode');
        }
      });
    }
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  convertTime24to12(time24) {
    if (time24) {
      const [sHours, minutes] = time24.match(/([0-9]{1,2})([0-9]{2})/).slice(1);
      return `${sHours}:${minutes}`;
    }
    return null;
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }
}
