import { rrPickupList } from 'projects/pickup/src/app/app.constant';
import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
 
const commonValidators = new CommonValidators();

export const regularsearchconfig = [
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: 'txtArea',
        validations: commonValidators.AREA_CODE_VALIDATOR,
        class: 'col w90 p-l-0',
        tabIndex: 1,
        eventRef: 'txtAreaForRPSearch',
        apiUrl: apiUrl.VALIDATE_AREA_CODE,
        maxlength: "3"
      },
      {
        type: 'input',
        label: lbl.SERVICE_CENTER,
        class: 'col w180 p-l-0',
        inputType: 'text',
        name: 'txtServiceCenter',
        validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
        tabIndex: 2,
        eventRef: 'txtServiceCenterForRPSearch',
        apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
        maxlength: "3"
      },
      {
        type: 'input',
        label: lbl.CLIENT_CODE,
        class: 'col w180 p-l-0',
        inputType: 'text',
        name: 'txtClientCode',
        validations: commonValidators.CLIENT_CODE_VALIDATOR,
        tabIndex: 3,
        eventRef: 'txtClientCodeForRPSearch',
        apiUrl: apiUrl.VALIDATE_CUSTOMER_CODE,
        maxlength: "6"
      },
      {
        type: 'input',
        label: lbl.PICKUP_SERIAL_NO,
        class: 'col w180 p-l-0',
        inputType: 'text',
        name: 'txtSerialNumber',
        validations: commonValidators.PICKUP_SERIAL_NO_VALIDATOR,
        id:'rp-serial-no',
        helpIconComp: true,
        helpId: 'rp-serial-no-help',
        submitValue: 'Serial No',
        helpApiUrl: apiUrl.REGISTERED_REGULAR_PICKUP,
        helpDialogGridColumns: rrPickupList,
        tabIndex: 4,
        eventRef: 'txtSerialNumberForRPSearch',
        apiUrl: apiUrl.VALIDATE_SERIAL_NO,
        maxlength: "2"
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        class: 'col w155 p-l-0',
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'rp-search-btn',
        eventRef: 'viewPickupForRPSearch',
        tabIndex: 5,
        apiUrl: apiUrl.REGULAR_PICKUP,
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];
