import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManifestDataPendingPickupComponent } from './manifest-data-pending-pickup.component';

describe('ManifestDataPendingPickupComponent', () => {
  let component: ManifestDataPendingPickupComponent;
  let fixture: ComponentFixture<ManifestDataPendingPickupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManifestDataPendingPickupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManifestDataPendingPickupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
