import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DynamicFormComponent, DynamicGridComponent } from 'projects/tools/src/public-api';
import { IGridColumn, FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { gridCols } from '../manifest-data-pending-pickup/manifest-data-pending-pickup.constant'
import { manifestDataPendingConfig } from './manifest-data-pending-pickup.config';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { Router } from '@angular/router';
import { MessageService } from 'projects/tools/src/lib/message.service';
import { AuthenticationService } from 'projects/services/src/lib/authentication.service';
import { AUDIO_SETTINGS, NOTIFICATIONS, VALIDATION_STATUS } from 'projects/tools/src/lib/constants/constant';
import * as displayMsg from 'projects/pickup/src/assets/messages.json';
import { MatDialog } from '@angular/material/dialog';
import { HelpicondialogcompComponent } from 'projects/tools/src/lib/components/controls/helpicondialogcomp/helpicondialogcomp.component';
import { BDHelpers } from 'projects/vendors/src/lib/bd.helpers';
import { MessageService as AlertService } from 'primeng/api';
import { Observable } from 'rxjs';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';
import { NgShortcut, NgShortcutService } from 'ng-shortcut';

@Component({
  selector: 'app-manifest-data-pending-pickup',
  templateUrl: './manifest-data-pending-pickup.component.html',
  styleUrls: ['./manifest-data-pending-pickup.component.scss']
})
export class ManifestDataPendingPickupComponent implements OnInit, OnDestroy {

  @ViewChild(DynamicFormComponent, { static: false })
  form: DynamicFormComponent;

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;

  manifestConfig: FieldConfig[];

  gridCols: IGridColumn[] = gridCols;
  rows = [];
  totalRecords = [];
  topCustomers: any = [];
  selectedCustomerRecord = {};
  currentUser: any;

  isTableVisible: boolean;

  fields = {
    height: 40,
    infoLabel: {
      class: 'label-small',
      type: 'static',
    }
  }

  creditLabel: string = "";
  tableHeight: string;

  constructor(
    private eventEmitt: EventEmitterService,
    private restService: RestService,
    private sharedService: SharedService,
    private router: Router,
    private messageService: MessageService,
    private element: ElementRef,
    private authenticationService: AuthenticationService,
    public dialog: MatDialog,
    private alertService: AlertService,
    private ngShortcutService: NgShortcutService
  ) {
    this.messageService.sendHeaderShowMessage(true);
    this.manifestConfig = manifestDataPendingConfig;
    this.ngShortcutService.push(new NgShortcut('f', () => this.element.nativeElement.querySelector('#manifest-search-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));

    this.ngShortcutService.push(new NgShortcut('r', () => this.element.nativeElement.querySelector('#manifest-reset-btn')?.click(), {
      preventDefault: true,
      ctrlKey: true
    }));
  }

  get serviceCentre() {
    return this.form.form.get('txtServiceCentre');
  }

  get noOfDays() {
    return this.form.form.get('txtNoOfDays');
  }

  get pickupRoute() {
    return this.form.form.get('txtPURouteCode');
  }

  get pincode() {
    return this.form.form.get('txtPincode');
  }

  get topCustomer() {
    return this.form.form.get('topCustomers')
  }

  get groupCode() {
    return this.form.form.get('txtGroupCode');
  }

  get area() {
    return this.form.form.get('txtArea');
  }

  get custCode() {
    return this.form.form.get('txtCustomerCode');
  }

  ngOnInit(): void {
    let gridTblHt = window.innerHeight - 150 - 20 - 125;
    this.tableHeight = gridTblHt + 'px';
    this.currentUser = this.authenticationService.currentUserValue;
    console.log('current user:', this.currentUser);
    this.rows = [];
    if (this.rows.length === 0) {
      this.isTableVisible = false;
    }
    this.setCountLabel(this.rows.length);
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((field: string) => {
      switch (field["eventRef"]) {
        case 'txtServiceCentreForManifest':
          this.validateServiceCenterCode(field);
          break;
        case 'txtPURouteCodeForManifest':
          field["helpEventRef"] ? this.openDialogHelpManifest(field) : this.validatePickupRoute(field);
          break;
        case 'searchManifestData':
          this.searchManifestData(field);
          break;
        case 'resetManifestForm':
          this.resetForm();
          break;
      }
    });
  }

  ngAfterViewInit() {
    Promise.resolve().then(() => {
      setTimeout(() => {
        const ele = this.element.nativeElement.querySelector('#manifest-service-centre')
        ele?.focus();
      }, 0);
    });
    this.form.form.controls['txtServiceCentre']?.setValue(this.currentUser.location);
    this.form.form.controls['txtNoOfDays']?.setValue(4);
  }

  submit(evt) {
  }

  validateServiceCenterCode(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.value) {
      const payload = {
        "a": this.currentUser.location,
        "b": this.serviceCentre.value
      };

      this.restService.post(field["apiUrl"], JSON.stringify(payload)).subscribe(
        (res: any) => {
          if (res.a) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_SERVICE_CENTRE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  openDialogHelpManifest(field) {
    if (this.serviceCentre.value) {
      let payload = {
        "a": this.serviceCentre.value
      };
      const dialogRef = this.dialog.open(HelpicondialogcompComponent, {
        disableClose: true,
        width: '' + field.helpDialogWidth + 'px',
        minWidth: 400,
        data: {
          title: displayMsg.PICKUP_ROUTE_TITLE, apiurl: field.helpApiUrl, gridColumns: field.helpDialogGridColumns, fieldname: field.submitValue, payload: payload,
          noteText: displayMsg.PICKUP_ROUTE_NOTE
        }
      });

      dialogRef.afterClosed().subscribe(ress => {
        if (ress) {
          this.form.form.controls[field.name].setValue(ress);
        }
      });
    }
  }

  validatePickupRoute(field) {
    this.setErrorPanel(field.name, "", VALIDATION_STATUS.VALID);
    if (this.serviceCentre.value && this.pickupRoute.value && this.pickupRoute.valid) {
      const payload = {
        "a": this.pickupRoute.value,
        "b": this.serviceCentre.value
      };

      this.restService.get(field["apiUrl"], '', payload).subscribe(
        (res: any) => {
          if (res.c) {
            this.form.form.controls[field.name].setErrors({ 'pattern': true });
            this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          this.form.form.controls[field.name].setErrors({ 'pattern': true });
          this.setErrorPanel(field.name, displayMsg.INVALID_PICKUP_ROUTE, VALIDATION_STATUS.INVALID);
        }
      );
    }
  }

  searchManifestData(field) {
    // this.setErrorPanel(field.id, "", VALIDATION_STATUS.VALID);
    this.resetGridView();
    if (this.serviceCentre.value && (this.noOfDays.value && this.noOfDays.valid)) {
      const payload = {
        "a": this.serviceCentre.value,
        "b": this.noOfDays.value,
        "c": this.pickupRoute.value,
        "d": this.pincode.value,
        "e": this.topCustomer.value,
        "f": this.groupCode.value || null,
        "g": this.area.value,
        "h": this.custCode.value
      };

      console.log('payload', payload);

      this.restService.post(field['apiUrl'], payload).subscribe(
        (res) => {
          if (res.a) {
            this.resetGridView();
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(res.b);
            //this.setErrorPanel(field.id, res.b, VALIDATION_STATUS.INVALID);
          }
          else if (res.data && res.data.length) {
            this.totalRecords = res.data;
            this.rows = res.data;
            this.isTableVisible = true;
            this.setCountLabel(res.data.length);
          }
          else {
            this.resetGridView();
            BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
            this.showToaster(displayMsg.NO_RECORDS_FOUND);
            //this.setErrorPanel(field.id, displayMsg.NO_RECORDS_FOUND, VALIDATION_STATUS.INVALID);
          }
        },
        (err) => {
          BDHelpers.playSound(AUDIO_SETTINGS.PLAY_SOUND);
          this.showToaster(err.error.message);
          this.resetGridView();
          //this.setErrorPanel(field.id, err.error.b, VALIDATION_STATUS.INVALID);
        })
    } else if (this.noOfDays.value === "") {
      this.setErrorPanel(field.id, displayMsg.NO_OF_DAYS_BLANK, VALIDATION_STATUS.INVALID);
    }
    else {
      this.setErrorPanel(field.id, displayMsg.ONE_SEARCH_CRITERIA, VALIDATION_STATUS.INVALID);
    }
  }

  setCountLabel(count: number = 0) {
    this.manifestConfig[0].rows[1].label = count ? count + ' Pending Pickup(s) Available' : '';
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: "api",
      label: "",
      message: message,
      status: type,
      screenName: this.router.url
    }

    this.sharedService.setErrorMessage(errorObj);
  }

  resetForm() {
    this.setErrorPanel('manifest-search-btn', "", VALIDATION_STATUS.VALID);
    this.form.form.reset();
    this.resetGridView();
    this.serviceCentre.setValue(this.currentUser.location)
  }

  resetGridView() {
    this.rows = [];
    this.totalRecords = [];
    this.setCountLabel();
    this.isTableVisible = false;
  }

  showToaster(message, type = 'error') {
    this.alertService.add({
      key: 'bc',
      severity: type,
      detail: message,
      life: NOTIFICATIONS.life
    });
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }

    this.resetForm(); // todo: need to remove when we will implement state management
  }

}
