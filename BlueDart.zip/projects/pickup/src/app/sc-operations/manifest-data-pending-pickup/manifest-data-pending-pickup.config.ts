import * as lbl from 'projects/login/src/assets/labelDataList.json';
import { CommonValidators } from 'projects/vendors/src/lib/common.validator';
import { apiUrl } from 'projects/pickup/src/app/pickup-module-api.constant';

const commonValidators = new CommonValidators();

export const pickupRouteList = [
  {
    field: "a",
    header: lbl.SERVICE_CENTER,
    showFilter: true
  },
  {
    field: "b",
    header: lbl.ROUTE_CODE,
    showFilter: true
  },
  {
    field: "c",
    header: lbl.ROUTE_NAME,
    showFilter: true
  }
];

export const manifestDataPendingConfig = [
  {
    type: 'header',
    rows: [
      {
        type: 'label',
        label: lbl.MANIFEST_DATA_PENDING_PICKUP,
        classes: {
          labelHead: true
        }
      },
      {
        type: 'label',
        label: '',
        classes: {
          labelHead: true,
          greenHead: true
        }
      },
      {
        type: 'button',
        label: lbl.RESET,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'manifest-reset-btn',
        eventRef: 'resetManifestForm',
        tabIndex: 10,
        classes: {
          buttonType: 'action-button',
          rightAlign: true,
        }
      }
    ]
  },
  {
    type: 'row',
    rows: [
      {
        type: 'input',
        label: lbl.SERVICE_CENTER,
        class: 'col w120 p-l-0',
        inputType: 'text',
        name: 'txtServiceCentre',
        validations: commonValidators.SERVICE_CENTER_CODE_VALIDATOR,
        tabIndex: 1,
        eventRef: 'txtServiceCentreForManifest',
        apiUrl: apiUrl.VALIDATE_SERVICE_CENTERS,
        maxlength: "3",
        id: 'manifest-service-centre',
        disabled: true
      },
      {
        type: 'input',
        label: lbl.NO_OF_DAYS,
        inputType: 'text',
        name: 'txtNoOfDays',
        class: 'col w90 p-l-0',
        tabIndex: 2,
        maxlength: "2",
        regExp: commonValidators.regexExpressions.ONLY_NUMBER,
        validations: commonValidators.NO_OF_DAYS_LENGTH_VALIDATOR
      },
      {
        type: 'input',
        label: lbl.PICKUP_ROUTE,
        inputType: 'text',
        name: 'txtPURouteCode',
        id: 'manifest-pickup-route',
        helpId: 'manifest-pickup-route-help',
        helpIconComp: true,
        submitValue: 'Route Code',
        helpDialogWidth: 500,
        helpDialogGridColumns: pickupRouteList,
        helpApiUrl: apiUrl.ROUTE_CODES,
        class: 'col w130 p-l-0',
        tabIndex: 3,
        eventRef: 'txtPURouteCodeForManifest',
        apiUrl: apiUrl.VALIDATE_ROUTE_CODE,
        maxlength: '2'
      },
      {
        type: 'input',
        label: lbl.PINCODE,
        inputType: 'text',
        name: 'txtPincode',
        maxlength: '6',
        regExp: commonValidators.regexExpressions.ONLY_NUMBER,
        validations: commonValidators.PINCODE_LENGTH_VALIDATOR,
        class: 'col w120 p-l-0',
        tabIndex: 4,
        eventRef: 'txtPincodeForManifest',
        apiUrl: apiUrl.VALIDATE_PINCODE,
      },
      {
        class: 'col w140 p-l-0',
        type: 'select',
        label: lbl.TOPCUSTOMERS,
        name: 'topCustomers',
        multiple: false,
        ApiUrl: apiUrl.MANIFEST_TOP_CUSTOMERS,
        eventRef: 'manifestTopCustomers',
        map: {
          label: 'a',
          value: 'a'
        },
        tabIndex: 5
      },
      {
        type: 'input',
        label: lbl.GROUP_CODE,
        inputType: 'text',
        name: 'txtGroupCode',
        validations: commonValidators.GROUP_CODE_VALIDATOR,
        class: 'col w140 p-l-0',
        tabIndex: 6,
        maxlength: "6"
      },
      {
        type: 'input',
        label: lbl.AREA,
        inputType: 'text',
        name: 'txtArea',
        eventRef: 'txtAreaCodeForManifest',
        apiUrl: apiUrl.VALIDATE_AREA_CODE,
        validations: commonValidators.MANIFEST_AREA_CODE_VALIDATOR,
        class: 'col w90 p-l-0',
        tabIndex: 7,
        maxlength: "3",
        id: 'cdata-area-code'
      },
      {
        type: 'input',
        label: lbl.CUSTOMER_CODE,
        inputType: 'text',
        validations: commonValidators.MANIFEST_CUSTOMER_CODE_VALIDATOR,
        name: 'txtCustomerCode',
        class: 'col w120 p-l-0',
        tabIndex: 8,
        maxlength: "6"
      },
      {
        type: 'button',
        label: lbl.SEARCH,
        buttonType: 'button',
        trigerOnClick: 'true',
        id: 'manifest-search-btn',
        eventRef: 'searchManifestData',
        tabIndex: 9,
        class: 'col w150 p-l-0',
        apiUrl: apiUrl.MANIFEST_DATA_SEARCH,
        classes: {
          buttonType: 'primary-button'
        }
      }
    ]
  }
];
