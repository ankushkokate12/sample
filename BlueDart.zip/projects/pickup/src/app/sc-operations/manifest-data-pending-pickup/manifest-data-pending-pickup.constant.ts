export const gridCols = [
  {
    field: 'a',
    header: 'Vendor Code',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'b',
    header: 'Cust Code',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'c',
    header: 'Customer Address',
    showFilter: true,
  },
  {
    field: 'd',
    header: 'Customer Pincode',
    showFilter: true,
    colWidth: '100px'
  },
  {
    field: 'e',
    header: 'Customer Phone',
    showFilter: true,
    colWidth: '120px'
  },
  {
    field: 'f',
    header: 'Customer Mobile',
    showFilter: true,
    colWidth: '120px'
  },
  {
    field: 'g',
    header: 'Apex Etail',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'h',
    header: 'SFC Etail',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'i',
    header: 'RVP',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'j',
    header: 'DP',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'k',
    header: 'Apex',
    showFilter: true,
    colWidth: '60px'
  },
  {
    field: 'l',
    header: 'SFC',
    showFilter: true,
    colWidth: '60px'
  }
];
