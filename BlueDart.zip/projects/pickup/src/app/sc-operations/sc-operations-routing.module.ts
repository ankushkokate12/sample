import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManifestDataPendingPickupComponent } from './manifest-data-pending-pickup/manifest-data-pending-pickup.component';

const routes: Routes = [
  {
    path: "manifest-data-pending-pickup",
    component: ManifestDataPendingPickupComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ScOperationsRoutingModule { }
