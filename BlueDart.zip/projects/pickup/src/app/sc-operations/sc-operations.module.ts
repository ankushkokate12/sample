import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ScOperationsRoutingModule } from './sc-operations-routing.module';
import { ManifestDataPendingPickupComponent } from './manifest-data-pending-pickup/manifest-data-pending-pickup.component';
import { ToolsModule } from 'projects/tools/src/public-api';
import { MessageService } from 'primeng/api';
import { NgShortcutModule } from 'ng-shortcut';
import { ToastModule } from 'primeng/toast';


@NgModule({
  declarations: [ManifestDataPendingPickupComponent],
  imports: [
    CommonModule,
    ScOperationsRoutingModule,
    ToolsModule,
    ToastModule,
    NgShortcutModule.forRoot()
  ],
  providers: [MessageService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class ScOperationsModule { }
