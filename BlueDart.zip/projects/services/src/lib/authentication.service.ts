import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(private router: Router) { }

  public get currentUserValue(): any {
    return JSON.parse(sessionStorage.getItem('currentUser'));
  }

  private setInitialTabs() {
    const tabsData = [
      {
        tabName: 'Welcome',
        tabUrl: 'welcome-screen',
        newUrl: '',
        isActive: true
      }
    ];
    localStorage.setItem('tabsData', JSON.stringify(tabsData));
  }

  saveUserValue(user: any): void {
    sessionStorage.setItem('currentUser', JSON.stringify(user));
    // this.setInitialTabs();
    // TODO: will need to take care while loading permissions based menu.
    // window.location.href = 'welcome-screen';
    this.router.navigate(['welcome-screen']);
  }

  logout(): void {
    // remove user from session storage to log user out
    sessionStorage.removeItem('currentUser');
    sessionStorage.clear();
    localStorage.removeItem('tabsData');
    localStorage.clear();
    this.router.navigate(['/']);
  }

  getToken() {
    if (sessionStorage.getItem('currentUser')) {
      return JSON.parse(sessionStorage.getItem('currentUser')).userToken;
    } else {
      return 0;
    }
  }
}
