import { TestBed } from '@angular/core/testing';

import { BdBackendcomService } from './bd-backendcom.service';

describe('BdBackendcomService', () => {
  let service: BdBackendcomService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BdBackendcomService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
