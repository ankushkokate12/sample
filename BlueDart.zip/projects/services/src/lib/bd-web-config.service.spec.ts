import { TestBed } from '@angular/core/testing';

import { BdWebConfigService } from './bd-web-config.service';

describe('BdWebConfigService', () => {
  let service: BdWebConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BdWebConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
