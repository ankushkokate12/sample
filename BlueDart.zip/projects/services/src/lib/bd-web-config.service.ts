import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BdWebConfigService {
  public serviceURLReport: string;
  public serviceURLOBRapidValPincode: string;
  public serviceURLOBRapidValAWBNo: string;
  public serviceURLOBRapidValShippercode: string;
  public serviceURLOBRapidAWBSubmit: string;
  public serviceURLOBNormalInscan: string;
  public serviceURLAuthentication: string;
  public serviceURLRouteCode: string;
  public serviceURLVehicleNumber: string;
  public serviceURLvalidateProuctCode: string;
  public serviceURLAWBValidate: string;
  public serviceURLValidateAWBInscan: string;
  public validateAWbCount: string;
  public validateArea: string;
  public validateDestiScode: string;
  public validateConsigneeCode: string;
  public validatePackaging: string;
  public validateProductCode: string;
  public validateServiceCenter: string;
  public apiURL: string;
  public usrapiURL: string;
  public apiURLPickupRouteMaster: string;
  public apiURLProductConfiguration: string;
  public apiURLPickupRouteMasterServiceCentrePremission: string;
  public apiURLPickupRouteMasterGetAreaCode: string;
  public custServiceAPIURL: string;
  public masterServiceAPIURL: string;
  constructor(private http: HttpClient) { }

  loadSettings(): Promise<any> {
    return this.http
      .get('assets/webconfig.json')
      .toPromise()
      .then((configdata) => {
        Object.assign(this, configdata);
        return configdata;
      });
  }
}
