import {
  HttpHeaders,
  HttpErrorResponse,
  HttpClient
} from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { BDOpaqueData } from 'projects/vendors/src/lib/bd.opaquedata';
import { LoggerFacility } from 'projects/vendors/src/lib/LoggerFacility';
import { BdBackendcomService } from './bd-backendcom.service';
import { BdWebConfigService } from './bd-web-config.service';

@Injectable({
  providedIn: 'root'
})
export class BDBackServiceBase<T> {
  constructor(
    protected bdlogger: LoggerFacility,
    protected hClient: HttpClient,
    protected webconfig: BdWebConfigService
  ) {}
  protected static readonly httpHeaders: HttpHeaders = new HttpHeaders().set(
    'Content-Type',
    'application/json'
  );
  protected backSvcAsyncCom: BdBackendcomService = null;
  protected backendSvcURL: string;

  init() {
    this.bdlogger.loginfo(
      'BDBackServiceBase: init: using backend URL: ' + this.backendSvcURL
    );
  }

  vehicleCode(vehicleNumber: string) {
    const vehicleNumberApiUrl =
      this.webconfig.serviceURLVehicleNumber + vehicleNumber;
    return this.hClient
      .get(vehicleNumberApiUrl, {
        headers: BDBackServiceBase.httpHeaders,
        responseType: 'json'
      })
      .pipe(catchError(this.handleError));
  }

  validateBatchCount(batchNumber: number, location: string) {
    const { yyyy, mm, dd } = this.getCurrDate();

    const validateBatchCountAPIURL =
      this.webconfig.validateAWbCount +
      '/' +
      batchNumber +
      '/' +
      location +
      '/' +
      yyyy +
      '-' +
      mm +
      '-' +
      dd;
    return this.hClient
      .get(validateBatchCountAPIURL, {
        headers: BDBackServiceBase.httpHeaders,
        responseType: 'json'
      })
      .pipe(catchError(this.handleError));
  }

  private getCurrDate() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return { yyyy, mm, dd };
  }

  validateAWBForPincode(scanCode: string, issfapex: boolean) {
    const validateAWBForpincode =
      this.webconfig.serviceURLAWBValidate + scanCode + '?issfapex=' + issfapex;
    return this.hClient
      .get(validateAWBForpincode, {
        headers: BDBackServiceBase.httpHeaders,
        responseType: 'json'
      })
      .pipe(catchError(this.handleError));
  }

  doOperation(
    payload: T,
    backSvcAsyncCommunication: BdBackendcomService,
    serverTripStartTime: number,
    opaqueData?: any
  ) {
    console.log(
      'BDBackServiceBase: init: using backend URL: ' + this.backendSvcURL
    );
    this.bdlogger.logverbose(
      `doOperation: awbNumber=${(payload as any).awbNumber}`
    );

    this.backSvcAsyncCom = backSvcAsyncCommunication;
    this.postTheOperation(payload).subscribe(
      (resp) =>
        this.postComplete(
          resp,
          true,
          (payload as any).awbNumber,
          serverTripStartTime,
          opaqueData
        ),

      (errorMsg) =>
        this.backSvcAsyncCom.sendUpdateEvent({
          message: errorMsg,
          succeeded: false,
          scancode: (payload as any).awbNumber,
          serverTripStartTime,
          opaqueData
        })
    );
  }

  private postTheOperation(payload: T): Observable<any> {
    return this.hClient
      .post(this.backendSvcURL, payload, {
        headers: BDBackServiceBase.httpHeaders,
        responseType: 'json'
      })
      .pipe(catchError(this.handleError));
  }

  private postComplete(
    httpResponse: any,
    succeeded: boolean,
    awbNumber: string,
    serverTripStartTime: number,
    opaqueData: any
  ) {
    this.bdlogger.logverbose('postComplete: awbNumber=' + awbNumber);

    const respObj = httpResponse;
    console.log('ank' + respObj);

    this.bdlogger.logverbose(
      `postComplete: respObj.isErr=${respObj.isError}, message=${respObj.message}`
    );

    this.backSvcAsyncCom.sendUpdateEvent({
      message: respObj.errorMessage ? respObj.errorMessage : 'Unknown error',
      succeeded: respObj.isError === 'false' ? true : false,
      scancode: awbNumber,
      gatewayProcessingTime: respObj.apiTime,
      wcfResponseTime: respObj.wcfTime,
      serverTripStartTime,
      serverValue: respObj.value || respObj,
      opaqueData: opaqueData as BDOpaqueData,
      dstArea: respObj.dstArea,
      dstSc: respObj.dstSc
    });
  }

  protected handleError(error: HttpErrorResponse) {
    let errorMsg: string = null;
    console.log(error);
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMsg = error.error.message;
    } else if (error.status === 500 || error.status === 400) {
      errorMsg = error.error.errorMessage;
    } else if (error.status === 404) {
      errorMsg = 'Not found';
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMsg = `${error}`;
    }

    // return an observable with a user-facing error message
    return throwError(errorMsg);
  }

  getRouteCodeData(area: string, location?: string): Observable<any> {
    // http://10.53.17.47:8090/routes?defaultarea=C1&location=NM
    return this.hClient
      .get(
        this.webconfig.serviceURLRouteCode +
          '?defaultarea=' +
          area +
          '&location=' +
          location,
        {
          headers: BDBackServiceBase.httpHeaders,
          responseType: 'json'
        }
      )
      .pipe(catchError(this.handleError));
  }
}
