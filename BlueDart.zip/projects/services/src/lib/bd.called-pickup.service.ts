import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class BdCalledPickupService {
    private backendSubject = new Subject<any>();

    constructor() { }

    sendUpdateEvent(result) {
        this.backendSubject.next(result);
    }

    subscribeToEvents(): Observable<any> {
        return this.backendSubject.asObservable();
    }

    uninit() {
        this.backendSubject.unsubscribe();
    }
}
