import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-services',
  template: ` <p>services works!</p> `,
  styles: []
})
export class ServicesComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
