import { Action } from '@ngrx/store';

export enum NavigationActionTypes {
  Add = '[Customer Component] Add',
  Remove = '[Customer Component] Remove',
  Update = '[Customer Component] Update'
}
export class ActionEx implements Action {
  readonly type;
  payload: any;
}
export class NavigationAdd implements ActionEx {
  readonly type = NavigationActionTypes.Add;
  constructor(public payload: any) {}
}

export class NavigationUpdate implements ActionEx {
  readonly type = NavigationActionTypes.Update;
  constructor(public payload: any) {}
}

export class NavigationRemove implements ActionEx {
  readonly type = NavigationActionTypes.Remove;
  constructor(public payload: any) {}
}
