import { Injectable } from '@angular/core';
import { AUDIO_SETTINGS } from './constants/constant';

@Injectable({
  providedIn: 'root'
})
export class BeepService {

  constructor() { }
  
  playSound(frequency: number) {
    let audio;

    try {
      audio = new AudioContext();
    } catch (error) {
      return;
    }

    if (audio != null) {
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      osc.frequency.value = frequency;
      osc.type = AUDIO_SETTINGS.OSC_TYPE;
      gain.connect(audio.destination);
      gain.gain.value = AUDIO_SETTINGS.GAIN_VALUE;
      osc.start(audio.currentTime);
      osc.stop(audio.currentTime + 0.1);
    }
  }
}
