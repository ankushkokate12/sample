import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;
  constructor(private eventEmitterService: EventEmitterService, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIcon(
      'info',
      sanitizer.bypassSecurityTrustResourceUrl('assets/images/info.svg'));
  }
  ngOnInit() { }

  OnChangeEvent(event, fields: any, elem) {
    this.eventEmitterService.onCommonComponentEvents(fields);
    if (event.key === 'Enter') {
      this.selectNextTab(elem);
    }
  }

  selectNextTab(elem?: any) {
    let flg = true;
    if (elem) {
      var tidx = elem.field ? elem.field.tabIndex + 1 : elem + 1;
      let elems = document.querySelectorAll('[tabindex]');

      for (var i = elems.length; i--;) {
        var tidx2 = +(elems[i].getAttribute('tabindex'));
        if (tidx2 == tidx) {
          if (elems[i].getAttribute('disabled') != null) {
            this.selectNextTab(tidx);
            continue;
          }
          else {
            (elems[i] as HTMLElement).focus();
          }
        } else {
          flg = false;
        }
      }
    }
  }

  onKeydown(event, elem) {
    if (event.key === 'Enter') {
      this.selectNextTab(elem);
    }
  }
}
