import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormGroupName } from '@angular/forms';
import { MatChip } from '@angular/material/chips';
import { FieldConfig } from '../../../interfaces/field.interface';

@Component({
    selector: 'lib-chips',
    templateUrl: './chips.component.html',
    styleUrls: ['./chips.component.css']
})
export class ChipsComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;

    constructor() { }

    ngOnInit(): void {
    }

    toggleSelection(chip: MatChip) {
        if (!chip.disabled) chip.toggleSelected();
    }
}
