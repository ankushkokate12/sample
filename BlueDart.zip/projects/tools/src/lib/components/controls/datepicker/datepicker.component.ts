import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import * as moment from 'moment';

@Component( {
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: [ './datepicker.component.scss' ]
} )
export class DatepickerComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  minDate = new Date();
  maxDate = new Date();
  uptoLastDate = new Date();
  todayDate = new Date( new Date().getTime() - 3888000000 );
  currentYear = new Date().getFullYear();
  modifyDateRange: boolean;

  constructor ( private eventEmitterService: EventEmitterService, private sharedService: SharedService, private router: Router, private beepService: BeepService ) { }

  ngOnInit(): void {
    if ( this.field.minDate || this.field.enablePrevNextYear ) {
      this.modifyDateRange = true;
    }
    this.maxDate.setDate( this.minDate.getDate() + this.field.enableDateDays - 1 );
    if ( this.field.minDate ) {
      this.uptoLastDate.setDate( this.uptoLastDate.getDate() - this.field.minDate );
    }
    if ( this.field.enablePrevNextYear ) {
      this.uptoLastDate = new Date( this.currentYear - 1, 0, 1 );
      this.maxDate = new Date( this.currentYear + 1, 11, 31 );
    }

    this.group.controls[ this.field.name ].valueChanges.subscribe( ( r ) => {
      let obj = {};
      if ( r == null || r == undefined ) {
        obj = {
          error: 'pattern',
          label: this.field.label,
          message: '',
          status: 'VALID',
          screenName: this.router.url
        };
        this.sharedService.setErrorMessage( { [ this.field.name ]: obj } );
      }
    } );
  }

  focusOut( fields: any ) {
    this.eventEmitterService.onCommonComponentEvents( fields );
    this.detectErrors();
  }

  focusOutOField() {
    if ( this.group.controls[ this.field.name ].errors ) {
      this.beepService.playSound( AUDIO_SETTINGS.PLAY_SOUND );
    }
  }

  onKeydown( event, fields: any, elem ) {
    if ( event.shiftKey && event.key === 'Tab' ) {
    } else if ( event.key === 'Enter' || event.key === 'Tab' ) {
      if ( this.group.controls[ this.field.name ].errors ) {
        this.group.controls[ this.field.name ].markAsTouched();
        event.preventDefault();
        this.beepService.playSound( AUDIO_SETTINGS.PLAY_SOUND );
      } else if ( event.key === 'Enter' ) {
        event.preventDefault();
        this.selectNextTab( elem );
      }
    }
  }

  selectNextTab( elem?: any ) {
    let flg = true;
    if ( elem ) {
      var tidx = elem.field? elem.field.tabIndex + 1 : elem+1;
      let elems = document.querySelectorAll( '[tabindex]' );
      for ( var i = elems.length; i--; ) {
        var tidx2 = +( elems[ i ].getAttribute( 'tabindex' ) );
        if ( tidx2 == tidx ) {
          if(elems[ i ].getAttribute('disabled') != null) {
            this.selectNextTab(tidx);
            continue;
          }
          else {
            ( elems[ i ] as HTMLElement ).focus();
          }
        } else {
          flg = false;
        }
      }
    }
  }

  detectErrors() {
    let obj = {};
    if (this.group.controls[this.field.name].errors) {
      let msg = "Please add date in format dd/mm/yyyy";
      if (this.group.controls[this.field.name].errors.matDatepickerMin != undefined) {
        let dt = moment(this.group.controls[this.field.name].errors.matDatepickerMin.min).format('DD/MM/YYYY')
        msg = "Please select date greater then or equal to date " + dt;
      }
      obj = {
        error: Object.keys( this.group.controls[ this.field.name ].errors )[ 0 ],
        label: this.field.label,
        status: this.group.controls[this.field.name].status,
        screenName: this.router.url,
        message: msg
      };
    }
    else {
      obj = {
        error: 'pattern',
        label: this.field.label,
        message: '',
        status: 'VALID',
        screenName: this.router.url
      };
    }
    this.sharedService.setErrorMessage( { [ this.field.name ]: obj } );
  }

  handleClose() {
    if (this.field.id) {
      document.getElementById(this.field.id).focus();
    }
  }
}
