import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { IGridColumn } from '../../../interfaces/grid-columns.interface';
import { SortEvent } from 'primeng/api';
import { SharedService } from '../../../shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';
@Component({
  selector: 'app-dynamic-grid',
  templateUrl: './dynamic-grid.component.html',
  styleUrls: ['./dynamic-grid.component.scss']
  // encapsulation: ViewEncapsulation.None
})
export class DynamicGridComponent implements OnInit, OnChanges {
  @Input() rows: any[];
  @Input() columns: IGridColumn[] = [];
  @Input() selectedProduct1: string;
  @Input() frozenCols: IGridColumn[] = [];
  @Input() isSortable: boolean;
  @Input() isExpandable: boolean;
  @Input() isColumnFilter: boolean;
  @Input() tableHeight: string;
  @Input() isGroupable: boolean;
  @Input() isCaption: boolean;
  @Input() actionColumn: boolean = false;
  @Input() selectAllRows: boolean = false;
  @Input() primaryColumn: string;
  @Input() showReleaseMenu: boolean = false;
  @Input() showCloneMenu: boolean = false;
  @Input() showDeleteMenu: boolean = false;
  @Input() showHistoryMenu: boolean = false;
  @Input() isScrollable: boolean;
  @Input() isClickable: boolean;
  @Output() getRow: EventEmitter<any> = new EventEmitter<any>();
  @Input() selectionMode: string = 'single';
  @Input() deleteWarningMessage: string = 'Record will be marked as inactive. Click yes to proceed.';
  @Input() headerColor: string = '#DEF0FF';
  @Input() historyVisible: boolean = false;

  @Output() handleSelectedCheckbox: EventEmitter<string> = new EventEmitter<string>();

  groupByColumns: string[] = [];
  showFilterRow: boolean = false;

  constructor(
    private sharedService: SharedService,
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.showFilterRow = this.columns.some((obj) => obj.showFilter);
    if (this.selectAllRows) {
      this.selectionMode = '';
    } else {
      this.selectionMode = 'single';
    }
  }

  ngOnChanges(_simpleChange) {
    console.log(_simpleChange);
    if (_simpleChange.rows) {
      this.rows = _simpleChange.rows.currentValue;
    }
    if (_simpleChange.selectedProduct1) {
      this.selectedProduct1 = _simpleChange.selectedProduct1?.currentValue;
    }

    if (_simpleChange.historyVisible) {
      this.historyVisible = _simpleChange.historyVisible?.currentValue;
    }
  }

  toggleMenu() {
    //this.ddMenu.
  }

  customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
      const value1 = data1[event.field];
      const value2 = data2[event.field];
      let result = null;

      if (value1 == null && value2 != null) {
        result = -1;
      } else if (value1 != null && value2 == null) {
        result = 1;
      } else if (value1 == null && value2 == null) {
        result = 0;
      } else if (typeof value1 === 'string' && typeof value2 === 'string') {
        result = value1.localeCompare(value2, undefined, {
          numeric: true,
          sensitivity: 'base'
        });
      } else {
        result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
      }

      return event.order * result;
    });
  }

  exportPdf() {
    import('jspdf').then((jsPDF) => {
      import('jspdf-autotable').then(() => {
        const doc: any = new jsPDF.default();
        doc.autoTable(this.columns, this.rows);
        doc.save('grid.pdf');
      });
    });
  }

  exportExcel() {
    import('xlsx').then((xlsx) => {
      let cols2Add = this.columns.map((e) => e.field);
      let colsInOrgArray = Object.keys(this.rows[0]);

      let difference = colsInOrgArray.filter((x) => !cols2Add.includes(x));

      let cloneOfArray = JSON.parse(JSON.stringify(this.rows));
      cloneOfArray.map((e) => {
        difference.forEach((element) => {
          delete e[element];
        });
        return e;
      });

      let headerRow = Object.create({});
      for (let i = 0; i < this.columns.length; i++) {
        headerRow[this.columns[i].field] = this.columns[i].header;
      }

      const worksheet = xlsx.utils.json_to_sheet([headerRow], { header: cols2Add, skipHeader: true });
      xlsx.utils.sheet_add_json(worksheet, cloneOfArray, { header: cols2Add, skipHeader: true, origin: 'A2' });
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, 'products');
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    import('file-saver').then((FileSaver) => {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.xlsx';
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
      FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
    });
  }

  groupBy(event, column) {
    event.stopPropagation();
    this.checkGroupByColumn(column.field, true);
    this.rows = this.addGroups(this.rows, this.groupByColumns);
  }

  addGroups(data: any[], groupByColumns: string[]): any[] {
    const rootGroup = new Group();
    rootGroup.expanded = true;
    return this.getSublevel(data, 0, groupByColumns, rootGroup);
  }

  getSublevel(data: any[], level: number, groupByColumns: string[], parent: Group): any[] {
    if (level >= groupByColumns.length) {
      return data;
    }
    const groups = this.uniqueBy(
      data.map((row) => {
        const result = new Group();
        result.level = level + 1;
        result.parent = parent;
        for (let i = 0; i <= level; i++) {
          result[groupByColumns[i]] = row[groupByColumns[i]];
        }
        return result;
      }),
      JSON.stringify
    );

    const currentColumn = groupByColumns[level];
    let subGroups = [];
    groups.forEach((group) => {
      const rowsInGroup = data.filter((row) => group[currentColumn] === row[currentColumn]);
      group.totalCounts = rowsInGroup.length;
      const subGroup = this.getSublevel(rowsInGroup, level + 1, groupByColumns, group);
      subGroup.unshift(group);
      subGroups = subGroups.concat(subGroup);
    });
    return subGroups;
  }

  uniqueBy(a, key) {
    const seen = {};
    return a.filter((item) => {
      const k = key(item);
      return seen.hasOwnProperty(k) ? false : (seen[k] = true);
    });
  }

  checkGroupByColumn(field, add) {
    let found = null;
    for (const column of this.groupByColumns) {
      if (column === field) {
        found = this.groupByColumns.indexOf(column, 0);
      }
    }
    if (found != null && found >= 0) {
      if (!add) {
        this.groupByColumns.splice(found, 1);
      }
    } else {
      if (add) {
        this.groupByColumns.push(field);
      }
    }
  }

  unGroupBy(event, column) {
    event.stopPropagation();
    this.checkGroupByColumn(column.field, false);
    this.rows = this.addGroups(this.rows, this.groupByColumns);
  }

  release(row: any) {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to release?',
          message: 'Data will be transferred to live. Click yes to proceed.',
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.sharedService.setGridRowForRelease(row);
        }
      });
  }

  clone(row: any) {
    this.router.navigate(['clone', row[this.primaryColumn]], { relativeTo: this.route });
  }

  delete(row: any) {
    this.dialog
      .open(DialogComponent, {
        data: {
          title: 'Do you want to delete?',
          message: this.deleteWarningMessage,
          yesno: true
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.sharedService.setGridRowForDelete(row);
        }
      });
  }

  onChangeSel(val) {
    console.log(val);
  }

  handleRowClick(row) {
    // .onRowSelect()
  }

  history(row: any) {
    console.log(row);
    this.sharedService.setShowHistoryPopup(true);
    this.sharedService.setGridRowForHistory(row);
  }

  onRowSelect(e) {
    this.getRow.emit(e.data);
    if (this.selectAllRows) {
      console.log(this.selectedProduct1);
      this.handleSelectedCheckbox.emit(this.selectedProduct1);
    }
    if (this.showHistoryMenu && this.historyVisible) {
      console.log('aaa', this.historyVisible, this.showHistoryMenu);

      this.sharedService.setGridRowForHistory(e.data);
    }
  }

  onRowSelected() {
    // single row selection error resolve
    this.selectAllRows;
  }

  onHeaderToggle(e) {
    this.handleSelectedCheckbox.emit(this.selectedProduct1);
  }

  onRowUnselect(e) {
    if (!this.selectAllRows) {
      this.router.navigate(['view', e.data[this.primaryColumn]], { relativeTo: this.route });
    } else {
      this.handleSelectedCheckbox.emit(this.selectedProduct1);
    }
  }

  handleEdit(id) {
    this.router.navigate(['edit', id], { relativeTo: this.route });
  }
}

export class Group {
  level = 0;
  parent: Group;
  expanded = true;
  totalCounts = 0;
  get visible(): boolean {
    return !this.parent || (this.parent.visible && this.parent.expanded);
  }
}
