import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empty',
  templateUrl: './empty.component.html',
  styles: ['.control-div.empty-control {  min-width: 180px; }']
})
export class EmptyComponent {
  constructor() {}
}
