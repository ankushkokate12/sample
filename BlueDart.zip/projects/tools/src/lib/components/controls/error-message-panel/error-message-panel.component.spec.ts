import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorMessagePanelComponent } from './error-message-panel.component';

describe('ErrorMessagePanelComponent', () => {
  let component: ErrorMessagePanelComponent;
  let fixture: ComponentFixture<ErrorMessagePanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ErrorMessagePanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorMessagePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
