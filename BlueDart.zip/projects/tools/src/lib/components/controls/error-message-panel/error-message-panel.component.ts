import { Component, ElementRef, HostListener, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, RoutesRecognized } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { Subscription } from 'rxjs';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';

@Component({
  selector: 'lib-error-message-panel',
  templateUrl: './error-message-panel.component.html',
  styleUrls: ['./error-message-panel.component.scss']
})
export class ErrorMessagePanelComponent implements OnInit {
  panelOpenState: boolean = false;

  errorMsg: string = '';
  errorMsgArray: string[] = [];
  warMsgArray: string[] = [];
  private errMsgSubscription = new Subscription();
  validationMsg = [];
  errorMsgs: any; //IErrorMsgs;
  isValError = false;
  isWarError = false;
  isBeep = false;

  constructor(private errorMsgService: SharedService, private router: Router, private elementRef: ElementRef, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, private beepService: BeepService) {
    iconRegistry.addSvgIcon(
      'error-warning',
      sanitizer.bypassSecurityTrustResourceUrl('assets/images/ErrorWarning.svg'));
  }

  ngOnInit(): void {
    this.router.events.subscribe(Event => {
      // NavigationEnd
      // NavigationCancel
      // NavigationError
      // RoutesRecognized
      if (Event instanceof RoutesRecognized) {
        this.errorMsgArray = [];
        this.validationMsg = [];
        if (Object.keys(this.validationMsg).length > 0) {
          Object.keys(this.validationMsg).forEach((e) => {
            if (this.validationMsg[e].screenName != Event.url) {
              this.errorMsgArray = [];
              this.validationMsg = [];
            }
          });
        }
        else {
          this.errorMsgArray = [];
          this.validationMsg = [];
        }
      }
    });

    this.errMsgSubscription = this.errorMsgService.getErrorMessage().subscribe((res) => {
      this.errorMsg = '';
      this.isValError = false;
      this.isWarError = false;

      if (res.all) {
        this.validationMsg = res.all;
        this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND)
      }
      else if (res == null || res == undefined || Object.keys(res).length == 0) {
        this.isBeep = false;
        this.validationMsg = [];
      }
      else {
        Object.keys(res).forEach((k) => {
          if (k != "") {
            if (!this.isBeep && (res[k].error == "api" && (res[k].status == 'INVALID' || res[k].status == 'WARNING'))) {
              this.isBeep = true;
            } else this.isBeep = false;
            //this.validationMsg[k] = res[k];
            if (this.validationMsg.hasOwnProperty(k) && (res[k].status == 'VALID' || res[k].status == 'NOWARNING') && res[k].screenName == this.router.url) {
              // exist and valid status
              // removed from array
              delete this.validationMsg[k];
            } else if (this.validationMsg.hasOwnProperty(k) && (res[k].status == 'INVALID' || res[k].status == 'WARNING') && res[k].screenName == this.router.url) {
              //exist and invalid
              //check error validation
              //if same ignore
              // if different update
              if (this.validationMsg[k].error != res[k].error) {
                this.validationMsg[k] = res[k];
                this.panelOpenState = true;
              }
            } else if (!this.validationMsg.hasOwnProperty(k) && (res[k].status == 'INVALID' || res[k].status == 'WARNING') && res[k].screenName == this.router.url) {
              //not exist but invalid
              // add       
              this.validationMsg[k] = res[k];
              this.panelOpenState = true;
            }
          }
        });
      }

      this.errorMsgArray = [];
      this.warMsgArray = [];
      if (Object.keys(this.validationMsg).length > 0) {
        let RequiredAlreadyAdded = false;
        Object.keys(this.validationMsg).forEach((e) => {
          if (!(RequiredAlreadyAdded && this.validationMsg[e].error == 'required')) {
            let msg = '';
            if (this.validationMsg[e].error == 'required') {
              RequiredAlreadyAdded = true;
              msg = 'Please enter all required fields highlighted in red';
              this.isValError = true;
              this.errorMsgArray.push(msg);
            } else {
              msg = this.validationMsg[e].message;

              if (this.validationMsg[e].status == "INVALID") {
                this.isValError = true;
                this.errorMsgArray.push(msg);
              }
              if (this.validationMsg[e].status == "WARNING") {
                this.isWarError = true;
                this.warMsgArray.push(msg);
              }
            }
          }
        });
        if (this.isBeep) {
          this.isBeep = false;
          this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
        }
      }
    });
  }

  TogglePanel() {
    if (this.panelOpenState) {
      this.panelOpenState = false;
    } else {
      this.panelOpenState = true;
    }
  }

  ngOnDestroy() {
    if (this.errMsgSubscription != null) {
      this.errMsgSubscription.unsubscribe();
    }
  }

  @HostListener('document:mousedown', ['$event'])
  onGlobalClick(event): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.panelOpenState = false;
    }
  }
}
