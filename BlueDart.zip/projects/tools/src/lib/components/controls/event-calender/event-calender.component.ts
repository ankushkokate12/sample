import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CalendarContent, CalendarOptions } from '@fullcalendar/angular';
import { EventEmitterService } from '../../../event-emitter.service';
import { FieldConfig } from '../../../interfaces/field.interface';

@Component({
  selector: 'app-event-calender',
  templateUrl: './event-calender.component.html',
  styleUrls: ['./event-calender.component.scss']
})
export class EventCalenderComponent implements OnInit {
  @Input() calendarOptions: CalendarOptions;

  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;

  constructor(private eventEmitterService: EventEmitterService) {}

  ngOnInit() {}

  OnClick(fields: any) {
    this.eventEmitterService.onCommonComponentEvents(fields);
  }
}
