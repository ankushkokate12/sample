import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../../interfaces/field.interface';
import { RestService } from '../../../rest.service';
import { SharedService } from '../../../shared.service';
import { FileUploadService } from '../../../file-upload.service';
import { FileHandle } from '../../../drag-drop.directive';
import { DomSanitizer } from '@angular/platform-browser';
import { MessageService as AlertService } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lib-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css']
})
export class FileuploadComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;
  @ViewChild('fileInput') fileInput: ElementRef;
  fileAttr = 'Select File';
  imageSrc: any;
  file: any;
  files: FileHandle[];
  resImg: any;
  isDeleted: boolean = false;
  resImgType: any;
  errorMsg: any;
  showPlaceholder: boolean = true;
  disabledImage: boolean = false;

  constructor(
    private errorMsgService: SharedService,
    private primengMessageService: AlertService,
    private restService: RestService,
    private fileUploadService: FileUploadService,
    private domSanitizer: DomSanitizer,
    private router: Router
  ) { }

  ngOnInit() {
    this.fileUploadService.getViewOnlyImageFlag().subscribe((res) => {
      this.disabledImage = res;
    });
    this.showPlaceholder = true;
    // FOr VIew Image
    this.fileUploadService.getViewId().subscribe((res) => {
      this.resImg = res?.a == undefined ? '' : res?.a;
      this.resImgType = res?.b == undefined ? '' : res?.b;
      this.imageSrc = this.domSanitizer.bypassSecurityTrustUrl('data:' + this.resImgType + ';base64,' + this.resImg);
      this.showPlaceholder = false;
    });
    this.fileUploadService.getResetImageFlag().subscribe((res) => {
      this.showPlaceholder = res;
    });
  }

  onKeydown(event) {
    if (event.key === 'Enter') {
      this.fileInput.nativeElement.click();
    }
  }
  // Upload Image
  uploadFileEvt($event: any) {
    const reader = new FileReader();
    if ($event.target.files && $event.target.files[0].size <= 500000) {
      const file = $event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageSrc = reader.result as string;
        this.showPlaceholder = false;
        this.fileUploadService.setImgFile(file);
      };
      this.selectNextTab();
      this.setErrorPanel('ot', '', 'NOWARNING');
    } else if ($event.target.files[0].size >= 500000) {
      this.errorMsg = 'Image should be less than 500KB';
      this.setErrorPanel('ot', this.errorMsg, 'WARNING');
    }
  }

  selectNextTab() {
    let tidx = this.field.tabIndex + 1;
    let elems = document.querySelectorAll('[tabindex]');
    for (var i = elems.length; i--;) {
      var tidx2 = +(elems[i].getAttribute('tabindex'));
      if (tidx2 == tidx) {
        (elems[i] as HTMLElement).focus();
        break;
      }
    }
  }

  setErrorPanel(key: string, message: string, type: string) {
    let errorObj = {};
    errorObj[key] = {
      error: 'api',
      label: '',
      message: message,
      status: type,
      screenName: this.router.url
    };

    this.errorMsgService.setErrorMessage(errorObj);
  }

  deleteImage() {
    this.isDeleted = true;
    this.fileUploadService.setDeleteFlag(this.isDeleted);
    this.showPlaceholder = true;
    this.selectNextTab();
  }

  replaceImage($event: any) {
    this.showPlaceholder = true;
  }

  /**
   * on file drop handler
   */
  onFileDropped(files: FileHandle[]): void {
    this.files = files;
  }

  ngOnDestroy() {
    // this.fileUploadService.fileData.unsubscribe();
    // this.fileUploadService.viewId.unsubscribe();
  }
}
