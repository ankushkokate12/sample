import { Component, OnInit, Inject, ViewChild, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RestService } from '../../../rest.service';
import { MatTableDataSource } from '@angular/material/table';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { DynamicFormComponent } from 'projects/tools/src/lib/components/dynamic-form/dynamic-form.component';
import { EventEmitterService } from '../../../event-emitter.service';
import { DynamicGridComponent } from '../dynamic-grid/dynamic-grid.component';
import { SharedService } from '../../../shared.service';
import { SnackBarComponent } from '../snack-bar/snack-bar.component';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-helpicondialog',
  templateUrl: './helpicondialog.component.html',
  styleUrls: ['./helpicondialog.component.scss']
})
export class HelpicondialogComponent implements OnInit, OnDestroy {
  @ViewChild(DynamicFormComponent, { static: false })
  searchForm: DynamicFormComponent;
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  isTableVisible = false;
  errorMessage: string;
  fieldName;
  tableData = [];
  tableText: string;
  dataSource;
  selectedRow;
  displayedColumns;
  regdata: FieldConfig[];
  //dataColumn: IGridColumn[];
  rows;
  isSortable = true;
  rowData;
  dataColumn: any;
  constructor(
    public dialogRef: MatDialogRef<HelpicondialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private restService: RestService,
    private eventEmitt: EventEmitterService,
    private sharedService: SharedService,
    public snackBar: MatSnackBar
  ) {
    this.regdata = data.fieldData ? data.fieldData : [];
  }
  ngOnInit(): void {
    this.eventEmitt.subsVar = this.eventEmitt.invokeCommonComponentFunction.subscribe((control: string) => {
      switch (control['eventRef']) {
        case 'btnSearch':
          this.search();
          break;
        case 'btnClientCodeSearch':
          this.searchClientCode();
          break;
        case 'txtFCArea':
          this.validateAreaCode(control['apiURLs']);
          break;
      }
    });

    this.fieldName = this.data.fieldname;
    this.displayedColumns = this.data.tdHead;
    this.tableText = this.data.title;
    const requestBody = {};

    if (!this.data.fieldData && this.data.apiurl != 'undefined') {
      this.restService.get(this.data.apiurl, requestBody).subscribe(
        (response) => {
          if (response != ' ') {
            // if (response != ' ') {
            //   this.rows = response['data'];
            // }
            this.rows = response !== ' ' ? response['data'] : [];
          }
        },
        (error) => {
          console.log(error);
          this.rows = [];
        }
      );
    }
  }

  ngOnDestroy() {
    if (this.eventEmitt.subsVar) {
      this.eventEmitt.subsVar.unsubscribe();
    }
  }

  getValue(evt: any) {
    const res = {
      fieldvalue: evt.toElement.textContent.trim(),
      fieldname: this.fieldName
    };
    this.dialogRef.close(res);
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  submit(event) {
    console.log(event);
  }

  search() {}

  searchClientCode() {
    //search functionality in progress
    let formValue = this.searchForm ? this.searchForm.form.value : this.searchForm;
    const requestBody = {};
    this.errorMessage = null;
    let count = 0;
    let requestMapping = {
      a: 'mobile',
      b: 'telephone',
      c: 'contactPerson',
      d: 'area',
      e: 'clientName'
    };
    let requestB = {};

    for (let map in requestMapping) {
      requestB[map] = formValue[requestMapping[map]] ? formValue[requestMapping[map]] : '';
    }
    // requestB['spinner'] = 'yes';

    /*this.data.apiurl='http://localhost:8085/location/region/WRL';
    requsteB={
      "a": "1930",
      "b": "I",
      "c":"WRL"
      };
      requsteB={
        "a": "",
        "b": "",
        "c": "",
        "d": "BOM",
        "e": ""
    };*/

    if (this.searchForm.form.valid && this.data.apiurl != 'undefined') {
      this.restService.post(this.data.apiurl, requestB).subscribe(
        (response) => {
          if (!response['c']) {
            response['data'].forEach((item) => (item['z'] = '000000'));
            this.rows = response['data'];
            this.dataSource = new MatTableDataSource(response);
          } else {
            this.rows = [];
          }
        },
        (error) => {
          this.rows = [];
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      );
    }
  }

  validateAreaCode(control) {
    let requestMapping = {
      a: 'area'
    };
    let responseMapping = {
      a: 'isError',
      b: 'errorMessage',
      c: 'apiTime',
      d: 'destinationAreaCode'
    };
    this.errorMessage = null;
    if (this.searchForm.form.get('area').value) {
      let requestBody = {
        a: this.searchForm.form.get('area').value
      };
      requestBody['spinner'] = 'no';
      this.restService.post(control[0], requestBody).subscribe(
        (response) => {
          if (!response['a']) {
            this.searchForm.form.get('area').setValue(response['d']);
            if (control['eventRef'] == 'btnClientCodeSearch') {
              this.searchClientCode();
            }
          } else {
            //show error message
            this.snackBar.openFromComponent(SnackBarComponent, {
              data: {
                code: false,
                message: 'Invalid Area Code'
              },
              ...{ duration: 2000, panelClass: ['error'] }
            });
            this.searchForm.form.get('area').setErrors({ incorrect: true, message: 'Invalid Area Code' });
          }
        },
        (error) => {
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              code: false,
              message: 'There is some error. Please try again.'
            },
            ...{ duration: 2000, panelClass: ['error'] }
          });
        }
      );
    }
  }

  getData(event) {
    this.selectedRow = event;
  }

  closeDialog() {
    if(this.selectedRow) {
      if (this.data.gridOptions && this.data.gridOptions.isClickable) {
        this.dialogRef.close(this.selectedRow);
      }
    }
  }
}
