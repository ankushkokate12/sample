import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpicondialogcompComponent } from './helpicondialogcomp.component';

describe('HelpicondialogComponent', () => {
  let component: HelpicondialogcompComponent;
  let fixture: ComponentFixture<HelpicondialogcompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HelpicondialogcompComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpicondialogcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
