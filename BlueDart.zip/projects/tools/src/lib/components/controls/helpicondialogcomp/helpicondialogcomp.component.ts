import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IGridColumn } from '../../../interfaces/field.interface';
import { RestService } from '../../../rest.service';
import { DynamicGridComponent } from '../dynamic-grid/dynamic-grid.component';
import { SharedService } from '../../../shared.service';
@Component({
  selector: 'app-helpicondialogcomp',
  templateUrl: './helpicondialogcomp.component.html',
  styleUrls: ['./helpicondialogcomp.component.scss']
})
export class HelpicondialogcompComponent implements OnInit {
  valuePass;
  fieldName;
  tableData = [];
  dataSource;
  tableDataRow;
  displayedColumns;
  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  gridColumns: IGridColumn[] = [];
  dataColumn: string;
  rows = [];
  isSortable = true;
  noteText;
  rowData;
  constructor(
    public dialogRef: MatDialogRef<HelpicondialogcompComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private restService: RestService,
    private sharedService: SharedService
  ) {}

  ngOnInit(): void {
    this.fieldName = this.data.fieldname;
    this.dataColumn = this.data.helpTableDataColumn;
    this.gridColumns = this.data.gridColumns;

    this.noteText = this.data.noteText ? this.data.noteText : '';
    const requestBody = {};
    if (this.data.apiurl != undefined) {
      this.restService.get(this.data.apiurl, '', this.data.payload).subscribe(
        (response) => {
          if (response != ' ') {
            if (this.dataColumn) this.rowData = response[this.dataColumn];
            else this.rowData = response;
          }
        },
        (error) => {
          console.log(error);
        }
      );
    } else if (this.data.rows) {
      this.rowData = this.data.rows;
    }
  }

  selectedValue() {
    if (this.tableDataRow && this.fieldName) {
      const header = this.data.gridColumns.find((ele) => ele.header === this.fieldName);
      return header ? this.tableDataRow[header.field] : '';
    } else return this.tableDataRow;
  }

  getData(event) {
    this.tableDataRow = event;
  }

  onCancel(): void {
    let data = this.selectedValue();
    if(data) {
      this.dialogRef.close(data);
    }
  }
}