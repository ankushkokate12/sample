import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EventEmitterService } from '../../../event-emitter.service';
import { FieldConfig } from '../../../interfaces/field.interface';
@Component({
  selector: 'app-iconbutton',
  templateUrl: './iconbutton.component.html',
  styleUrls: ['./iconbutton.component.scss']
})
export class IconbuttonComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;
  constructor(private eventEmitterService: EventEmitterService) {}

  ngOnInit() {}

  OnClick(fields: any) {
    this.eventEmitterService.onCommonComponentEvents(fields);
  }
}
