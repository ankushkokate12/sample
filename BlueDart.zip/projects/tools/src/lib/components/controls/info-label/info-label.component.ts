import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../../interfaces/field.interface';

@Component({
  selector: 'lib-info-label',
  templateUrl: './info-label.component.html',
  styleUrls: ['./info-label.component.scss']
})
export class InfoLabelComponent implements OnInit {
  @Input() field:FieldConfig;
  @Input() value: any
  group: FormGroup;
  constructor() { }

  ngOnInit(): void {
  }

}
