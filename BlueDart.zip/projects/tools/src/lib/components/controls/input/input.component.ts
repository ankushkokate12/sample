import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { HelpicondialogComponent } from 'projects/tools/src/lib/components/controls/helpicondialog/helpicondialog.component';
import { SuggestionTableComponent } from 'projects/tools/src/lib/components/controls/suggestion-table/suggestion-table.component';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';

@Component( {
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: [ './input.component.scss' ],
  encapsulation: ViewEncapsulation.None
} )
export class InputComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;
  targetedInputForCheckboxValues: string;
  isAutoCaps: boolean = false;
  isNumberField: boolean = false;
  regExp: string;

  constructor(
    private sharedService: SharedService,
    public dialog: MatDialog,
    private eventEmitterService: EventEmitterService,
    iconRegistry: MatIconRegistry, sanitizer: DomSanitizer,
    private router: Router,
    private beepService: BeepService
  ) {
    iconRegistry.addSvgIcon(
      'info',
      sanitizer.bypassSecurityTrustResourceUrl( 'assets/images/info.svg' ) );
  }

  ngOnInit() {
    if ( this.field.isAutoCaps != null ) {
      this.isAutoCaps = this.field.isAutoCaps;
    }
    this.setFieldProperties();
    this.sharedService.getSelectedGridRows().subscribe((res) => {
      if (res.fieldName === this.field.name) {
        let r = res.data.map((i) => i.a).join(', ');
        this.group.controls[this.targetedInputForCheckboxValues].setValue(r);
      }
    } );

    this.group.controls[ this.field.name ].valueChanges.subscribe( ( r ) => {
      let obj = {};
      if ( r == null || r == undefined ) {
        obj = {
          error: 'pattern',
          label: this.field.label,
          message: '',
          status: 'VALID',
          screenName: this.router.url
        };
        this.sharedService.setErrorMessage( { [ this.field.name ]: obj } );
      }
    } );
  }

  setFieldProperties() {
    if (this.field.isAutoCaps != null) {
      this.isAutoCaps = this.field.isAutoCaps;
    }
    if (this.field.regExp != null) {
      this.regExp = this.field.regExp;
    }
  }

  detectErrors() {
    let obj = {};
    if ( this.group.controls[ this.field.name ].errors ) {
      obj = {
        error: Object.keys( this.group.controls[ this.field.name ].errors )[ 0 ],
        label: this.field.label,
        message: this.field.validations.filter(
          ( itm ) => itm.name == Object.keys( this.group.controls[ this.field.name ].errors )[ 0 ]
        )[ 0 ].message,
        status: this.group.controls[ this.field.name ].status,
        screenName: this.router.url
      };
    }
    else {
      obj = {
        error: 'pattern',
        label: this.field.label,
        message: '',
        status: 'VALID',
        screenName: this.router.url
      };
    }
    this.sharedService.setErrorMessage( { [ this.field.name ]: obj } );
  }

  OnChangeEvent( fields: any ) {
    fields.helpEventRef = false;
    this.eventEmitterService.onCommonComponentEvents( fields );
  }

  focusOut( fields: any ) {
    fields.helpEventRef = false;
    this.eventEmitterService.onCommonComponentEvents( fields );
    this.detectErrors();
    if ( this.group.controls[ this.field.name ].errors ) {
      this.beepService.playSound( AUDIO_SETTINGS.PLAY_SOUND );
    }
  }

  onKeydown( event, fields: any, elem ) {
    fields.helpEventRef = false;
    if ( event.shiftKey && event.key === 'Tab' ) {
    } else if ( event.key === 'Enter' || event.key === 'Tab' ) {
      if ( this.group.controls[ this.field.name ].errors ) {
        this.group.controls[ this.field.name ].markAsTouched();
        event.preventDefault();
        this.detectErrors();
        this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      } else if (event.key === 'Enter') {
        // event.preventDefault();
        this.eventEmitterService.onCommonComponentEvents( fields );
        this.selectNextTab( elem );
      }
    }
  }
  
  onKeyPress(event, fields: any) {
    fields.helpEventRef = false;
    let inp = String.fromCharCode(event.keyCode);
    if (this.regExp != null) {
      const localRegExp = new RegExp(this.regExp);
      if (localRegExp.test(event.target.value + inp)) {
        return true;
      }
      else {
        event.preventDefault();
        return false;
      }
    }
  }

  selectNextTab( elem?: any ) {
    let flg = true;
    if ( elem ) {
      var tidx = elem.field? elem.field.tabIndex + 1 : elem+1;
      let elems = document.querySelectorAll( '[tabindex]' );
      for ( var i = elems.length; i--; ) {
        var tidx2 = +( elems[ i ].getAttribute( 'tabindex' ) );
        if ( tidx2 == tidx ) {
          if(elems[ i ].getAttribute('disabled') != null) {
            this.selectNextTab(tidx);
            continue;
          }
          else {
            ( elems[ i ] as HTMLElement ).focus();
          }
        } else {
          flg = false;
        }
      }
    }
  }

  showSuggestion() {
    if (!this.field.gridOptions.isSelectAllRows) {
      this.sharedService.singleSelectSuggestionTableSubject(this.field);
    } else {
    this.targetedInputForCheckboxValues = this.field.name;
    const dialogRef = this.dialog.open( SuggestionTableComponent, {
      width: '' + this.field.helpDialogWidth + 'px',
      minWidth: 350,
      data: {
        title: this.field.label,
        apiurl: this.field.helpApiUrl,
        tdHead: this.field.helpTableHead,
        fieldname: this.field.name,
        fieldData: this.group.controls[ this.field.name ].value,
        gridColumns: this.field.helpDialogGridColumns ? this.field.helpDialogGridColumns : null,
        gridOptions: this.field.gridOptions ? this.field.gridOptions : null,
        disclaimer: this.field.disclaimer,
        selectBtn: this.field.selectBtn
      }
    } );

    dialogRef.afterClosed().subscribe( () => {
	document.getElementById(this.field.id).focus();
    } );
    }
  }

  openHelpDialog() {
    const dialogRef = this.dialog.open( HelpicondialogComponent, {
      width: '' + this.field.helpDialogWidth + 'px',
      minWidth: 400,
      data: {
        title: this.field.label,
        apiurl: this.field.helpApiUrl,
        tdHead: this.field.helpTableHead,
        heading: this.field.dialogTitle,
        fieldname: this.field.name ? this.field.name : null,
        //Passing date such as grid details, form details to be used in help icon idalog
        fieldData: this.field.helpDialogFormData ? this.field.helpDialogFormData : null,
        gridOptions: this.field.gridOptions ? this.field.gridOptions : null,
        gridColumns: this.field.helpDialogGridColumns ? this.field.helpDialogGridColumns : null,
        errorMessage: this.field.errorMessage ? this.field.errorMessage : null,
        apiURLs: this.field.apiURLs ? this.field.apiURLs : null
      }
    } );

    dialogRef.afterClosed().subscribe( ( res ) => {
      this.sharedService.setPopupData( { field: this.field, data: res } );
    } );
  }

  //open helpicon from component
  openHelpDialogComp( fields ) {
    fields.helpEventRef = true;
    this.eventEmitterService.onCommonComponentEvents( fields );
  }
}
