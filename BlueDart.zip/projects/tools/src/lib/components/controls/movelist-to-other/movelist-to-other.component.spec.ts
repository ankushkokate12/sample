import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MovelistToOtherComponent } from './movelist-to-other.component';

describe('MovelistToOtherComponent', () => {
  let component: MovelistToOtherComponent;
  let fixture: ComponentFixture<MovelistToOtherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MovelistToOtherComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MovelistToOtherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
