import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../../interfaces/field.interface';
import { RestService } from '../../../rest.service';

@Component({
  selector: 'lib-movelist-to-other',
  templateUrl: './movelist-to-other.component.html',
  styleUrls: ['./movelist-to-other.component.css'],
  encapsulation:ViewEncapsulation.Emulated
})
export class MovelistToOtherComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup; 
  public source: Array<any>;
	public confirmed: Array<any>; 
  format = { add: 'Add', remove: 'Remove', direction: 'left-to-right'}; 
 

  constructor( private restService: RestService) {}

  ngOnInit(): void {
    if (this.field.ApiUrl  !== undefined) {
      this.restService
        .get(this.field.ApiUrl)
        .subscribe(
          (response) => {
            if (response != '') {
              this.source = response; 
            }
          },
          (error) => {
            console.log(error);
          }
        );
    }
  }

}
