import { Component, Input, OnChanges, OnInit, ViewEncapsulation } from '@angular/core';
import { SharedService } from '../../../shared.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss']
})
export class PageHeaderComponent implements OnInit, OnChanges {
  @Input() header: any;
  @Input() group: any;

  showbackArrow: boolean = false;
  backArrowObj: any;
  titleObj: any;
  subTitleObj: any;
  buttonArray: any[] = [];
  infoLabel: any;
  showInfoLabel: boolean = false;

  constructor(private sharedService: SharedService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.handleHeaderRow();
  }

  handleHeaderRow(): void {
    this.buttonArray = [];
    this.header.rows.forEach((ele) => {
      if (ele.type == 'iconbutton') {
        this.showbackArrow = true;
        this.backArrowObj = ele;
      } else if (ele.type == 'label' && ele.classes.greenHead) {
        this.subTitleObj = ele;
      } else if (ele.type == 'label') {
        this.titleObj = ele;
      } else if (ele.type == 'button') {
        this.buttonArray.push(ele);
      } else if (ele.type == 'infoLabel') {
        console.log(ele);
        this.showInfoLabel = true;
        this.infoLabel = ele;
      }
    });
    console.log(this.buttonArray);
  }

  ngOnChanges(_simpleChange) {
    this.header = _simpleChange.header.currentValue;
    this.handleHeaderRow();
  }
}
