export class Report {
  origin: string;
  from: string;
  to: string;
  daysOfWeek: number;
  flightNo: string;
  departure: string;
  arrival: string;
  days: number;
  products: string;
  status: string;
  modifiedBy: string;
  modifiedOn: string;
  editStatus: boolean;

  constructor(
    origin: string,
    from: string,
    to: string,
    daysOfWeek: number,
    flightNo: string,
    departure: string,
    arrival: string,
    days: number,
    products: string,
    status: string,
    modifiedBy: string,
    modifiedOn: string,
    editStatus: boolean
  ) {
    this.origin = origin;
    this.from = from;
    this.to = to;
    this.daysOfWeek = daysOfWeek;
    this.flightNo = flightNo;
    this.departure = departure;
    this.arrival = arrival;
    this.days = days;
    this.products = products;
    this.status = status;
    this.modifiedBy = modifiedBy;
    this.modifiedOn = modifiedOn;
    this.editStatus = editStatus;
  }
}
