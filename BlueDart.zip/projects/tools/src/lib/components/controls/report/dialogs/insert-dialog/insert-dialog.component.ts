import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-insert-dialog',
  templateUrl: './insert-dialog.component.html',
  styleUrls: ['./insert-dialog.component.scss']
})
export class InsertDialogComponent implements OnInit {
  form: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<InsertDialogComponent>
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      origin: ['', [Validators.required]],
      from: ['', [Validators.required]],
      to: ['', [Validators.required]],
      daysOfWeek: ['', [Validators.required]],
      flightNo: ['', [Validators.required]],
      departure: ['', [Validators.required]],
      arrival: ['', [Validators.required]],
      days: ['', [Validators.required]],
      products: ['', [Validators.required]],
      status: ['', [Validators.required]],
      modifiedBy: ['', [Validators.required]],
      modifiedOn: ['', [Validators.required]]
    });
  }

  submit(form) {
    this.dialogRef.close({ event: 'insert', data: form.value });
  }
  cancel() {
    this.dialogRef.close({ event: 'cancel' });
  }
}
