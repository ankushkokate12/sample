import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatTable } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Report } from './Report';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { ConfirmationDialogComponent } from './dialogs/confirmation-dialog/confirmation-dialog.component';
import { InsertDialogComponent } from './dialogs/insert-dialog/insert-dialog.component';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
  data: Report[] = [];

  dataSource = new MatTableDataSource(this.data);

  lastEdited: Report = null;

  tempEdit: Report = null;

  displayedColumns = [
    'origin',
    'from',
    'to',
    'daysOfWeek',
    'flightNo',
    'departure',
    'arrival',
    'days',
    'products',
    'status',
    'modifiedBy',
    'modifiedOn',
    'editStatus'
  ];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  currentEditItem = null;

  constructor(private dialog: MatDialog) {
    for (let i = 0; i < 10; i++) {
      this.data.push(
        new Report(
          'BOM',
          'BOM',
          i + 'AHD',
          1,
          'PUN' + i,
          '20:45',
          '20:15',
          5,
          'AE',
          'Released',
          'BACKEND ADMIN',
          '20/01/2020',
          false
        )
      );
    }
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  toggleStatus(element) {
    if (element.editStatus === false) {
      if (this.lastEdited != null) {
        this.lastEdited.editStatus = false;
      }
      this.lastEdited = element;
    }
    element.editStatus = !element.editStatus;
  }

  save(element) {
    element.origin = this.tempEdit.origin;
    element.from = this.tempEdit.from;
    element.to = this.tempEdit.to;
    element.daysOfWeek = this.tempEdit.daysOfWeek;
    element.flightNo = this.tempEdit.flightNo;
    element.departure = this.tempEdit.departure;
    element.arrival = this.tempEdit.arrival;
    element.days = this.tempEdit.days;
    element.products = this.tempEdit.products;

    this.toggleStatus(element);
  }

  edit(element) {
    this.tempEdit = Object.assign({}, element);
    this.toggleStatus(element);
  }

  deleteItem(element) {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.data.forEach((item, index) => {
          if (item === element) {
            this.data.splice(index, 1);
            this.dataSource.data = this.data;
          }
        });
      }
    });
  }

  insertItem() {
    const dialogRef = this.dialog.open(InsertDialogComponent, {
      width: '950px'
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result.event === 'insert') {
        this.data.push(result.data);
        this.dataSource.data = this.data;
      }
    });
  }
}
