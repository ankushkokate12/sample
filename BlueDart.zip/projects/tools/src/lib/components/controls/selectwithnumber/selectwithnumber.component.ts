import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSelect } from '@angular/material/select';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig, ISelectMapper } from 'projects/tools/src/lib/interfaces/field.interface';
import { RestService } from 'projects/tools/src/lib/rest.service';
import { SharedService } from 'projects/tools/src/lib/shared.service';

@Component({
  selector: 'app-selectwithnumber',
  templateUrl: './selectwithnumber.component.html',
  styleUrls: ['./selectwithnumber.component.scss']
})
export class SelectwithnumberComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  selectOptions;
  allSelected = false;
  @ViewChild('selectMulti') select: MatSelect;
  optionLabel: string = 'name';
  optionValue: string = 'id';
  nullAlias: string = 'id';
  isOptionDisabled = false;
  fieldName: string;
  toolTipText: any;
  firstSelectedText: string;
  countItemSelected: number;

  constructor(
    private restService: RestService,
    private eventEmitterService: EventEmitterService,
    private sharedService: SharedService,
    iconRegistry: MatIconRegistry, sanitizer: DomSanitizer,
    private router: Router,
    private beepService: BeepService
  ) {
    iconRegistry.addSvgIcon(
      'info',
      sanitizer.bypassSecurityTrustResourceUrl('assets/images/info.svg'));
  }

  ngOnInit() {
    if (this.field.map != undefined) {
      this.optionLabel = this.field.map.label instanceof Array ? 'newKey' : this.field.map.label;
      this.optionValue = this.field.map.value;
      if (this.field.map.nullAlias) {
        this.nullAlias = this.field.map.nullAlias;
      }
    }

    if (this.field.options != undefined) {
      this.selectOptions = this.field.options;
    } else {
      if (this.field.ApiUrl !== undefined) {
        this.restService.get(this.field.ApiUrl).subscribe(
          (response) => {
            if (response != '') {
              if (this.field.handleNullValues) {
                this.selectOptions = response.data.map((item) => {
                  item[this.field.map.value] = item[this.field.map.value] == null ? "null" : item[this.field.map.value];
                  return item;
                });
              } else {
                this.selectOptions = response.data;
              }

              if (this.field.map.label instanceof Array) {
                this.selectOptions.forEach((element) => {
                  element = Object.assign(element, {
                    newKey: element[this.field.map.label[0]] == null || element[this.field.map.label[0]] == 'null' ? element[this.field.map.label[1]] : element[this.field.map.label[0]] + ' - ' + element[this.field.map.label[1]]
                  });
                });
              }
            }
          },
          (error) => {
            console.log(error);
          }
        );
      }
    }
    //If value of secondary dropdown depends on value selected on primary dropdown
    this.sharedService.getSubSelectValues().subscribe((result) => {
      if (this.field.name == result.targetName) {
        this.selectOptions = result.options;
      }
    });

    this.group.controls[this.field.name].valueChanges.subscribe((r) => {
      if (this.group.controls[this.field.name].value) {
        if (this.group.controls[this.field.name].value instanceof Array) {
          this.toolTipText = this.group.controls[this.field.name].value.map((item) => item[this.optionLabel]).join(', ');
        } else {
          // this.toolTipText = this.selectOptions.filter(i => i[this.field.map.value] == this.group.controls[this.field.name].value)
        }

      }

      let obj = {};
      if (r != null || r != undefined) {
        if (this.group.controls[this.field.name].errors) {
          obj = {
            error: Object.keys(this.group.controls[this.field.name].errors)[0],
            label: this.field.label,
            message: this.field.validations.filter(
              (itm) => itm.name == Object.keys(this.group.controls[this.field.name].errors)[0]
            )[0].message,
            status: this.group.controls[this.field.name].status,
            screenName: this.router.url
          };
        }
        else {
          obj = {
            error: 'pattern',
            label: this.field.label,
            message: '',
            status: 'VALID',
            screenName: this.router.url
          };
        }
        this.sharedService.setErrorMessage({ [this.field.name]: obj });
      }
      else {
        obj = {
          error: 'pattern',
          label: this.field.label,
          message: '',
          status: 'VALID',
          screenName: this.router.url
        };
        this.sharedService.setErrorMessage({ [this.field.name]: obj });
      }
    });
  }

  OnChangeEvent(fields: any, elem) {
    this.eventEmitterService.onCommonComponentEvents(fields);
    this.detectErrors();
  }

  handleClose(elem) {
    this.detectErrors();
    this.selectNextTab(elem);
  }

  detectErrors() {
    let obj = {};

    if (this.group.controls[this.field.name].errors) {
      this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      obj = {
        error: Object.keys(this.group.controls[this.field.name].errors)[0],
        label: this.field.label,
        message: this.field.validations.filter(
          (itm) => itm.name == Object.keys(this.group.controls[this.field.name].errors)[0]
        )[0].message,
        status: this.group.controls[this.field.name].status,
        screenName: this.router.url
      };
    } else {
      obj = {
        error: '',
        label: this.field.label,
        message: '',
        status: 'VALID',
        screenName: this.router.url
      };
    }
    this.sharedService.setErrorMessage({ [this.field.name]: obj });
  }

  toggleAllSelection() {
    var keyNames = Object.keys(this.selectOptions[0]);
    this.fieldName = keyNames.length == 3 ? keyNames[1] : keyNames[0];

    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => {
        // Added by Mahesh Karekar on 18-05-2021 for disabling feature options.
        if (this.field.disableOptionsOnNoSel && !item.value[this.fieldName]) {
          item.deselect();
        } else {
          // End : Added by Mahesh Karekar on 18-05-2021 for disabling feature options.
          item.select();
        }
      });
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  optionClick(evt) {
    if (!evt.source.disabled) {
      let newStatus = true;
      this.isOptionDisabled = false;
      let count = 0;
      var keyNames = Object.keys(this.selectOptions[0]);
      this.fieldName = keyNames.length == 3 ? keyNames[1] : keyNames[0];
      this.firstSelectedText = "";
      this.countItemSelected = 0;
      this.select.options.forEach((item: MatOption) => {
        if (!item.selected) {
          newStatus = false;
        }
        else if (this.field.disableOptionsOnNoSel && !item.value[this.fieldName]) {
          this.isOptionDisabled = true;
        }
      });
      this.allSelected = newStatus;

      this.select.options.forEach((item: MatOption) => {
        if (this.field.disableOptionsOnNoSel && item.selected && item.value[this.fieldName] && this.isOptionDisabled) {
          item.deselect();
          this.allSelected = false;
        }
        if (item.selected) {
          this.countItemSelected++;
          if (this.firstSelectedText == "") {
            this.firstSelectedText = item.value["c"];
          }
        }
      });
    }
  }

  compareObjects(o1: any, o2: any): boolean {
    return JSON.stringify(o1) == JSON.stringify(o2);
  }

  //only when tab/enter key pressed and there is error beep sound will hear
  onKeydown(event) {
    if (event.key === 'Enter' || event.key === 'Tab') {
      if (this.group.controls[this.field.name].errors) {
        this.group.controls[this.field.name].markAsTouched();
        event.preventDefault();
        this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      }
    }
  }

  selectNextTab(elem?: any) {
    let flg = true;
    if (elem) {
      var tidx = elem.field.tabIndex + 1,
        elems = document.getElementsByTagName('*');

      for (var i = elems.length; i--;) {
        var tidx2 = +(elems[i].getAttribute('tabindex'));
        if (tidx2 == tidx) {
          (elems[i] as HTMLElement).focus();
        } else {
          flg = false;
        }
      }
    }
  }
}
