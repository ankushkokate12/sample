// import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RestService } from '../../../rest.service';
// import {MatTableDataSource} from '@angular/material/table';
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { IGridColumn } from '../../../interfaces/grid-columns.interface';
import { DynamicGridComponent } from 'projects/tools/src/public-api';
import { SharedService } from '../../../shared.service';

@Component({
  selector: 'app-suggestion-table',
  templateUrl: './suggestion-table.component.html',
  styleUrls: ['./suggestion-table.component.scss']
})
export class SuggestionTableComponent implements OnInit {
  fieldName;
  tableData = [];
  dataSource;
  displayedColumns;
  selectAllRows: boolean = true;
  selectioMode: string = '';

  @ViewChild(DynamicGridComponent, { static: false })
  grid: DynamicGridComponent;
  dataColumn: IGridColumn[];
  rows = [];
  isSortable = true;
  selectedKeys: any[];

  constructor(
    public dialogRef: MatDialogRef<SuggestionTableComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private restService: RestService,
    private sharedService: SharedService
  ) { }

  ngOnInit(): void {
    this.fieldName = this.data.fieldname;
    this.displayedColumns = this.data.gridColumns;
    const requestBody = {};
    if (this.data.apiurl != 'undefined') {
      this.restService.get(this.data.apiurl, requestBody).subscribe(
        (response) => {
          if (response != ' ') {
            this.rows = response.data;
            this.filterOutSelectedObjectToPopulateOnGrid();
          }
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getValue(evt: any) {
    const res = {
      fieldvalue: evt.toElement.textContent.trim(),
      fieldname: this.fieldName
    };
    this.dialogRef.close(res);
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  filterOutSelectedObjectToPopulateOnGrid() {
    let strArr = this.data.fieldData.split(', ');
    if (strArr instanceof Array) {
      this.selectedKeys = this.rows.filter(e => strArr.indexOf(e.a) >= 0);
    } else {
      this.selectedKeys = this.rows.filter(e => this.data.fieldData === e.a);
    }
    console.log(this.selectedKeys, this.data.fieldData);

  }

  handleCheckboxSelection(res) {
    let a = {
      fieldName: this.fieldName,
      data: res
    };
    this.sharedService.sendSelectedGridRows(a);
  }
}
