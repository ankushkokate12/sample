import { NavigationEnd, Router } from '@angular/router';
import { Component, Input, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Page } from '../../../interfaces/page';
import { ITabs } from './tabs.interface';
@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements OnInit {
  navigations: Observable<Page[]>;
  activeTabUrl: string;
  @Input() tabsData: ITabs[];
  // toggleDisplay: boolean;
  constructor(private store: Store<{ navigations: Page[] }>, private router: Router) {
    this.navigations = store.pipe(select('navigations'));
    // this.toggleDisplay = true;
  }

  ngOnInit(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.activeTabUrl = event.urlAfterRedirects;
      }
    });
  }

  removeNavigation(index: number) {
    if (index !== 0) {
      const tabsData = JSON.parse(localStorage.getItem('tabsData'));
      const currentTab = tabsData.splice(index, 1);

      const futureTab = tabsData[tabsData.length - 1]

      tabsData.forEach((tab) => {
        tab.isActive = false;
        if (tab.tabUrl === futureTab.tabUrl) {
          tab.isActive = true;
        }
      });

      localStorage.setItem('tabsData', JSON.stringify(tabsData));
      this.tabsData = tabsData

      this.router.navigate([futureTab.tabUrl]);
      // TODO: To restore conditional routereuse
      // this.router.navigate([futureTab.tabUrl], { queryParams: { showSnap: "YES", deletedTab: currentTab.tabUrl } });
    }
  }

  navigateToTab(url) {
    let actualTabUrl = url;
    const tabsData = JSON.parse(localStorage.getItem('tabsData'));

    tabsData.forEach((tab) => {
      tab.isActive = false;
      if (tab.tabUrl === url) {
        tab.isActive = true;
        actualTabUrl = tab.newUrl.length > 0 ? tab.newUrl : url
      }
    });

    localStorage.setItem('tabsData', JSON.stringify(tabsData));
    this.tabsData = tabsData

    this.router.navigate([actualTabUrl]);
    // TODO: To restore conditional routereuse
    // this.router.navigate([actualTabUrl], { queryParams: { showSnap: "YES" } });
  }

  /*  toggleView(){
    this.toggleDisplay = false;
  } */
}
