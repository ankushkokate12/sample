export interface ITabs {
  tabName: string;
  tabUrl: string;
  newUrl?: string;
  isActive: boolean;
}
