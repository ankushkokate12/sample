import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { AUDIO_SETTINGS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';

@Component({
  selector: 'app-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.scss']
})
export class TextareaComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  apiValidationMsg: string;

  constructor(
    private sharedService: SharedService,
    private router: Router,
    private beepService: BeepService,
    private eventEmitterService: EventEmitterService
  ) { }

  ngOnInit() {
    this.group.controls[this.field.name].valueChanges.subscribe((r) => {
      let obj = {};
      if (r == null || r == undefined) {
        obj = {
          error: 'pattern',
          label: this.field.label,
          message: '',
          status: 'VALID',
          screenName: this.router.url
        };
        this.sharedService.setErrorMessage({ [this.field.name]: obj });
      }
    });
  }

  focusOut(fields: any) {
    this.detectErrors();
    if (this.group.controls[this.field.name].errors) {
      this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
    } else if(this.group.controls[this.field.name].value.replace(/\n/g, "") == '') {
        this.setTextAreaError();
    }
  }

  detectErrors() {
    let obj = {};
    if (this.group.controls[this.field.name].errors) {
      obj = {
        error: Object.keys(this.group.controls[this.field.name].errors)[0],
        label: this.field.label,
        message: this.field.validations.filter(
          (itm) => itm.name == Object.keys(this.group.controls[this.field.name].errors)[0]
        )[0].message,
        status: this.group.controls[this.field.name].status,
        screenName: this.router.url
      };
    }
    else {
      obj = {
        error: 'pattern',
        label: this.field.label,
        message: '',
        status: 'VALID',
        screenName: this.router.url
      };
    }
    this.sharedService.setErrorMessage({ [this.field.name]: obj });
  }

  onKeydown(event, fields: any, elem) {
    if (event.shiftKey && event.key === 'Tab') {
    } else if (event.key === 'Enter' || event.key === 'Tab') {
      if (this.group.controls[this.field.name].errors) {
        this.group.controls[this.field.name].markAsTouched();
        event.preventDefault();
        this.detectErrors();
        this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      } else if(this.group.controls[this.field.name].value.replace(/\n/g, "") == '') {
         this.setTextAreaError();
         event.preventDefault();
      } 
      else if (event.key === 'Enter') {
        this.eventEmitterService.onCommonComponentEvents(fields);
        this.selectNextTab( elem );
      }
    }
  }

  selectNextTab( elem?: any ) {
    let flg = true;
    if ( elem ) {
      var tidx = elem.field? elem.field.tabIndex + 1 : elem+1;
      let elems = document.querySelectorAll( '[tabindex]' );
      for ( var i = elems.length; i--; ) {
        var tidx2 = +( elems[ i ].getAttribute( 'tabindex' ) );
        if ( tidx2 == tidx ) {
          if(elems[ i ].getAttribute('disabled') != null) {
            this.selectNextTab(tidx);
            continue;
          }
          else {
            ( elems[ i ] as HTMLElement ).focus();
          }
        } else {
          flg = false;
        }
      }
    }
  }

  setTextAreaError() {
    this.group.controls[this.field.name].setValue(null); 
    this.group.controls[this.field.name].markAsTouched();
    this.detectErrors();
    this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
  }
}
