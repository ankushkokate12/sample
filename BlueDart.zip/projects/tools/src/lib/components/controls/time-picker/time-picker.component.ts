import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../../interfaces/field.interface';
import { EventEmitterService } from '../../../event-emitter.service';

@Component({
  selector: 'app-time-picker',
  templateUrl: './time-picker.component.html',
  styleUrls: ['./time-picker.component.scss']
})
export class TimePickerComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  apiValidationMsg: string;
  constructor(private eventEmitterService: EventEmitterService) { }

  ngOnInit(): void { }

  focusOut(fields: any) {
    this.eventEmitterService.onCommonComponentEvents(fields);
  }

  onKeydown(event, fields: any) {
    if (event.shiftKey && event.key === 'Tab') {
      // event.preventDefault();
      // this.group.controls[this.field.name].;
    } else if (event.key === 'Enter' || event.key === 'Tab') {
      if (this.group.controls[this.field.name].errors) {
        this.group.controls[this.field.name].markAsTouched();
        event.preventDefault();
      } else if (event.key === 'Enter') {
        event.preventDefault();
        this.selectNextTab();
      }
    }
  }

  selectNextTab() {
    const inputs = Array.from(
      document.querySelectorAll('form input:not(:disabled)')
    );
    let nextInput = inputs[inputs.indexOf(document.activeElement) + 1];
    if (!nextInput) {
      nextInput = document.querySelectorAll('form button')[0];
    }
    (nextInput as HTMLElement).focus();
  }

}
