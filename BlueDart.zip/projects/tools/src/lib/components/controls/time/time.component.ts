import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { BeepService } from 'projects/tools/src/lib/beep.service';
import { AUDIO_SETTINGS, MASK_INPUTS } from 'projects/tools/src/lib/constants/constant';
import { EventEmitterService } from 'projects/tools/src/lib/event-emitter.service';
import { FieldConfig } from 'projects/tools/src/lib/interfaces/field.interface';
import { SharedService } from 'projects/tools/src/lib/shared.service';
import { HelpicondialogComponent } from 'projects/tools/src/lib/components/controls/helpicondialog/helpicondialog.component';
import { SuggestionTableComponent } from 'projects/tools/src/lib/components/controls/suggestion-table/suggestion-table.component';
@Component({
  selector: 'lib-time',
  templateUrl: './time.component.html',
  styleUrls: ['./time.component.scss']
})
export class TimeComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  validationMessages: string[];
  apiValidationMsg: string;
  targetedInputForCheckboxValues: string;
  isAutoCaps: boolean = false;
  maskTime = MASK_INPUTS.TIME;
  constructor(
    private sharedService: SharedService,
    private eventEmitterService: EventEmitterService,
    private router: Router,
    private beepService: BeepService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.group.controls[this.field.name].valueChanges.subscribe((r) => {
      let obj = {};
      if (r == null || r == undefined) {
        obj = {
          error: 'pattern',
          label: this.field.label,
          message: '',
          status: 'VALID',
          screenName: this.router.url
        };
        this.sharedService.setErrorMessage({ [this.field.name]: obj });
      }
    });
  }

  detectErrors() {
    let obj = {};
    if (this.group.controls[this.field.name].errors) {
      obj = {
        error: Object.keys(this.group.controls[this.field.name].errors)[0],
        label: this.field.label,
        message: this.field.validations.filter(
          (itm) => itm.name == Object.keys(this.group.controls[this.field.name].errors)[0]
        )[0].message,
        status: this.group.controls[this.field.name].status,
        screenName: this.router.url
      };
    }
    else {
      obj = {
        error: 'pattern',
        label: this.field.label,
        message: '',
        status: 'VALID',
        screenName: this.router.url
      };
    }
    this.sharedService.setErrorMessage({ [this.field.name]: obj });
  }

  OnChangeEvent(fields: any) {
    fields.helpEventRef = false;
    this.eventEmitterService.onCommonComponentEvents(fields);
  }

  focusOut(fields: any) {
    fields.helpEventRef = false;
    this.eventEmitterService.onCommonComponentEvents(fields);
    this.detectErrors();
    if (this.group.controls[this.field.name].errors) {
      this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
    }
    this.setDefaultZero();
  }

  setDefaultZero() {
    if (this.group.get(this.field.name).value) {
      let value = this.group.get(this.field.name).value?.split(':');
      value[1] =  value[1]?  value[1]: '00'
      if (value[1]?.length == 1) {
        this.group.get(this.field.name).setValue(value[0] + ':0' + value[1]);
      }
      if (value[0]?.length == 1) {
        this.group.get(this.field.name).setValue('0'+ value[0] + ':' + value[1]);
      }
      if(value[0].length == 2 && value[1] == '00') {
        this.group.get(this.field.name).setValue(value[0] + ':' +  value[1]);
      }
    }
  }

  onKeydown(event, fields: any, elem) {
    fields.helpEventRef = false;
    if (event.shiftKey && event.key === 'Tab') {
    } else if (event.key === 'Enter' || event.key === 'Tab') {
      this.setDefaultZero();
      if (this.group.controls[this.field.name].errors) {
        this.group.controls[this.field.name].markAsTouched();
        event.preventDefault();
        this.detectErrors();
        this.beepService.playSound(AUDIO_SETTINGS.PLAY_SOUND);
      } else if (event.key === 'Enter') {
        this.eventEmitterService.onCommonComponentEvents(fields);
        this.selectNextTab( elem );
      }
    }
  }

  selectNextTab( elem?: any ) {
    let flg = true;
    if ( elem ) {
      var tidx = elem.field? elem.field.tabIndex + 1 : elem+1;
      let elems = document.querySelectorAll( '[tabindex]' );
      for ( var i = elems.length; i--; ) {
        var tidx2 = +( elems[ i ].getAttribute( 'tabindex' ) );
        if ( tidx2 == tidx ) {
          if(elems[ i ].getAttribute('disabled') != null) {
            this.selectNextTab(tidx);
            continue;
          }
          else {
            ( elems[ i ] as HTMLElement ).focus();
          }
        } else {
          flg = false;
        }
      }
    }
  }

  showSuggestion() {
    this.targetedInputForCheckboxValues = this.field.name;
    const dialogRef = this.dialog.open( SuggestionTableComponent, {
      width: '' + this.field.helpDialogWidth + 'px',
      minWidth: 350,
      data: {
        title: this.field.label,
        apiurl: this.field.helpApiUrl,
        tdHead: this.field.helpTableHead,
        fieldname: this.field.name,
        fieldData: this.group.controls[ this.field.name ].value,
        gridColumns: this.field.helpDialogGridColumns ? this.field.helpDialogGridColumns : null,
        gridOptions: this.field.gridOptions ? this.field.gridOptions : null,
        disclaimer: this.field.disclaimer,
        selectBtn: this.field.selectBtn
      }
    } );

    dialogRef.afterClosed().subscribe( () => {
    } );
  }

  openHelpDialog() {
    const dialogRef = this.dialog.open( HelpicondialogComponent, {
      width: '' + this.field.helpDialogWidth + 'px',
      minWidth: 400,
      data: {
        title: this.field.label,
        apiurl: this.field.helpApiUrl,
        tdHead: this.field.helpTableHead,
        heading: this.field.dialogTitle,
        fieldname: this.field.name ? this.field.name : null,
        //Passing date such as grid details, form details to be used in help icon idalog
        fieldData: this.field.helpDialogFormData ? this.field.helpDialogFormData : null,
        gridOptions: this.field.gridOptions ? this.field.gridOptions : null,
        gridColumns: this.field.helpDialogGridColumns ? this.field.helpDialogGridColumns : null,
        errorMessage: this.field.errorMessage ? this.field.errorMessage : null,
        apiURLs: this.field.apiURLs ? this.field.apiURLs : null
      }
    } );

    dialogRef.afterClosed().subscribe( ( res ) => {
      this.sharedService.setPopupData( { field: this.field, data: res } );
    } );
  }

  //open helpicon from component
  openHelpDialogComp( fields ) {
    fields.helpEventRef = true;
    this.eventEmitterService.onCommonComponentEvents( fields );
  }
}
