import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatTree, MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { FieldConfig, TreeModel } from '../../../interfaces/field.interface';
import { RestService } from '../../../rest.service';

@Component({
  selector: 'app-lib-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.css']
})
export class TreeComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  treeDataList;
  @ViewChild('tree') tree: MatTree<any>;

  subscription;
  count = 0;
  nestedTreeControl: NestedTreeControl<TreeModel>;
  nestedDataSource: MatTreeNestedDataSource<TreeModel>;
  inputValue;

  constructor(private restService: RestService) {
    this.nestedTreeControl = new NestedTreeControl<TreeModel>(this.getChildren);
    this.nestedDataSource = new MatTreeNestedDataSource();
  }

  ngOnInit() {
    const requestBody = {};
    if (this.field.ApiUrl != 'undefined') {
      this.restService
        .get(this.field.ApiUrl, requestBody)
        .subscribe(
          (response) => {
            if (response != ' ') {
              this.treeDataList = response;
              this.treeDataList.map((d: any) => {
                d.checked = false;
                d.expanded = false;
                return d;
              });
            } 
          },
          (error) => {
            console.log(error);
          }
        );
    }
    // for config data
    if(this.field.treeNode.length != 0){
      this.treeDataList = this.field.treeNode;
      this.treeDataList.map((d: any) => {
        d.checked = false;
        d.expanded = false;
        return d;
      });
    }
    this.nestedDataSource.data = this.treeDataList;
  }

  hasNestedChild = (_: number, nodeData: TreeModel) => nodeData.children.length > 0;

  private getChildren = (node: TreeModel) => node.children;

  clickedActive(element) {
    element.checked = !element.checked;
  }

  getCheckedAmount(data) {
    this.count = 0;
    this.loopData(data.children);
    return this.count;
  }

  loopData(data) {
    data.forEach((d) => {
      if (d.checked) {
        this.count += 1;
      }
      if (d.children && d.children.length > 0) {
        this.loopData(d.children);
      }
    });
  }

  changeState(data) {
    data.expanded = !data.expanded;
  }
}
