import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VolumetricTableComponent } from './volumetric-table.component';

describe('VolumetricTableComponent', () => {
  let component: VolumetricTableComponent;
  let fixture: ComponentFixture<VolumetricTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VolumetricTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VolumetricTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
