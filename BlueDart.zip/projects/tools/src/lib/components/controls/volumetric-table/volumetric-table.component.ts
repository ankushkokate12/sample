import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedService } from '../../../shared.service';
import { DialogComponent } from 'projects/tools/src/lib/components/controls/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'lib-volumetric-table',
  templateUrl: './volumetric-table.component.html',
  styleUrls: ['./volumetric-table.component.scss']
})
export class VolumetricTableComponent implements OnInit {
  @Input() columns;
  @Input() rows;
  @Input() header;
  @Input() pieces;
  values = '';
  @Output() calculation: EventEmitter<any> = new EventEmitter();
  constructor(public dialog: MatDialog, private sharedService: SharedService, private elementRef: ElementRef) { }

  ngOnInit(): void {
    this.pieces = this.pieces ? this.pieces : 0;
  }

  onFocusOut(rowData, field, event, index) {
    let emitData = {
      rowData: rowData,
      field: field,
      inputValue: event.target.value,
      index: index
    };
    this.calculation.emit(emitData);
  }

  clearRowData() {
    if (this.rows?.length) {
      const confirmDialog = this.dialog.open(DialogComponent, {
        data: {
          title: 'Do you want to Clear the data?',
          message: 'Data will be cleared. Click Yes to proceed.',
          primaryButton: 'Yes',
          secondaryButton: 'No'
        }
      });
      confirmDialog.afterClosed().subscribe(result => {
        if (result) {
          this.sharedService.sendClearAllEvent(true);
          this.rows.forEach((row) => {
            row.a = '';
            row.b = '';
            row.c = '';
            row.d = '';
            row.e = null;
          });
        }
      });
    }
  }

  onKeyDown(e, rowData) {
    if (e.key === 'Enter') {
      const inputs = Array.from(this.elementRef.nativeElement.querySelectorAll('input'));
      let nextInput = inputs[inputs.indexOf(document.activeElement) + 1];
      if (nextInput) {
        (nextInput as HTMLElement).focus();
      }
    }
    else if (!rowData.a) {
      if (!((e.keyCode > 95 && e.keyCode < 106) || (e.keyCode > 47 && e.keyCode < 58) || e.keyCode == 8 || e.keyCode === 9 || e.keyCode === 39 || e.keyCode === 37 || e.keyCode === 46)) {
        return false;
      }
      else {
        this.checkDecimalPoints(e);
      }
    } else {
      if (!((e.keyCode > 95 && e.keyCode < 106) || (e.keyCode > 47 && e.keyCode < 58) || e.keyCode == 8 || e.keyCode === 190 || e.keyCode === 9 || e.keyCode === 39 || e.keyCode === 37 || e.keyCode === 46)) {
        return false;
      }
      else {
        this.checkDecimalPoints(e);
      }
    }
  }

  checkDecimalPoints(event) {
    let inp = event.key;
    if (inp == '0' || inp == '1' || inp == '2' || inp == '3' || inp == '4' || inp == '5' || inp == '6' || inp == '7' || inp == '8' || inp == '9' || inp == '.') {
      let regExp = '^[0-9]{1,5}$|^[0-9]{1,5}\\.$|^[0-9]{1,5}\\.[0-9]{0,2}$';
      const localRegExp = new RegExp(regExp);
      if (localRegExp.test(event.target.value + inp)) {
        return true;
      }
      else {
        event.preventDefault();
        return false;
      }
    }
  }
}
