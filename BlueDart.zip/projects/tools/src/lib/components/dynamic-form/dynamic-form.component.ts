import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldConfig } from '../../interfaces/field.interface';
import { SharedService } from '../../shared.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit, OnChanges {
  @Input()
  fields: FieldConfig[] = [];

  @Input()
  formDisable: Array<string>;

  @Output()
  submitForm: EventEmitter<any> = new EventEmitter<any>();
  form: FormGroup;
  @Input() payload: any = {};
  fbGroup = this.fb.group({});
  validationErrors: any = [];
  keyLabelMapping: any = [];

  get value() {
    return this.form.value;
  }
  constructor(private fb: FormBuilder, private errorMsgService: SharedService, private router: Router) { }

  ngOnChanges(changes: SimpleChanges): void {
    const change = changes.formDisable;
    if (change && !change.firstChange) {
      if (change.currentValue) {
        this.form.enable();
        change.currentValue.forEach((element) => {
          this.form.controls[element].disable();
        });
      } else {
        this.form.enable();
      }
    }
  }

  ngOnInit() {
    this.fbGroup = this.fb.group({});
    this.form = this.createControl(this.fields);
    this.onChanges();
  }

  onChanges(): void {
    this.form.valueChanges.subscribe((val) => {
      /*  if (this.form.valid) {
          this.fields.forEach((field) => {
            if (field.type === 'button') {
              field.disabled = false;
            }
          });
        } else {
          this.fields.forEach((field) => {
            if (field.type === 'button') {
              field.disabled = true;
            }
          });
        } */
    });
  }

  onSubmit(event: Event) {
    event.preventDefault();
    event.stopPropagation();
    if (this.form.valid) {
      this.submitForm.emit(this.form);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  createControl(fields) {
    fields.forEach((field) => {
      if (field.type === 'row' || field.type === 'section') {
        this.createControl(field.rows || field.section);
      } else {
        this.keyLabelMapping[field.name] = {
          label: field.label,
          validations: field.validations
        };
        const control = this.fb.control(field.value, this.bindValidations(field.validations || []));
        if (field.disabled) {
          control.disable();
        } else {
          control.enable();
        }
        this.fbGroup.addControl(field.name, control);
      }
    });
    return this.fbGroup;
  }

  createControl_old() {
    const group = this.fb.group({});
    this.fields.forEach((field) => {
      if (!field.section) {
        if (field.type === 'button' || field.type === 'row') {
          return;
        }
        const control = this.fb.control(field.value, this.bindValidations(field.validations || []));
        if (field.disabled) {
          control.disable();
        } else {
          control.enable();
        }
        group.addControl(field.name, control);
      } else {
        field.section.forEach((f) => {
          if (f.type === 'button' || f.type === 'row') {
            return;
          }
          const control = this.fb.control(f.value, this.bindValidations(f.validations || []));
          if (f.disabled) {
            control.disable();
          } else {
            control.enable();
          }
          group.addControl(f.name, control);
        });
      }
    });
    return group;
  }

  bindValidations(validations: any) {
    if (validations.length > 0) {
      const validList = [];
      validations.forEach((valid) => {
        validList.push(valid.validator);
      });
      return Validators.compose(validList);
    }
    return null;
  }

  validateAllFormFields(formGroup: FormGroup) {
    let tempArr = new Array();
    Object.keys(formGroup.controls).forEach((field) => {
      if (formGroup.controls[field].status == 'INVALID') {
        tempArr[field] = {
          error: Object.keys(formGroup.controls[field].errors)[0],
          label: this.keyLabelMapping[field].label,
          message: this.keyLabelMapping[field].validations.filter(
            (itm) => itm.name == Object.keys(formGroup.controls[field].errors)[0]
          )[0].message
          , status: 'INVALID'
          , screenName: this.router.url
        };
      }
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    this.generateErrorArray(tempArr);
  }

  generateErrorArray(validationsArray) {
    console.log(validationsArray);
    if (Object.keys(validationsArray).length > 0) {
      this.errorMsgService.setErrorMessage({ all: validationsArray });
    }
  }
}
