import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OpenTabsNavComponent } from './open-tabs-nav.component';

describe('OpenTabsNavComponent', () => {
  let component: OpenTabsNavComponent;
  let fixture: ComponentFixture<OpenTabsNavComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [OpenTabsNavComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenTabsNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
