import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-tabs-nav',
  templateUrl: './open-tabs-nav.component.html',
  styleUrls: ['./open-tabs-nav.component.css']
})
export class OpenTabsNavComponent implements OnInit {
  opened: boolean;
  constructor() {
    this.opened = true;
  }

  ngOnInit() {}
}
