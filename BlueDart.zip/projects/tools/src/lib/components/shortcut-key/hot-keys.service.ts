import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotKeysService {
  hotKeys: any[] = [];
  constructor(private http: HttpClient) {}

  getHotKeys() {
    return this.http
      .get('assets/hot-keys.json')
      .toPromise()
      .then((res: any[]) => {
        this.hotKeys = res;
      });
  }
}
