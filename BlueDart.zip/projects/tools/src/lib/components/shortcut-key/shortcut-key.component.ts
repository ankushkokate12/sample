import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { fromEvent } from 'rxjs/internal/observable/fromEvent';
import { map } from 'rxjs/operators';
import { HelpDialogComponent } from '../controls/help-dialog/help-dialog.component';
import { HotKeysService } from './hot-keys.service';

@Component({
  selector: 'app-shortcut-key',
  templateUrl: './shortcut-key.component.html',
  styleUrls: ['./shortcut-key.component.scss']
})
export class ShortcutKeyComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  @Output() showHelp: EventEmitter<any> = new EventEmitter<any>();
  @Input() screenKey: string;
  hotKeyArray: any[] = [];

  constructor(private dialog: MatDialog, private hotkeyService: HotKeysService) {
    this.hotkeyService.getHotKeys();
  }

  ngOnInit(): void {
    this.subscription = fromEvent(document, 'keyup')
      .pipe(map((event: any) => event))
      .subscribe((e: any) => {
        if (e.code === 'F12' && e.ctrlKey) {
          this.dialog.open(HelpDialogComponent, { width: "400px", data: 'dummy' });
        } else if (e.ctrlKey) {
          this.showHelp.emit(e);
        }
      });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
