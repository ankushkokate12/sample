import { ConsigneepinDirective } from './consigneepin.directive';

describe('ConsigneepinDirective', () => {
  it('should create an instance', () => {
    const directive = new ConsigneepinDirective();
    expect(directive).toBeTruthy();
  });
});
