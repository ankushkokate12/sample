import { HttpHeaders } from '@angular/common/http';
export const RoleConstants = {
  CCT: 'gg_app_CCPA_CustomerServices',
  Analyst: 'gg_app_CCPA_PrivacyAnalyst',
  digital: 'gg_app_CCPA_DigitalChannels',
  marketing: 'gg_app_CCPA_Marketing',
  eagle: 'gg_app_CCPA_EagleIntelligence',
  legal: 'gg_app_CCPA_Legal',
  audit: 'gg_app_CCPA_Audit_Readonly',
  pro: 'gg_app_CCPA_PrimaryRelationshipOwner'
};

export const PathConst = {
  eagleLogo: '../assets/images/eagle.svg'
};

export const MsgConst = {
  headerTitle: 'CCPA - Enter New Request'
};

export const C3NGHttpConst = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

export const HeaderMenu = [
  { label: 'Home', link: '/privacy-request' },
  { label: 'Requests', link: '/request-summary' },
  { label: 'Reports', link: '/request-analyst' },
  { label: 'Inventory', link: '/dashboard' },
  { label: 'Policies', link: '/temp2' }
];

export const APIURL = {
  baseURL: 'http://10.77.100.223:8080/',
  commodityLimit: 8,
  noDataFoundStr: 'No Data Found !'
};

export const SEVEN_WEEKDAYS = [
  { value: '1', label: 'Monday', displayValue: '1' },
  { value: '2', label: 'Tuesday', displayValue: '2' },
  { value: '3', label: 'Wednesday', displayValue: '3' },
  { value: '4', label: 'Thursday', displayValue: '4' },
  { value: '5', label: 'Friday', displayValue: '5' },
  { value: '6', label: 'Saturday', displayValue: '6' },
  { value: '7', label: 'Sunday', displayValue: '7' }
];

export const NOTIFICATIONS = {
  life: 5000 // we are going to display the toster error message for 5000 mili second
}; 

export const VALIDATION_STATUS = {
  INVALID: "INVALID",
  VALID: "VALID",
  NO_WARNING: "NOWARNING",
  WARNING: "WARNING"
};

export const AUDIO_SETTINGS = {
  PLAY_SOUND: 300,
  OSC_TYPE: 'square',
  GAIN_VALUE: 10
}
export const MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
"July", "August", "September", "October", "November", "December" ];

export const MASK_INPUTS = {
  TIME: 'Hh:m0'
}
