import { DocsDutsDirective } from './docs-duts.directive';

describe('DocsDutsDirective', () => {
  it('should create an instance', () => {
    // const directive = new DocsDutsDirective();
    // expect(directive).toBeTruthy();
  });
});
