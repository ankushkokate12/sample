import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[libDocsDuts]'
})
export class DocsDutsDirective {
  constructor(private el: ElementRef) {}

  @HostListener('input', ['$event']) onInputChange(event) {
    let initalValue = this.el.nativeElement.value;
    if (initalValue.length >= 1) {
      initalValue = initalValue.substr(0, 1);
    }
    this.el.nativeElement.value = initalValue.replace(/[^0-9]*/g, '');
    if (initalValue !== this.el.nativeElement.value) {
      event.stopPropagation();
    }
  }
}
