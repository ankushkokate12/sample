import { DragDropDirective } from './drag-drop.directive';

describe('DragDropDirective', () => {
  it('should create an instance', () => {
    // const directive = new DragDropDirective();
    // expect(directive).toBeTruthy();
  });
});
