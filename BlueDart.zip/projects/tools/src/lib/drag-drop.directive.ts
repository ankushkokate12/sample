import { Directive, Output, Input, OnInit, EventEmitter, HostBinding, HostListener } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
export interface FileHandle {
  file: File;
  url: SafeUrl;
}
@Directive({
  selector: '[appDragDrop]'
})
export class DragDropDirective implements OnInit {
  // @HostBinding('class.fileover') fileOver: boolean;
  @HostBinding('style.background') private background = '#ffffff';
  // @Output() fileDropped = new EventEmitter<any>();
  @Output() file: EventEmitter<FileHandle[]> = new EventEmitter();
  constructor(private sanitizer: DomSanitizer) {}
  ngOnInit() {}
  // Dragover listener
  @HostListener('dragover', ['$event']) public onDragOver(evt: DragEvent) {
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#999';
  }

  //   Dragleave listener
  @HostListener('dragleave', ['$event']) public onDragLeave(evt: DragEvent) {
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#eee';
  }

  // Drop listener
  @HostListener('drop', ['$event']) public onDrop(evt: DragEvent) {
    console.log(evt);
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#eee';
    let files: FileHandle[] = [];
    // const file = evt.dataTransfer.files;
    // let files = evt.dataTransfer.files;
    // for (let i = 0; i < evt.dataTransfer.files.length; i++) {
    const file = evt.dataTransfer.files;
    const url = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(file));
    // files.push({ file, url });
    // }
    if (files.length > 0) {
      this.file.emit(files);
    }
  }
}
