import { ComponentFactoryResolver, Directive, Input, OnInit, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { from } from 'rxjs';
import { ButtonComponent } from './components/controls/button/button.component';
import { CheckboxComponent } from './components/controls/checkbox/checkbox.component';
import { EmptyComponent } from './components/controls/empty/empty.component';
import { InputComponent } from './components/controls/input/input.component';
import { LabelComponent } from './components/controls/label/label.component';
import { RadiobuttonComponent } from './components/controls/radiobutton/radiobutton.component';
import { ReportComponent } from './components/controls/report/report.component';
import { SelectComponent } from './components/controls/select/select.component';
import { TextareaComponent } from './components/controls/textarea/textarea.component';
import { FileuploadComponent } from './components/controls/fileupload/fileupload.component';
import { TreeComponent } from './components/controls/tree/tree.component';
import { DatepickerComponent } from './components/controls/datepicker/datepicker.component';
import { TabsComponent } from './components/controls/tabs/tabs.component';
import { TimePickerComponent } from './components/controls/time-picker/time-picker.component';
import { MovelistToOtherComponent } from './components/controls/movelist-to-other/movelist-to-other.component';
import { FieldConfig } from './interfaces/field.interface';
import { IconbuttonComponent } from './components/controls/iconbutton/iconbutton.component';
import { ChipsComponent } from './components/controls/chips/chips.component';
import { PageHeaderComponent } from './components/controls/page-header/page-header.component';
import { InfoLabelComponent } from './components/controls/info-label/info-label.component';
import { TimeComponent } from './components/controls/time/time.component';
import { SelectwithnumberComponent } from './components/controls/selectwithnumber/selectwithnumber.component';

const componentMapper = {
  input: InputComponent,
  button: ButtonComponent,
  select: SelectComponent,
  radiobutton: RadiobuttonComponent,
  checkbox: CheckboxComponent,
  empty: EmptyComponent,
  label: LabelComponent,
  report: ReportComponent,
  textarea: TextareaComponent,
  fileupload: FileuploadComponent,
  tree: TreeComponent,
  date: DatepickerComponent,
  timepicker: TimePickerComponent,
  tabs: TabsComponent,
  movelist: MovelistToOtherComponent,
  iconbutton: IconbuttonComponent,
  chips: ChipsComponent,
  infoLabel: InfoLabelComponent,
  header: PageHeaderComponent,
  time: TimeComponent,
  selectnumber: SelectwithnumberComponent,
};
@Directive({
  selector: '[libDynamicField]'
})
export class DynamicFieldDirective implements OnInit {
  @Input() field: FieldConfig;
  @Input() group: FormGroup;
  @Input() payload: any;
  componentRef: any;
  constructor(private resolver: ComponentFactoryResolver, private container: ViewContainerRef) { }
  ngOnInit() {
    if (this.field != undefined) {
      const factory = this.resolver.resolveComponentFactory(componentMapper[this.field.type]);
      this.componentRef = this.container.createComponent(factory);
      this.componentRef.instance.field = this.field;
      this.componentRef.instance.group = this.group;
      this.componentRef.instance.payload = this.payload;
    }
  }
}
