import { BrowserModule} from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { MessageService, ConfirmationService } from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { BaseApiPathService } from './common/services/baseapi.service';
import { CacheInterceptor } from './common/services/CacheInterceptor';
import { BackButtonDisableModule } from 'angular-disable-browser-back-button';
import { TokenInterceptor } from './common/services/TokenInterceptor';

export const configFactory = (baseApiPathService: BaseApiPathService) => {
  return () => baseApiPathService.loadConfigPath();
};


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    CommonModule,
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    ConfirmDialogModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    BackButtonDisableModule.forRoot({
      preserveScrollPosition: true
    })
  ],
  providers: [ConfirmationService,MessageService,
    {
    provide: APP_INITIALIZER,
    useFactory: configFactory,
    deps: [BaseApiPathService],
    multi: true
    },
    BaseApiPathService,
    { provide: HTTP_INTERCEPTORS, useClass: CacheInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true }
  ],
  bootstrap: [AppComponent],
  exports: [FormsModule]
})
export class AppModule { }
