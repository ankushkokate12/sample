import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch, MustNotMatch } from '../../directives/match.validator';
import { LoginService } from '../../services/login.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  errorMsg: string = '';
  changePasswordObj = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  };
  currentUserloginData:any;

  constructor(private formBuilder: FormBuilder,
    private loginService: LoginService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private router: Router) { }

  ngOnInit() {
    this.getCurrentLoginData();
    this.loadForm();
  }

  getCurrentLoginData() {
    this.loginService.currentUserLoginData
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        this.currentUserloginData = response;
      });
  }

  loadForm() {
    this.changePasswordForm = this.formBuilder.group({
      oldPassword: [this.changePasswordObj.oldPassword, Validators.required],
      newPassword: [this.changePasswordObj.newPassword, [
        Validators.required,
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{9,}')]],
      confirmPassword: [this.changePasswordObj.confirmPassword,{validators:[Validators.required],updateOn:'blur'}]
    }, {
      validators: [MustMatch('newPassword', 'confirmPassword'),MustNotMatch('oldPassword','newPassword')],
      updateOn:'blur'
    })
  }

  get oPassword() { return this.changePasswordForm.get('oldPassword'); }
  get nPassword() { return this.changePasswordForm.get('newPassword'); }
  get cPassword() { return this.changePasswordForm.get('confirmPassword'); }

  onChangePassword() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to update password?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      key: 'changePasswordUserProfile',
      accept: () => {
        let userCredentials:any = {
          "OldPassword": this.oPassword.value,
          "NewPassword": this.cPassword.value
        }
        let currentUser:any = (JSON.parse(sessionStorage.getItem("loggedInUser")));
        this.loginService
          .changePasswordUserProfile(userCredentials,currentUser.access.token)
          .subscribe(
            response => {
              this.messageService.add({ key: 'messageToast', severity: 'success', summary: 'SUCCESS', detail: 'Password changed successfuly!!' });
              this.clearData();
            },
            error => {
              this.errorMsg = error.statusText;
              this.confirmationService.confirm({
                message:this.errorMsg,
                key: "changePasswordErrorDialog",
                accept: () => {},
                reject: () => {
                return;
                }
              });
            }
          )
      },
      reject: () => {
        return;
      }
    });
  }

  clearData() {
    this.changePasswordForm.clearValidators();
    this.changePasswordForm.reset();
  }
}