import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataCollectionHistoryComponent } from './data-collection-history.component';

describe('DataCollectionHistoryComponent', () => {
  let component: DataCollectionHistoryComponent;
  let fixture: ComponentFixture<DataCollectionHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataCollectionHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataCollectionHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
