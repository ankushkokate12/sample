import { Component, OnInit } from '@angular/core';
import { DataCollectionHistoryVo } from '../../vo/datacolleciton-interface';
import { DataCollectionService } from '../../services/datacollection.service';
import { ɵWebAnimationsStyleNormalizer } from '@angular/animations/browser';
import { ExportUtil, ExportFileType } from '../../utils/export-util';

@Component({
  selector: 'data-collection-history',
  templateUrl: './data-collection-history.component.html',
  styleUrls: ['./data-collection-history.component.css']
})
export class DataCollectionHistoryComponent implements OnInit {
  errorMsg: string = '';
  dataCollectionHistoryArr: Array<any> = [];
  planListArr: Array<any> = [];
  historyListArr: Array<any> = [];
  completedTaskArr: Array<any> = [];
  cols: any[];
  selectedPlan:any;

  dcHistory: any[];
  planTitle: any;

  constructor(private dataCollectionService: DataCollectionService) { }

  ngOnInit() {
    this.getDataCollectionHistory();

    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'startDate', header: 'Period Start Date' },
      { field: 'endDate', header: 'Period End Date' },
      { field: 'completedDate', header: 'Completed' }
    ];
  }

  getDataCollectionHistory() {
    this.dataCollectionService
      .getDataCollectionHistory()
      .subscribe((response: Array<any>) => {
        if((response != null ) && (response != undefined)){
          this.completedTaskArr = response;
          this.dataCollectionHistoryArr = response;
          //this.planListArr = this.getPlanList(response);
          this.selectedPlan = this.dataCollectionHistoryArr[0];
        }else{
          this.dataCollectionHistoryArr = [];
        }
      },
        error => {
          this.dataCollectionHistoryArr = [];
          this.errorMsg = error.statusText;
        }
      );
  }

  onPlanSelectionChange(plan:any){
    this.selectedPlan = plan;
  }

  getPlanList(response:any){
    const arr = response.map(function(obj) {
      return {planId: obj.planId, plan: obj.plan};
    });

    let filteredArr = Array.from(new Set(arr.map(a => a.planId)))
    .map(id => {
      return arr.find(a => a.planId === id)
    })

    let resultArr = [
      {
        "planId": "All",
        "plan":"All Plans",
        "roles": null,
        "completedTasks":[]
      }
    ];

    return (resultArr.concat(filteredArr));
  }

  exportDataCollectionHistory(data:any){
    this.dataCollectionService.completedTaskHistoryDownloadAsExcel(data.id)
      .subscribe(resultBlob => {
        ExportUtil.exportReportHandler(resultBlob, ExportFileType.EXCEL, data.name + '.xlsx');     
      });
  }
}
