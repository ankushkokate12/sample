import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcLandingComponent } from './dc-landing.component';

describe('DcLandingComponent', () => {
  let component: DcLandingComponent;
  let fixture: ComponentFixture<DcLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
