import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dc-landing',
  templateUrl: './dc-landing.component.html',
  styleUrls: ['./dc-landing.component.css']
})
export class DcLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
