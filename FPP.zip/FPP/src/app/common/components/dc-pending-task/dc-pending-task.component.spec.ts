import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcPendingTaskComponent } from './dc-pending-task.component';

describe('DcPendingTaskComponent', () => {
  let component: DcPendingTaskComponent;
  let fixture: ComponentFixture<DcPendingTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcPendingTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcPendingTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
