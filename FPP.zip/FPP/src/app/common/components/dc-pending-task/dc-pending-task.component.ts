import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { DataCollectionService } from '../../services/datacollection.service';
import { PendingTasksVo } from '../../vo/datacolleciton-interface';

@Component({
  selector: 'dc-pending-task',
  templateUrl: './dc-pending-task.component.html',
  styleUrls: ['./dc-pending-task.component.css']
})
export class DcPendingTaskComponent implements OnInit {
  errorMsg: string = '';
  pendingTasksArr: Array<PendingTasksVo> = [];


  @Input()
  isDashboard: boolean;

  constructor(
    private router: Router,
    private dataCollectionService: DataCollectionService) { }

  ngOnInit() {
    this.getPendingTasksData();
    // localStorage.removeItem("taskDetails");
  }

  getPendingTasksData() {
    this.dataCollectionService
      .getPendingTasks()
      .subscribe((response: PendingTasksVo[]) => {
        
        this.pendingTasksArr = response
        this.dataCollectionService.updatePendingTaskCount(this.pendingTasksArr.length);
      },
        error => {
          this.errorMsg = error.statusText;
        }
      );
  }

  onResumeClick(pendingTask:PendingTasksVo) {  
    // this.dataCollectionService.selectedPendingTask(pendingTask);
    // this.router.navigate(["/datacollection/datacollection-year-end"], {skipLocationChange: true})
    localStorage.setItem('taskDetails', JSON.stringify(pendingTask));
    this.router.navigate(["/home/datacollection/datacollection-year-end"])
  }
}
