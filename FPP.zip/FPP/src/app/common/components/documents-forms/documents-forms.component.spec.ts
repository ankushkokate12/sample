import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsFormsComponent } from './documents-forms.component';

describe('DocumentsFormsComponent', () => {
  let component: DocumentsFormsComponent;
  let fixture: ComponentFixture<DocumentsFormsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentsFormsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsFormsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
