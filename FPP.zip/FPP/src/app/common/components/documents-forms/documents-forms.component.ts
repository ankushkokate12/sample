import { Component, OnInit } from '@angular/core';
import { DocumentsAndFormsService } from '../../services/documentsandforms.service';

@Component({
  selector: 'app-documents-forms',
  templateUrl: './documents-forms.component.html',
  styleUrls: ['./documents-forms.component.css']
})
export class DocumentsFormsComponent implements OnInit {

  constructor(private documentsAndFormsService: DocumentsAndFormsService) { }

  ngOnInit() {
    this.documentsAndFormsService.getDocumentsAndFormsData();
  }
}
