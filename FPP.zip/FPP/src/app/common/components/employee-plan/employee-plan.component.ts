import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataCollectionService } from '../../services/datacollection.service';

@Component({
  selector: 'app-employee-plan',
  templateUrl: './employee-plan.component.html',
  styleUrls: ['./employee-plan.component.css']
})
export class EmployeePlanComponent implements OnInit {
  employerPlanArr:any = [];
  errorMsg:string = '';

  constructor(private router: Router,
    private dataCollectionService: DataCollectionService) { }

  ngOnInit() {
    this.getEmployerPlanData();
  }

  getEmployerPlanData() {
    this.dataCollectionService
      .getEmployerPlanData()
      .subscribe((response: any) => {
        this.employerPlanArr = response;
      },
        error => {
          this.errorMsg = error.statusText;
        }
      );
  }
}
