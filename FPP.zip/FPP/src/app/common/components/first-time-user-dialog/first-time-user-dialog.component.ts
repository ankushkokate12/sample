import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';

import { FormBuilder, Validators, FormGroup } from "@angular/forms";

@Component({
  selector: 'app-first-time-user-dialog',
  templateUrl: './first-time-user-dialog.component.html',
  styleUrls: ['./first-time-user-dialog.component.css', '../dialog.css']
})
export class FirstTimeUserDialogComponent implements OnInit {
  @Input() display: boolean;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  title: string = '';
  content: string = '';
  firstTimeUserForm: FormGroup;

  constructor(public fb: FormBuilder) { }
  ngOnInit() {
    this.title = 'FIRST TIME USER REGISTRATION';
    this.content = 'If this is your first time accessing our portal, please enter your email address below to have a temporary password sent to your email for initial access. If you receive any error, please contact us directly for portal setup assistance.';
    
    this.firstTimeUserForm = this.fb.group({
      emailAddress: ['', [Validators.required, Validators.email]],     
    });
  }

  get f() { return this.firstTimeUserForm.controls; }

  
  onHide() {
    this.firstTimeUserForm.reset();
    this.display = false;
    this.onClose.emit(this.display);
  }

  onSubmit(){
    
    this.firstTimeUserForm.markAllAsTouched();
    console.log(this.firstTimeUserForm.value);

    //ToDo:  Call api for first time user and then hide the dialog

    
    this.onHide();
  }

  
}