import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';

import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { LoginService } from '../../services/login.service';
import { spaceValidator } from '../../pipes/removeTextBoxSpaces';

@Component({
  selector: 'app-forgot-password-dialog',
  templateUrl: './forgot-password-dialog.component.html',
  styleUrls: ['./forgot-password-dialog.component.css', '../dialog.css']
})
export class ForgotPasswordDialogComponent implements OnInit {
  @Input() display: boolean;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  title: string = '';
  forgotPasswordForm: FormGroup;
  isSucess:boolean = false;

  constructor(private fb: FormBuilder, private loginService: LoginService) { }
  ngOnInit() {
    this.title = 'FORGOT PASSWORD';
    this.forgotPasswordForm = this.fb.group({
      emailAddress: ['', [Validators.required, Validators.email,Validators.pattern('^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$'),spaceValidator]],     
    });
  }

  get f() { return this.forgotPasswordForm.controls; }

  onHide() {
    this.forgotPasswordForm.reset();
    this.display = false;
    let data:any = {
      isDisplay: this.display,
      isSucess: this.isSucess
    }
    this.onClose.emit(data);
  }

  onSubmit(){
    this.forgotPasswordForm.markAllAsTouched();
    this.isSucess = false;
    this.loginService.forgotPassword(this.forgotPasswordForm.value.emailAddress).subscribe(data=>{
       this.isSucess = true;
       this.onHide();
    }, error => {
      this.isSucess = false;
      this.onHide();
    })
  }

}