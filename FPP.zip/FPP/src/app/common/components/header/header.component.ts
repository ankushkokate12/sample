import { Component, OnInit } from '@angular/core';
import { DataCollectionService } from '../../services/datacollection.service';
import { DataService } from '../../services/data.service';
import { UserProfileService } from '../../services/userprofile.service';
import { LoginService } from '../../services/login.service';
import {SecureCommunicationService} from '../../services/securecommunication.service'
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router'
import { PermissionUtil } from '../../utils/permission-util';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isShow: boolean = false;
  pendingTaskCount: number = 0;
  loggedInUserFirstName: string = '';
  loggedInUserEmployeer: any;
  contextHelpMap: any = [];
  unreadMessageCount:any;
  errorMsg:string = '';
  permissionObj:any = {};

  constructor(private dataCollectionService: DataCollectionService, private loginService: LoginService,
    private secureCommunicationService: SecureCommunicationService, private userProfileService: UserProfileService,
    private router: Router) { }

  ngOnInit() {
    if(!PermissionUtil.isPermissionSet()){
      PermissionUtil.setPermission(JSON.parse(sessionStorage.getItem("permissionRights")));
    }

    this.permissionObj = PermissionUtil.getPermission();

    this.contextHelpMap = [
      { key: '/', path: '' },
      { key: 'profile', path: '#Updating_User_Profile.htm' },
      { key: 'dashboard', path: '#Viewing_Dashboard.htm' },
      { key: 'datacollection-landing', path: '#Collecting_Year_End_Data.htm' },
      { key: 'inbox', path: '#Managing_Secure_Messages.htm' },
      { key: 'sent-items', path: '#Managing_Secure_Messages.htm' },
      { key: 'loans-and-distribution', path: '#Viewing_loans_and_distributions_Records.htm' },
      { key: 'docs-and-forms', path: '#Downloading_Documents_and_Forms.htm' },
    ];
    this.dataCollectionService.currentPendingTaskCount.subscribe(count => this.pendingTaskCount = count)
    this.userProfileService.currentUser.subscribe(user => this.loggedInUserFirstName = user)
    this.getUser();
    this.getUnreadMessageCount();
    this.getPendingTasksData();

    this.secureCommunicationService.unreadMessageCount.subscribe(data => {
      this.unreadMessageCount = data;
    })
  }

  getUnreadMessageCount(){
    this.secureCommunicationService.getSecureMessageCount().subscribe(data => {
      if (data){
        this.secureCommunicationService.notifyUnreadMessageCount(data.unReadMessageCount);        
      }      
    })
  }

  getPendingTasksData() {
    this.dataCollectionService
      .getPendingTasks()
      .subscribe((response: any) => {
        if((response != undefined) && (response != null)){
          this.dataCollectionService.updatePendingTaskCount(response.length);
        }else{
          this.dataCollectionService.updatePendingTaskCount(response.length);
        }
      },
        error => {
          this.errorMsg = error.error.detail;
        }
      );
  }

  getUser() {
    this.userProfileService.getLoggedInUser().subscribe((user: any) => {
      this.loggedInUserFirstName = user.firstName;
      this.loggedInUserEmployeer = user.employerName;
      this.userProfileService.updateLoggedInUser(this.loggedInUserFirstName);
    });
  }

  toggleUserOptions() {
    this.isShow = !this.isShow;
  }

  logout() {
    this.loginService.logout();
  }

  onHelpClick($event: Event) {
    let key = this.router.url.substring(this.router.url.lastIndexOf('/') + 1);
    let currentPath: any = this.contextHelpMap.filter(obj => { return obj.key === key });
    
    if(currentPath.length > 0){
      currentPath = currentPath[0].path;
    }else{
      currentPath = '';
    }
    
    window.open('../../../../assets/webhelpcontent/FuturePlan_Client_Portal_User_Help.htm' + currentPath, '_blank');
  }
};
