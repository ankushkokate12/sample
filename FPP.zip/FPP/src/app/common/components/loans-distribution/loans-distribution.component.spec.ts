import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoansDistributionComponent } from './loans-distribution.component';

describe('LoansDistributionComponent', () => {
  let component: LoansDistributionComponent;
  let fixture: ComponentFixture<LoansDistributionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoansDistributionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoansDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
