import { Component, OnInit, Input } from "@angular/core";
import { LoansAndDistributionService } from "../../services/loansanddistribution.service";
import {
  LoansAndDistributionVo,
  LoanStatusVo,
  DistributionTypeVo
} from "../../vo/loans-and-distribution-interface";
import { OverlayPanel } from "primeng/overlaypanel/public_api";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from "@angular/forms";
import { DataService } from "../../services/data.service";
import { Observable } from "rxjs";
import { SecureCommunicationService } from "../../services/securecommunication.service";
import { DateFormatUtility } from "../../utils/dateFormat-utility";
import * as XLSX from "xlsx";
import { formatDate } from "@angular/common";

const currentDate = new Date();
const pastDate = new Date();
const pastYear = pastDate.getFullYear() - 1;
pastDate.setFullYear(pastYear);

@Component({
  selector: "app-loans-distribution",
  templateUrl: "./loans-distribution.component.html",
  styleUrls: ["./loans-distribution.component.css"]
})
export class LoansDistributionComponent implements OnInit {
  loanList: any = [];
  exportForm: FormGroup;
  errorMsg: string = "";
  cols: any = [];
  plans: any = [];
  plans$: Observable<any>;
  loanStatus: any = [];
  distributionTypeArr: any = [];
  calendarForm: FormGroup;
  isAdditionalFilter: boolean = false;
  filterObj: any = {
    planId: null,
    employerSSN: "",
    employerFullName: "",
    status: "",
    distributionType: "",
    initiatedFrom: null,
    initiatedTo: null
  };

  @Input()
  isDashboard: boolean;
  filterApplied: any;

  todayDate = new Date();

  constructor(
    private loansAndDistributionService: LoansAndDistributionService,
    private secureCommunicationService: SecureCommunicationService,
    private dataService: DataService,
    private formBuilder: FormBuilder
  ) {}
  showLoadingIndicator: boolean;

  ngOnInit() {
    this.setDefaultSearchDate();
    this.getLoanMasterData();
    this.getLoansAndDistributionData(this.filterObj);

    this.cols = [
      { field: "employerFullName", header: "Employee Name" },
      { field: "status_Description", header: "Status" },
      { field: "planName", header: "Plan Name" },
      { field: "employerSSN", header: "Employee SSN" },
      { field: "distributionType_Description", header: "Distribution Type" },
      { field: "createdDate", header: "Date Initiated" },
      { field: "completionDate", header: "Date Completed" }
    ];
  }

  // convenience getter for easy access to form fields
  get startDate() {
    return this.calendarForm.get("startDate");
  }
  get endDate() {
    return this.calendarForm.get("endDate");
  }

  setDefaultSearchDate() {
    if (!this.calendarForm) {
      this.calendarForm = this.formBuilder.group({
        startDate: new FormControl(pastDate, [Validators.required]),
        endDate: new FormControl(currentDate, [Validators.required])
      });
    } else {
      this.calendarForm.patchValue({
        startDate: pastDate,
        endDate: currentDate
      });
    }
    this.filterObj["initiatedFrom"] = new Date(
      this.calendarForm.get("startDate").value
    );
    this.filterObj["initiatedTo"] = new Date(
      this.calendarForm.get("endDate").value
    );
  }

  getLoanMasterData() {    
    this.loansAndDistributionService.getLoanMasterData().subscribe(      
      (response: any) => {        
        this.plans = response.planList;
        this.distributionTypeArr = response.distributionTypeList;
        this.loanStatus = response.distributionStatusList;
      },
      error => {
        this.loanStatus = [];
        this.plans = [];
        this.distributionTypeArr = [];
        this.errorMsg = error.statusText;
      }
    );
  }

  getLoansAndDistributionData(filterObj) {
    this.showLoadingIndicator = true;
    this.loansAndDistributionService
      .getLoansAndDistributionData(filterObj)
      .subscribe(
        (response: Array<LoansAndDistributionVo>) => {          
          this.filterApplied = this.isFilterApplied(filterObj);

          if (
            this.isDashboard != undefined &&
            this.isDashboard.toString() == "true"
          ) {
            this.loanList = response.filter(
              obj =>
                obj.status_val != "New" &&
                obj.status_val != "ResolvedCancelled" &&
                obj.status_val != "ResolvedCompleted"
            );
          } else {
            this.loanList = response;
          }
          this.showLoadingIndicator = false;
        },
        error => {
          this.showLoadingIndicator = false;
          this.loanList = [];
          this.errorMsg = error.statusText;
        }
      );
  }

  getLoanStatus() {
    this.showLoadingIndicator = true;
    this.loansAndDistributionService.getLoanStatus().subscribe(
      (response: Array<LoanStatusVo>) => {        
        this.loanStatus = response;
        this.showLoadingIndicator = false;
      },
      error => {
        this.showLoadingIndicator = false;
        this.loanStatus = [];
        this.errorMsg = error.statusText;
      }
    );
  }

  getDistributionType() {
    this.showLoadingIndicator = true;
    this.loansAndDistributionService.getDistributionType().subscribe(
      (response: Array<DistributionTypeVo>) => {        
        this.distributionTypeArr = response;
        this.showLoadingIndicator = false;
      },
      error => {
        this.showLoadingIndicator = false;
        this.distributionTypeArr = [];
        this.errorMsg = error.statusText;
      }
    );
  }
  startDateApply(fromDate) {
    this.calendarForm.get("startDate").setValue(fromDate);
  }
  endDateApply(toDate) {
    this.calendarForm.get("endDate").setValue(toDate);
  }

  applyDateFilter(op: OverlayPanel) {
    if (
      this.calendarForm.get("startDate").value !== "" &&
      this.calendarForm.get("endDate").value !== ""
    ) {
      this.filterObj.initiatedFrom = new Date(
        this.calendarForm.get("startDate").value
      );
      this.filterObj.initiatedTo = new Date(
        this.calendarForm.get("endDate").value
      );
    }
    op.hide();
  }

  closeDateFilter() {
    if (
      Date.UTC(
        this.filterObj["initiatedFrom"].getFullYear(),
        this.filterObj["initiatedFrom"].getMonth(),
        this.filterObj["initiatedFrom"].getDate()
      ) !=
        Date.UTC(
          this.startDate.value.getFullYear(),
          this.startDate.value.getMonth(),
          this.startDate.value.getDate()
        ) ||
      Date.UTC(
        this.filterObj["initiatedTo"].getFullYear(),
        this.filterObj["initiatedTo"].getMonth(),
        this.filterObj["initiatedTo"].getDate()
      ) !=
        Date.UTC(
          this.endDate.value.getFullYear(),
          this.endDate.value.getMonth(),
          this.endDate.value.getDate()
        )
    ) {
      this.setDefaultSearchDate();
    }
  }

  clearDateFilter(op: OverlayPanel) {
    this.setDefaultSearchDate();
    op.hide();
  }

  isFilterApplied(search) {
    return (
      search &&
      (search.employerFullName.length > 0 ||
        search.status.length > 0 ||
        Math.floor(
          (Date.UTC(
            search["initiatedFrom"].getFullYear(),
            search["initiatedFrom"].getMonth(),
            search["initiatedFrom"].getDate()
          ) -
            Date.UTC(
              pastDate.getFullYear(),
              pastDate.getMonth(),
              pastDate.getDate()
            )) /
            (1000 * 60 * 60 * 24)
        ) !== 0 ||
        Math.floor(
          (Date.UTC(
            search["initiatedTo"].getFullYear(),
            search["initiatedTo"].getMonth(),
            search["initiatedTo"].getDate()
          ) -
            Date.UTC(
              currentDate.getFullYear(),
              currentDate.getMonth(),
              currentDate.getDate()
            )) /
            (1000 * 60 * 60 * 24)
        ) !== 0 ||
        search.planId ||
        search.employerSSN.length > 0 ||
        search.distributionType.length > 0)
    );
  }

  clearFilter() {
    this.calendarForm.reset();

    this.filterObj = {
      planId: null,
      employerSSN: "",
      employerFullName: "",
      status: "",
      distributionType: ""
    };
    this.setDefaultSearchDate();
    this.getLoansAndDistributionData(this.filterObj);
  }

  applyFilter() {
    if (this.filterObj.planId != null) {
      this.filterObj.planId = Number(this.filterObj.planId);
    }

    this.getLoansAndDistributionData(this.filterObj);
  }

  showOverlay(event, data, op: OverlayPanel) {
    op.toggle(event);
  }

  additinalFilters() {
    if (this.isAdditionalFilter === false) {
      this.isAdditionalFilter = true;
    } else {
      this.isAdditionalFilter = false;
    }
  }

  ondownloadXLS() {
    let xlsArr = JSON.parse(JSON.stringify(this.loanList));

    xlsArr.forEach(x => {
      if (x.createdDate != null && x.createdDate != "") {
        x.createdDate = formatDate(x.createdDate, "MM/dd/yyyy", "en-US");
      }
      if (x.completionDate != null && x.completionDate != "") {
        x.completionDate = formatDate(x.completionDate, "MM/dd/yyyy", "en-US");
      }
    });

    this.exportsAsExcel(xlsArr);
  }

  exportsAsExcel(loanListArr: any) {
    let ExcelHeading = [
      [
        "Employee Name",
        "Status",
        "Plan Name",
        "Employee SSN",
        "Distribution Type",
        "Date Initiated",
        "Date Completed"
      ]
    ];

    let exportArray = JSON.parse(JSON.stringify(loanListArr));

    exportArray.map(function(item) {
      delete item.employerFirstName;
      delete item.employerLastName;
      delete item.status_val;
      delete item.distributionType_val;
      delete item.initiatedFrom;
      delete item.initiatedTo;

      return item;
    });

    const workBook = XLSX.utils.book_new(); // Create a new blank book
    let ws = XLSX.utils.aoa_to_sheet(ExcelHeading); // Add custom heading
    let workSheet = XLSX.utils.sheet_add_json(ws, exportArray, {
      skipHeader: true,
      origin: "A2"
    });

    XLSX.utils.book_append_sheet(workBook, workSheet, "Loans And Distribution"); // Add the worksheet to the book
    XLSX.writeFile(
      workBook,
      "Loans_Distribution_" + new Date().toLocaleDateString() + ".xlsx"
    ); // Initiate a file download in browser
  }
}
