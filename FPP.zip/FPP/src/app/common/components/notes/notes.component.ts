import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChange, SimpleChanges, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataCollectionService } from '../../services/datacollection.service';
import { NoteVo, SectionsNotesData } from '../../vo/datacolleciton-interface';
import { ConfirmationService, MessageService } from "primeng/api";
import { Utility } from "../../utils/utility";
import { spaceValidator } from '../../pipes/removeTextBoxSpaces';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit, OnChanges {
  notesForm: FormGroup;
  @ViewChild('notesTable', { static: false }) noteTable;
  @Input() sectionId: string;
  @Input() display: boolean;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  notesList: Array<any> = [];
  Notes: Array<any> = [];
  cols: Array<any> = [];
  isEditable: boolean;
  isEditNote: boolean;
  selectedNote: any;
  errorMsg: string = '';
  taskDetils:any = JSON.parse(localStorage.getItem("taskDetails"));

  constructor(private formBuilder: FormBuilder,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private dataCollectionService: DataCollectionService) {
    this.notesForm = this.formBuilder.group({
      notes: ['', [Validators.required, spaceValidator]]
    });
  }

  ngOnInit() {
    this.cols = [
      { field: 'note', header: 'Note' },
      { field: 'createdOn', header: 'Date' },
      { field: 'createdByfullName', header: 'Created By' }
    ];
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.display){
      if((this.sectionId !=  undefined) && (this.sectionId != null)){
        this.getNoteData();
      }else{
        this.notesList = [];
      }
    }
  }

  get note() { return this.notesForm.get('notes'); }

  getNoteData() {
    let taskId:any = JSON.parse(localStorage.getItem("taskDetails")).taskId;
    this.dataCollectionService
      .getDataCollectionNoteData(taskId,this.sectionId)
      .subscribe((response: Array<any>) => {
        if((response != undefined) && (response != null)){
          if(response.length > 0){
            this.notesList = response;
          }else{
            this.notesList = [];
          }
        }else{
          this.notesList = [];
        }
      },
        error => {
          this.notesList = [];
          this.errorMsg = error.statusText;
        }
      );
  }

  setFormData() {
    this.notesForm.get('notes').setValue(this.selectedNote.note);
  }

  onHide() {
    this.notesForm.reset();
    this.display = false;
    this.onClose.emit(this.display);
    this.isEditable = false;
  }

  addNewNotes() {
    this.notesForm.reset();
    this.isEditable = true;
    this.isEditNote = false;
  }

  editNotes(selectedNotes) {
    this.selectedNote = selectedNotes;
    this.isEditable = true;
    this.isEditNote = true;
    this.setFormData();
  }
  onCancelEditable() {
    this.notesForm.reset();
    this.isEditable = false;
  }

  deleteNotes(selectedNotes) {
    // this.dataCollectionService.deleteNotesData(selectedNotes.id)
    // .subscribe(
    //   response => {
    //     this.getNoteData();
    //     this.dataCollectionService.completionTick(this.sectionId)
    //   },
    //   error => {
    //     this.errorMsg = Utility.showErrMsg(error);
    //     this.messageService.add({
    //       key: "toaster-massege",
    //       severity: "error",
    //       summary: "ERROR",
    //       detail: error.error.detail
    //     });
    //   }
    // );

    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "notesConfirmDialog",
      accept: () => {
        this.dataCollectionService.deleteNotesData(selectedNotes.id)
        .subscribe(
          response => {
            this.getNoteData();
            this.dataCollectionService.completionTick(this.sectionId)
          },
          error => {
            this.errorMsg = Utility.showErrMsg(error);
            this.messageService.add({
              key: "toaster-massege",
              severity: "error",
              summary: "ERROR",
              detail: error.error.detail
            });
          }
        );
    
      },
      reject: () => {
        return;
      }
    });
  }

  onSubmit() {
    if (this.isEditNote) {
      this.selectedNote.note = this.note.value;
      this.dataCollectionService.updateNotesData(this.isEditNote, this.selectedNote).subscribe(
        response => {
          this.getNoteData();
          this.onCancelEditable();
          this.dataCollectionService.completionTick(this.sectionId)
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'noteToast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
    }
    else {
      const noteObj: any = {
        dcTaskId: JSON.parse(localStorage.getItem("taskDetails")).taskId,
        note: this.note.value,
        portalSubSectionCode: this.sectionId
      };

      this.dataCollectionService.updateNotesData(this.isEditNote, noteObj).subscribe(
        response => {
          this.getNoteData();
          this.onCancelEditable();
          this.dataCollectionService.completionTick(this.sectionId)
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'noteToast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
    }
  }
}

