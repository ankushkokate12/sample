import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanSpecificComponent } from './plan-specific.component';

describe('PlanSpecificComponent', () => {
  let component: PlanSpecificComponent;
  let fixture: ComponentFixture<PlanSpecificComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanSpecificComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanSpecificComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
