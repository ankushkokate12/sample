import { Component, OnInit } from '@angular/core';
import { DocumentsAndFormsService } from '../../services/documentsandforms.service';
import { PlanSpecificDocumentVo } from '../../vo/documentsandforms-interface';
import { ExportUtil, ExportFileType } from '../../utils/export-util';
import { MessageService } from 'primeng/api';
import { Utility } from '../../utils/utility';

@Component({
  selector: 'app-plan-specific',
  templateUrl: './plan-specific.component.html',
  styleUrls: ['./plan-specific.component.css']
})
export class PlanSpecificComponent implements OnInit {
  planSpecificDocumentList: any = [];
  errorMsg: string = '';
  cols: any = [];
  constructor(private documentsAndFormsService: DocumentsAndFormsService,
    private messageService: MessageService) { }

  ngOnInit() {
    this.getPlanSpecificData();

    this.cols = [
      { field: 'fileName', header: 'File Name' },
      { field: 'planName', header: 'Plan Name' },
      { field: 'category', header: 'Category' }
    ];
  }

  getPlanSpecificData() {
    this.documentsAndFormsService.documentsAndFormsData
    .subscribe((response: any) => {
      this.planSpecificDocumentList = response.planSpecificDocuments;
    }, error => {
      this.planSpecificDocumentList = [];
      this.errorMsg = Utility.showErrMsg(error);
      this.messageService.add({ key: 'planSpecificErr', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
    }
    );
  }

  exportPlanSpecificDocument(data: any) {
    //delete data.planName;
    //delete data.category;

    this.documentsAndFormsService.downloadAsExcel(data)
      .subscribe(blobData => {
        let downloadUrl;
        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
          //msSaveBlob only available for IE & Edge
          downloadUrl = window.navigator.msSaveBlob(blobData, data.fileName);
        }else{
          downloadUrl = window.URL.createObjectURL(blobData);
        }        
        let link = document.createElement('a');
        link.href = downloadUrl;
        link.download = data.fileName;
        link.click();        
      });
  }
}
