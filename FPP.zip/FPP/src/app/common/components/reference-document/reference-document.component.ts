import { Component, OnInit } from '@angular/core';
import { DocumentsAndFormsService } from '../../services/documentsandforms.service';
import { ReferenceDocumentVo } from '../../vo/documentsandforms-interface';
import { ExportUtil } from '../../utils/export-util';
import { MessageService } from 'primeng/api';
import { Utility } from '../../utils/utility';

@Component({
  selector: 'app-reference-document',
  templateUrl: './reference-document.component.html',
  styleUrls: ['./reference-document.component.css']
})
export class ReferenceDocumentComponent implements OnInit {
  referenceDocumentsList:Array<ReferenceDocumentVo>= [];
  cols: any[];
  errorMsg:string = '';
  constructor(
    private documentsAndFormsService:DocumentsAndFormsService,
    private messageService: MessageService) {}

  ngOnInit() {
    this.cols = [
      { field: 'fileName', header: '' }
    ];

    this.getReferenceDocumentsData();
  }

  getReferenceDocumentsData() {
    this.documentsAndFormsService.documentsAndFormsData
    .subscribe((response: any) => {
      this.referenceDocumentsList = response.referenceDocuments;
    }, error => {
      this.referenceDocumentsList = [];
      this.errorMsg = Utility.showErrMsg(error);
      this.messageService.add({ key: 'planSpecificErr', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
    }
    );
  }

  exportReferenceDocument(data: any) {
    this.documentsAndFormsService.downloadAsExcel(data)
      .subscribe(blobData => {
        let downloadUrl;
        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
          //msSaveBlob only available for IE & Edge
          downloadUrl = window.navigator.msSaveBlob(blobData, data.fileName);
        }else{
          downloadUrl = window.URL.createObjectURL(blobData);
        }        
        let link = document.createElement('a');
        link.href = downloadUrl;
        link.download = data.fileName;
        link.click();        
      });
  }
}
