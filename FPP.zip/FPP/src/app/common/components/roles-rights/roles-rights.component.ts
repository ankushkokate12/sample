import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { CompanyData } from '../../vo/userprofile-interface';

@Component({
  selector: 'app-roles-rights',
  templateUrl: './roles-rights.component.html',
  styleUrls: ['./roles-rights.component.css']
})
export class RolesRightsComponent implements OnInit, OnChanges {
  colsRolesRights: any[];
  @Input() rolesList: any[] = [];
  overlayData: any;
  comapanyName: any;
  planName: any;
  rolesName: any;
  rightsName: any;

  constructor() { }

  ngOnInit() {
    this.colsRolesRights = [
      { field: 'plans', header: 'Plan Name' },
      { field: 'companyName', header: 'Company Name' }
    ];
  }

  rolesRigths: any;
  totalCompany = [];
  totalPlans = [];
  totalRole = [];
  totalRights = [];
  ngOnChanges(changes: SimpleChanges) {
    if ((changes.rolesList.currentValue != null) && (changes.rolesList.currentValue != undefined)) {
      this.rolesList = changes.rolesList.currentValue;

      this.planName = "";
      for (let i = 0; i < this.rolesList[0].companies.length; i++) {
        let listCompanies = this.rolesList[0].companies[i]
        this.comapanyName = listCompanies.companyName;
        for (let j = 0; j < listCompanies.plans.length; j++) {
          let listPlans = listCompanies.plans[j];
          this.planName = listPlans.planName;
          this.totalRole = [];
          this.totalRights = [];
          for (let k = 0; k < listPlans.roles.length; k++) {
            let listRoles = listPlans.roles[k];
            this.rolesName = listRoles.roleDescription;
            this.totalRole.push(this.rolesName)
            for (let l = 0; l < listRoles.rolePermissions.length; l++) {
              let listRights = listRoles.rolePermissions[l];
              this.rightsName = listRights.permissionDescription;
              this.totalRights.push(this.rightsName)
              if (listRoles.rolePermissions.length - 1 == l && listPlans.roles.length - 1 == k) {
                let obj = {
                  "companyName": this.comapanyName,
                  "plans": this.planName,
                  "roles": this.squash(this.totalRole),
                  "rights": this.squash(this.totalRights)
                }
                this.totalCompany.push(obj)
              }

            }
          }
        }
      }
    }
    else {
      this.rolesList = [];
    }
  }

  squash(arr) {
    var tmp = [];
    for (var i = 0; i < arr.length; i++) {
      if (tmp.indexOf(arr[i]) == -1) {
        tmp.push(arr[i]);
      }
    }
    return tmp;
  }


  showOverlay(event, data, op: OverlayPanel) {
    this.overlayData = data;
    op.toggle(event);
  }
}
