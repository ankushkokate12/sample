import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserProfileService } from '../../services/userprofile.service';
import { UserProfileVo } from '../../vo/userprofile-interface';
import { Location } from '@angular/common';
import { ConfirmationService, MessageService } from 'primeng/api';
import { DataService } from '../../services/data.service';
import { Utility } from '../../utils/utility';
import { spaceValidator } from '../../pipes/removeTextBoxSpaces';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit, OnChanges {
  userDetailForm: FormGroup;
  userprofileVo: UserProfileVo;
  errorMsg: string = '';
  LoggedInUserId: string = "1";
  prefixList: Array<any> = [];
  stateList: Array<any> = [];
  countryCodeList: Array<any> = [];
  rolesAndRights: any;
  isAddressDisabled:boolean = true;

  constructor(private formBuilder: FormBuilder,
    private _router: Router,
    private userProfileService: UserProfileService,
    private location: Location,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private dataService: DataService) { }

  ngOnInit() {
    // this.prefixList = this.dataService.prefixList();
    //this.stateList = this.dataService.getStateList();
    this.isAddressDisabled=true;
    this.getPrefix();
    this.getSatetCountry();
    this.initializeData();    
    this.loadForm();
  }

  ngOnChanges(changes: SimpleChanges) {
    // this.userprofileVo = changes.userprofileVo.currentValue;
  }
 
  getUserProfileData() {
    this.userProfileService
      .getUserProfileData()
      .subscribe((response: UserProfileVo) => {
        if((response != undefined) && (response != null)){
          this.userprofileVo = response;
          this.rolesAndRights = response.rolesAndPermissions;

          if(
            ((this.userprofileVo.address1 != undefined) && (this.userprofileVo.address1 != '')) ||
            ((this.userprofileVo.address2 != undefined) && (this.userprofileVo.address2 != '')) ||
            ((this.userprofileVo.city != undefined) && (this.userprofileVo.city != '')) ||
            ((this.userprofileVo.state != undefined) && (this.userprofileVo.state != '')) ||
            ((this.userprofileVo.zip != undefined) && (this.userprofileVo.zip != ''))){
              this.isAddressDisabled = false;
            }else{
              this.isAddressDisabled = true;
            }
  
          this.onAddressDisabed();
          this.updateValues(this.userprofileVo);
        }
      },
        error => {
          this.errorMsg = Utility.showErrMsg(error);;
          this.messageService.add({ key: 'userToast', severity: 'error', summary: 'ERROR', detail: error.statusText });
        }
      );
  }

  getSatetCountry() {
    this.dataService
      .getStateCountryCodeData()
      .subscribe((response:any) => {
        this.stateList = response.states;
        this.countryCodeList = response.countries;
      });
  }

  getPrefix() {
    this.dataService
      .getPrefixData()
      .subscribe((response:any) => {
        this.prefixList = response;
      });
  }

  updateValues(dataObject: any) {
    this.userDetailForm.patchValue({
      prefixCode: dataObject.prefixCode,
      firstName: dataObject.firstName,
      lastName: dataObject.lastName,
      suffix: dataObject.suffix,
      email: dataObject.email,
      title: dataObject.title,
      address1: dataObject.address1,
      address2: dataObject.address2,
      city: dataObject.city,
      state: dataObject.state,
      zip: dataObject.zip,
      officePhone: dataObject.officePhone,
      isdOffice: dataObject.isdOffice!=null ? dataObject.isdOffice : "1",
      extension: dataObject.extension,
      fax: dataObject.fax,
      mobile: dataObject.mobile,
      isdMobile: dataObject.isdMobile!=null ? dataObject.isdMobile : "1"
    });
  }

  loadForm() {
    this.userDetailForm = this.formBuilder.group({
      prefixCode: [this.userprofileVo.prefixCode],
      firstName: [this.userprofileVo.firstName, [Validators.required, spaceValidator]],
      lastName: [this.userprofileVo.lastName],
      suffix: [this.userprofileVo.suffix],
      email: [this.userprofileVo.email, [Validators.required, spaceValidator, Validators.pattern('^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$')]],
      title: [this.userprofileVo.title],
      address1: [{value: this.userprofileVo.address1, disabled: false}],
      address2: [{value: this.userprofileVo.address2, disabled: false}],
      state: [{value: this.userprofileVo.state, disabled: false}, [Validators.required]],
      city: [{value: this.userprofileVo.city, disabled: false}],
      zip: [{value: this.userprofileVo.zip, disabled: false}, [Validators.required, Validators.pattern('^\[0-9]{5}(?:[-\s]?[0-9]{4})?$')]],
      officePhone: [this.userprofileVo.officePhone, [Validators.pattern('[0-9]{3}[-]*[0-9]{3}[-]*[0-9]{4}')]],
      isdOffice: [this.userprofileVo.isdOffice],
      extension: [this.userprofileVo.extension],
      fax: [this.userprofileVo.fax, [Validators.pattern('[0-9]{3}[-]*[0-9]{3}[-]*[0-9]{4}')]],
      mobile: [this.userprofileVo.mobile, [spaceValidator, Validators.pattern('[0-9]{3}[-]*[0-9]{3}[-]*[0-9]{4}')]],
      isdMobile: [this.userprofileVo.isdMobile],
    });

    this.getUserProfileData();
  }

  // convenience getter for easy access to form fields
  get prefixCode() { return this.userDetailForm.get('prefixCode'); }
  get firstName() { return this.userDetailForm.get('firstName'); }
  get lastName() { return this.userDetailForm.get('lastName'); }
  get suffix() { return this.userDetailForm.get('suffix'); }
  get emailAddress() { return this.userDetailForm.get('email'); }
  get title() { return this.userDetailForm.get('title'); }
  get address1() { return this.userDetailForm.get('address1'); }
  get state() { return this.userDetailForm.get('state'); }
  get city() { return this.userDetailForm.get('city'); }
  get zip() { return this.userDetailForm.get('zip'); }
  get officePhone() { return this.userDetailForm.get('officePhone'); }
  get isdOffice() { return this.userDetailForm.get('isdOffice'); }
  get extension() { return this.userDetailForm.get('extension'); }
  get mobile() { return this.userDetailForm.get('mobile'); }
  get isdMobile() { return this.userDetailForm.get('isdMobile'); }
  get fax() { return this.userDetailForm.get('fax'); }

  onSubmit() {
    let userData:UserProfileVo = this.userDetailForm.value;
    userData.officePhone = Utility.removeMasking(this.userDetailForm.value.officePhone);
    userData.fax = Utility.removeMasking(this.userDetailForm.value.fax);
    userData.mobile = Utility.removeMasking(this.userDetailForm.value.mobile);
    userData.zip = Utility.removeMasking(this.userDetailForm.value.zip);
    userData.extension = (this.userDetailForm.value.extension == "" || this.userDetailForm.value.extension== null) ? null : +this.userDetailForm.value.extension
    userData.isAddressDisabled = (this.isAddressDisabled ? true  : false);
    if(this.isAddressDisabled){
      userData.address1 = "";
      userData.address2 = "";
      userData.state = "";
      userData.city = "";
      userData.zip = "";
    }

    this.userProfileService
      .updateUserProfileData(userData)
      .subscribe(
        response => {
          this.userProfileService.updateLoggedInUser(this.firstName.value);
          this.messageService.add({ key: 'userToast', severity: 'success', summary: 'SUCCESS', detail: 'User detail is updated successfully' });
        },
        error => {
          this.messageService.add({ key: 'userToast', severity: 'error', summary: 'ERROR',sticky:true, detail: error.error.detail});
        }
      )
  }

  onCancel() {
    this.location.back();
  }

  onAddressDisabed(){
    if(this.isAddressDisabled){
      this.userDetailForm.controls["address1"].setValue("");
      this.userDetailForm.controls["address2"].setValue("");
      this.userDetailForm.controls["city"].setValue("");
      this.userDetailForm.controls["state"].setValue("");
      this.userDetailForm.controls["zip"].setValue("");

      this.userDetailForm.get('address1').clearValidators();
      this.userDetailForm.get('address2').clearValidators();
      this.userDetailForm.get('city').clearValidators();
      this.userDetailForm.get('state').clearValidators();
      this.userDetailForm.get('zip').clearValidators();

      this.userDetailForm.get('address1').updateValueAndValidity(); 
      this.userDetailForm.get('address2').updateValueAndValidity(); 
      this.userDetailForm.get('city').updateValueAndValidity(); 
      this.userDetailForm.get('state').updateValueAndValidity(); 
      this.userDetailForm.get('zip').updateValueAndValidity(); 
    }else{
     // this.userDetailForm.controls['address1'].setValidators([Validators.required]);
    //  this.userDetailForm.controls['address2'].setValidators([Validators.required]);
    //  this.userDetailForm.controls['city'].setValidators([Validators.required]);
      this.userDetailForm.controls['state'].setValidators([Validators.required]);
      this.userDetailForm.controls['zip'].setValidators([Validators.required, Validators.pattern('^\[0-9]{5}(?:[-\s]?[0-9]{4})?$')]);
      this.userDetailForm.get('state').updateValueAndValidity(); 
      this.userDetailForm.get('zip').updateValueAndValidity(); 
    }
  }

  initializeData() {
    this.userprofileVo = {
      "userId": "",
      "prefixCode": "",
      "firstName": "",
      "lastName": "",
      "suffix": "",
      "email": "",
      "title": "",
      "company": "",
      "address1": "",
      "address2": "",
      "city": "",
      "state": "",
      "zip": "",
      "officePhone": "",
      "isdOffice": "",
      "extension": null,
      "fax": "",
      "mobile": "",
      "isdMobile": "",
      "isAddressDisabled": false,
      "rolesAndPermissions": [
        {
          "userId": null,
          "userName": "",
          "companies": [            
            {
              "companyId": null,              
              "companyName": "",
              "plans": [
                {
                  "planId": null,
                  "planName": "",
                  "roles": [
                    {
                      "roleCode": "",
                      "roleDescription": "",
                      "rolePermissions": [
                        {
                          "permissionID": null,
                          "permissionCode": "",
                          "permissionDescription": ""
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    };
  }
}
