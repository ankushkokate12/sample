import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WarningDialogUnsavedDataComponent } from './warning-dialog-unsaved-data.component';

describe('WarningDialogUnsavedDataComponent', () => {
  let component: WarningDialogUnsavedDataComponent;
  let fixture: ComponentFixture<WarningDialogUnsavedDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WarningDialogUnsavedDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WarningDialogUnsavedDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
