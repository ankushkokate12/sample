import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warning-dialog-unsaved-data',
  templateUrl: './warning-dialog-unsaved-data.component.html',
  styleUrls: ['./warning-dialog-unsaved-data.component.css']
})
export class WarningDialogUnsavedDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
