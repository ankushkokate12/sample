import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { DataCollectionService } from '../../../services/datacollection.service';
import { Utility } from '../../../utils/utility';
import { DateFormatUtility } from '../../../utils/dateFormat-utility';
import { MessageService } from 'primeng/api';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'address-popup',
  templateUrl: './address-popup.component.html',
  styleUrls: ['./address-popup.component.css']
})
export class AddressPopupComponent implements OnInit, OnChanges {
  employerCompanyAddressForm: FormGroup;
  addressTypeList: Array<any> = [];
  stateList: Array<any> = [];
  errorMsg: string = '';
  isSucess: boolean = false;

  @Input()
  display: boolean;

  @Input()
  isEditState: boolean;

  @Input()
  selectedAddress: any;

  @Input()
  taskMapId: string;


  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.employerCompanyAddressForm = this.formBuilder.group({
      address1: ['', [Validators.required, spaceValidator]],
      address2: [''],
      city: ['', [Validators.required]],
      stateCode: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern('[0-9]{5}([-]{1}[0-9]{4})?$')]],
      addressTypeCode: ['', [Validators.required]],
    });
  }

  ngOnInit() {
    this.isEditState = false;
  }

  getDcMasterData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        if((response.states != undefined) && (response.states != null)){
          this.stateList = response.states;
        }
        
        if((response.addressTypes != undefined) && (response.addressTypes != null)){
          this.addressTypeList = response.addressTypes;
        }
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState != true) {
      this.selectedAddress = {
        address1: "",
        address2: "",
        city: "",
        stateCode: "",
        zip: "",
        addressTypeCode: "",
      }
    }

    if((this.stateList.length == 0) || (this.addressTypeList.length == 0)){
      this.getDcMasterData();
    }

    this.employerCompanyAddressForm.get('address1').setValue(this.selectedAddress.address1);
    this.employerCompanyAddressForm.get('address2').setValue(this.selectedAddress.address2);
    this.employerCompanyAddressForm.get('city').setValue(this.selectedAddress.city);
    this.employerCompanyAddressForm.get('stateCode').setValue(this.selectedAddress.stateCode);
    this.employerCompanyAddressForm.get('zip').setValue(this.selectedAddress.zip);
    this.employerCompanyAddressForm.get('addressTypeCode').setValue(this.selectedAddress.addressTypeCode);

  }

  // convenience getter for easy access to form fields
  get address1() { return this.employerCompanyAddressForm.get('address1'); }
  get address2() { return this.employerCompanyAddressForm.get('address2'); }
  get city() { return this.employerCompanyAddressForm.get('city'); }
  get stateCode() { return this.employerCompanyAddressForm.get('stateCode'); }
  get zip() { return this.employerCompanyAddressForm.get('zip'); }
  get addressTypeCode() { return this.employerCompanyAddressForm.get('addressTypeCode'); }

  onHide() {
    this.employerCompanyAddressForm.reset();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState,
        addressData: this.selectedAddress
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
    //this.resetForm();
  }

  onSubmit() {
    const taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;

    this.selectedAddress.taskMapId = taskMapId;
    this.selectedAddress.address1 = this.address1.value;
    this.selectedAddress.address2 = this.address2.value;
    this.selectedAddress.city = this.city.value;
    this.selectedAddress.stateCode = this.stateCode.value;
    this.selectedAddress.zip = this.zip.value;
    this.selectedAddress.addressTypeCode = this.addressTypeCode.value;
    
    this.dataCollectionService
      .addUpdateEmployerCompanyAddress(this.isEditState, this.selectedAddress, taskMapId)
      .subscribe(
        response => {
          this.isSucess = true;
          this.dataCollectionService.completionTick("DCEmpCompData")
          // if(this.isEditState){
          //   this.messageService.add({ key: 'employeeAddress', severity: 'success', summary: 'SUCCESS', detail: 'Address updated successfully!!' });
          // }else{
          //   this.messageService.add({ key: 'employeeAddress', severity: 'success', summary: 'SUCCESS', detail: 'Address added successfully!!' });
          // }
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'employeeAddress', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
  }

  resetForm() {
    this.selectedAddress = {
      address1: "",
      address2: "",
      city: "",
      stateCode: "",
      zip: "",
      addressTypeCode: "",
    }

    this.employerCompanyAddressForm.get('address1').setValue('');
    this.employerCompanyAddressForm.get('address2').setValue('');
    this.employerCompanyAddressForm.get('city').setValue('');
    this.employerCompanyAddressForm.get('stateCode').setValue('');
    this.employerCompanyAddressForm.get('zip').setValue('');
    this.employerCompanyAddressForm.get('addressTypeCode').setValue('');
    this.isSucess = false;
    this.errorMsg = '';
  }
}
