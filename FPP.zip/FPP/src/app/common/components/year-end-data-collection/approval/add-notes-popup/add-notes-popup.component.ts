import { Component, OnInit, Output, Input, EventEmitter, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../../services/data.service';
import { DataCollectionService } from '../../../../services/datacollection.service';
import { MessageService } from 'primeng/api';
import { Utility } from '../../../../utils/utility';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'add-notes-popup',
  templateUrl: './add-notes-popup.component.html',
  styleUrls: ['./add-notes-popup.component.css']
})
export class AddNotesPopupComponent implements OnInit {
  notesForm: FormGroup;
  sectionList: any = [];
  errorMsg: string = '';
  isSucess: boolean = false;
  @Input()
  display: boolean;
  @Input()
  isEditState: boolean;
  @Input()
  selectedNote: any;
  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();
  sectionIds: any;
  portalSubSectionCodes: any
  selectedSectionNumber: any ={};

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.notesForm = this.formBuilder.group({
      portalSubSectionCode: ['', [Validators.required]],
      note: ['', [Validators.required, spaceValidator]]
    });
   }

  ngOnInit() {
    //this.sectionList = this.dataService.getSectionList();
    this.isEditState = false;
  }
  
  ngOnChanges(changes: SimpleChanges) {
    if(this.isEditState!= true){
      this.selectedNote = {
        portalSubSectionCode: "",
        note: ""
      }
    }

    if((this.sectionList != undefined) && (this.sectionList != null)){
      if(this.sectionList.length == 0){
        this.getSectionList();
      }
    }

    this.notesForm.get('portalSubSectionCode').setValue(this.selectedNote.portalSubSectionCode);
    this.notesForm.get('note').setValue(this.selectedNote.note);
    this.isSucess = false;
  }

  // convenience getter for easy access to form fields
  get portalSubSectionCode() { return this.notesForm.get('portalSubSectionCode'); }
  get note() { return this.notesForm.get('note'); }

  getSectionList() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        if((response.subSections != undefined) && (response.subSections != null)){
          this.sectionList = response.subSections;
        }
      });
  }

  onHide() {
    this.notesForm.reset();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState,
        notesData: this.selectedNote
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
  }

  onSubmit() {
    if (this.isEditState) {
      this.selectedNote.portalSubSectionCode = this.portalSubSectionCode.value;
      this.selectedNote.note = this.note.value;
      this.selectedNote.isApproval = true;
      this.dataCollectionService.updateNotesData(this.isEditState, this.selectedNote).subscribe(
        response => {
          this.isSucess = true;
          // this.messageService.add({ key: 'approvalNote', severity: 'success', summary: 'SUCCESS', detail: 'Record updated successfully!!' });
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'approvalNote', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
    }
    else {
      const noteObj: any = {
        dcTaskId: JSON.parse(localStorage.getItem("taskDetails")).taskId,
        note: this.note.value,
        portalSubSectionCode: this.portalSubSectionCode.value,
        isApproval:true
      };

      this.dataCollectionService.updateNotesData(this.isEditState, noteObj).subscribe(
        response => {
          this.isSucess = true;
          // this.messageService.add({ key: 'approvalNote', severity: 'success', summary: 'SUCCESS', detail: 'Record added successfully!!' });
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'noteToast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
    }
  }

  resetForm(){
    this.selectedNote = {
      portalSubSectionCode: "",
      notes: "",
    }

    this.selectedNote.get('portalSubSectionCode').setValue('');
    this.selectedNote.get('notes').setValue('');
    this.isSucess = false;
    this.errorMsg = '';
  }

}
