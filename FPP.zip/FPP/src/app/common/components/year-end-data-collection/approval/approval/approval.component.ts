import { Component, OnInit } from '@angular/core';
import { DataCollectionService } from '../../../../services/datacollection.service';
import { ApprovalNotesVo, DocumentsVo } from '../../../../vo/datacolleciton-interface';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from "primeng/api";
import { Utility } from "../../../../utils/utility";
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css']
})
export class ApprovalComponent implements OnInit {
  notesVo: Array<any> = [];
  documentsVo: Array<any> = [];
  errorMsg: string = '';
  colsdocuments: Array<any> = [];
  documentsList: Array<any> = [];
  isNoteEdit: boolean = false;
  isDocumentEdit: boolean = false;
  selectedNote: ApprovalNotesVo;
  selectedDocument: any;
  displayNotesDialog: boolean = false;
  displayDocumentsDialog: boolean = false;
  colsNotes: Array<any> = [];
  notesList: Array<any> = [];
  saveDetails: any = {};
  taskId: any;
  SectionMenu: any;
  taskDetils: any = JSON.parse(localStorage.getItem("taskDetails"));
  allSectionStatus: any;
  enableSignSubmit: boolean;
  isAllSectionCompleted:boolean = true;

  constructor(private dataCollectionService: DataCollectionService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private router: Router) { }

  ngOnInit() {
    this.colsdocuments = [
      { field: 'DisplayName', header: 'Name' },
      { field: 'DocumentTypeName', header: 'Type' },
      { field: 'Descreption', header: 'Description' }
    ];

    this.colsNotes = [
      { field: 'portalSubSectionName', header: 'Section Name' },
      { field: 'note', header: 'Note' },
      { field: 'createdOn', header: 'Date Created' },
      { field: 'createdByfullName', header: 'Created By' }
    ];

    this.getNoteData();
    this.getApprovalDocumentData();
    this.dataCollectionService.currentMenuStatus
    .pipe(distinctUntilChanged())
    .subscribe((response: any) => {
      // this.allSectionStatus.forEach(sectionStatus => {
      //   if(sectionStatus.subSectionCode != "DCApproval"){
      //     sectionStatus.isCompleted 
      //   }
      // });
      this.allSectionStatus = response.filter(submitStatus => ((submitStatus.subSectionCode != "DCApproval") && submitStatus.isCompleted == true)).length;
      if(this.allSectionStatus>0){
        this.enableSignSubmit = false
      }
      else{
        this.enableSignSubmit = true;
      }
    });
    console.log(this.allSectionStatus)

  }

  ngOnChanges() {
    this.getNoteData();
    this.getApprovalDocumentData();
  }

  getNoteData() {
    let taskId: any = JSON.parse(localStorage.getItem("taskDetails")).taskId;
    this.dataCollectionService
      .getDataCollectionNoteData(taskId)
      .subscribe((response: Array<any>) => {
        if ((response != undefined) && (response != null)) {
          if (response.length > 0) {
            this.notesList = response;
          } else {
            this.notesList = [];
          }
        } else {
          this.notesList = [];
        }
      },
        error => {
          this.notesList = [];
          this.errorMsg = error.statusText;
        }
      );
  }


  getApprovalDocumentData() {
    this.dataCollectionService
      .getApprovalDocumentData()
      .subscribe((response: any) => {
        if ((response != undefined) && (response != null)) {
          if (response.length > 0) {
            this.documentsList = response;
          } else {
            this.documentsList = [];
          }
        } else {
          this.documentsList = [];
        }
      },
        error => {
          this.documentsList = [];
          this.errorMsg = error.error.detail;
        }
      );
  }

  addNoteDialog() {
    this.isNoteEdit = false;
    this.selectedNote = null;
    this.displayNotesDialog = true;
  }

  onEditNotes(selectedNote) {
    this.isNoteEdit = true;
    this.selectedNote = selectedNote;
    this.displayNotesDialog = true;
  }

  deleteNotes(selectedNote) {
    //this.notesList = this.notesList.filter(item => item.noteId != selectedNote.noteId);
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      key: "approvalConfirmDialog",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        this.dataCollectionService
          .deleteNotesData(
            selectedNote.id
          )
          .subscribe(
            response => {
              this.getNoteData();
              // this.messageService.add({
              //   key: "approvalToast",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record deleted successfully!!"
              // });
            },
            error => {
              this.messageService.add({
                key: "approvalToast",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error.detail
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onNotesDialogClose(data: any) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getNoteData();
    }
    this.displayNotesDialog = false;
  }


  addDocumentsDialog() {
    this.isDocumentEdit = false;
    this.selectedDocument = null;
    this.displayDocumentsDialog = true;
  }
  onEditDocuments(selectedDocument) {
    this.isDocumentEdit = true;
    this.selectedDocument = selectedDocument;
    this.displayDocumentsDialog = true;
  }

  deleteDocuments(selectedDocument) {
    //this.documentsList = this.documentsList.filter(item => item.GUID != selectedDocument.GUID);
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      key: "approvalConfirmDialog",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        let docObj = {
          DataCollectionApprovalDocId: selectedDocument.DataCollectionApprovalDocumentID,
          Description: null
        }
        this.dataCollectionService.updateAndDeleteApprovalDocument(docObj)
          .subscribe(
            response => {
              this.getApprovalDocumentData();
              // this.messageService.add({
              //   key: "approvalToast",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record deleted successfully!!"
              // });
            },
            error => {
              this.messageService.add({
                key: "approvalToast",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error.detail
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onDocumentsDialogClose(data) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getApprovalDocumentData();
    }
    this.displayDocumentsDialog = false;
  }

  validateSubmit(sectionData: any) {
    this.dataCollectionService.currentMenuStatus
    .pipe(distinctUntilChanged())
    .subscribe((response: any) => {
      this.SectionMenu = response;
  },error => {
    this.isAllSectionCompleted = false;
  });

  this.SectionMenu.forEach(element => {
    if(element.subSectionCode != "DCApproval"){
      if(!element.isCompleted){
        this.isAllSectionCompleted = false;
        return;
      }
    }
  });

  if(this.isAllSectionCompleted){
    this.saveDetails.taskMapId = this.taskDetils.taskMapId;
    this.saveDetails.taskId = this.taskId
    this.saveDetails.subSectionCode = "DCApproval";
    if (sectionData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;
    }
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response;
          this.dataCollectionService.currentMenuStatus
          .pipe(distinctUntilChanged())
          .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
              if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });

          if (sectionData == "SaveAndNext") {
          if(obj.isCompleted){
            this.confirmationService.confirm({
              message: "Thank you for submitting the Year End task",
              key: "acceptSignsubmitConfirmDialog",
              accept: () => {
                this.router.navigate(["/home/datacollection/datacollection-landing"])
              },
              reject: () => {
                return;
              }
            });
        }
        else{
          this.confirmationService.confirm({
            message: "You have not filled in the information in all the sections. Please update and submit",
            key: "rejectSignsubmitConfirmDialog",
            accept: () => {
            },
            reject: () => {
              return;
            }
          });
        }
      }
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
        }
      );
    } else{
      if (sectionData == "SaveAndNext") {
        this.confirmationService.confirm({
          message: "You have not yet completed all the sections. Please update and submit.",
          key: "rejectSignsubmitConfirmDialog",
          accept: () => {
          },
          reject: () => {
            return;
          }
        });
      }
    }
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

  save(){
    this.validateSubmit("Save");
  }

  signAndSubmit() {
    this.validateSubmit("SaveAndNext");
    
  }

}
