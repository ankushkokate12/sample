import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsPopupComponent } from './documents-popup.component';

describe('DocumentsPopupComponent', () => {
  let component: DocumentsPopupComponent;
  let fixture: ComponentFixture<DocumentsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
