import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../../services/data.service';
import { DataCollectionService } from '../../../../services/datacollection.service';
import { MessageService } from 'primeng/api';
import { Utility } from '../../../../utils/utility';
import { FileValidations } from './constants/validation.constants';
import { AnonymousSubject } from 'rxjs/internal/Subject';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'documents-popup',
  templateUrl: './documents-popup.component.html',
  styleUrls: ['./documents-popup.component.css']
})
export class DocumentsPopupComponent implements OnInit {
  documentsForm: FormGroup;
  documentTypeList: any = [];
  errorMsg: string = '';
  isSucess: boolean = false
  fileName: any="";
  selectedFile:any;
  UploadfileObj:any = {
    file:null,
    fileName:''
  };
  @Input()
  display: boolean;
  @ViewChild("fileInput", { static: false }) fileInputRef: ElementRef;
  @Input()
  isDocumentEditState: boolean;
  
  @Input()
  selectedDocument: any;
  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();

  fileValidations = FileValidations;

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService,
    private cd: ChangeDetectorRef) { 
    this.documentsForm = this.formBuilder.group({
      DisplayName: [null, [Validators.required]],
      DocumentTypeCode: ['', [Validators.required]],
      Descreption: ['', [Validators.required, spaceValidator]]
    });
    
  }

  ngOnInit() {
    //this.documentTypeList = this.dataService.getDocumentTypeList();
    this.isDocumentEditState= false;
    this.getFileValidations();
  }
  
  ngOnChanges(changes: SimpleChanges) {
    if(this.isDocumentEditState != true){
      this.selectedDocument = {
        DisplayName: '',
        DocumentTypeCode: "",
        Descreption: ""
      }
      this.fileName = "";
      this.documentsForm.controls['DisplayName'].enable();
    }else{
      this.documentsForm.controls['DisplayName'].disable();
     
    }

    if((this.documentTypeList != undefined) && (this.documentTypeList != null)){
      if(this.documentTypeList.length == 0){
        this.getDocumentTypeList();
      }
    }
   
    if(!this.isDocumentEditState){
      this.documentsForm.get('DisplayName').setValue(this.selectedDocument.DisplayName);
    }else{
      this.fileName = this.selectedDocument.DisplayName;
    }
    
    this.documentsForm.get('DocumentTypeCode').setValue(this.selectedDocument.DocumentTypeCode);
    this.documentsForm.get('Descreption').setValue(this.selectedDocument.Descreption);
    this.isSucess = false;
  }

  ngAfterViewInit() {
    let acceptedFileType = [];
    this.fileValidations.file_types.forEach(i => {
      acceptedFileType.push('.' + i);
    })
    this.fileInputRef.nativeElement.accept = acceptedFileType;
  }

  // convenience getter for easy access to form fields
  get DisplayName() { return this.documentsForm.get('DisplayName'); }
  get DocumentTypeCode() { return this.documentsForm.get('DocumentTypeCode'); }
  get Descreption() { return this.documentsForm.get('Descreption'); }

  getFileValidations() {
    this.dataService.currentFileValidations
      .subscribe((response: any) => {
        if((response != undefined) && (response != null)){
          this.fileValidations = response;
        }
      });
  }

  getDocumentTypeList() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        if((response.approvedDocumentType != undefined) && (response.approvedDocumentType != null)){
          this.documentTypeList = response.approvedDocumentType;
        }
      });
  }

  handleFileUpload(){

  }

  onHide() {
    this.documentsForm.reset();
    this.display = false;
    this.UploadfileObj.fileName = null;
      this.UploadfileObj.file = null;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isDocumentEditState,
        documentsData: this.selectedDocument
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
  }

  openFile() {
    document.getElementById('file-input').click();
  }


  onFileChange(event) {
    let reader = new FileReader();  
    this.UploadfileObj.fileName = '';
    this.UploadfileObj.file = null;
    if(event.target.files && event.target.files.length) {
      const file = <File>event.target.files[0];
      this.fileName = event.target.files[0].name     
      
        if (file.size > this.fileValidations.max_file_size_mb) {
          this.messageService.clear('approvalDocument');
          setTimeout(() => {
            this.messageService.add({
              key: 'approvalDocument', severity: 'error',
              summary: 'ERROR', sticky: true, detail: "File size limit exceeded. Allowed file size is " + this.fileValidations.max_file_size_mb / (1024 * 1024) + " MB"
            });
          }, 1000);
        }
        else if (this.checkFileExtension(file)) {          
           this.UploadfileObj.file = file;
           this.UploadfileObj.fileName = this.fileName;
      };
    }
  }

  checkFileExtension(file) {
    let returnValue = false;
    console.log(file);
    let ext = file.name.match(/\.([^\.]+)$/)[1];
    if (this.fileValidations.file_types.indexOf(ext) > -1) {
      returnValue = true
    } else {
      this.messageService.clear('approvalDocument');
      setTimeout(() => {
        this.messageService.add({ key: 'approvalDocument', severity: 'error', summary: 'ERROR', sticky: true, detail: "Sorry! file type is invalid, allowed extensions are-" + this.fileValidations.file_types.toString() });
      }, 1000);
    }

    return returnValue;
  }

  onSubmit() {
    this.selectedDocument.DisplayName = this.DisplayName.value;
    this.selectedDocument.DocumentTypeCode = this.DocumentTypeCode.value;
    this.selectedDocument.Descreption = this.Descreption.value;

    if (this.isDocumentEditState) {
      const editDocObj = {
        DataCollectionApprovalDocId: this.selectedDocument.DataCollectionApprovalDocumentID,
        ApprovalDocumentTypeCode : this.DocumentTypeCode.value,
        Description: this.Descreption.value
      }
      this.dataCollectionService.updateAndDeleteApprovalDocument(editDocObj).subscribe(
        response => {
          this.isSucess = true;
          // this.messageService.add({ key: 'approvalNote', severity: 'success', summary: 'SUCCESS', detail: 'Record updated successfully!!' });
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'approvalDocument', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error});
        }
      )
    }else{
      let docObj: any = {
        DataCollectionTaskId: JSON.parse(localStorage.getItem("taskDetails")).taskId,
        DisplayName:this.fileName,
        Description: this.selectedDocument.Descreption,
        ApprovalDocumentTypeCode: this.selectedDocument.DocumentTypeCode,
        Files:this.UploadfileObj.file
      };

      const fd = new FormData();
      for (const property in docObj) {
          fd.append(property, docObj[property]);
      }

      this.dataCollectionService.addApprovalDocument(fd).subscribe(
        response => {
          this.isSucess = true;
          // this.messageService.add({ key: 'approvalNote', severity: 'success', summary: 'SUCCESS', detail: 'Record added successfully!!' });
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'approvalDocument', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
        }
      )
    }

  }

}
