import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessesPopupComponent } from './businesses-popup.component';

describe('BusinessesPopupComponent', () => {
  let component: BusinessesPopupComponent;
  let fixture: ComponentFixture<BusinessesPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessesPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessesPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
