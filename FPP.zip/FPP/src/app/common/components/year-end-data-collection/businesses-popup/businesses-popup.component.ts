import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ContactNumberVo } from '../../../vo/datacolleciton-interface';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { DataCollectionService } from '../../../services/datacollection.service';
import { MessageService } from 'primeng/api';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { Utility } from '../../../utils/utility';
import { DateFormatUtility } from '../../../utils/dateFormat-utility';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'businesses-popup',
  templateUrl: './businesses-popup.component.html',
  styleUrls: ['./businesses-popup.component.css']
})
export class BusinessesPopupComponent implements OnInit {
  businessForm: FormGroup;
  stateList: Array<any> = [];
  countryCodeList: Array<any> =[];
  entityTypeList: Array<any> = [];
  employeesConfirmationList: Array<any> = [];
  sponsoredConfrmationList: Array<any> = [];
  errorMsg: string = '';
  isSucess: boolean = false;
  taskMapId: any;
  overlayData: any;
  defaultContryCode:any;
  todayDate: number = new Date().getTime()

  @Input()
  display: boolean;

  @Input()
  isEditState: boolean;

  @Input()
  selectedBusiness: any;

  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.businessForm = this.formBuilder.group({
      companyName: ['', [Validators.required, spaceValidator]],
      address: [''],
      city: [''],
      state: [''],
      zip: ['', [Validators.pattern('[0-9]{5}([-]{1}[0-9]{4})?$')]],
      phone: ['', [Validators.pattern('[0-9]{3}[-]*[0-9]{3}[-]*[0-9]{4}')]],
      //isdCode: [null],
      datePurchase: [{value:null, disabled: false}],
      ein: ['', [Validators.required, Validators.pattern('[0-9]{2}[-]*[0-9]{7}')]],
      hasEmployees: [false, [Validators.required]],
      qualifiedPlan: [false, [Validators.required]],
      entityTypeCode: ['', [Validators.required]],
      otherBusinessOwners: this.formBuilder.array([]),
    });
  }

  createOwnerRecord(oRecord?:any) {
    if((oRecord != null) && (oRecord != undefined)){
      return this.formBuilder.group({
        dcOtherBusinessOwnerId: [oRecord.dcOtherBusinessOwnerId],
        dcOtherBusinessId: [oRecord.dcOtherBusinessId],
        oName: [oRecord.oName ,Validators.compose([Validators.required])],
        oPercent: [oRecord.oPercent ,Validators.compose([Validators.required, Validators.max(100)])]
      })
    }else{
      return this.formBuilder.group({
        dcOtherBusinessOwnerId: [null],
        dcOtherBusinessId: [null],
        oName: ['',Validators.compose([Validators.required])],
        oPercent: ['',Validators.compose([Validators.required,Validators.max(100)])]
      })
    }
  }

  ngOnInit() {
    this.isEditState = false;
  }

  // get the formgroup under otherBusinessOwners form array
  getOwnersFormGroup(index): FormGroup {
    const formGroup = this.otherBusinessOwners.controls[index] as FormGroup;
    return formGroup;
  }

  getDcMasterData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        this.entityTypeList = response.entityTypes;
      });
  }

  getSatetCountry() {
    this.dataService
      .getStateCountryCodeData()
      .subscribe((response:any) => {
        this.stateList = response.states;
        this.countryCodeList = response.countries;
        this.defaultContryCode = this.countryCodeList.filter(m => (m.isoAlpha3CountryCode == 'CAN'))[0];
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    this.businessForm.reset();
    this.businessForm.markAsUntouched();
    this.businessForm.markAsPristine();

    Object.keys(this.businessForm.controls).forEach(key => {
      this.businessForm.get(key).setErrors(null) ;
    });

    if (this.isEditState != true) {
      this.selectedBusiness = {
        companyName: "",
        addresses: {
          taskMapId: null,
          address1: "",
          addressTypeCode: "",
          city: "",
          stateCode: "",
          zip: ""
        },
        phone: "",
       // isdCode: null,
        datePurchase: null,
        ein: "",
        hasEmployees: false,
        qualifiedPlan: false,
        entityTypeCode: "",
        otherBusinessOwners: []
      }
      if(this.defaultContryCode != undefined){
        this.selectedBusiness.isdCode = this.defaultContryCode.isdCode;
      }

      (this.businessForm.get('otherBusinessOwners') as FormArray).clear();
    }

    if (this.entityTypeList.length == 0) {
      this.getDcMasterData();
    }

    if (this.employeesConfirmationList.length == 0) {
     this.employeesConfirmationList =  this.dataService.getBooleanList();
    }

    if (this.sponsoredConfrmationList.length == 0) {
      this.sponsoredConfrmationList = this.dataService.getBooleanList();
    }

    if (this.stateList.length == 0) {
      this.getSatetCountry();
    }

    this.businessForm.get('companyName').setValue(this.selectedBusiness.companyName);
    this.businessForm.get('address').setValue(this.selectedBusiness.addresses.address1);
    this.businessForm.get('city').setValue(this.selectedBusiness.addresses.city);
    this.businessForm.get('state').setValue(this.selectedBusiness.addresses.stateCode);
    this.businessForm.get('zip').setValue(this.selectedBusiness.addresses.zip);
    this.businessForm.get('phone').setValue(this.selectedBusiness.phone);
    //this.businessForm.get('isdCode').setValue(this.selectedBusiness.isdCode);
    this.businessForm.get('datePurchase').setValue(
      this.selectedBusiness.datePurchase == null
        ? this.selectedBusiness.datePurchase
        : DateFormatUtility.UTCToLocal(this.selectedBusiness.datePurchase)
    );
    this.businessForm.get('ein').setValue(this.selectedBusiness.ein);
    this.businessForm.get('hasEmployees').setValue(this.selectedBusiness.hasEmployees);
    this.businessForm.get('qualifiedPlan').setValue(this.selectedBusiness.qualifiedPlan);
    this.businessForm.get('entityTypeCode').setValue(this.selectedBusiness.entityTypeCode);
    if(this.selectedBusiness.otherBusinessOwners.length > 0){
      this.otherBusinessOwners.clear();
      Object.keys(this.otherBusinessOwners.controls).forEach(key => {
        this.otherBusinessOwners.get(key).setErrors(null) ;
      });
      for(let i=0;i<this.selectedBusiness.otherBusinessOwners.length;i++){
        this.otherBusinessOwners.push(this.createOwnerRecord(this.selectedBusiness.otherBusinessOwners[i]));
      }
    }
    this.isSucess = false;
  }

  // convenience getter for easy access to form fields
  get companyName() { return this.businessForm.get('companyName'); }
  get address() { return this.businessForm.get('address'); }
  get city() { return this.businessForm.get('city'); }
  get state() { return this.businessForm.get('state'); }
  get zip() { return this.businessForm.get('zip'); }
  get phone() { return this.businessForm.get('phone'); }
  //get isdCode() { return this.businessForm.get('isdCode'); }
  get datePurchase() { return this.businessForm.get('datePurchase'); }
  get ein() { return this.businessForm.get('ein'); }
  get hasEmployees() { return this.businessForm.get('hasEmployees'); }
  get qualifiedPlan() { return this.businessForm.get('qualifiedPlan'); }
  get entityTypeCode() { return this.businessForm.get('entityTypeCode'); }
  get otherBusinessOwners() { return this.businessForm.get('otherBusinessOwners') as FormArray; }

  addNewOwner() {
    this.otherBusinessOwners.push(this.createOwnerRecord());
  }
  deleteOwner(index) {
    this.otherBusinessOwners.removeAt(index)
  }

  onHide() {
    this.businessForm.reset();
    this.otherBusinessOwners.clear();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState,
        business: this.selectedBusiness
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
  }

  onSubmit() {
    const taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    let selectedBusinessObj:any = {};
    selectedBusinessObj.addresses = {};
    selectedBusinessObj.taskMapId = taskMapId;
    selectedBusinessObj.companyName = this.companyName.value;
    selectedBusinessObj.addresses.address1 = this.address.value;
    selectedBusinessObj.addresses.city = this.city.value;
    selectedBusinessObj.addresses.stateCode = this.state.value;
    selectedBusinessObj.addresses.taskMapId = taskMapId;
    selectedBusinessObj.addresses.addressTypeCode = 'Business';
    selectedBusinessObj.addresses.zip = (this.zip.value);
    selectedBusinessObj.phone =  Utility.removeMasking(this.phone.value);
    //selectedBusinessObj.isdCode = (this.isdCode.value == "" || this.isdCode.value== null) ? null : this.isdCode.value
    selectedBusinessObj.datePurchase = this.datePurchase.value;
    selectedBusinessObj.ein = (Utility.removeMasking(this.ein.value));
    selectedBusinessObj.hasEmployees = this.hasEmployees.value;
    selectedBusinessObj.qualifiedPlan = this.qualifiedPlan.value;
    selectedBusinessObj.entityTypeCode = this.entityTypeCode.value;

    if((this.otherBusinessOwners.value != undefined) && (this.otherBusinessOwners.value.length > 0)){
      selectedBusinessObj.otherBusinessOwners = (this.otherBusinessOwners.value).filter(
        item => ((item.oName != "") && (item.oPercent != ""))
      );
    }else{
      selectedBusinessObj.otherBusinessOwners = [];
    }

    if(selectedBusinessObj.otherBusinessOwners.length > 0){
      selectedBusinessObj.otherBusinessOwners.forEach(element => {
        element.oPercent = +element.oPercent;

        if(element.dcOtherBusinessId == null){
          delete element.dcOtherBusinessOwnerId;
          delete element.dcOtherBusinessId;
        }
      });
    }
    
    if(this.isEditState){
      selectedBusinessObj.dcEmployerOtherBusinessId = this.selectedBusiness.dcEmployerOtherBusinessId;
    }

    this.dataCollectionService
    .updateBusinessData(this.isEditState, selectedBusinessObj)
    .subscribe(
      response => {
        this.isSucess = true;
        this.dataCollectionService.completionTick("DCOtherBusiness");
        // if(this.isEditState){
        //   this.messageService.add({ key: 'business-toast', severity: 'success', summary: 'SUCCESS', detail: 'Record updated successfully!!' });
        // }else{
        //   this.messageService.add({ key: 'business-toast', severity: 'success', summary: 'SUCCESS', detail: 'Record added successfully!!' });
        // }
        
        this.onHide();
      },
      error => {
        this.isSucess = false;
        this.messageService.add({ key: 'business-toast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
      }
    )
  }

  showOverlay(event, data, op: OverlayPanel) {
    this.overlayData = data;
    op.toggle(event);
  }
}