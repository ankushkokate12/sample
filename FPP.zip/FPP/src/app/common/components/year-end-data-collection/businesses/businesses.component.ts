import { Component, OnInit } from "@angular/core";
import {
  BusinessVo,
  BusinessesDetails
} from "../../../vo/datacolleciton-interface";
import { DataCollectionService } from "../../../services/datacollection.service";
import { OverlayPanel } from "primeng/overlaypanel/public_api";
import { Router, ActivatedRoute } from "@angular/router";
import { ConfirmationService, MessageService } from "primeng/api";
import { Observable, Observer } from "rxjs";
import { Utility } from "../../../utils/utility";
import { distinctUntilChanged } from "rxjs/operators";

@Component({
  selector: "businesses",
  templateUrl: "./businesses.component.html",
  styleUrls: ["./businesses.component.css"]
})
export class BusinessesComponent implements OnInit {
  isEditState: boolean;
  isBusinessEdit: boolean = false;
  displayNotesDialog: boolean = false;
  displayBusinessesDialog: boolean = false;
  colsBusinesses: any[];
  businessesDetails: BusinessesDetails;
  businessList: any = [];
  originalData: any = [];
  selectedBusiness: any;
  errorMsg: string = "";
  overlayData: any;
  SectionMenu: any;
  isBusinessesdisabled: boolean;
  taskMapId: any;
  saveDetails: any = {};
  portalSubSectionCode: string = "DCOtherBusiness";
  taskId: any;

  constructor(
    private router: Router,
    private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.taskMapId = JSON.parse(localStorage.getItem("taskDetails")).taskMapId;
    this.taskId = JSON.parse(localStorage.getItem("taskDetails")).taskId;
    this.colsBusinesses = [
      { field: "companyName", header: "Company Name" },
      { field: "ein", header: "EIN" },
      { field: "phone", header: "Phone" },
      { field: "qualifiedPlan", header: "Plan Sponsor" },
      { field: "addresses.address1", header: "Address" },
      { field: "hasEmployees", header: "Employees" }
    ];

    this.getBusinessData();
  }

  getBusinessData() {
    this.dataCollectionService.getBusinessData(this.taskMapId).subscribe(
      response => {
        if (response.otherBusinesses != undefined) {
          if (response.otherBusinesses.noConsent != undefined) {
            this.businessList = [];
            this.isBusinessesdisabled = response.otherBusinesses.noConsent;
          } else {
            this.businessList = response.otherBusinesses;
            //this.isBusinessesdisabled = false;
          }
        } else {
          this.businessList = [];
          this.isBusinessesdisabled = false;
        }
      },
      error => {
        this.businessList = [];
        this.errorMsg = error.statusText;
      }
    );
  }

  // canDeactivate() {
  //   return Observable.create((observer: Observer<boolean>) => {
  //     // if(JSON.stringify(this.originalData)===JSON.stringify(this.businessList)){
  //       if(JSON.stringify(Object.entries(this.originalData).sort()) === JSON.stringify(Object.entries(this.businessList).sort())){
  //       observer.next(true);
  //       observer.complete();
  //   }
  //   else
  //   {
  //     this.confirmationService.confirm({
  //       message: 'You have unsaved changes. Are you sure you want to leave this page?',
  //       accept: () => {
  //         observer.next(true);
  //         observer.complete();
  //       },
  //       reject: () => {
  //         observer.next(false);
  //         observer.complete();
  //       }
  //     });
  //   }
  //   });

  // }

  addBusinessDialog() {
    this.isBusinessEdit = false;
    this.selectedBusiness = null;
    this.displayBusinessesDialog = true;
  }

  editBusiness(selectedBusiness) {
    this.isBusinessEdit = true;
    this.selectedBusiness = selectedBusiness;
    this.displayBusinessesDialog = true;
  }

  deleteBusiness(selectedBusiness) {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "businessConfirmPopup",
      accept: () => {
        this.dataCollectionService
          .deleteBusinessData(selectedBusiness.dcEmployerOtherBusinessId)
          .subscribe(
            response => {
              this.getBusinessData();
              this.dataCollectionService.completionTick("DCOtherBusiness");
              // this.messageService.add({
              //   key: "business-toast",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record Deleted successfully!!"
              // });
            },
            error => {
              this.errorMsg = Utility.showErrMsg(error);
              this.messageService.add({
                key: "business-toast",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onBusinessesDialogClose(data: any) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getBusinessData();
    }
    this.displayBusinessesDialog = false;
  }

  showOverlay(event, data, op: OverlayPanel) {
    if (data != undefined && data != null) {
      this.overlayData = data;
    } else {
      this.overlayData = [];
    }
    op.toggle(event);
  }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }

  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  validateSubmit(sectionData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskId;
    this.saveDetails.subSectionCode = "DCOtherBusiness";
    if (sectionData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    } else {
      this.saveDetails.isSaveandContinue = false;
    }
    // if (!this.isBusinessesdisabled) {
    //   if(this.businessList.length==0){
    //     this.saveDetails.isSaveandContinue = false;
    //   }
    //   else{
    //     this.saveDetails.isSaveandContinue = true;
    //   }

    // }
    // else {
    //   this.saveDetails.isSaveandContinue = true;
    // }
    console.log(this.saveDetails);
    this.dataCollectionService.saveAndSubmit(this.saveDetails).subscribe(
      response => {
        let obj = response.response;
        this.dataCollectionService.currentMenuStatus
          .pipe(distinctUntilChanged())
          .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
              if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });
        if (sectionData == "SaveAndNext") {
          if (!obj.isCompleted) {
            this.confirmationService.confirm({
              message:
                "Please update all mandatory fields before completing the section.",
              key: "rejectBusinessConfirmDialog",
              accept: () => { },
              reject: () => {
                return;
              }
            });
          } else {
            this.router.navigate(["../contacts"], { relativeTo: this.route });
            // this.confirmationService.confirm({
            //   message: "You have not filled in the information in all the sections. Please update and submit",
            //   key: "rejectSignsubmitConfirmDialog",
            //   accept: () => {
            //   },
            //   reject: () => {
            //     return;
            //   }
            // });
          }
        }
      },
      error => {
        this.errorMsg = Utility.showErrMsg(error);
      }
    );
  }
  save() {
    //this.dataCollectionService.completionTick("DCOtherBusiness");
   this.validateSubmit("Save");
  }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");
  }

  onBusinessSectionDisabed() {
    if (this.isBusinessesdisabled == true && this.businessList.length > 0) {
      this.confirmationService.confirm({
        message: "This action will delete all records. Do you want to proceed?",
        header: "Confirmation",
        icon: "pi pi-exclamation-triangle",
        key: "businessConfirmPopup",
        accept: () => {
          let businessConsentObj: any = {};
          businessConsentObj.taskMapId = this.taskMapId;
          businessConsentObj.businessConsent = true;

          this.dataCollectionService
            .updateBusinessConsent(businessConsentObj)
            .subscribe(
              response => {
                this.businessList = [];
                this.dataCollectionService.completionTick("DCOtherBusiness");
                // this.messageService.add({
                //   key: "messageToast",
                //   severity: "success",
                //   summary: "SUCCESS",
                //   detail: "Business records deleted successfully."
                // });
              },
              error => {
                this.messageService.add({
                  key: "messageToast",
                  severity: "error",
                  summary: "ERROR",
                  detail: error.error.detail
                });
              }
            );
        },
        reject: () => {
          return (this.isBusinessesdisabled = false);
        }
      });
    } else {
      let businessConsentObj: any = {};
      businessConsentObj.taskMapId = this.taskMapId;
      businessConsentObj.businessConsent = this.isBusinessesdisabled;

      this.dataCollectionService
        .updateBusinessConsent(businessConsentObj)
        .subscribe(
          response => {
            this.dataCollectionService.completionTick("DCOtherBusiness");
            //this.messageService.add({key: "messageToast",severity: "success",summary: "SUCCESS",detail: "Business records deleted successfully."});
          },
          error => {
            this.messageService.add({ key: "messageToast", severity: "error", summary: "ERROR", detail: error.error.detail });
          }
        );
    }
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"]);
  }
}
