import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactIssuesComponent } from './contact-issues.component';

describe('ContactIssuesComponent', () => {
  let component: ContactIssuesComponent;
  let fixture: ComponentFixture<ContactIssuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactIssuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactIssuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
