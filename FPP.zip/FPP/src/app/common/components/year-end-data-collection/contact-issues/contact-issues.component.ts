import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, ViewChild } from '@angular/core';
import { ContactsVo, ContactInfoVo, NoteVo, IssuesVo } from '../../../vo/datacolleciton-interface';
import { DataCollectionService } from '../../../../common/services/datacollection.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Utility } from '../../../../common/utils/utility';
import { ContactsPopupComponent } from '../contacts-popup/contacts-popup.component';

@Component({
  selector: 'contact-issues',
  templateUrl: './contact-issues.component.html',
  styleUrls: ['./contact-issues.component.css']
})
export class ContactIssuesComponent implements OnInit {
  @ViewChild('issueTable', { static: false }) fileInputRef;
  @Input()
  extistingIssues: IssuesVo[];
  @Input()
  issuesActions: boolean;
  @Output()
  editSelectedIssue: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  deletedSelectedIssue: EventEmitter<any> = new EventEmitter<any>();

  isEditState: boolean;
  isDeleteState: boolean;
  issuesVo: IssuesVo;
  colsIssues: any[];
  errorMsg: string = '';

  constructor(private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService) { }

  ngOnInit() {
    this.colsIssues = [
      { field: 'description', header: 'Issue' },
      { field: 'createDateTimeStamp', header: 'Date' },
      { field: 'fullName', header: 'Added By' }
    ];
   
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.extistingIssues!= undefined){
      this.extistingIssues;
    }    
  }

  onEditIssue(selectedIssue) {
    this.isEditState = true;
    this.editSelectedIssue.emit({
      isEdit: this.isEditState,
      issueData: selectedIssue
    });
  }


  deleteIssue(selectedIssue: IssuesVo) {
  //   this.dataCollectionService
  //     .deleteContactIssue(selectedIssue.id)
  //     .subscribe(
  //       response => {
  //         this.dataCollectionService.completionTick("DCContacts")
  //        this.deletedSelectedIssue.emit();
  //       //  this.messageService.clear('addIssue');
  //       //  setTimeout(() => {
  //       //   this.messageService.add({ key: 'addIssue', severity: 'success', summary: 'SUCCESS', detail: "Issue deleted Successfully!!" });
  //       //  }, 1000);          
          
  //       },
  //       error => {
  //         this.errorMsg = Utility.showErrMsg(error);
  //         this.messageService.clear('addIssue');
  //        setTimeout(() => {
  //         this.messageService.add({ key: 'addIssue', severity: 'error', summary: 'ERROR', detail: error.statusText });
  //        }, 1000); 
  //       }
  //     )
  // }
  this.confirmationService.confirm({
    message: "Are you sure that you want to delete this record?",
    header: "Confirmation",
    icon: "pi pi-exclamation-triangle",
    key: "deleteIssue",
    accept: () => {
      this.dataCollectionService
      .deleteContactIssue(selectedIssue.id)
      .subscribe(
        response => {
          this.dataCollectionService.completionTick("DCContacts")
         this.deletedSelectedIssue.emit();
        //  this.messageService.clear('addIssue');
        //  setTimeout(() => {
        //   this.messageService.add({ key: 'addIssue', severity: 'success', summary: 'SUCCESS', detail: "Issue deleted Successfully!!" });
        //  }, 1000);          
          
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.clear('addIssue');
         setTimeout(() => {
          this.messageService.add({ key: 'addIssue', severity: 'error', summary: 'ERROR', detail: error.statusText });
         }, 1000); 
        }
      )
  
    },
    reject: () => {
      return;
    }
  });
  
}
}
