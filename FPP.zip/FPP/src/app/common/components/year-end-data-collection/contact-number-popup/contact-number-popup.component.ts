import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ContactNumberVo } from '../../../vo/datacolleciton-interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { Utility } from '../../../utils/utility';
import { DataCollectionService } from '../../../services/datacollection.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'contact-number-popup',
  templateUrl: './contact-number-popup.component.html',
  styleUrls: ['./contact-number-popup.component.css']
})
export class ContactNumberPopupComponent implements OnInit, OnChanges {
  employerCompanyContactForm: FormGroup;
  contactTypeList: Array<any> = [];
  countryCodeList: Array<any> = [];
  isSucess: boolean = false;
  errorMsg: string = '';
  defaultContryCode:any;
  
  @Input()
  display: boolean;

  @Input()
  isEditState: boolean;

  @Input()
  selectedContact: any;

  @Input()
  taskMapId: string;

  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.employerCompanyContactForm = this.formBuilder.group({
      phoneNumber: ['', [Validators.required, Validators.pattern('[0-9]{3}[-]*[0-9]{3}[-]*[0-9]{4}')]],
      phoneNumberTypeCode: ['', [Validators.required]],
      isdCode: [''],
    });
  }

  ngOnInit() {
    this.isEditState = false;
  }

  getStateCountry() {
    this.dataService
      .getStateCountryCodeData()
      .subscribe((response: any) => {
        if(response.countries != undefined && response.countries != null){
          this.countryCodeList = response.countries;
          this.defaultContryCode = this.countryCodeList.filter(m => (m.isoAlpha3CountryCode == 'CAN'))[0];
        }else{
          this.countryCodeList =[];
        }
      });
  }

  getContactTypeData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        if((response != undefined) && (response != null)){
          this.contactTypeList = response.phoneNumberTypes;
        }else{
          this.contactTypeList = [];
        }
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if((this.contactTypeList != undefined) && (this.contactTypeList.length == 0)){
      this.getContactTypeData();
    }
    
    if((this.contactTypeList != undefined) && (this.countryCodeList.length == 0)){
      this.getStateCountry();      
    }  

    if (this.isEditState != true) {
      this.selectedContact = {
        phoneNumberTypeCode: "",
        phoneNumber: "",
        isdCode: ""
      }
      if(this.defaultContryCode != undefined){
        this.selectedContact.isdCode = this.defaultContryCode.isdCode;
      }
    }
  
    this.employerCompanyContactForm.get('phoneNumberTypeCode').setValue(this.selectedContact.phoneNumberTypeCode);
    this.employerCompanyContactForm.get('phoneNumber').setValue(this.selectedContact.phoneNumber);
    this.employerCompanyContactForm.get('isdCode').setValue(this.selectedContact.isdCode);
  }

  // convenience getter for easy access to form fields
  get phoneNumber() { return this.employerCompanyContactForm.get('phoneNumber'); }
  get phoneNumberTypeCode() { return this.employerCompanyContactForm.get('phoneNumberTypeCode'); }
  get isdCode() { return this.employerCompanyContactForm.get('isdCode'); }

  onHide() {
    this.employerCompanyContactForm.reset();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState,
        contactData: this.selectedContact
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
  }

  onSubmit() {
    const taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.selectedContact.taskMapId = taskMapId;
    this.selectedContact.phoneNumberTypeCode = this.phoneNumberTypeCode.value;
    this.selectedContact.phoneNumber = Utility.removeMasking(this.phoneNumber.value);
    this.selectedContact.isdCode = this.isdCode.value;

    this.dataCollectionService
      .addUpdateEmployerCompanyContact(this.isEditState, this.selectedContact, taskMapId)
      .subscribe(
        response => {
          this.isSucess = true;
          this.dataCollectionService.completionTick("DCEmpCompData")
          // if(this.isEditState){
          //   this.messageService.add({ key: 'contactNumberToast', severity: 'success', summary: 'SUCCESS', detail: 'Contact updated successfully!!' });
          // }else{
          //   this.messageService.add({ key: 'contactNumberToast', severity: 'success', summary: 'SUCCESS', detail: 'Contact added successfully!!' });
          // }
          this.onHide();
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'contactNumberToast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
  }
}
