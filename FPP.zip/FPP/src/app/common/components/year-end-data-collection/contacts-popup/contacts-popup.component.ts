import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { IssuesVo } from 'src/app/common/vo/datacolleciton-interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataCollectionService } from 'src/app/common/services/datacollection.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Utility } from 'src/app/common/utils/utility';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'contacts-popup',
  templateUrl: './contacts-popup.component.html',
  styleUrls: ['./contacts-popup.component.css']
})
export class ContactsPopupComponent implements OnInit {
  contactsIssueForm: FormGroup;

  @Input()
  display: boolean;
  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  newAddedIssues: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  currentContactId: EventEmitter<any> = new EventEmitter<any>();
  @Input()
  isEditable: boolean;
  @Input()
  extistingIssue: IssuesVo[];
  @Input()
  issueAction: boolean;
  isEditIssue: boolean;
  selectedIssue: IssuesVo;
  issuesVo: IssuesVo;
  issuesList: Array<IssuesVo>;
  taskID: number;
  @Input()
  existingContactId: number;
  

  errorMsg: string = '';
  title: string;

  constructor(private formBuilder: FormBuilder,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.contactsIssueForm = this.formBuilder.group({
      description: ['', [Validators.required, spaceValidator]]
    });
  }
  get description() { return this.contactsIssueForm.get('description'); }

  ngOnInit() {
    this.title = "ISSUES";
    this.taskID = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    // this.cdr.detectChanges();    
    this.initializeData();
    this.selectedIssue = this.issuesVo;    
    this.setFormData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if(this.extistingIssue!= undefined){
      this.extistingIssue;
    }    
  }

  // getContactsIssues() {
  //   this.dataCollectionService
  //     .dataCollectionIssuesData
  //     .subscribe((response: IssuesVo[]) => {
  //       this.extistingIssue = response;        
  //     });
  // }
  // getContactsIssues() {
  //   this.dataCollectionService
  //     .getContactIssues(this.taskID, this.contactId)
  //     .subscribe((response: IssuesVo[]) => {
  //       this.extistingIssue = response
  //     },
  //       error => {
  //         this.extistingIssue = [];
  //         this.errorMsg = error.statusText;
  //       }
  //     );
  // }
  onHide() {
    this.contactsIssueForm.reset();
    this.display = false;
    this.isEditable = false;
    this.isEditIssue = false
    this.messageService.clear('addIssue');
    // this.getContactsIssues();
    this.onClose.emit({
      isDisplay: this.display,
      issueData: this.extistingIssue
    });
  }

  addNewIssue() {
    this.isEditable = true;
    this.isEditIssue = false;
    this.initializeData();
    this.selectedIssue = this.issuesVo;    
    this.setFormData();
    this.messageService.clear('addIssue');   
  }

  onCancelEditable() {
    this.isEditable = false;
    this.isEditIssue = false;
    this.setFormData();
  }
  onEditDeleteIssue(data: any) {
    if (data.isEdit) {
      this.isEditIssue = data.isEdit;
      this.selectedIssue = data.issueData;
      this.isEditable = true;
      this.setFormData();
      this.messageService.clear('addIssue');
    }
  }
  
  setFormData() {
    this.contactsIssueForm.get('description').setValue(this.selectedIssue.description);
  }

  refrashData(){
    this.newAddedIssues.emit();
    this.currentContactId.emit(this.existingContactId)
  }

  onSubmit() {
    this.selectedIssue.description = this.description.value;
    this.selectedIssue.contactId = this.existingContactId;

    this.isEditable = false;
    this.dataCollectionService
      .addEditContactIssues(this.isEditIssue, this.selectedIssue, this.taskID)
      .subscribe(
        response => {
          this.dataCollectionService.completionTick("DCContacts")
          this.refrashData();  
          // if (this.isEditIssue) {      
          //   this.messageService.add({ key: 'addIssue', severity: 'success', summary: 'SUCCESS', detail: "Issue updated Successfully!!" });
          // }
          // else {
          //   this.refrashData();           
          //     this.messageService.add({ key: 'addIssue', severity: 'success', summary: 'SUCCESS', detail: "Issue added Successfully!!" });                  
          // }
        },
        error => {
          console.log('Error');
          this.messageService.clear('addIssue');
          this.errorMsg = Utility.showErrMsg(error);
          setTimeout(() => {
          this.messageService.add({ key: 'addIssue', severity: 'error', summary: 'ERROR', detail: error.statusText });
        }, 1000);
      }
      )
  }
  initializeData() {
    this.issuesVo = {
      "description": "",      
      "contactId": null,
      // "fullName": "",
      // "createContactId": 0,
      // "createDateTimeStamp": ""
    }
  }
}
