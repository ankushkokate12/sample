import { Component, OnInit, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { ContactsVo, ContactInfoVo, NoteVo, IssuesVo } from '../../../vo/datacolleciton-interface';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { DataCollectionService } from '../../../services/datacollection.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { Observable, Observer } from 'rxjs';
import { QuestionnaireService } from '../../../services/questionnaire.service'
import { QuestionSection } from '../../../vo/questionnaire.model';
import { Utility } from "../../../utils/utility";
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {
  contactsDetailsVo: Array<ContactsVo>;
  contactsVo: Array<ContactsVo> = [];
  contactInfoVo: ContactInfoVo;
  errorMsg: string = '';
  displayNotesDialog: boolean = false;
  displayIssuesDialog: boolean = false;
  isEditable: boolean;
  issuesAction: boolean;
  messages: any;
  overlayData: any;
  SectionMenu: any;
  taskID: number;
  userIssues: Array<IssuesVo> = [];
  contactId: number;
  contacts: any[];
  colsContacts: any[];
  globalQuestionData: QuestionSection[];
  issueContactId: any;
  taskMapId: any;
  saveDetails: any = {};
  nextRoute: any;
  annulPlan: any = [];
  q5500: any = [];
  menu: any;
  portalSubSectionCode: string = "DCContacts";

  constructor(private router: Router,
    private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private questionnaireService: QuestionnaireService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.taskID = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.initializeData();
    // this.getQuestionnaireMenus();
    this.getAnnualPlanQuestionnarieMenu();
    this.getQ5550Menu()
    this.getContactsData();
    this.colsContacts = [
      { field: 'contactName', header: 'Name' }
    ];
  }

  getContactsData() {
    this.dataCollectionService
      .getContactsData(this.taskID)
      .subscribe((response: ContactsVo[]) => {
        this.contactsVo = response;
        if (this.issueContactId != undefined) {
          this.getIssues(this.issueContactId)
        }
      },
        error => {
          this.contactsVo = [];
          this.errorMsg = error.statusText;
        }
      );
  }

  // canDeactivate() {
  //   return Observable.create((observer: Observer<boolean>) => {
  //     this.confirmationService.confirm({
  //       message: 'You have unsaved changes. Are you sure you want to leave this page?',
  //       accept: () => {
  //         observer.next(true);
  //         observer.complete();
  //       },
  //       reject: () => {
  //         observer.next(false);
  //         observer.complete();
  //       }
  //     });
  //   });
  // }

  showOverlay(event, data, op: OverlayPanel) {
    this.overlayData = data;
    op.toggle(event);
  }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }
  showIssuesDialog(rowData) {
    this.displayIssuesDialog = true;
    this.isEditable = true;
    this.issuesAction = true;
    this.overlayData = rowData.issues;
    this.contactId = rowData.contactId
  }
  onEditIssues(rowData) {
    this.displayIssuesDialog = true;
    this.isEditable = false;
    this.overlayData = rowData.issues;
    this.contactId = rowData.contactId
    this.issuesAction = true;
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  onIssuesDialogClose(data: any) {
    this.displayIssuesDialog = false;
    this.isEditable = false;
    this.getContactsData();
  }

  getIssues(currentContactId) {
    this.issueContactId = currentContactId
    this.contactsVo.forEach(data => {
      if (data.contactId == currentContactId) {
        this.overlayData = data.issues;
      }
    })
  }
  getIssuesCount() {
    return this.overlayData.length;
  }

  validateSubmit(sectionData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskID
    this.saveDetails.subSectionCode = "DCContacts";
    if (sectionData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;
    }
    // if(this.contactsVo.length==0){
    //   this.saveDetails.isSaveandContinue = false;
    // }
    // else{
    //   this.saveDetails.isSaveandContinue = true;
    // }
    console.log(this.saveDetails)
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response
          this.dataCollectionService.currentMenuStatus
          .pipe(distinctUntilChanged())
          .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
              if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });

          if (sectionData == "SaveAndNext") {
            if (!obj.isCompleted) {
              this.confirmationService.confirm({
                message: "Please update all mandatory fields before completing the section.",
                key: "rejectContactSecConfirmDialog",
                accept: () => {
                },
                reject: () => {
                  return;
                }
              });
            }
            else {
              if( this.q5500.length > 0){
                this.globalQuestionData = this.questionnaireService.getGlobalQuestionData();
                this.nextRoute = this.annulPlan[0].SubSectionCode;
                this.router.navigate(["../questionnaire", this.nextRoute], { relativeTo: this.route })
              }
              else{   
                this.router.navigate(["../employee-census"], { relativeTo: this.route });
              }
              // this.confirmationService.confirm({
              //   message: "You have not filled in the information in all the sections. Please update and submit",
              //   key: "rejectSignsubmitConfirmDialog",
              //   accept: () => {
              //   },
              //   reject: () => {
              //     return;
              //   }
              // });
            }
          }

        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
        }
      );
  }
  save() {
    this.validateSubmit("Save")
  }

  getAnnualPlanQuestionnarieMenu() {
    this.dataCollectionService.currentAnnualPlanQuestionnarieMenu
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        this.annulPlan = response;
        // this.setDcMenuStatus('QuestionnarieMenu')
      });
  }

  getQ5550Menu() {
    this.dataCollectionService.currentQ5550Menu
      .subscribe((response: any) => {
        this.q5500 = response;
        //this.setDcMenuStatus('QuestionnarieMenu')
      });
  }

  // getQuestionnaireMenus() {
  //   this.questionnaireService
  //     .getQuestionnaireMenu()
  //     .subscribe((response: any) => {
  //       this.menu = response;
  //       this.menu.forEach(section => {
  //         if (section.SectionId == "100") {
  //           section.subSections.forEach(subSection => {
  //             this.annulPlan.push(subSection)
  //           })

  //         }
  //         else if (section.SectionId == "200") {
  //           section.subSections.forEach(subSection1 => {
  //             this.q5500.push(subSection1)
  //           })
  //         }
  //       });
  //     });
  // }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");

  }

  initializeData() {
    this.contactsVo = [
      {
        "contactId": null,
        "contactName": "",
        "contactInfos": [{
          "name": "",
          "email": "",
          "mobile": "",
          "workPhone": ""
        }],
        "roles": [],
        "permissions": [],
        "issues": [
        ]
      }
    ]
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }
}
