import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcYearEndComponent } from './dc-year-end.component';

describe('DcYearEndComponent', () => {
  let component: DcYearEndComponent;
  let fixture: ComponentFixture<DcYearEndComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcYearEndComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcYearEndComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
