import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataCollectionService } from '../../../services/datacollection.service';
import { ConfirmationService } from 'primeng/api';
import { DataService } from '../../../services/data.service';
import { QuestionnaireService } from '../../../services/questionnaire.service';
import { QuestionSection } from '../../../vo/questionnaire.model';
import { SectionCompletion } from '../../../vo/datacolleciton-interface';
import { PermissionUtil } from '../../../utils/permission-util';
import { Utility } from 'src/app/common/utils/utility';
import { distinctUntilChanged } from 'rxjs/operators';
import { BehaviorSubject, Subject } from 'rxjs';

@Component({
  selector: 'app-dc-year-end',
  templateUrl: './dc-year-end.component.html',
  styleUrls: ['./dc-year-end.component.css']
})
export class DcYearEndComponent implements OnInit,OnDestroy {
  taskDetails: any;
  planId: number;
  planTypeCode: string;
  PlanDetails: {};
  questionnaire: any;
  errorMsg: string = '';
  menu: any;
  SectionMenu: any = [];
  employerCompanyData: string;
  principals: string;
  familyRelationship: string;
  business: string;
  contacts: string;
  census: string;
  approval: string;
  annulPlan: any = [];
  q5500: any = [];
  menuStatusBody: any;
  employerId: any;

  permissionObj: any = {};

  constructor(private router: Router, private activatedRoute: ActivatedRoute,
    private dataCollectionService: DataCollectionService,
    private dataService: DataService,
    private confirmationService: ConfirmationService,
    private questionnaireService: QuestionnaireService) {
  }

  ngOnInit() {
    this.getDcMenuStatus();
    // this.getAnnualPlanQuestionnarieMenu();
    // this.getQ5550Menu();

    if (!PermissionUtil.isPermissionSet()) {
      PermissionUtil.setPermission(JSON.parse(sessionStorage.getItem("permissionRights")));
    }
    this.permissionObj = PermissionUtil.getPermission();

    this.dataService.getDataCollectionMasterData();
    this.taskDetails = JSON.parse(localStorage.getItem('taskDetails'));
    this.planId = this.taskDetails.planId;
    this.planTypeCode = this.taskDetails.planTypeCode;

    this.PlanDetails = {
      "planId": this.planId,
      "PlanTypeCode": this.planTypeCode,
      "DataCollectionTaskID": this.taskDetails.taskId
    }

    this.getEmployeeInfoData();
    if (this.taskDetails.taskMapId != undefined) {
      this.menuStatusBody = {
        "subSectionCode": "",
        "TaskId": this.taskDetails.taskId,
        "EmployerId": this.taskDetails.taskMapId
      }
    }
    
    this.getMenuCompletionData();
    this.getQuestionnaireMenus();

    // if((this.employerId != undefined) && (this.employerId != null)){
    //  
    // }
  }

  getDcMenuStatus() {
    this.dataCollectionService.currentMenuStatus
      .subscribe((response: any) => {
        this.SectionMenu = response;
        this.setDcMenuStatus('dcMenu');
      });
  }


  getAnnualPlanQuestionnarieMenu() {
    this.dataCollectionService.currentAnnualPlanQuestionnarieMenu
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        this.annulPlan = response;
        // this.setDcMenuStatus('QuestionnarieMenu')
      });
  }

  getQ5550Menu() {
    this.dataCollectionService.currentQ5550Menu
      .subscribe((response: any) => {
        this.q5500 = response;
        //this.setDcMenuStatus('QuestionnarieMenu')
      });
  }

  setDcMenuStatus(sectionStr: string) {
      this.SectionMenu.forEach(sectionMenu => {
        if (sectionMenu.subSectionCode == "DCEmpCompData") {
          this.employerCompanyData = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCOwnership") {
          this.principals = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCFamilyRelationship") {
          this.familyRelationship = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCOtherBusiness") {
          this.business = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCContacts") {
          this.contacts = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCEmployeeCensus") {
          this.census = sectionMenu.isCompleted
        }
        else if (sectionMenu.subSectionCode == "DCApproval") {
          this.approval = sectionMenu.isCompleted
        }
      }
    )

    if (this.annulPlan.length > 0) {
      for (let i = 0; i < this.SectionMenu.length; i++) {
        for (let j = 0; j < this.annulPlan.length; j++) {
          if (this.annulPlan[j].SubSectionCode == this.SectionMenu[i].subSectionCode) {
            this.annulPlan[j].isCompleted = this.SectionMenu[i].isCompleted;
          }
        }
      }
      this.dataCollectionService.updateAnnualPlanQuestionnarieMenu(this.annulPlan);
    }

    if (this.q5500.length > 0) {
      for (let i = 0; i < this.q5500.length; i++) {
        for (let j = 0; j < this.SectionMenu.length; j++) {
          if (this.q5500[i].subSectionCode == this.SectionMenu[j].subSectionCode) {
            this.q5500[i].isCompleted = this.SectionMenu[j].isCompleted;
          }
        }
      }
        this.dataCollectionService.updateQ5550Menu(this.q5500);
    }
  }

  getMenuCompletionData() {
    this.dataCollectionService.getMenuStatus(this.menuStatusBody).subscribe((response: any) => {
      this.dataCollectionService.updateMenuStatus(response);
      this.SectionMenu = response;
      this.setDcMenuStatus("dcMenu");
    });
  }

  // getSecondArrayItem(id) {
  //   return this.SectionMenu.find(item => item.sectionId == id);
  // }

  getQuestionnaireMenus() {
    this.annulPlan = [];
    this.q5500 = [];
    this.questionnaireService
      .getQuestionnaireMenu(this.PlanDetails)
      .subscribe((response: any) => {
        this.menu = response;

        if(this.SectionMenu.length == 0){
          this.getDcMenuStatus();
        }

        this.menu.forEach(section => {
          if (section.SectionId == "100") {
            section.subSections.forEach(subSection => {
              subSection.isCompleted = false;
              this.annulPlan.push(subSection)
            })
          }
          else if (section.SectionId == "200") {
            section.subSections.forEach(subSection1 => {
              subSection1.isCompleted = false
              this.q5500.push(subSection1)
            })
          }
        });

        if (this.annulPlan.length > 0) {
          for (let i = 0; i < this.annulPlan.length; i++) {
            for (let j = 0; j < this.SectionMenu.length; j++) {
              if (this.annulPlan[i].SubSectionCode == this.SectionMenu[j].subSectionCode) {
                this.annulPlan[i].isCompleted = this.SectionMenu[j].isCompleted;
              }
            }
          }
        }

        if (this.q5500.length > 0) {
          for (let i = 0; i < this.q5500.length; i++) {
            for (let j = 0; j < this.SectionMenu.length; j++) {
              if (this.q5500[i].SubSectionCode == this.SectionMenu[j].subSectionCode) {
                this.q5500[i].isCompleted = this.SectionMenu[j].isCompleted;
              }
            }
          }
        }

         this.dataCollectionService.updateAnnualPlanQuestionnarieMenu(this.annulPlan);
         this.dataCollectionService.updateQ5550Menu(this.q5500);
      });
  }

  // getMenuCompletionData() {
  //   this.dataCollectionService
  //     .getMenuStatus()
  //     .subscribe((response: any[]) => {
  //       response.forEach(sectionMenu => {
  //         if (sectionMenu.sectionId == "employerData") {
  //           this.employerCompanyData = sectionMenu.isSave
  //         }
  //         else if (sectionMenu.sectionId == "principal") {
  //           this.principals = sectionMenu.isSave
  //         }
  //         else if (sectionMenu.sectionId == "family") {
  //           this.familyRelationship = sectionMenu.isSave
  //         }
  //         else if (sectionMenu.sectionId == "business") {
  //           this.business = sectionMenu.isSave
  //         }
  //         else {
  //           this.contacts = sectionMenu.isSave
  //         }
  //       });
  //     },
  //       error => {
  //         this.errorMsg = error.statusText;
  //       }
  //     );
  // }

  getEmployeeInfoData() {
    this.questionnaireService
      .getEmployeeInformationData(this.PlanDetails)
      .subscribe((response: QuestionSection[]) => {
        this.questionnaire = response;
        this.questionnaireService.setGlobalQuestionData(response);
      },
        error => {
          this.errorMsg = error.statusText;
        }
      );
  }
  onSectionChange() {
    this.questionnaireService.getEmployeeInformationData(this.PlanDetails);
    this.router.navigate(["/datacollection/datacollection-year-end/questionnaire"])
  }

  // onClose() {
  //   this.router.navigate(["/home/datacollection/datacollection-landing"])
  // }

  unsubscribe$:Subject<void> = new Subject();
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
