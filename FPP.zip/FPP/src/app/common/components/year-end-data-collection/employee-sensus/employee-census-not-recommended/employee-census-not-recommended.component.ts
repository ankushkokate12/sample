import { Component, OnInit, SimpleChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from 'src/app/common/services/data.service';
import { DataCollectionService } from 'src/app/common/services/datacollection.service';
import { distinctUntilChanged } from 'rxjs/operators';
import { Utility } from '../../../../utils/utility';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-employee-census-not-recommended',
  templateUrl: './employee-census-not-recommended.component.html',
  styleUrls: ['./employee-census-not-recommended.component.css']
})
export class EmployeeCensusNotRecommendedComponent implements OnInit {
  censusNotRecommendedForm: FormGroup;
  isOtherReason: boolean;
  isAknwolege: boolean = false;
  isEnableSaveNext: boolean = false;
  censusConsentsOptions: any;
  taskID: any;
  taskMapId: any;
  saveDetails: any = {};
  errorMsg: string = '';
  SectionMenu: any;
  dcCensusConsentDTO: any;
  censusNoConsentData: any;

  constructor(private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService) {

  }

  ngOnInit() {
    this.taskID = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.initializeData();
    this.getDcMasterData();
    this.loadForm();
    this.getNoConcentData();
    this.dataCollectionService.currentMenuStatus
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        for (let i = 0; i < response.length; i++) {
          if (response[i].subSectionCode == "DCEmployeeCensus") {
            this.isAknwolege = response[i].isCompleted;
            this.isEnableSaveNext = response[i].isCompleted;

          }
        }
      });
  }

  // ngOnChanges(changes: SimpleChanges) {    
  //     if (this.dcNoCensusConsentReasonTypeCode.value == "Other") {
  //       this.isOtherReason = true;
  //     } 
  // }


  getNoConcentData() {
    this.dataCollectionService.getCensusNoConsent(this.taskID).subscribe(
      (response: any) => {
        if (response[0].noCensusConsent != undefined) {
          this.censusNoConsentData = response[0];

          this.setFormData();
          if (this.dcNoCensusConsentReasonTypeCode.value == "Other") {
            this.isOtherReason = true;
          }
          if ((this.dcNoCensusConsentReasonTypeCode.value == "" || this.dcNoCensusConsentReasonTypeCode.value == null) && (this.noCensusConsentNote.value == "" || this.noCensusConsentNote.value == null)) {
            this.isAknwolege = false;
            this.isEnableSaveNext = false;
          }
        }
      },
      error => {

        this.errorMsg = error.statusText;
      }
    );
  }

  loadForm() {
    this.censusNotRecommendedForm = this.formBuilder.group({
      dcNoCensusConsentReasonTypeCode: [null, [Validators.required]],
      noCensusConsentNote: ['', [Validators.required]]
    });
  }

  setFormData() {
    if (this.censusNoConsentData.noCensusConsent == true) {
      this.censusNotRecommendedForm.get('dcNoCensusConsentReasonTypeCode').setValue(this.censusNoConsentData.dcNoCensusConsentReasonTypeCode);
      this.censusNotRecommendedForm.get('noCensusConsentNote').setValue(this.censusNoConsentData.noCensusConsentNote);
    }
    else {
      this.censusNotRecommendedForm.get('dcNoCensusConsentReasonTypeCode').setValue(null);
      this.censusNotRecommendedForm.get('noCensusConsentNote').setValue("");
    }
  }



  getDcMasterData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        if ((response.censusConsentOptions != undefined) && (response.censusConsentOptions != null)) {
          this.censusConsentsOptions = response.censusConsentOptions;
        }

      });
  }

  get dcNoCensusConsentReasonTypeCode() { return this.censusNotRecommendedForm.get('dcNoCensusConsentReasonTypeCode'); }
  get noCensusConsentNote() { return this.censusNotRecommendedForm.get('noCensusConsentNote'); }

  selectedReason(event: any) {
    if (event.target.value == 'Other') {
      this.isOtherReason = true;
      // this.censusNotRecommendedForm.controls['dcNoCensusConsentReasonTypeCode'].valueChanges.subscribe(value => {
      //   if (value == "Other") {
      //       this.censusNotRecommendedForm.controls['noCensusConsentNote'].setValidators(Validators.required);
      //       this.censusNotRecommendedForm.controls['noCensusConsentNote'].updateValueAndValidity();
      //     }
      //     else {
      //       this.censusNotRecommendedForm.controls['noCensusConsentNote'].clearValidators();
      //       this.censusNotRecommendedForm.controls['noCensusConsentNote'].updateValueAndValidity();
      //     }
      //   })
    }
    else {
      this.isOtherReason = false;
    }

    if (event.target.value == '' || event.target.value == null) {
      this.isAknwolege = false;
    }
  }
  acknowledge() {
    if (this.isAknwolege == true) {
      this.isEnableSaveNext = true;
    }
    else {
      this.isEnableSaveNext = false;
    }
  }

  // deleteAllEmployees() {
  //   this.confirmationService.confirm({
  //     message: 'This action will delete all records. You can download a copy of the records for reference before deleting all records.',
  //     header: 'Confirmation',
  //     icon: 'pi pi-exclamation-triangle',
  //     key: "dconsentDeleteAllEmpCensus",
  //     accept: () => {
  //       this.dataCollectionService
  //         .deleteAllEmployees(this.taskID)
  //         .subscribe(
  //           response => {
  //             this.dataCollectionService.completionTick("DCEmployeeCensus")
  //             // this.messageService.add({ key: 'CensusToast', severity: 'success', summary: 'SUCCESS', detail: "All records are deleted Successfully!!" });
  //             this.validateSubmit("SaveAndNext");
  //           },
  //           error => {
  //             this.errorMsg = Utility.showErrMsg(error);
  //             this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', detail: error.statusText });

  //           }
  //         )
  //     },
  //     reject: () => {
  //       return;
  //     }
  //   });
  // }

  // onSaveAndNext() {
  //   this.router.navigate(["../../approval"], { relativeTo: this.route })
  // }
  validateSubmit(sectionCmpData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskID
    this.saveDetails.subSectionCode = "DCEmployeeCensus";
    // this.saveDetails.isSaveandContinue = true;
    if (sectionCmpData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;
      if (this.isAknwolege == true) {
        this.confirmationService.confirm({
          message: "As you have opted to perform census submission later, we would be requiring your acknowledgment at the completion of employee census.",
          key: "acceptCensusNoConsentConfirmDialog",
          accept: () => {
            this.isAknwolege = false;
            this.isEnableSaveNext = false;
          },
          reject: () => {            
            return;
          }
        });
      }
      else {
        this.isAknwolege = false;
        this.isEnableSaveNext = false;
      }

    }

    this.dcCensusConsentDTO = {
      "taskMapId": this.taskMapId,
      "noCensusConsent": true,
      "noCensusConsentNote": this.noCensusConsentNote.value,
      "dcNoCensusConsentReasonTypeCode": this.dcNoCensusConsentReasonTypeCode.value
    }
    this.saveDetails.dcCensusConsentDTO = this.dcCensusConsentDTO
    if (sectionCmpData == "SaveAndNext" && this.dcNoCensusConsentReasonTypeCode.value == null || (sectionCmpData == "SaveAndNext" && this.dcNoCensusConsentReasonTypeCode.value == "Other" && (this.noCensusConsentNote.value == ""))) {
      this.confirmationService.confirm({
        message: "Please update all mandatory fields before completing the section.",
        key: "rejectCensusNoConsentConfirmDialog",
        accept: () => {
        },
        reject: () => {
          return;
        }
      });
    }
    else {
      this.dataCollectionService
        .saveAndSubmit(this.saveDetails)
        .subscribe(
          response => {
            this.dataCollectionService.updateCensusCount(0);
            let obj = response.response
            this.dataCollectionService.currentMenuStatus
              .pipe(distinctUntilChanged())
              .subscribe((response: any) => {
                this.SectionMenu = response;
                for (let i = 0; i < response.length; i++) {
                  if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                    this.SectionMenu[i].isCompleted = obj.isCompleted;
                  }
                }
                this.dataCollectionService.updateMenuStatus(this.SectionMenu);
              });

            if (sectionCmpData == "SaveAndNext") {
              if (!obj.isCompleted) {
                this.confirmationService.confirm({
                  message: "Please update all mandatory fields before completing the section.",
                  key: "rejectCensusNoConsentConfirmDialog",
                  accept: () => {
                  },
                  reject: () => {
                    return;
                  }
                });
              }
              else {

                this.router.navigate(["../../approval"], { relativeTo: this.route })
              }
            }
          },
          error => {
            this.errorMsg = Utility.showErrMsg(error);
          }
        );
    }
  }

  save() {
    this.validateSubmit("save");
  }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");
    // this.deleteAllEmployees();   
    // this.router.navigate(["../../approval"], { relativeTo: this.route })
  }
  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }
  initializeData() {
    this.censusNoConsentData = {
      dcCensusConsentId: null,
      taskMapId: null,
      noCensusConsent: false,
      noCensusConsentNote: "",
      dcNoCensusConsentReasonTypeCode: "",
      dcNoCensusConsentReasonType: ""
    };
  }

}
