import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCensusAddEmployeePopupComponent } from './employee-census-add-employee-popup.component';

describe('EmployeeCensusPopupComponent', () => {
  let component: EmployeeCensusAddEmployeePopupComponent;
  let fixture: ComponentFixture<EmployeeCensusAddEmployeePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeCensusAddEmployeePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCensusAddEmployeePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
