import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { EmployeeSensusInfo } from 'src/app/common/vo/datacolleciton-interface';
import { DataCollectionService } from 'src/app/common/services/datacollection.service';
import { Utility } from 'src/app/common/utils/utility';
import { DateFormatUtility } from 'src/app/common/utils/dateFormat-utility';
import { MessageService } from 'primeng/api';
import { DataService } from 'src/app/common/services/data.service';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';
import { DateValidators } from 'src/app/common/utils/censusValidations/dateOfBirth-validation';
import { ZeroCheckValidators } from 'src/app/common/utils/censusValidations/zeroCheck.validation';

export class FormGroupWarn extends FormGroup { warnings: any; }

@Component({
  selector: 'employee-census-add-employee-popup',
  templateUrl: './employee-census-add-employee-popup.component.html',
  styleUrls: ['./employee-census-add-employee-popup.component.css']
})
export class EmployeeCensusAddEmployeePopupComponent implements OnInit, OnChanges {
  @Input()
  display: boolean;
  @Input()
  isEditState: boolean;
  @Input()
  selectedEmployee: any;
  @Input()
  selectedEmployeeSSN: any;
  @Output()
  onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Output()
  editedRecord: EventEmitter<boolean> = new EventEmitter<boolean>();

  employeeSensusForm: FormGroup;
  employeeSensusInfo: EmployeeSensusInfo;
  errorMsg: string = '';
  isSucess: boolean = false;
  genderList: any = [];
  todayDate = DateFormatUtility.UTCToLocal(new Date())
  tasksId: any;
  plansID: any;
  isAddState: boolean;
  currentDate: any = new Date();
  planDueDate: any;
  yearRange: any = "1901:2099";
  startBirthYear: any = "1901"
  endBirthYear: any;
  endDeathYear: any;
  deathYearRange: any = "1901:2099";
  birthYearRange: any = "1901:2099";

  planYear: any;
  fiscalStartDt: any;
  fiscalEndDt: any;
  taskDetails: any;


  constructor(private formBuilder: FormBuilder,
    private messageService: MessageService,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService
  ) {
    this.planDueDate = DateFormatUtility.UTCToLocal(JSON.parse(localStorage.getItem('taskDetails')).dueDate);
    console.log(this.planDueDate)
    this.employeeSensusForm = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      middleInitial: [''],
      lastName: ['', [Validators.required]],
      gender: [''],
      ssn: ['', [Validators.required, Validators.pattern(ZeroCheckValidators.validateSSN())]],
      dateofBirth: [null, [Validators.required]],
      dateOfHire: [null, [Validators.required]],
      dos: [null],
      dateOfDeath: [null],
      dateOfRehire: [null],
      empStatus: [null],
      isOfficer: [''],
      companyDivision: [''],
      grossCompensation: [null, [Validators.required]],
      excludedCompensation: [null],
      severanceCompensation: [null],
      hours: [null, [Validators.required]],
      salariedEmployee: [''],
      // equivalencyRate: [null],
      ksalaryDeferral: [null],
      rothSalaryDeferral: [null],
      safeHarborContribution: [null],
      employerMatch: [null],
      // employerContribution: [null],
      otherContribution: [null],
      jobClassification: [''],
      isUnionEmployee: [''],
      // isActiveMilitary: [''],
      // isLeasedEmployee: [''],
      note: ['']
    },
      {
        validator: Validators.compose([
          DateValidators.dateLessThan('dateofBirth', 'dateOfHire', { 'DOBafterODOH': true }),
          DateValidators.dobLessOHD('dateofBirth', 'dateOfHire', { 'BirtDateafterHire': true }),
          DateValidators.dobLessthan99OHD('dateofBirth', 'dateOfHire', { 'DOBmorethat99': true }),
          DateValidators.DOBmorethatToday('dateofBirth', 'dateofBirth', { 'DOBmorethatToday': true }),

          DateValidators.dateLessThan('dateOfHire', 'dos', { 'DOSafterHire': true }),
          DateValidators.dateLessThan('dateOfHire', 'dateOfDeath', { 'DODafterODH': true }),
          DateValidators.dateLessThan('dateofBirth', 'dateOfDeath', { 'DODafterDOB': true }),
          DateValidators.dateLessThan('dateOfHire', 'dateOfRehire', { 'DORehireafterOH': true }),
          DateValidators.rehireTerminationDateCheck('dos', 'dateOfRehire', { 'DORHandDOS': true }),

          ZeroCheckValidators.zeroCheck('hours', 'note', { 'hoursZeroCheck': true }),
          ZeroCheckValidators.zeroCheck('grossCompensation', 'note', { 'grossCompensationZeroCheck': true }),

          ZeroCheckValidators.excludedCompensationCompareWithGrossCheck('excludedCompensation', 'grossCompensation', { 'excludedCompensationCompareWithGross': true }),
          
          ZeroCheckValidators.severanceCompCheck('severanceCompensation', 'dos', { 'severanceCompensationCheck': true }),
          this.dateLessThanPlanYear('dos','dateofBirth', { 'OhirebeforePlandate': true }),
        ])
      }
      // {validator: dateLessThan('dateofBirth', 'dateOfHire')}severanceCompensationCheck
    )
  }

  ngOnInit() {
    this.genderList = this.dataService.getGenderList();
    this.taskDetails = JSON.parse(localStorage.getItem("taskDetails"));
    this.tasksId = JSON.parse(localStorage.getItem('taskDetails')).taskId;

    this.plansID = JSON.parse(localStorage.getItem('taskDetails')).planId;
    this.setBirthYearDate();
    this.setFiscalYearDate(this.taskDetails);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState != true) {
      this.selectedEmployee = {
        firstName: "",
        middleInitial: "",
        lastName: "",
        gender: "",
        planID: null,
        ssn: "",
        dateofBirth: null,
        dateOfHire: null,
        dateOfDeath: null,
        dos: null,
        dateOfRehire: null,
        empStatus: null,
        isOfficer: false,
        companyDivision: "",
        grossCompensation: null,
        excludedCompensation: null,
        severanceCompensation: null,
        hours: null,
        salariedEmployee: false,
        // equivalencyRate: null,
        ksalaryDeferral: null,
        rothSalaryDeferral: null,
        safeHarborContribution: null,
        employerMatch: null,
        // employerContribution: null,
        otherContribution: null,
        jobClassification: "",
        isUnionEmployee: false,
        // isActiveMilitary: false,
        // isLeasedEmployee: false,
        note: ""
      }

      for (let inner in this.employeeSensusForm.controls) {
        this.employeeSensusForm.get(inner).markAsUntouched();
        this.employeeSensusForm.get(inner).updateValueAndValidity();
      }
    }
    else {
      for (let inner in this.employeeSensusForm.controls) {
        this.employeeSensusForm.get(inner).markAsTouched();
        this.employeeSensusForm.get(inner).markAsDirty();
        this.employeeSensusForm.get(inner).updateValueAndValidity();
      }
    }

    if (this.selectedEmployee.hasError == true) {
      this.isAddState = true
    }
    else {
      this.isAddState = false
    }

    this.employeeSensusForm.get('firstName').setValue(this.selectedEmployee.firstName);
    this.employeeSensusForm.get('middleInitial').setValue(this.selectedEmployee.middleInitial); 
    this.employeeSensusForm.get('lastName').setValue(this.selectedEmployee.lastName);
    this.employeeSensusForm.get('gender').setValue(this.selectedEmployee.gender);    
    this.employeeSensusForm.get('dateofBirth').setValue((this.selectedEmployee.dateofBirth == null || this.selectedEmployee.dateofBirth == "0001-01-01T05:00:00" || this.selectedEmployee.dateofBirth == "0001-01-01T00:00:00") ? null : DateFormatUtility.UTCToLocal(this.selectedEmployee.dateofBirth));
    this.employeeSensusForm.get('dateOfHire').setValue((this.selectedEmployee.dateOfHire == null || this.selectedEmployee.dateOfHire == "0001-01-01T05:00:00" || this.selectedEmployee.dateOfHire == "0001-01-01T00:00:00") ? null : DateFormatUtility.UTCToLocal(this.selectedEmployee.dateOfHire));
    this.employeeSensusForm.get('dos').setValue((this.selectedEmployee.dos == null || this.selectedEmployee.dos == "0001-01-01T05:00:00" || this.selectedEmployee.dos == "0001-01-01T00:00:00") ? null : DateFormatUtility.UTCToLocal(this.selectedEmployee.dos));
    this.employeeSensusForm.get('dateOfDeath').setValue((this.selectedEmployee.dateOfDeath == null || this.selectedEmployee.dateOfDeath == "0001-01-01T05:00:00" || this.selectedEmployee.dateOfDeath == "0001-01-01T00:00:00") ? null : DateFormatUtility.UTCToLocal(this.selectedEmployee.dateOfDeath));
    this.employeeSensusForm.get('dateOfRehire').setValue((this.selectedEmployee.dateOfRehire == null || this.selectedEmployee.dateOfRehire == "0001-01-01T05:00:00" || this.selectedEmployee.dateOfRehire == "0001-01-01T00:00:00") ? null : DateFormatUtility.UTCToLocal(this.selectedEmployee.dateOfRehire));
    this.employeeSensusForm.get('empStatus').setValue(this.selectedEmployee.empStatus);
    this.employeeSensusForm.get('isOfficer').setValue((this.selectedEmployee.isOfficer == "true") || (this.selectedEmployee.isOfficer == "True"));
    this.employeeSensusForm.get('companyDivision').setValue(this.selectedEmployee.companyDivision);
    this.employeeSensusForm.get('excludedCompensation').setValue(this.selectedEmployee.excludedCompensation);
    this.employeeSensusForm.get('severanceCompensation').setValue(this.selectedEmployee.severanceCompensation);
    this.employeeSensusForm.get('hours').setValue(this.selectedEmployee.hours);
    this.employeeSensusForm.get('grossCompensation').setValue(this.selectedEmployee.grossCompensation);
    this.employeeSensusForm.get('salariedEmployee').setValue((this.selectedEmployee.salariedEmployee == "true") || this.selectedEmployee.salariedEmployee == "True");
    // this.employeeSensusForm.get('equivalencyRate').setValue(this.selectedEmployee.equivalencyRate);
    this.employeeSensusForm.get('ksalaryDeferral').setValue(this.selectedEmployee.ksalaryDeferral);
    this.employeeSensusForm.get('rothSalaryDeferral').setValue(this.selectedEmployee.rothSalaryDeferral);
    this.employeeSensusForm.get('safeHarborContribution').setValue(this.selectedEmployee.safeHarborContribution);
    this.employeeSensusForm.get('employerMatch').setValue(this.selectedEmployee.employerMatch);
    // this.employeeSensusForm.get('employerContribution').setValue(this.selectedEmployee.employerContribution);
    this.employeeSensusForm.get('otherContribution').setValue(this.selectedEmployee.otherContribution);
    this.employeeSensusForm.get('jobClassification').setValue(this.selectedEmployee.jobClassification);
    this.employeeSensusForm.get('isUnionEmployee').setValue((this.selectedEmployee.isUnionEmployee == "true") || (this.selectedEmployee.isUnionEmployee == "True"));
    // this.employeeSensusForm.get('isActiveMilitary').setValue(this.selectedEmployee.isActiveMilitary == "true");
    // this.employeeSensusForm.get('isLeasedEmployee').setValue(this.selectedEmployee.isLeasedEmployee == "true");
    this.employeeSensusForm.get('note').setValue(this.selectedEmployee.note);

    // if (this.selectedEmployee.salariedEmployee == "True") {
    //   this.employeeSensusForm.controls['equivalencyRate'].enable();
    // }
    // else {
    //   this.employeeSensusForm.controls['equivalencyRate'].disable();
    //   this.employeeSensusForm.controls['equivalencyRate'].patchValue("");
    // }

    if ((this.selectedEmployee.hasError == true) && (this.selectedEmployee.hasError != undefined)) {
      this.employeeSensusForm.get('ssn').setValue(this.selectedEmployee.ssn);
    }
    else {
      if (this.isEditState == true) {
        if (this.selectedEmployeeSSN != undefined) {
          this.employeeSensusForm.get('ssn').setValue(this.selectedEmployeeSSN.toString());
        }
      }
      else {
        this.employeeSensusForm.get('ssn').setValue(this.selectedEmployee.ssn);
        this.employeeSensusForm.get('ssn').touched;
      }
    }

  }

  get firstName() { return this.employeeSensusForm.get('firstName'); }
  get middleInitial() { return this.employeeSensusForm.get('middleInitial'); }
  get lastName() { return this.employeeSensusForm.get('lastName'); }
  get gender() { return this.employeeSensusForm.get('gender'); }
  get ssn() { return this.employeeSensusForm.get('ssn'); }
  get dateofBirth() { return this.employeeSensusForm.get('dateofBirth'); }
  get dateOfHire() { return this.employeeSensusForm.get('dateOfHire'); }
  get dos() { return this.employeeSensusForm.get('dos'); }
  get dateOfDeath() { return this.employeeSensusForm.get('dateOfDeath'); }
  get dateOfRehire() { return this.employeeSensusForm.get('dateOfRehire'); }
  get empStatus() { return this.employeeSensusForm.get('empStatus'); }
  get isOfficer() { return this.employeeSensusForm.get('isOfficer'); }
  get companyDivision() { return this.employeeSensusForm.get('companyDivision'); }
  get grossCompensation() { return this.employeeSensusForm.get('grossCompensation'); }
  get excludedCompensation() { return this.employeeSensusForm.get('excludedCompensation'); }
  get severanceCompensation() { return this.employeeSensusForm.get('severanceCompensation'); }
  get hours() { return this.employeeSensusForm.get('hours'); }
  get salariedEmployee() { return this.employeeSensusForm.get('salariedEmployee'); }
  // get equivalencyRate() { return this.employeeSensusForm.get('equivalencyRate'); }
  get ksalaryDeferral() { return this.employeeSensusForm.get('ksalaryDeferral'); }
  get rothSalaryDeferral() { return this.employeeSensusForm.get('rothSalaryDeferral'); }
  get safeHarborContribution() { return this.employeeSensusForm.get('safeHarborContribution'); }
  get employerMatch() { return this.employeeSensusForm.get('employerMatch'); }
  // get employerContribution() { return this.employeeSensusForm.get('employerContribution'); }
  get otherContribution() { return this.employeeSensusForm.get('otherContribution'); }
  get jobClassification() { return this.employeeSensusForm.get('jobClassification'); }
  get isUnionEmployee() { return this.employeeSensusForm.get('isUnionEmployee'); }
  // get isActiveMilitary() { return this.employeeSensusForm.get('isActiveMilitary'); }
  // get isLeasedEmployee() { return this.employeeSensusForm.get('isLeasedEmployee'); }
  get note() { return this.employeeSensusForm.get('note'); }


  onHide() {
    this.employeeSensusForm.reset();
    this.messageService.clear('employeeCensusError');
    this.display = false;
    this.onClose.emit(this.display)
  }


  // dependedChangeListener() {
  //   if (this.employeeSensusForm.controls['salariedEmployee'].value == true) {
  //     this.employeeSensusForm.controls['equivalencyRate'].enable();

  //   }
  //   else {
  //     this.employeeSensusForm.controls['equivalencyRate'].disable();
  //     this.employeeSensusForm.controls['equivalencyRate'].patchValue("");
  //   }
  // }
  findInvalidControls(f: FormGroup) {
    if (f != undefined) {
      const invalid = [];
      const controls = f.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }

      return invalid.length;
    }
  }
  dateLessThanPlanYear(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
        const date1 = c.get(dateField1).value;
        if ((date1 !== null) && date1 > this.planDueDate) {
            return validatorField;
        }
        return null;
    };
  }
  setBirthYearDate() {
    let currentYr: any;
    currentYr = (new Date()).getFullYear();
    this.endBirthYear = currentYr;
    this.birthYearRange = this.setBirthYearRange();
  }

  setBirthYearRange() {
    return (this.startBirthYear + ':' + ((this.endBirthYear)));
  }
  setFiscalYearDate(taskDetails) {
    let currentYr: any;
    if ((taskDetails.year != undefined) && (taskDetails.year != null)) {
      currentYr = taskDetails.year;
    } else {
      currentYr = (new Date()).getFullYear();
    }
    this.planYear = currentYr;
    this.fiscalStartDt = (new Date(this.startBirthYear,0,1));
    this.fiscalEndDt = (new Date(currentYr+1,12,0));
    this.yearRange = this.setYearRange();
  }

  setYearRange() {
    return (this.startBirthYear + ':' + ((this.planYear) + 1));
  }
hasWarning: boolean;
findWarnings(){
  if(this.employeeSensusForm.errors.OhirebeforePlandate ||
    this.employeeSensusForm.errors.grossCompensationZeroCheck || this.employeeSensusForm.errors.hoursZeroCheck ||
    this.employeeSensusForm.errors.DORHandDOS || this.employeeSensusForm.errors.DORehireafterOH ||
    this.employeeSensusForm.errors.DODafterDOB || this.employeeSensusForm.errors.DODafterODH ||
    this.employeeSensusForm.errors.DOSafterHire || this.employeeSensusForm.errors.DOBmorethat99 ||
    this.employeeSensusForm.errors.BirtDateafterHire){
      this.hasWarning = true;
    }
    else{
      this.hasWarning = false;
    }
}

  onSubmit() {
    this.selectedEmployee.planID = this.plansID;
    this.selectedEmployee.firstName = this.firstName.value;   
    this.selectedEmployee.lastName = this.lastName.value;
    this.selectedEmployee.middleInitial = this.middleInitial.value;
    this.selectedEmployee.gender = this.gender.value;
    this.selectedEmployee.ssn = Utility.removeMasking(this.ssn.value),
    this.selectedEmployee.dateofBirth = this.dateofBirth.value;
    this.selectedEmployee.dateOfHire = this.dateOfHire.value;
    this.selectedEmployee.dos = this.dos.value;
    this.selectedEmployee.dateOfDeath = this.dateOfDeath.value;
    this.selectedEmployee.dateOfRehire = this.dateOfRehire.value;
    this.selectedEmployee.empStatus = this.empStatus.value
    this.selectedEmployee.isOfficer = this.isOfficer.value.toString();
    this.selectedEmployee.companyDivision = this.companyDivision.value;
    // this.selectedEmployee.grossCompensation = +this.grossCompensation.value;
    // this.selectedEmployee.excludedCompensation = +this.excludedCompensation.value;
    // this.selectedEmployee.severanceCompensation = +this.severanceCompensation.value;
    // this.selectedEmployee.hours = +this.hours.value;
    // this.selectedEmployee.equivalencyRate = +this.equivalencyRate.value;
    // this.selectedEmployee.ksalaryDeferral = +this.ksalaryDeferral.value;
    // this.selectedEmployee.rothSalaryDeferral = +this.rothSalaryDeferral.value;
    // this.selectedEmployee.safeHarborContribution = +this.safeHarborContribution.value;
    // this.selectedEmployee.employerMatch = +this.employerMatch.value;
    // this.selectedEmployee.employerContribution = +this.employerContribution.value;
    // this.selectedEmployee.otherContribution = +this.otherContribution.value;
    this.selectedEmployee.grossCompensation = +this.grossCompensation.value;
    this.selectedEmployee.excludedCompensation = (this.excludedCompensation.value == "" || this.excludedCompensation.value == null) ? null : +this.excludedCompensation.value;
    this.selectedEmployee.severanceCompensation = (this.severanceCompensation.value == "" || this.severanceCompensation.value == null) ? null : +this.severanceCompensation.value;
    this.selectedEmployee.hours = +this.hours.value;
    // this.selectedEmployee.equivalencyRate = (this.equivalencyRate.value == "" || this.equivalencyRate.value == null) ? null : +this.equivalencyRate.value;
    this.selectedEmployee.ksalaryDeferral = (this.ksalaryDeferral.value == "" || this.ksalaryDeferral.value == null) ? null : +this.ksalaryDeferral.value;
    this.selectedEmployee.rothSalaryDeferral = (this.rothSalaryDeferral.value == "" || this.rothSalaryDeferral.value == null) ? null : +this.rothSalaryDeferral.value;
    this.selectedEmployee.safeHarborContribution = (this.safeHarborContribution.value == "" || this.safeHarborContribution.value == null) ? null : +this.safeHarborContribution.value;
    this.selectedEmployee.employerMatch = (this.employerMatch.value == "" || this.employerMatch.value == null) ? null : +this.employerMatch.value;
    // this.selectedEmployee.employerContribution = (this.employerContribution.value == "" || this.employerContribution.value == null) ? null : +this.employerContribution.value;
    this.selectedEmployee.otherContribution = (this.otherContribution.value == "" || this.otherContribution.value == null) ? null : +this.otherContribution.value;
    this.selectedEmployee.jobClassification = this.jobClassification.value;
    this.selectedEmployee.salariedEmployee = this.salariedEmployee.value.toString();
    this.selectedEmployee.isUnionEmployee = this.isUnionEmployee.value.toString();
    // this.selectedEmployee.isActiveMilitary = this.isActiveMilitary.value.toString();
    // this.selectedEmployee.isLeasedEmployee = this.isLeasedEmployee.value.toString();
    this.selectedEmployee.note = this.note.value;

    if (this.selectedEmployee.hasError == true) {
      this.dataCollectionService
        .addEmployeeSensusInfo(this.selectedEmployee, this.tasksId)
        .subscribe(
          response => {
            this.dataCollectionService.completionTick("DCEmployeeCensus")
            this.onHide();
            if (this.selectedEmployee != 0) {
              // this.findWarnings()
              // response.hasWarning = this.hasWarning
              // console.log(response)
              this.editedRecord.emit(response);
            }
            // this.messageService.add({ key: 'employeeCensus', severity: 'success', summary: 'SUCCESS', detail: 'Employee Added successfully!!' });

          },
          error => {
            this.messageService.clear('employeeCensusError');
            this.errorMsg = Utility.showErrMsg(error);
            setTimeout(() => {
              this.messageService.add({ key: 'employeeCensusError', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
            }, 1000);
          }
        )
    }
    else {
      if (this.isEditState != true) {
        this.dataCollectionService
          .addEmployeeSensusInfo(this.selectedEmployee, this.tasksId)
          .subscribe(
            response => {
              this.dataCollectionService.completionTick("DCEmployeeCensus")
              this.onHide();
              // this.messageService.add({ key: 'employeeCensus', severity: 'success', summary: 'SUCCESS', detail: 'Employee Added successfully!!' });

            },
            error => {
              this.messageService.clear('employeeCensusError');
              this.errorMsg = Utility.showErrMsg(error);
              setTimeout(() => {
                this.messageService.add({ key: 'employeeCensusError', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
              }, 1000);
            }
          )
      }
      else {
        this.dataCollectionService
          .updateEmployeeSensusInfo(this.selectedEmployee, this.tasksId)
          .subscribe(
            response => {
              // this.findWarnings()
              // response.hasWarning = this.hasWarning
              // console.log(response)
              this.dataCollectionService.completionTick("DCEmployeeCensus")
              this.onHide();
              this.editedRecord.emit(response);
              // this.messageService.add({ key: 'employeeCensus', severity: 'success', summary: 'SUCCESS', detail: 'Employee Updated successfully!!' });

            },
            error => {
              this.messageService.clear('employeeCensusError');
              this.errorMsg = Utility.showErrMsg(error);
              setTimeout(() => {
                this.messageService.add({ key: 'employeeCensusError', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error });
              }, 1000);
            }
          )
      }
    }
  }
}
