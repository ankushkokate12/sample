import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCensusRecommendedComponent } from './employee-census-recommended.component';

describe('EmployeeCensusRecommendedComponent', () => {
  let component: EmployeeCensusRecommendedComponent;
  let fixture: ComponentFixture<EmployeeCensusRecommendedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeCensusRecommendedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCensusRecommendedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
