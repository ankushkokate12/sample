import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { DataCollectionService } from '../../../../services/datacollection.service';
import { EmployeeSensusDetails, EmployeeSensusInfo } from '../../../../vo/datacolleciton-interface';
import { ExportUtil, ExportFileType } from '../../../../utils/export-util';
import { SSNMasking } from '../../../../pipes/ssn-masking';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { Utility } from '../../../../utils/utility';
import { of, Observable, Observer } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { DirtyComponent } from 'src/app/guard/has-unsaved-notification-guard.guard';
import { DateFormatUtility } from 'src/app/common/utils/dateFormat-utility';

@Component({
  selector: 'app-employee-census-recommended',
  templateUrl: './employee-census-recommended.component.html',
  styleUrls: ['./employee-census-recommended.component.css']
})
export class EmployeeCensusRecommendedComponent implements OnInit, DirtyComponent {
  @ViewChild("fileInput", { static: false }) fileInputRef: ElementRef;
  displayNotesDialog: boolean = false;
  displayAddEmployeeSensusDialog: boolean = false;
  displayEmployeeSensusSummaryDialog: boolean = false
  displayEmployeeSensusFieldDescDialog: boolean = false
  isEmployeeEdit: boolean = false;
  visible: boolean;
  employeeSensusInfoList: any = [];
  employees: any[];
  colsEmployees: any[];
  errorMsg: string = '';
  employeeSensusDetails: EmployeeSensusDetails;
  employeeSensusInfo: Array<any> = [];
  selectedEmployee: any;
  showFileInput: boolean;
  filesToUpload = [];
  isEmpCensusSectiondisabled: boolean = false;
  taskID: any;
  taskMapId: any;
  saveDetails: any = {};
  planId: number;
  fullSSN: any;
  SectionMenu: any;
  isReadyReview: boolean = false;
  isEnableSaveNext: boolean = false;
  colsEmployeesErrors: any[];
  employeeCensusErrors: any = [];
  isShowImportErrors: boolean = false;
  failedRecordCount: any;
  errorHeader: any;
  firstpagination: any = 0;
  showLoadingIndicator: boolean;
  dcCensusConsentDTO: any;
  planDueDate: any;

  portalSubSectionCode: string = "EmployeeCensus";

  constructor(private router: Router, private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.taskID = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.planId = JSON.parse(localStorage.getItem('taskDetails')).planId;
    this.planDueDate = DateFormatUtility.UTCToLocal(JSON.parse(localStorage.getItem('taskDetails')).dueDate);
    this.getEmployeeSensusData();
    this.colsEmployees = [
      { field: 'firstName', header: 'First Name' },
      { field: 'lastName', header: 'Last Name' },
      { field: 'ssn', header: 'SSN' },
      { field: 'dateofBirth', header: 'Birth Date' },
      { field: 'dateOfHire', header: 'Original Hire Date' },
      { field: 'dos', header: 'Termination Date' },
      { field: 'grossCompensation', header: 'Gross Compensation' },
      { field: 'hours', header: 'Hours' }
    ];

    this.getMenuStatus();
    this.getNoConcentData();
    this.dataCollectionService.setPlanDate(this.planDueDate);
  }

  @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) {
    event.returnValue = !(this.employeeCensusErrors.filter(errors => (errors.warningOrError == "E")).length > 0);
  }

  // canDeactivate() {
  //   return (this.employeeCensusErrors.length>0);    
  // }this.allSectionStatus = response.filter(submitStatus => ((submitStatus.subSectionCode != "DCApproval") && submitStatus.isCompleted == true)).length;
  canDeactivate() {
    // if (this.employeeCensusErrors.length > 0) {
    if (this.employeeCensusErrors.filter(errors => (errors.warningOrError == "E")).length > 0) {
      return Observable.create((observer: Observer<boolean>) => {
        this.confirmationService.confirm({
          message: `You have unsaved changes.
          All rows with errors will be removed.  
          All rows with warnings will remain, but warnings will no longer be shown.
          Are you sure you want to leave this page?`,
          header: "Confirmation",
          icon: "pi pi-exclamation-triangle",
          key: "validateEmpCensus",
          accept: () => {
            observer.next(true);
            observer.complete();
          },
          reject: () => {
            observer.next(false);
            observer.complete();
          }
        });
      });
    }
    else {
      return Observable.create((observer: Observer<boolean>) => {
        observer.next(true);
        observer.complete();
      })
    }
  }

  getMenuStatus() {
    this.dataCollectionService.currentMenuStatus
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        for (let i = 0; i < response.length; i++) {
          if (response[i].subSectionCode == "DCEmployeeCensus") {
            this.isReadyReview = response[i].isCompleted;
            this.isEnableSaveNext = response[i].isCompleted;

          }
        }
      });
  }
  getNoConcentData() {
    this.dataCollectionService.getCensusNoConsent(this.taskID).subscribe(
      (response: any) => {
        if (response != null) {
          if (response[0].noCensusConsent != undefined || response[0].noCensusConsent != null) {
            if (response[0].noCensusConsent == true) {
              this.isReadyReview = false;
            }
            else {

            }
          }
        }
        else {

        }
      }
    );
  }

  getEmployeeSensusData() {
    this.showLoadingIndicator = true;
    this.dataCollectionService
      .getEmployeeSensusData(this.taskID)
      .subscribe((response) => {
        this.employeeSensusInfo = response;
        if ((response != undefined) && (response != null)) {
          this.dataCollectionService.updateCensusCount(response.length);
        } else {
          this.dataCollectionService.updateCensusCount(response.length);
        }
        this.firstpagination = 0;
        this.showLoadingIndicator = false;
        // this.isEmpCensusSectiondisabled =this.employeeSensusDetails.isOveride; 
      },
        error => {
          this.employeeSensusInfo = [];
          this.errorMsg = error.statusText;
          this.showLoadingIndicator = false;
        }
      );
  }

  geSSN() {

  }

  addEmployees() {
    this.isEmployeeEdit = false
    this.selectedEmployee = null;
    this.displayAddEmployeeSensusDialog = true;
  }

  editSingleEmployee(selectedEmployees) {
    this.isEmployeeEdit = true;
    this.selectedEmployee = selectedEmployees;
    this.displayAddEmployeeSensusDialog = true;
    if (selectedEmployees.hasError == true) {
      this.fullSSN = selectedEmployees.socialSecurityNumberLastFour;
    }
    else {
      this.dataCollectionService
        .getFullSSN(selectedEmployees.dataCollectionCensusInfoId)
        .subscribe((response) => {
          this.fullSSN = response.response;
          console.log(this.fullSSN)
          // this.isEmpCensusSectiondisabled =this.employeeSensusDetails.isOveride; 
        },
          error => {
            this.errorMsg = error.statusText;
          }
        );
    }


  }

  deleteSingleEmployee(selectedEmployees: any) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete this record?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      key: "empCensus",
      accept: () => {
        if (selectedEmployees.hasError == true) {

          this.employeeCensusErrors.forEach(rowIndex => {
            if (rowIndex.rowId == selectedEmployees.rowId) {
              this.employeeCensusErrors.splice(this.employeeCensusErrors.indexOf(rowIndex), 1)
              this.errorHeader = "Errors - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "E")).length + ",       Warnings - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "W")).length;
            }
          });

          this.employeeSensusInfo.forEach(selectedRecord => {
            if (selectedRecord.rowId == selectedEmployees.rowId) {
              this.employeeSensusInfo.splice(this.employeeSensusInfo.indexOf(selectedRecord), 1)
            }
          });
          this.dataCollectionService.updateCensusCount(this.employeeSensusInfo.length);


          // this.employeeCensusErrors.splice(this.employeeCensusErrors.indexOf(selectedEmployees), 1)
          // this.employeeSensusInfo.splice(this.employeeSensusInfo.indexOf(selectedEmployees), 1)
          // this.errorHeader=  "Error Details (" + this.employeeCensusErrors.length +")";
          if (this.employeeCensusErrors.length > 0) {
            this.isShowImportErrors = true;

          }
          else {
            this.isShowImportErrors = false;
            this.getEmployeeSensusData();
          }

        }
        else {
          this.dataCollectionService
            .deleteEmployeeSensusInfo(selectedEmployees.dataCollectionCensusInfoId)
            .subscribe(
              response => {
                this.dataCollectionService.completionTick("DCEmployeeCensus")
                this.isReadyReview = false;
                this.isEnableSaveNext = false;
                this.employeeSensusInfo.splice(this.employeeSensusInfo.indexOf(selectedEmployees), 1)
                this.dataCollectionService.updateCensusCount(this.employeeSensusInfo.length);
              },
              error => {
                this.errorMsg = Utility.showErrMsg(error);
                this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', detail: error.statusText });

              }
            )
        }

      },
      reject: () => {
        return;
      }
    });

  }

  highlightRecord(selectedRecord) {
    this.employeeSensusInfo.forEach(rowIndex => {
      if (rowIndex.rowId == selectedRecord.rowId) {
        this.editSingleEmployee(rowIndex);
      }
    });

  }


  readyForReview() {
    if (this.isReadyReview == true) {
      if ((this.employeeSensusInfo.filter(rothDeff => (rothDeff.rothSalaryDeferral != null && rothDeff.rothSalaryDeferral != "")).length == 0) && (this.employeeSensusInfo.filter(preTaxDeff => (preTaxDeff.ksalaryDeferral != null && preTaxDeff.ksalaryDeferral != "")).length == 0)) {
        this.confirmationService.confirm({
          message: "For plans that allow deferrals, usually at least one employee will have Pre-tax or Roth Deferrals",
          key: "rejectCensusConfirmDialog",
          accept: () => {
          },
          reject: () => {
            return (this.isReadyReview = false, this.isEnableSaveNext = false);

          }
        });
      }
      else if ((this.employeeSensusInfo.filter(rothDeff => (rothDeff.rothSalaryDeferral != null && rothDeff.rothSalaryDeferral != "")).length == this.employeeSensusInfo.length) && (this.employeeSensusInfo.filter(preTaxDeff => (preTaxDeff.ksalaryDeferral != null && preTaxDeff.ksalaryDeferral != "")).length == this.employeeSensusInfo.length)) {
        this.confirmationService.confirm({
          message: "Census records indicate all employees have deferrals.  Please be sure your census includes ALL employees, not just those with deferrals",
          key: "rejectCensusConfirmDialog",
          accept: () => {
          },
          reject: () => {
            return (this.isReadyReview = false, this.isEnableSaveNext = false);

          }
        });
      }
      else {
        this.isEnableSaveNext = true;
      }

      // let  a = (this.employeeSensusInfo.filter(rothDeff => (rothDeff.rothSalaryDeferral != null && rothDeff.rothSalaryDeferral != "")).length == 0)
      // console.log(a)
      this.isEnableSaveNext = true;
    }
    else {

      this.isEnableSaveNext = false;
    }
  }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }

  showSummaryDialog() {
    this.displayEmployeeSensusSummaryDialog = true;
  }

  onErrorEdit(editedRow) {
    this.employeeCensusErrors.forEach(rowIndex => {
      if (rowIndex.rowId == editedRow.rowId) {
        this.employeeCensusErrors.splice(this.employeeCensusErrors.indexOf(rowIndex), 1)
        // this.errorHeader = "Error Details (" + this.employeeCensusErrors.length + ")";
      }
    });

    this.errorHeader = "Errors - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "E")).length + ",      Warnings - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "W")).length;

    this.employeeSensusInfo.forEach(selectedRecord => {
      if (selectedRecord.rowId == editedRow.rowId) {
        //selectedRecord = editedRow;
        selectedRecord.hasError = false;
        selectedRecord.ssn = editedRow.socialSecurityNumberLastFour;
        selectedRecord.socialSecurityNumberLastFour = editedRow.socialSecurityNumberLastFour;
        selectedRecord.dataCollectionCensusInfoId = editedRow.dataCollectionCensusInfoId;
      }
    });

    if (this.employeeCensusErrors.length > 0) {
      this.isShowImportErrors = true;

    }
    else {
      this.isShowImportErrors = false;
      this.getEmployeeSensusData();
    }

  }

  addEmployeesDialogClose(data: any) {
    this.displayAddEmployeeSensusDialog = false;
    this.getMenuStatus()
    if (this.employeeCensusErrors.length == 0) {
      this.getEmployeeSensusData();

    }
    else {
      this.employeeSensusInfo;
    }
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  summaryDialogClose() {
    this.displayEmployeeSensusSummaryDialog = false;
  }

  clearSelectedFiles() {
    this.fileInputRef.nativeElement.value = null;
  }

  openFile() {
    this.clearSelectedFiles();
    if (this.employeeSensusInfo.length > 0) {
      this.confirmationService.confirm({
        message: 'This action will delete all records before uploading new records. You can download a copy of the records for reference before uploading new records',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        key: "deleteAllEmpCensus",
        accept: () => {
          // this.employeeSensusInfo = [];
          // this.employeeCensusErrors = [];
          // this.dataCollectionService
          //   .deleteAllEmployees(this.taskID)
          //   .subscribe(
          //     response => {
          //       this.dataCollectionService.completionTick("DCEmployeeCensus")
          //       this.isReadyReview = false;
          //       this.isEnableSaveNext = false;
          //       this.employeeSensusInfo = [];
          //       this.employeeCensusErrors = [];
          //       document.getElementById('file-input').click();
          //       if (this.employeeCensusErrors.length > 0) {
          //         this.isShowImportErrors = true;
          //       }
          //       else {
          //         this.isShowImportErrors = false;
          //       }
          //     },
          //     error => {
          //       this.errorMsg = Utility.showErrMsg(error);
          //       this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', detail: error.statusText });
          //       return;
          //     }
          //   )
          this.isReadyReview = false;
          this.isEnableSaveNext = false;
          // this.employeeSensusInfo = [];
          // this.employeeCensusErrors = [];
          document.getElementById('file-input').click();
          if (this.employeeCensusErrors.length > 0) {
            this.isShowImportErrors = true;
          }
          else {
            this.isShowImportErrors = false;
          }

        },
        reject: () => {
          return;
        }
      });
    }
    else {
      document.getElementById('file-input').click();
      if (this.employeeCensusErrors.length > 0) {
        this.isShowImportErrors = true;
      }
      else {
        this.isShowImportErrors = false;
      }
    }
  }

  onEmpCensusSectionDisabed() {
    if (this.isEmpCensusSectiondisabled == true && this.employeeSensusInfo.length > 0) {
      this.confirmationService.confirm({
        message: 'This action will delete all records. You can download a copy of the records for reference before deleting all records.',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        key: "deleteAllEmpCensus",
        accept: () => {
          this.dataCollectionService
            .deleteAllEmployees(this.taskID)
            .subscribe(
              response => {
                // this.messageService.add({ key: 'CensusToast', severity: 'success', summary: 'SUCCESS', detail: "All records are deleted Successfully!!" });
                this.employeeSensusInfo = [];
                // this.getEmployeeSensusData();
                this.firstpagination = 0;

              },
              error => {
                this.errorMsg = Utility.showErrMsg(error);
                this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', detail: error.statusText });

              }
            )
        },
        reject: () => {
          return this.isEmpCensusSectiondisabled = false;
        }
      });
    }
  }
  preliminaryError: any;

  onFileChange(event) {
    if (event.target.files.length > 0) {
      this.showFileInput = false;
      const file = event.target.files[0];
      const formFile = new FormData();
      formFile.append('taskId', this.taskID.toString());
      formFile.append('planId', this.planId.toString());
      formFile.append('formFile', file);
      this.showLoadingIndicator = true;
      this.dataCollectionService
        .importCensusFile(formFile)
        .subscribe((importData: any) => {
          this.dataCollectionService.completionTick("DCEmployeeCensus")
          this.isReadyReview = false;
          this.isEnableSaveNext = false;
          this.employeeCensusErrors = importData.importCensusErrors;
          this.employeeSensusInfo = importData.censusInfos;
          this.failedRecordCount = importData.validationResultCount.failed;
          this.errorHeader = "Errors - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "E")).length + ",      Warnings - " + this.employeeCensusErrors.filter(errors => (errors.warningOrError == "W")).length;
          if ((this.employeeSensusInfo != undefined) && (this.employeeSensusInfo != null)) {
            this.dataCollectionService.updateCensusCount(this.employeeSensusInfo.length);
          } else {
            this.dataCollectionService.updateCensusCount(this.employeeSensusInfo.length);
          }
          this.showLoadingIndicator = false;
          if (this.employeeCensusErrors.length > 0) {
            this.isShowImportErrors = true;
          }
          else {
            this.isShowImportErrors = false;
          }
          this.firstpagination = 0;
        },
          error => {
            this.showLoadingIndicator = false;
            this.errorMsg = Utility.showErrMsg(error);
            this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.preliminaryError });

          });
    }
  }



  downloadFieldDescription() {
    let link = document.createElement("a");
    link.download = "Field_Descriptions";
    link.href = "assets/files/Field_Descriptions.xlsx";
    link.click();
  }

  downloadEmpCensusExcel() {
    // this.dataCollectionService.CensusDownloadAsExcel(this.taskID)
    //   .subscribe(resultBlob => {
    //     ExportUtil.exportReportHandler(resultBlob, ExportFileType.EXCEL, 'employee_census_field.xlsx');
    //   });



    this.dataCollectionService.CensusDownloadAsExcel(this.taskID)
      .subscribe(blobData => {
        let downloadUrl;
        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
          //msSaveBlob only available for IE & Edge
          downloadUrl = window.navigator.msSaveBlob(blobData, 'employee_census_field.xlsx');
        } else {
          downloadUrl = window.URL.createObjectURL(blobData);
        }
        let link = document.createElement('a');
        link.href = downloadUrl;
        link.download = 'employee_census_field.xlsx';
        link.click();
      });
  }

  downloadEmpCensusTemplate() {
    let link = document.createElement("a");
    link.download = "Template_EmployeeCensus";
    link.href = "assets/files/Template_EmployeeCensus.xlsx";
    link.click();
  }

  deleteAllEmployees() {
    this.confirmationService.confirm({
      message: 'This action will delete all records. You can download a copy of the records for reference before deleting all records.',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      key: "deleteAllEmpCensus",
      accept: () => {
        this.dataCollectionService
          .deleteAllEmployees(this.taskID)
          .subscribe(
            response => {
              this.dataCollectionService.completionTick("DCEmployeeCensus")
              // this.messageService.add({ key: 'CensusToast', severity: 'success', summary: 'SUCCESS', detail: "All records are deleted Successfully!!" });
              this.employeeSensusInfo = [];
              this.employeeCensusErrors = [];
              if (this.employeeCensusErrors.length > 0) {
                this.isShowImportErrors = true;
              }
              else {
                this.isShowImportErrors = false;
              }
              this.getEmployeeSensusData();
            },
            error => {
              this.errorMsg = Utility.showErrMsg(error);
              this.messageService.add({ key: 'CensusToast', severity: 'error', summary: 'ERROR', detail: error.statusText });

            }
          )
      },
      reject: () => {
        return;
      }
    });
  }

  validateSubmit(sectionCmpData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskID
    this.saveDetails.subSectionCode = "DCEmployeeCensus";
    // this.saveDetails.isSaveandContinue = true;
    if (sectionCmpData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;

      if (this.isReadyReview == true) {
        this.confirmationService.confirm({
          message: "As you have opted to perform census submission later, we would be requiring your acknowledgment at the completion of employee census.",
          key: "acceptCensusConfirmDialog",
          accept: () => {
            this.isReadyReview = false;
            this.isEnableSaveNext = false;
          },
          reject: () => {
            return;
          }
        });
      }
      else {
        this.isReadyReview = false;
        this.isEnableSaveNext = false;
      }

    }
    this.dcCensusConsentDTO = {
      "taskMapId": this.taskMapId,
      "noCensusConsent": false,
      "noCensusConsentNote": null,
      "dcNoCensusConsentReasonTypeCode": null
    }
    this.saveDetails.dcCensusConsentDTO = this.dcCensusConsentDTO
    // if (this.employeeSensusInfo.length == 0) {
    //   this.saveDetails.isSaveandContinue = false;
    // }
    // else {
    //   this.saveDetails.isSaveandContinue = true;
    // }
    console.log(this.saveDetails)
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response
          this.dataCollectionService.currentMenuStatus
            .pipe(distinctUntilChanged())
            .subscribe((response: any) => {
              this.SectionMenu = response;
              for (let i = 0; i < response.length; i++) {
                if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                  this.SectionMenu[i].isCompleted = obj.isCompleted;
                }
              }
              this.dataCollectionService.updateMenuStatus(this.SectionMenu);
            });

          if (sectionCmpData == "SaveAndNext") {
            if (!obj.isCompleted) {
              this.confirmationService.confirm({
                message: "Please add employee census records before completing the section. If you wish to provide census information in a different way, please select the radio button accordingly.",
                key: "rejectCensusConfirmDialog",
                accept: () => {
                },
                reject: () => {
                  return;
                }
              });
            }
            else {
              this.router.navigate(["../../approval"], { relativeTo: this.route })
              // this.confirmationService.confirm({
              //   message: "Please update all mandatory fields before completing the section.",
              //   key: "rejectCensusConfirmDialog",
              //   accept: () => {
              //   },
              //   reject: () => {
              //     return;
              //   }
              // });
            }
          }
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
        }
      );
  }

  save() {
    this.validateSubmit("save");
  }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");
    // this.router.navigate(["../../approval"], { relativeTo: this.route })
  }
  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

}
