import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCensusSummaryPopupComponent } from './employee-census-summary-popup.component';

describe('EmployeeCensusSummaryPopupComponent', () => {
  let component: EmployeeCensusSummaryPopupComponent;
  let fixture: ComponentFixture<EmployeeCensusSummaryPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeCensusSummaryPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCensusSummaryPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
