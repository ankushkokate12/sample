import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'employee-census-summary-popup',
  templateUrl: './employee-census-summary-popup.component.html',
  styleUrls: ['./employee-census-summary-popup.component.css']
})
export class EmployeeCensusSummaryPopupComponent implements OnInit, OnChanges {
  @Input() 
  display: boolean;
  @Input() 
  viewSummaryData: [];
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  summaryDetails:Array<any> = [];
  colsSummary: any[];

  constructor() { }

  ngOnInit() {
    this.colsSummary = [
      { field: 'summary', header: '' },
      { field: 'total', header: 'Total' }
    ];
  }
  ngOnChanges(changes: SimpleChanges) {
    if(this.viewSummaryData!=undefined || this.viewSummaryData!=null){
    this.summaryDetails = [
      {
        summary: "Total Employees",
        total: this.viewSummaryData.length
      },
      {
        summary: "Total Employees Terminated",
        total: this.viewSummaryData.filter((count: any) => (count.dos != null && (count.dos !="0001-01-01T05:00:00" && count.dos !="0001-01-01T00:00:00"))).length
      },
      {
        summary: "Total Employees Rehired",
        total: this.viewSummaryData.filter((count: any) => (count.dateOfRehire != null && (count.dateOfRehire != "0001-01-01T05:00:00" && count.dateOfRehire != "0001-01-01T00:00:00"))).length

      },
      {
        summary: "Total Officer",
        total: this.viewSummaryData.filter((count: any) => (count.isOfficer == "True" || count.isOfficer == "true" || count.isOfficer == "1" || count.isOfficer == "Yes" || count.isOfficer == "YES" || count.isOfficer == "y" || count.isOfficer == "Y" || count.isOfficer == "T" || count.isOfficer == "t")).length
      },
      {
        summary: "Total Gross Compensation",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.grossCompensation, 0)
      },
      {
        summary: "Total Excluded Compensation",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.excludedCompensation, 0)
      },
      {
        summary: "Total Severance Compensation",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.severanceCompensation, 0)
      },
      {
        summary: "Total 401(k) Salary Deferral",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.ksalaryDeferral, 0)
      },
      {
        summary: "Total Roth Salary Deferral",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.rothSalaryDeferral, 0)
      },
      {
        summary: "Total Safe Harbor Contribution",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.safeHarborContribution, 0)
      },
      {
        summary: "Total Employer Match",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.employerMatch, 0)
      },
      {
        summary: "Total Employer Contribution",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.employerContribution, 0)
      },
      {
        summary: "Total Other Contribution",
        total: "$" + this.viewSummaryData.reduce((sum, item: any) => sum + item.otherContribution, 0)
      },
      {
        summary: "Total Union Employee",
        // total: this.viewSummaryData.filter((count: any) => count.isUnionEmployee == "True").length
        total: this.viewSummaryData.filter((count: any) => (count.isUnionEmployee == "True" || count.isUnionEmployee == "true" || count.isUnionEmployee == "1" || count.isUnionEmployee == "Yes" || count.isUnionEmployee == "YES" || count.isUnionEmployee == "y" || count.isUnionEmployee == "Y" || count.isUnionEmployee == "T" || count.isUnionEmployee == "t")).length
      },
      {
        summary: "Total Active Military",
        // total: this.viewSummaryData.filter((count: any) => count.isActiveMilitary == "True").length
        total: this.viewSummaryData.filter((count: any) => (count.isActiveMilitary == "True" || count.isActiveMilitary == "true" || count.isActiveMilitary == "1" || count.isActiveMilitary == "Yes" || count.isActiveMilitary == "YES" || count.isActiveMilitary == "y" || count.isActiveMilitary == "Y" || count.isActiveMilitary == "T" || count.isActiveMilitary == "t")).length
      }
    ]  
  }
  }
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);
  }


}
