import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataCollectionService } from 'src/app/common/services/datacollection.service';
import { EmployeeSensusDetails, EmployeeSensusInfo } from 'src/app/common/vo/datacolleciton-interface';
import { ExportUtil, ExportFileType } from 'src/app/common/utils/export-util';
import { SSNMasking } from 'src/app/common//pipes/ssn-masking';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router, ActivatedRoute, RouterEvent, NavigationEnd } from '@angular/router';
import { Utility } from 'src/app/common/utils/utility';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'employee-census',
  templateUrl: './employee-census.component.html',
  styleUrls: ['./employee-census.component.css']
})
export class EmployeeCensusComponent implements OnInit {
  @ViewChild("recommended", { static: false }) recommendedInputRef: ElementRef;
  selectedRadiButton: string;
  employeeSensusInfo: EmployeeSensusInfo[];
  taskID: any;
  errorMsg: string = '';
  censusCount: any;
  recommendedInput: boolean = true;
  getNoConsent: any;
  public destroyed = new Subject<any>();

  constructor(private router: Router, private dataCollectionService: DataCollectionService,
    private messageService: MessageService,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.taskID = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    this.dataCollectionService.currentCensusCount.subscribe(count => this.censusCount = count)
    this.dataCollectionService.getCensusNoConsent(this.taskID)
    this.getNoConcentData();
    // this.getDcMenuStatus()
    this.router.events.pipe(
      filter((event: RouterEvent) => event instanceof NavigationEnd),
      takeUntil(this.destroyed)
    ).subscribe(() => {
      if (this.router.url == "/home/datacollection/datacollection-year-end/employee-census") {
        this.getNoConcentData();
        // this.getDcMenuStatus()
      }

    });
  }
  ngOnDestroy(): void {
    this.destroyed.next();
    this.destroyed.complete();
  }

  // getDcMenuStatus() {
  //   this.dataCollectionService.currentCensusConsen
  //     .subscribe((response: any) => {
  //          this.getNoConsent = response[0];
  //          this.setDcNoConsent();
  //     });
  // }

  setDcNoConsent(){
    if (this.getNoConsent != null) {
      if (this.getNoConsent.noCensusConsent != undefined || this.getNoConsent.noCensusConsent != null) {
        if (this.getNoConsent.noCensusConsent == true) {
          this.router.navigate(["../employee-census/census-notrecommended"], { relativeTo: this.route })
          this.recommendedInput = false;
        }
        else {
          this.router.navigate(["../employee-census/census-recommended"], { relativeTo: this.route })
          this.recommendedInput = true
        }
      }
    }
    else {
      this.router.navigate(["../employee-census/census-recommended"], { relativeTo: this.route })
      this.recommendedInput = true
    }
  }
  

  getNoConcentData() {
    this.dataCollectionService.getCensusNoConsent(this.taskID).subscribe(
      (response: any) => {
        if(response != null){
         this.getNoConsent = response[0];
        }
           this.setDcNoConsent();
      }
    );
  }

  censusRecommendedSelection(value) {
    if (value == "recommended") {
      this.router.navigate(["../employee-census/census-recommended"], { relativeTo: this.route })
      this.recommendedInput = true;
    }
    else {
      this.router.navigate(["../employee-census/census-notrecommended"], { relativeTo: this.route })
      this.recommendedInput = false;
    }
  }
}