import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerCompanyDataComponent } from './employer-company-data.component';

describe('EmployerCompanyDataComponent', () => {
  let component: EmployerCompanyDataComponent;
  let fixture: ComponentFixture<EmployerCompanyDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployerCompanyDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployerCompanyDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
