import { Component, OnInit, HostListener } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  EmployerCompanyData,
  Employer,
  NoteVo,
  AddressVo,
  ContactNumberVo,
  SaveSubmitVo
} from "../../../vo/datacolleciton-interface";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { DataCollectionService } from "../../../services/datacollection.service";
import { DataService } from "../../../services/data.service";
import { ConfirmationService, MessageService } from "primeng/api";
import { Utility } from "../../../utils/utility";
import { Observable, Observer } from "rxjs";
import { CanComponentDeactivate } from "../../../guards/confirmation/confirmation.guard"
import { DateFormatUtility } from "../../../utils/dateFormat-utility";
import { DirtyComponent } from "src/app/guard/has-unsaved-notification-guard.guard";
import { distinctUntilChanged } from "rxjs/operators";
import { spaceValidator } from "src/app/common/pipes/removeTextBoxSpaces";

@Component({
  selector: "app-employer-company-data",
  templateUrl: "./employer-company-data.component.html",
  styleUrls: ["./employer-company-data.component.css"]
})
export class EmployerCompanyDataComponent implements OnInit,DirtyComponent {
  employerCompanyDataVo: EmployerCompanyData;
  addressList: Array<AddressVo> = [];
  contactList: Array<ContactNumberVo> = []
  employerCompanyDetailForm: FormGroup;
  errorMsg: string = "";
  displayNotesDialog: boolean = false;
  displayAddressDialog: boolean = false;
  displayContactDialog: boolean = false;
  fiscalDate: Array<any> = [];
  entityList: Array<any> = [];
  payrollFrequencyList: Array<any> = [];
  colsEmployerAddress: Array<any> = [];
  colsEmployerContact: Array<any> = [];
  isContatEdit: boolean = false;
  isAddressEdit: boolean = false;
  selectedContact: any;
  selectedAddress: any;
  employerData: Employer;
  taskMapId: number = 0;
  taskId: number = 0;
  employerId: number;
  isAddRecord: boolean = false;
  saveDetails: any = {};
  menuStatusBody: any = {}
  SectionMenu: any;
  showLoadingIndicator: boolean;
  isDirty = false;
  portalSubSectionCode: string = "DCEmpCompData";
  planYear:any;
  fiscalStartDt: any;
  fiscalEndDt:any;
  yearRange:any = "1901:2099";
  taskDetails:any;

  constructor(
    private formBuilder: FormBuilder,
    private dataCollectionService: DataCollectionService,
    private dataService: DataService,
    private router: Router,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.taskDetails = JSON.parse(localStorage.getItem("taskDetails"));
    this.taskMapId = this.taskDetails.taskMapId;
    this.taskId = this.taskDetails.taskId;
    this.planYear = DateFormatUtility.UTCToLocal(this.taskDetails.year);
    this.setFiscalYearDate(this.taskDetails);

    this.showLoadingIndicator = true;
    this.colsEmployerAddress = [
      { field: "addressTypeCode", header: "Type" },
      { field: "address1", header: "Address" }
    ];

    this.colsEmployerContact = [
      { field: "phoneNumberTypeCode", header: "Type" },
      { field: "phoneNumber", header: "Number" }
    ];

    this.initializeData();
    this.getEntityTypesData();
    this.getEmployerCompanyData();
    this.loadForm();
    this.menuStatusBody = {
      "SectionId": "",
      "TaskId": this.taskId,
      "EmployerId": this.employerData.employerId

    }
    // this.dataCollectionService.getMenuStatus(this.menuStatusBody);
    this.employerCompanyDetailForm.valueChanges.subscribe( e => this.isDirty = true );
  }

  @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) {
    event.returnValue = !this.employerCompanyDetailForm.dirty;
  }

  // canDeactivate() {
  //   return this.employerCompanyDetailForm.dirty;
  // }

  canDeactivate() {
    if (this.employerCompanyDetailForm.dirty) {
      return Observable.create((observer: Observer<boolean>) => {
        this.confirmationService.confirm({
          message: "You have unsaved changes. Are you sure you want to leave this page?",
          header: "Confirmation",
          icon: "pi pi-exclamation-triangle",
          key: "emplyerData",
          accept: () => {
            observer.next(true);
            observer.complete();
          },
          reject: () => {
            observer.next(false);
            observer.complete();
          }
        });
      });
    }
    else {
      return Observable.create((observer: Observer<boolean>) => {
        observer.next(true);
        observer.complete();
      })
    }
  }

  // getMenuCompletionData() {
  //   this.dataCollectionService.getMenuStatus(this.menuStatusBody).subscribe((response: any) => {
  //     this.dataCollectionService.updateMenuStatus(response);
  //   });
  // }

  loadForm() {
    this.employerCompanyDetailForm = this.formBuilder.group({
      companyName: [this.employerData.companyName, [Validators.required, spaceValidator]],
      ein: ['', [Validators.required, Validators.pattern("[0-9]{2}[-]*[0-9]{7}")]
      ],
      fiscalYear: [
        {
          value:
            this.employerData.fiscalYear == null
              ? this.employerData.fiscalYear
              : DateFormatUtility.UTCToLocal(this.employerData.fiscalYear),
          disabled: false
        },
        [Validators.required]
      ],
      entityTypeCode: [this.employerData.entityTypeCode, [Validators.required]],
      naicCode: [this.employerData.naicCode, [Validators.required, spaceValidator]],
      payrollProvider: [this.employerData.payrollProvider],
      payrlFreqTypes: [this.employerData.payrlFreqTypes, [Validators.required]]
    });
  }

  // convenience getter for easy access to form fields
  get companyName() {
    return this.employerCompanyDetailForm.get("companyName");
  }
  get ein() {
    return this.employerCompanyDetailForm.get("ein");
  }
  get fiscalYear() {
    return this.employerCompanyDetailForm.get("fiscalYear");
  }
  get naicCode() {
    return this.employerCompanyDetailForm.get("naicCode");
  }
  get entityTypeCode() {
    return this.employerCompanyDetailForm.get("entityTypeCode");
  }
  get payrollProvider() {
    return this.employerCompanyDetailForm.get("payrollProvider");
  }
  get payrlFreqTypes() {
    return this.employerCompanyDetailForm.get("payrlFreqTypes");
  }

  getEmployerCompanyData(operation?: string) {
    this.dataCollectionService.getEmployerCompanyData(this.taskId).subscribe(
      (response: EmployerCompanyData) => {
        if (response != null && response != undefined) {
          if (operation == "address") {
            this.addressList = response.addresses;
          } else if (operation == "contact") {
            this.contactList = response.contacts;
          } else {
            if (response.employer != null && response.employer != undefined) {
              this.employerCompanyDetailForm.markAsTouched();
              this.employerData = response.employer;
              this.dataCollectionService.dcEmployerCompanyData = this.employerData;
              this.isAddRecord = false;
            } else {
              this.isAddRecord = true;
            }
            this.addressList = response.addresses;
            this.contactList = response.contacts;
            this.setFormData();
          }
        }
        this.showLoadingIndicator = false;
      },
      error => {
        this.employerData = null;
        this.addressList = [];
        this.contactList = [];
        this.errorMsg = error.statusText;
      }
    );
  }

  getEntityTypesData() {
    this.dataService.dataCollectionMasterData.subscribe((response: any) => {
      if (response.entityTypes != undefined && response.entityTypes != null) {
        this.entityList = response.entityTypes;
      }

      if (
        response.payrollFrequencyTypes != undefined &&
        response.payrollFrequencyTypes != null
      ) {
        this.payrollFrequencyList = response.payrollFrequencyTypes;
      }
    });
  }

  setFormData() {
    this.employerCompanyDetailForm.controls["companyName"].setValue(
      this.employerData.companyName
    );
    this.employerCompanyDetailForm.controls["ein"].setValue(
      this.employerData.ein
    );
    this.employerCompanyDetailForm.controls["fiscalYear"].setValue(
      this.employerData.fiscalYear == null
        ? this.employerData.fiscalYear
        : DateFormatUtility.UTCToLocal(this.employerData.fiscalYear)
    );
    this.employerCompanyDetailForm.controls["entityTypeCode"].setValue(
      this.employerData.entityTypeCode
    );
    this.employerCompanyDetailForm.controls["naicCode"].setValue(
      this.employerData.naicCode
    );
    this.employerCompanyDetailForm.controls["payrollProvider"].setValue(
      this.employerData.payrollProvider
    );
    this.employerCompanyDetailForm.controls["payrlFreqTypes"].setValue(
      this.employerData.payrlFreqTypes
    );
  }

  setFiscalYearDate(taskDetails){
    let currentYr:any;
    if((taskDetails.year != undefined) && (taskDetails.year != null)){
      currentYr = taskDetails.year;
    }else{
      currentYr = (new Date()).getFullYear();
    }
    this.planYear = currentYr;
    this.fiscalStartDt = (new Date(currentYr,0,1));
    this.fiscalEndDt = (new Date(currentYr+1,12,0));
    this.yearRange = this.setYearRange();
  }

  setYearRange(){
    return (this.planYear + ':' + ((this.planYear)+1));
  }

  // getMenuCompletionData() {
  //   this.dataCollectionService
  //     .getMenuStatus(this.menuStatusBody)
  //     .subscribe((response: any[]) => {
  //       console.log(response)
  //     },
  //       error => {
  //         this.errorMsg = error.statusText;
  //       }
  //     );
  // }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }



  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }

  addAddressDialog() {
    this.isAddressEdit = false;
    this.selectedAddress = null;
    this.displayAddressDialog = true;
  }

  editAddressDialog(selectedAddress) {
    this.isAddressEdit = true;
    this.selectedAddress = selectedAddress;
    this.displayAddressDialog = true;
  }

  deleteEmployerCompanyAddress(selectedAddress) {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "emplyerData",
      accept: () => {
        this.dataCollectionService
          .deleteEmployerCompanyAddress(selectedAddress.id)
          .subscribe(
            response => {
              this.getEmployerCompanyData("address");
              this.dataCollectionService.completionTick("DCEmpCompData")
              // this.messageService.add({
              //   key: "employerData",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record deleted successfully!!"
              // });
            },
            error => {
              this.errorMsg = Utility.showErrMsg(error);
              this.messageService.add({
                key: "employerData",
                severity: "error",
                summary: "ERROR",
                detail: error.statusText
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onAddressDialogClose(data: any) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getEmployerCompanyData("address");
    }

    this.displayAddressDialog = false;
  }

  addContactDialog() {
    this.isContatEdit = false;
    this.selectedContact = null;
    this.displayContactDialog = true;
  }

  editContactDialog(selectedContact) {
    this.isContatEdit = true;
    this.selectedContact = selectedContact;
    this.displayContactDialog = true;
  }

  deleteEmployerCompanyContact(selectedContact) {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "emplyerData",
      accept: () => {
        this.dataCollectionService
          .deleteEmployerCompanyContact(selectedContact.id)
          .subscribe(
            response => {
              this.getEmployerCompanyData("contact");
              this.dataCollectionService.completionTick("DCEmpCompData")
              // this.messageService.add({
              //   key: "employerData",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record deleted successfully!!"
              // });
            },
            error => {
              this.errorMsg = Utility.showErrMsg(error);
              this.messageService.add({
                key: "employerData",
                severity: "error",
                summary: "ERROR",
                detail: error.statusText
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onContactDialogClose(data: any) {
    if (data.isSucess) {
      event.stopImmediatePropagation();
      data.isSucess = false;
      this.getEmployerCompanyData("contact");
    }

    this.displayContactDialog = false;
  }

  initializeData() {
    this.employerData = {
      employerId: null,
      taskMapId: null,
      companyName: "",
      ein: null,
      fiscalYear: null,
      entityTypeCode: "",
      naicCode: null,
      payrollProvider: "",
      payrlFreqTypes: []
    };
    this.addressList = [];
    this.contactList = [];
    //     this.entityList = this.dataService.getEntityTypeList();
    //     this.payrollFrequencyList = this.dataService.getPayrollFrequencyList();
  }

  onSaveAndNext() {
    this.onSubmit("SaveAndNext");
  }

  validateSubmit(sectionData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskId
    this.saveDetails.subSectionCode = "DCEmpCompData";
    if(sectionData == "SaveAndNext"){
      this.saveDetails.isSaveandContinue = true;
    }
    else{
      this.saveDetails.isSaveandContinue = false;
    }
    
    // if ((!this.employerCompanyDetailForm.valid) || (this.addressList.length == 0) || (this.contactList.length == 0)) {
    //   this.saveDetails.isSaveandContinue = false;
    // }
    // else {
    //   this.saveDetails.isSaveandContinue = true;
    // }
    console.log(this.saveDetails)
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response
          this.dataCollectionService.currentMenuStatus
            .pipe(distinctUntilChanged())
            .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
              if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });


          console.log(response.response)
          if (sectionData == "SaveAndNext") {
            if (!obj.isCompleted) {
              this.confirmationService.confirm({
                message: "Please update all mandatory fields before completing the section.",
                key: "rejectEmpCompDataConfirmDialog",
                accept: () => {
                },
                reject: () => {
                  return;
                }
              });
            }
            else {
              this.router.navigate(["../principals-owners"], { relativeTo: this.route });
              // this.confirmationService.confirm({
              //   message: "You have not filled in the information in all the sections. Please update and submit",
              //   key: "rejectSignsubmitConfirmDialog",
              //   accept: () => {
              //   },
              //   reject: () => {
              //     return;
              //   }
              // });
            }
          }
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);

        }
      );
  }

  onSubmit(clickedButton: any) {

    let employerDataObj: any = {};
    employerDataObj.taskMapId = this.employerData.taskMapId;
    employerDataObj.companyName = this.companyName.value;
    employerDataObj.ein = Utility.removeMasking(this.ein.value);
    employerDataObj.fiscalYear = this.fiscalYear.value;
    employerDataObj.entityTypeCode = ((this.entityTypeCode.value != "null")?this.entityTypeCode.value:null);
    employerDataObj.naicCode = this.naicCode.value;
    employerDataObj.payrollProvider = this.payrollProvider.value;
    employerDataObj.payrlFreqTypes = this.payrlFreqTypes.value;
    // this.validateSubmit();
    if (this.isAddRecord) {
      this.dataCollectionService
        .AddEmployerCompanyData(employerDataObj, this.taskId)
        .subscribe(
          response => {
            this.isDirty = false;
            this.employerCompanyDetailForm.markAsUntouched();
            this.employerCompanyDetailForm.markAsPristine();
            this.getEmployerCompanyData();
            this.validateSubmit(clickedButton);
            if(clickedButton != "SaveAndNext"){
              this.messageService.add({
                key: "employerData",
                severity: "success",
                summary: "SUCCESS",
                detail: "Employer company data added successfully!!"
              });
            }
          },
          error => {
            this.errorMsg = Utility.showErrMsg(error);
            this.messageService.add({
              key: "employerData",
              severity: "error",
              summary: "ERROR",
              sticky: true,
              detail: error.error.detail
            });
          }
        );
    } else {
      employerDataObj.taskMapId = this.taskMapId;
      this.dataCollectionService
        .UpdateEmployerCompanyData(employerDataObj, this.taskId)
        .subscribe(
          response => {
            this.isDirty = false;
            this.employerCompanyDetailForm.markAsUntouched();
            this.employerCompanyDetailForm.markAsPristine();
            this.getEmployerCompanyData();
            this.validateSubmit(clickedButton);
            if(clickedButton != "SaveAndNext"){
              this.messageService.add({
                key: "employerData",
                severity: "success",
                summary: "SUCCESS",
                detail: "Employer company data updated successfully!!"
              });
            }
          },
          error => {
            this.errorMsg = Utility.showErrMsg(error);
            this.messageService.add({
              key: "employerData",
              severity: "error",
              summary: "ERROR",
              sticky: true,
              detail: error.error.detail
            });
          }
        );
    }
  }
  

  // canDeactivate() {
  //   return Observable.create((observer: Observer<boolean>) => {
  //     this.confirmationService.confirm({
  //       message: 'You have unsaved changes. Are you sure you want to leave this page?',
  //       accept: () => {
  //         observer.next(true);
  //         observer.complete();
  //       },
  //       reject: () => {
  //         observer.next(false);
  //         observer.complete();
  //       }
  //     });
  //   });
  // }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"]);
  }
}
