import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FamilyRelationshipsPopupComponent } from './family-relationships-popup.component';

describe('FamilyRelationshipsPopupComponent', () => {
  let component: FamilyRelationshipsPopupComponent;
  let fixture: ComponentFixture<FamilyRelationshipsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FamilyRelationshipsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FamilyRelationshipsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
