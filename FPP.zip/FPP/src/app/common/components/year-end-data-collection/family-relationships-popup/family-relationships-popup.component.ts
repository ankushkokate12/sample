import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { DataCollectionService } from '../../../services/datacollection.service';
import { MessageService } from 'primeng/api';
import { Utility } from '../../../utils/utility';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'family-relationships-popup',
  templateUrl: './family-relationships-popup.component.html',
  styleUrls: ['./family-relationships-popup.component.css']
})
export class FamilyRelationshipsPopupComponent implements OnInit {
  familyRelationshipForm: FormGroup;
  relationshipList: Array<any> = [];
  relatedToList: Array<any> = [];
  errorMsg: string = '';
  isSucess: boolean = false;
  taskMapId: any;

  @Input()
  display: boolean;

  @Input()
  isEditState: boolean;

  @Input()
  selectedRelationship: any;

  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.familyRelationshipForm = this.formBuilder.group({
      name: ['', [Validators.required, spaceValidator]],
      relationship: ['', [Validators.required]],
      relatedTo: ['', [Validators.required]]
    });
  }

  ngOnInit() {
    //this.getFamilyRelationshipData();
    //this.relationshipList = this.dataService.getRelationshipType();
    this.isEditState = false;
  }

  getRelatedOwnershipList() {
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.dataCollectionService
      .getRelatedOwnershipList(this.taskMapId)
      .subscribe((response: any) => {
        this.relatedToList = response;
      },
        error => {
          this.errorMsg = error.statusText;
        }
      );
  }

  getDcMasterData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        this.relationshipList = response.relationshipTypes;
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState != true) {
      this.selectedRelationship = {
        name: "",
        relationshipTypeCode: "",
        dcEmployerOwnershipId: 0
      }
    }

    if (this.relatedToList.length == 0) {
      this.getRelatedOwnershipList();
    }

    if (this.relationshipList.length == 0) {
      this.getDcMasterData();
    }

    this.familyRelationshipForm.get('name').setValue(this.selectedRelationship.name);
    this.familyRelationshipForm.get('relationship').setValue(this.selectedRelationship.relationshipTypeCode);
    this.familyRelationshipForm.get('relatedTo').setValue(this.selectedRelationship.dcEmployerOwnershipId);
    this.isSucess = false;
  }

  // convenience getter for easy access to form fields
  get name() { return this.familyRelationshipForm.get('name'); }
  get relationship() { return this.familyRelationshipForm.get('relationship'); }
  get relatedTo() { return this.familyRelationshipForm.get('relatedTo'); }

  onHide() {
    this.familyRelationshipForm.reset();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display,
      });
    }
  }

  onSubmit() {
    let selectedRelationshipObj:any = {};
    selectedRelationshipObj.name = this.name.value;
    selectedRelationshipObj.relationshipTypeCode = this.relationship.value;
    selectedRelationshipObj.dcEmployerOwnershipId = this.relatedTo.value; 

    if(this.isEditState){
      selectedRelationshipObj.dcOwnerRelationshipId = this.selectedRelationship.dcOwnerRelationshipId;
    }
    this.dataCollectionService
    .updateFamilyRelationship(this.isEditState, selectedRelationshipObj)
    .subscribe(
      response => {
        this.isSucess = true;
        this.dataCollectionService.completionTick("DCFamilyRelationship")
        // if(this.isEditState){
        //   this.messageService.add({ key: 'familyRelationship', severity: 'success', summary: 'SUCCESS', detail: 'Record updated successfully!!' });
        // }else{
        //   this.messageService.add({ key: 'familyRelationship', severity: 'success', summary: 'SUCCESS', detail: 'Record added successfully!!' });
        // }
        this.onHide();
        
      },
      error => {
        this.isSucess = false;
        this.messageService.add({ key: 'familyRelationship', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
      }
    )

  }
}
