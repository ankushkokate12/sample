import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  NoteVo,
  FamilyRelationshipsVo
} from "../../../vo/datacolleciton-interface";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { DataCollectionService } from "../../../services/datacollection.service";
import { DataService } from "../../../services/data.service";
import { ConfirmationService, MessageService } from "primeng/api";
import { Observable, Observer } from "rxjs";
import { Utility } from "../../../utils/utility";
import { distinctUntilChanged } from "rxjs/operators";

@Component({
  selector: "family-relationships",
  templateUrl: "./family-relationships.component.html",
  styleUrls: ["./family-relationships.component.css"]
})
export class FamilyRelationshipsComponent implements OnInit {
  isRelationshipEdit: boolean;
  displayNotesDialog: boolean = false;
  displayFamilyRelationshipsDialog: boolean = false;
  colsFamilyRelationship: Array<any> = [];
  familyRelationshipList: Array<any> = [];
  errorMsg: string = "";
  selectedFamilyRelationship: FamilyRelationshipsVo;
  isFamilyRelationshipsdisabled: boolean = false;
  taskMapId: any;
  saveDetails: any = {};
  SectionMenu: any;
  portalSubSectionCode: string = "DCFamilyRelationship";
  taskId: any;

  constructor(
    private router: Router,
    private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.taskId = JSON.parse(localStorage.getItem("taskDetails")).taskId;
    this.colsFamilyRelationship = [
      { field: "name", header: "Name" },
      { field: "relationship", header: "Relation" },
      { field: "relatedTo", header: "Related To" }
    ];

    this.getFamilyRelationshipData();
  }

  getFamilyRelationshipData() {
    this.dataCollectionService.getFamilyRelationshipData(this.taskMapId).subscribe(
      response => {
        if (response.relationships != undefined) {
          if (response.relationships.noConsent != undefined) {
            this.familyRelationshipList = [];
            this.isFamilyRelationshipsdisabled = response.relationships.noConsent;
          } else {
            this.familyRelationshipList = response.relationships;
           // this.isFamilyRelationshipsdisabled = false;
          }
        } else {
          this.familyRelationshipList = [];
          this.isFamilyRelationshipsdisabled = false;
        }
      },
      error => {
        this.familyRelationshipList = [];
        this.errorMsg = error.statusText;
      }
    );
  }

  // canDeactivate() {
  //   return Observable.create((observer: Observer<boolean>) => {
  //     this.confirmationService.confirm({
  //       message: 'You have unsaved changes. Are you sure you want to leave this page?',
  //       accept: () => {
  //         observer.next(true);
  //         observer.complete();
  //       },
  //       reject: () => {
  //         observer.next(false);
  //         observer.complete();
  //       }
  //     });
  //   });
  // }

  addFamilyRelationshipsDialog() {
    this.isRelationshipEdit = false;
    this.selectedFamilyRelationship = null;
    this.displayFamilyRelationshipsDialog = true;
  }

  editFamilyRelationships(selectedFamilyRelationship) {
    this.isRelationshipEdit = true;
    this.selectedFamilyRelationship = selectedFamilyRelationship;
    this.displayFamilyRelationshipsDialog = true;
  }

  deleteFamilyRelationships(selectedFamilyRelationship) {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "familyRelation",
      accept: () => {
        this.dataCollectionService
          .deleteFamilyRelationshipData(
            selectedFamilyRelationship.dcOwnerRelationshipId
          )
          .subscribe(
            response => {
              this.getFamilyRelationshipData();
              this.dataCollectionService.completionTick("DCFamilyRelationship");
              // this.messageService.add({
              //   key: "family-relationship",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record Deleted successfully!!"
              // });
            },
            error => {
              this.errorMsg = Utility.showErrMsg(error);
              this.messageService.add({
                key: "family-relationship",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onFamilyRelationshipsDialogClose(data: any) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getFamilyRelationshipData();
    }
    this.displayFamilyRelationshipsDialog = false;
  }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }

  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  validateSubmit(sectionData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskId
    this.saveDetails.subSectionCode = "DCFamilyRelationship";
    this.saveDetails.isSaveandContinue = true;
    if (sectionData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;
    }
    console.log(this.saveDetails)
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response
          this.dataCollectionService.currentMenuStatus
          .pipe(distinctUntilChanged())
          .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
              if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });
          if (sectionData == "SaveAndNext") {
            if (!obj.isCompleted) {
              this.confirmationService.confirm({
                message: "Please update all mandatory fields before completing the section.",
                key: "rejectFamilyConfirmDialog",
                accept: () => {
                },
                reject: () => {
                  return;
                }
              });
            }
            else {      
              this.router.navigate(["../businesses"], { relativeTo: this.route });      
              // this.confirmationService.confirm({
              //   message: "You have not filled in the information in all the sections. Please update and submit",
              //   key: "rejectSignsubmitConfirmDialog",
              //   accept: () => {
              //   },
              //   reject: () => {
              //     return;
              //   }
              // });
            }
          }

        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);

        }
      );
  }

  save() {
    this.validateSubmit("Save");
  }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");    
  }
  onFamilyRelDisabed() {
    if (this.isFamilyRelationshipsdisabled == true && this.familyRelationshipList.length > 0) {
      this.confirmationService.confirm({
        message:
          "This action will delete all records. Do you want to proceed?",
        header: "Confirmation",
        icon: "pi pi-exclamation-triangle",
        key: "familyRelation",
        accept: () => {
          let familyConsentObj: any = {};
          familyConsentObj.taskMapId = this.taskMapId;
          familyConsentObj.noFamilyInfoConsent = true;

          this.dataCollectionService
            .updateFamilyConsent(familyConsentObj)
            .subscribe(
              response => {
                this.familyRelationshipList = [];
                this.dataCollectionService.completionTick("DCFamilyRelationship");
                // this.messageService.add({ key: 'messageToast', severity: 'success', summary: 'SUCCESS', detail: 'Family relationship records deleted successfully.' });
              },
              error => {
                this.messageService.add({ key: 'messageToast', severity: 'error', summary: 'ERROR', detail: error.error.detail });
              }
            )
        },
        reject: () => {
          return (this.isFamilyRelationshipsdisabled = false);
        }
      });
    }else{
      let familyConsentObj: any = {};
      familyConsentObj.taskMapId = this.taskMapId;
      familyConsentObj.noFamilyInfoConsent = this.isFamilyRelationshipsdisabled;

      this.dataCollectionService
        .updateFamilyConsent(familyConsentObj)
        .subscribe(
          response => {
            this.dataCollectionService.completionTick("DCFamilyRelationship");
            // this.messageService.add({ key: 'messageToast', severity: 'success', summary: 'SUCCESS', detail: 'Family relationship records deleted successfully.' });
          },
          error => {
            this.messageService.add({ key: 'messageToast', severity: 'error', summary: 'ERROR', detail: error.error.errorMessage });
          }
        );
    }
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"]);
  }
}
