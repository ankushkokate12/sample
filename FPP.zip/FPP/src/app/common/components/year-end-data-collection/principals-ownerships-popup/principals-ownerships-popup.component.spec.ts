import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrincipalsOwnershipsPopupComponent } from './principals-ownerships-popup.component';

describe('PrincipalsOwnershipsPopupComponent', () => {
  let component: PrincipalsOwnershipsPopupComponent;
  let fixture: ComponentFixture<PrincipalsOwnershipsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrincipalsOwnershipsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrincipalsOwnershipsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
