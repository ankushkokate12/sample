import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ContactNumberVo } from '../../../vo/datacolleciton-interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { DataCollectionService } from '../../../services/datacollection.service';
import { MessageService } from 'primeng/api';
import { Utility } from '../../../utils/utility';
import { spaceValidator } from 'src/app/common/pipes/removeTextBoxSpaces';

@Component({
  selector: 'principals-ownerships-popup',
  templateUrl: './principals-ownerships-popup.component.html',
  styleUrls: ['./principals-ownerships-popup.component.css']
})
export class PrincipalsOwnershipsPopupComponent implements OnInit, OnChanges {
  principalsOwnershipForm: FormGroup;
  principalsOwnersipTitleList: Array<any> = [];
  errorMsg: string = '';
  isSucess: boolean = false;
  employerId: any;

  @Input()
  display: boolean;

  @Input()
  isEditState: boolean;

  @Input()
  selectedPrincipalsOwnership: any;

  @Output()
  onClose: EventEmitter<any> = new EventEmitter<any>();
  taskMapId: any;

  constructor(private formBuilder: FormBuilder,
    private dataService: DataService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService) {
    this.principalsOwnershipForm = this.formBuilder.group({
      name: ['', [Validators.required, spaceValidator]],
      titleTypeCode: ['', [Validators.required]],
      ownershipPercent: ['', [Validators.required, Validators.max(100)]],
      isOfficer: [false, [Validators.required]],
    });
  }

  ngOnInit() {
    this.isEditState = false;
  }

  getDcMasterData() {
    this.dataService.dataCollectionMasterData
      .subscribe((response: any) => {
        this.principalsOwnersipTitleList = response.titleTypes;
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState != true) {
      this.selectedPrincipalsOwnership = {
        name: "",
        titleTypeCode: "",
        ownershipPercent: 0,
        isOfficer: false
      }
    }

    if((this.principalsOwnersipTitleList.length == 0) || (this.principalsOwnersipTitleList.length == 0)){
      this.getDcMasterData();
    }

    this.principalsOwnershipForm.get('name').setValue(this.selectedPrincipalsOwnership.name);
    this.principalsOwnershipForm.get('titleTypeCode').setValue(this.selectedPrincipalsOwnership.titleTypeCode);
    this.principalsOwnershipForm.get('ownershipPercent').setValue(this.selectedPrincipalsOwnership.ownershipPercent);
    this.principalsOwnershipForm.get('isOfficer').setValue(this.selectedPrincipalsOwnership.isOfficer);

  }

  // convenience getter for easy access to form fields
  get name() { return this.principalsOwnershipForm.get('name'); }
  get titleTypeCode() { return this.principalsOwnershipForm.get('titleTypeCode'); }
  get ownershipPercent() { return this.principalsOwnershipForm.get('ownershipPercent'); }
  get isOfficer() { return this.principalsOwnershipForm.get('isOfficer'); }

  onHide() {
    this.principalsOwnershipForm.reset();
    this.display = false;
    if (this.isSucess) {
      this.onClose.emit({
        isSucess: true,
        isDisplay: this.display,
        isEdit: this.isEditState,
        principalsOwnership: this.selectedPrincipalsOwnership
      });
    } else {
      this.onClose.emit({
        isSucess: false,
        isDisplay: this.display
      });
    }
  }

  onSubmit() {
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.selectedPrincipalsOwnership.taskMapId = this.taskMapId;
    this.selectedPrincipalsOwnership.name = this.name.value;
    this.selectedPrincipalsOwnership.titleTypeCode = this.titleTypeCode.value;
    this.selectedPrincipalsOwnership.ownershipPercent = +(this.ownershipPercent.value);
    this.selectedPrincipalsOwnership.isOfficer = this.isOfficer.value;
    this.dataCollectionService
      .updatePrincipalsOwnership(this.isEditState, this.selectedPrincipalsOwnership)
      .subscribe(
        response => {
          this.isSucess = true;
          this.dataCollectionService.completionTick("DCOwnership")
          // if(this.isEditState){
          //   this.messageService.add({ key: 'principalOwnership', severity: 'success', summary: 'SUCCESS', detail: 'Record updated successfully!!' });
          // }else{
          //   this.messageService.add({ key: 'principalOwnership', severity: 'success', summary: 'SUCCESS', detail: 'Record added successfully!!' });
          // }
          this.onHide();
        },
        error => {
          this.isSucess = false;
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'principalOwnership', severity: 'error', summary: 'ERROR', sticky: true, detail: error.error.detail });
        }
      )
  }
}