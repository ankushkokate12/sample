import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrincipalsOwnershipsComponent } from './principals-ownerships.component';

describe('PrincipalsOwnershipsComponent', () => {
  let component: PrincipalsOwnershipsComponent;
  let fixture: ComponentFixture<PrincipalsOwnershipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrincipalsOwnershipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrincipalsOwnershipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
