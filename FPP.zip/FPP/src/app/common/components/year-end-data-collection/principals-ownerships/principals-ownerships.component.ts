import { Component, OnInit } from "@angular/core";
import { DataCollectionService } from "../../../services/datacollection.service";
import { PrincipalsOwnershipVo } from "../../../vo/datacolleciton-interface";
import { Router, ActivatedRoute } from "@angular/router";
import { ConfirmationService, MessageService } from "primeng/api";
import { Observable, Observer } from "rxjs";
import { Utility } from "../../../utils/utility";
import { distinctUntilChanged } from "rxjs/operators";
import {ConfirmDialogModule} from 'primeng/confirmdialog';
//import {ConfirmationService} from 'primeng/api';

@Component({
  selector: "principals-ownerships",
  templateUrl: "./principals-ownerships.component.html",
  styleUrls: ["./principals-ownerships.component.css"]
})
export class PrincipalsOwnershipsComponent implements OnInit {
  isEditState: boolean;
  displayNotesDialog: boolean = false;
  displayPrincipalsOwnersDialog: boolean = false;
  colsPrincipalOwnership: any = [];
  principalOwnershipList: any = [];
  errorMsg: string = "";
  isPrincipalsOwnerEdit: boolean = false;
  selectedPrincipalsOwner: PrincipalsOwnershipVo;
  taskMapId: any;
  isOwnershipPercentage100:boolean = false;
  saveDetails: any ={};
  portalSubSectionCode:string = "DCOwnership";
  taskId: any;
  SectionMenu: any;

  constructor(
    private router: Router,
    private dataCollectionService: DataCollectionService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private route: ActivatedRoute) {}

  ngOnInit() {
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.taskId = JSON.parse(localStorage.getItem("taskDetails")).taskId;
    this.colsPrincipalOwnership = [
      { field: "name", header: "Name" },
      { field: "titleTypeCode", header: "Title" },
      { field: "isOfficer", header: "Officer" },
      { field: "ownershipPercent", header: "Ownership" }
    ];

    this.getPrincipalOwnershipData();
  }

  getPrincipalOwnershipData() {
    this.dataCollectionService
      .getPrincipalOwnershipData(this.taskMapId)
      .subscribe(
        (response: Array<PrincipalsOwnershipVo>) => {
          this.principalOwnershipList = response;

          if(this.principalOwnershipList.length > 0){
            let totalPercentage:number = 0;
           
            for(let i=0; i<this.principalOwnershipList.length;i++){
              totalPercentage += this.principalOwnershipList[i].ownershipPercent;
            }

            if(totalPercentage >= 100){
              this.isOwnershipPercentage100 = true;
            }else{
              this.isOwnershipPercentage100 = false;
            }
          }
        },
        error => {
          this.principalOwnershipList = [];
          this.errorMsg = error.error.detail;
        }
      );
  }

  // canDeactivate() {
  //   return Observable.create((observer: Observer<boolean>) => {
  //     this.confirmationService.confirm({
  //       message: 'You have unsaved changes. Are you sure you want to leave this page?',
  //       accept: () => {
  //         observer.next(true);
  //         observer.complete();
  //       },
  //       reject: () => {
  //         observer.next(false);
  //         observer.complete();
  //       }
  //     });
  //   });
  // }

  addPrincipalsOwnersDialog() {
    this.isPrincipalsOwnerEdit = false;
    this.selectedPrincipalsOwner = null;
    this.displayPrincipalsOwnersDialog = true;
  }
  editditPrincipalsOwners(selectedPrincipalsOwner) {
    this.isPrincipalsOwnerEdit = true;
    this.selectedPrincipalsOwner = selectedPrincipalsOwner;
    this.displayPrincipalsOwnersDialog = true;
  }

  deletePrincipalsOwners(selectedPrincipalsOwner) {
    this.confirmationService.confirm({
      message: "Are you sure that you want to delete this record?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      key: "pricipalOwnerships",
      accept: () => {
        this.dataCollectionService
          .deletePrincipalsOwnershipData(
            selectedPrincipalsOwner.dataCollectionEmployerOwnershipId
          )
          .subscribe(
            response => {
              this.getPrincipalOwnershipData();
              this.dataCollectionService.completionTick("DCOwnership")
              // this.messageService.add({
              //   key: "principalToast",
              //   severity: "success",
              //   summary: "SUCCESS",
              //   detail: "Record deleted successfully!!"
              // });
            },
            error => {
              this.messageService.add({
                key: "principalToast",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error.errorMessage
              });
            }
          );
      },
      reject: () => {
        return;
      }
    });
  }

  onPrincipalsOwnersDialogClose(data: any) {
    if (data.isSucess) {
      data.isSucess = false;
      this.getPrincipalOwnershipData();
    }
    this.displayPrincipalsOwnersDialog = false;
  }

  showNotesDialog() {
    this.displayNotesDialog = true;
  }

  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }

  validateSubmit(sectionData: any) {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.taskId
    this.saveDetails.subSectionCode = "DCOwnership";
    // this.saveDetails.isSaveandContinue = true;


    if (sectionData == "SaveAndNext") {
      this.saveDetails.isSaveandContinue = true;
    }
    else {
      this.saveDetails.isSaveandContinue = false;
    }
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
           let obj = response.response
          this.dataCollectionService.currentMenuStatus
          .pipe(distinctUntilChanged())
          .subscribe((response: any) => {
            this.SectionMenu = response;
            for (let i = 0; i < response.length; i++) {
                if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
                  this.SectionMenu[i].isCompleted = obj.isCompleted;
              }
            }
            this.dataCollectionService.updateMenuStatus(this.SectionMenu);
          });

          if (sectionData == "SaveAndNext") {
            if (!obj.isCompleted) {
              this.confirmationService.confirm({
                message: "Please update all mandatory fields before completing the section.",
                key: "rejectPricipalConfirmDialog",
                accept: () => {
                },
                reject: () => {
                  return;
                }
              });
            }
            else {      
              this.router.navigate(["../family-relationships"],{ relativeTo: this.route});    
              // this.confirmationService.confirm({
              //   message: "You have not filled in the information in all the sections. Please update and submit",
              //   key: "rejectSignsubmitConfirmDialog",
              //   accept: () => {
              //   },
              //   reject: () => {
              //     return;
              //   }
              // });
            }
          }

        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);

        }
      );
  }

  save(){
    this.validateSubmit("Save");
  }

  onSaveAndNext() {
    this.validateSubmit("SaveAndNext");   
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"]);
  }
}
