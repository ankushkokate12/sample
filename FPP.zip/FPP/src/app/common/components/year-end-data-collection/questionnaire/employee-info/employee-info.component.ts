import { Component, OnInit, SimpleChanges, OnDestroy, HostListener } from '@angular/core';
import { Router, ActivatedRoute, RouterEvent, NavigationEnd } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { QuestionFormGeneratorService } from '../../../../services/question-form-generator.service';
import { QuestionSection, Question, AnswersData } from '../../../../vo/questionnaire.model';
import { QuestionnaireService } from '../../../../services/questionnaire.service';
import { MessageService, ConfirmationService } from 'primeng/api';
import { Utility } from '../../../../utils/utility';
import { filter, takeUntil, distinctUntilChanged } from 'rxjs/operators';
import { Subject, Observable, Observer } from 'rxjs';
import { DataCollectionService } from 'src/app/common/services/datacollection.service';
import { DirtyComponent } from 'src/app/guard/has-unsaved-notification-guard.guard';

@Component({
  selector: 'employee-info',
  templateUrl: './employee-info.component.html',
  styleUrls: ['./employee-info.component.css']
})
export class EmployeeInfoComponent implements OnInit, OnDestroy, DirtyComponent {
  isEditState: boolean;
  displayNotesDialog: boolean = false;
  questionsForm: FormGroup;
  sectionQuestions: any;
  questionnaire: any;
  errorMsg: string = '';
  planId: number;
  planTypeCode: string;
  PlanDetails: {};
  selectedAnswers: any = [];
  tasksId: number;
  taskMapId: any;
  nextRoute: any;
  lastRoute: boolean;
  sectionName: string;
  SectionMenu: any;
  answers: any[];
  subSectionId: any;
  globalQuestionData: QuestionSection[];
  saveDetails: any = {};
  public destroyed = new Subject<any>();
  menu: any;
  annulPlan: any = [];
  q5500: any = [];
  nextSection: boolean;
  portalSubSectionCode: string = "";
  isDirty = false;

  constructor(private router: Router,
    private questionControlService: QuestionFormGeneratorService,
    private questionnaireService: QuestionnaireService,
    private dataCollectionService: DataCollectionService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private route: ActivatedRoute) {
    this.globalQuestionData = this.questionnaireService.getGlobalQuestionData();
  }

  @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) {
    event.returnValue = !this.questionsForm.dirty;
  }

  //  canDeactivate() {
  //    return this.questionsForm.dirty;
  //  }
  canDeactivate() {
    if((this.questionsForm != undefined) && (this.questionsForm != null)){
      if (this.questionsForm.dirty) {
        return Observable.create((observer: Observer<boolean>) => {
          this.confirmationService.confirm({
            message: "You have unsaved changes. Are you sure you want to leave this page?",
            header: "Confirmation",
            icon: "pi pi-exclamation-triangle",
            key: "Questionare",
            accept: () => {
              observer.next(true);
              observer.complete();
            },
            reject: () => {
              observer.next(false);
              observer.complete();
            }
          });
        });
      }
      else {
        return Observable.create((observer: Observer<boolean>) => {
          observer.next(true);
          observer.complete();
        })
      }
    }else{
      return Observable.create((observer: Observer<boolean>) => {
        observer.next(true);
        observer.complete();
      })
    }

  }

  ngOnInit() {
    if ((this.questionsForm != undefined) && (this.questionsForm != null)) {
      this.questionsForm.valueChanges.pipe(distinctUntilChanged()).subscribe(e => this.isDirty = true);
    }
    this.getAnnualPlanQuestionnarieMenu();
    this.getQ5550Menu();
    this.planId = JSON.parse(localStorage.getItem('taskDetails')).planId;
    this.planTypeCode = JSON.parse(localStorage.getItem('taskDetails')).planTypeCode;
    this.taskMapId = JSON.parse(localStorage.getItem('taskDetails')).taskMapId;
    this.tasksId = JSON.parse(localStorage.getItem('taskDetails')).taskId;
    this.PlanDetails = {
      "planId": this.planId,
      "PlanTypeCode": this.planTypeCode,
      "DataCollectionTaskID": this.tasksId
    }

    this.getEmployeeInfoData();
    //this.getQuestionnaireMenus();
    this.router.events.pipe(
      filter((event: RouterEvent) => event instanceof NavigationEnd),
      takeUntil(this.destroyed)
    ).subscribe(() => {
      this.getEmployeeInfoData();
      //this.getQuestionnaireMenus();
    });
  }
  getAnnualPlanQuestionnarieMenu() {
    this.dataCollectionService.currentAnnualPlanQuestionnarieMenu
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        this.annulPlan = response;
        // this.setDcMenuStatus('QuestionnarieMenu')
      });
  }

  getQ5550Menu() {
    this.dataCollectionService.currentQ5550Menu
      .subscribe((response: any) => {
        this.q5500 = response;
        //this.setDcMenuStatus('QuestionnarieMenu')
      });
  }
  ngOnDestroy(): void {
    this.destroyed.next();
    this.destroyed.complete();
  }

  getEmployeeInfoData() {
    if (this.globalQuestionData == undefined) {
      this.questionnaireService.getEmployeeInformationData(this.PlanDetails)
        .subscribe(Response => {
          this.globalQuestionData = Response;
          this.getSelectedSectionQuestions();
        });
    }
    else {
      this.globalQuestionData = this.questionnaireService.getGlobalQuestionData();
      this.getSelectedSectionQuestions();
    }
  }
  getSelectedSectionQuestions() {
    for (let i = 0; i < this.globalQuestionData.length; i++) {
      if (this.route.snapshot.paramMap.get('id') === this.globalQuestionData[i].SubsectionId) {
        this.sectionQuestions = this.globalQuestionData[i].questions;
        this.sectionName = this.globalQuestionData[i].SubsectionName;
        this.subSectionId = this.globalQuestionData[i].SubsectionId;
        this.answers = this.globalQuestionData[i].Answer;
        this.setFormData();
        if (this.globalQuestionData.length == i + 1) {
          this.lastRoute = true;
          this.nextSection = false;
        }
        else if (i == 0) {
          this.nextSection = true;
          this.lastRoute = true;
        }
        else {
          this.nextRoute = this.globalQuestionData[i + 1].SubsectionId;
          this.lastRoute = false;
          this.nextSection = true;
        }
      }
    }

  }


  setFormData() {
    this.questionsForm = this.questionControlService.getQuestionsFormGroup(this.sectionQuestions, this.answers);
  };
  showNotesDialog() {
    this.portalSubSectionCode = this.subSectionId;
    if ((this.portalSubSectionCode != undefined) && (this.portalSubSectionCode != null)) {
      this.displayNotesDialog = true;
    }
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }

  validateSubmit() {
    this.saveDetails.taskMapId = this.taskMapId;
    this.saveDetails.taskId = this.tasksId
    this.saveDetails.subSectionCode = this.subSectionId;
    this.saveDetails.isSaveandContinue = true;
    this.dataCollectionService
      .saveAndSubmit(this.saveDetails)
      .subscribe(
        response => {
          let obj = response.response;

          this.dataCollectionService.currentMenuStatus
            .pipe(distinctUntilChanged())
            .subscribe((response: any) => {
              this.SectionMenu = response;
              for (let i = 0; i < response.length; i++) {
                if (this.SectionMenu[i].subSectionCode == obj.SubSectionCode) {
                  this.SectionMenu[i].isCompleted = obj.isCompleted;
                }
              }
              this.dataCollectionService.updateMenuStatus(this.SectionMenu);
            });

          if (obj.SubSectionCode == "201") {
            this.dataCollectionService.currentQ5550Menu.subscribe((response: any) => {
              this.q5500 = response;
              for (let i = 0; i < response.length; i++) {
                if (this.q5500[i].SubSectionCode == obj.SubSectionCode) {
                  this.q5500[i].isCompleted = obj.isCompleted;
                }
              }
              this.dataCollectionService.updateQ5550Menu(this.q5500);
            });
          } else {
            this.dataCollectionService.currentAnnualPlanQuestionnarieMenu.subscribe((response: any) => {
              this.annulPlan = response;
              for (let i = 0; i < response.length; i++) {
                if (this.annulPlan[i].SubSectionCode == obj.SubSectionCode) {
                  this.annulPlan[i].isCompleted = obj.isCompleted;
                }
              }
              this.dataCollectionService.updateAnnualPlanQuestionnarieMenu(this.annulPlan);
            });
          }

        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);

        }
      );
  }

  onSaveAndNext() {
    this.onSave("SaveAndNext");
  }

  SaveAnwsers() {
    for (let i = 0; i < this.globalQuestionData.length; i++) {
      if (this.route.snapshot.paramMap.get('id') === this.globalQuestionData[i].SubsectionId) {
        this.sectionQuestions = this.globalQuestionData[i].questions;
        this.answers = this.globalQuestionData[i].Answer
        Object.keys(this.questionsForm.value).forEach(key => {
          if (typeof this.questionsForm.value[key] == "object" && Object.keys(this.questionsForm.value[key]).length > 0) {
            Object.keys(this.questionsForm.value[key]).forEach(op => {
              if (this.questionsForm.value[key][op] == true) {
                let obj: any = {
                  "QuestionMapId": key,
                  "Answer": op,
                  "AdditionalAnswerText": null
                }
                this.selectedAnswers.push(obj);
              }
              else {
                let obj: any = {
                  "QuestionMapId": key,
                  "Answer": "",
                  "AdditionalAnswerText": null
                }
                this.selectedAnswers.push(obj);
              }
            })
          }
          else {
            let obj: any = {
              "QuestionMapId": key,
              "Answer": this.questionsForm.value[key],
              "AdditionalAnswerText": null
            }

            this.selectedAnswers.push(obj);
          }
        })

        this.globalQuestionData[i].Answer = this.selectedAnswers
      }
    }

    this.questionnaireService.setGlobalQuestionData(this.globalQuestionData);
  }

  answerObject(isSave) {
    this.selectedAnswers = [];
    let isSaveAndNext;
    if (isSave == "SaveAndNext") {
      isSaveAndNext = true;
    }
    else {
      isSaveAndNext = false;
    }
    Object.keys(this.questionsForm.value).forEach(key => {
      if (typeof this.questionsForm.value[key] == "object" && Object.keys(this.questionsForm.value[key]).length > 0) {
        Object.keys(this.questionsForm.value[key]).forEach(op => {
          if (this.questionsForm.value[key][op] == true) {
            let obj: AnswersData = {
              "SubSectionId": +this.subSectionId,
              "QuestionMapId": key,
              "Answer": op,
              "DataCollectionTaskID": this.tasksId,
              "AdditionalAnswerText": null,
              "isSaveandContinue": isSaveAndNext
            }
            this.selectedAnswers.push(obj);
          }
          else {
            // let obj: AnswersData = {
            //   "SubSectionId": +this.subSectionId,
            //   "QuestionMapId": key,
            //   "Answer": "",
            //   "DataCollectionTaskID": this.tasksId,
            //   "AdditionalAnswerText": null,
            //   "isSaveandContinue": isSaveAndNext
            // }
            // this.selectedAnswers.push(obj);
          }
        })
      }
      else {
        if (this.questionsForm.value[key] != "") {
          let obj: AnswersData = {
            "SubSectionId": +this.subSectionId,
            "QuestionMapId": key,
            "Answer": this.questionsForm.value[key],
            "DataCollectionTaskID": this.tasksId,
            "AdditionalAnswerText": null,
            "isSaveandContinue": isSaveAndNext

          }
          this.selectedAnswers.push(obj);
        }
      }

    })
  }

  onSave(sectionData: any) {
    this.answerObject(sectionData)
    console.log(this.questionsForm.value)
    console.log(this.selectedAnswers)
    
    if (this.selectedAnswers.length > 0) {
      this.questionnaireService
        .updateEmployeeInformationData(this.selectedAnswers)
        .subscribe(
          response => {
            this.SaveAnwsers();
            this.isDirty = false;
            this.questionsForm.markAsUntouched();
            this.questionsForm.markAsPristine();
            //this.validateSubmit();
            this.handleSubmitSucessResponse(response);
            if (sectionData == "SaveAndNext") {
              if (!response.response.isCompleted) {
                this.confirmationService.confirm({
                  message: "Please update all mandatory fields before completing the section.",
                  key: "rejectQuestionnaireConfirmDialog",
                  accept: () => {
                  },
                  reject: () => {
                    return;
                  }
                });
              }
              else {
                if (!this.lastRoute && this.nextSection) {
                  this.router.navigate(["../../questionnaire", this.nextRoute], { relativeTo: this.route })
                }
                else if (this.nextSection) {
                  this.router.navigate(["../../employee-census"], { relativeTo: this.route })
                }
                else {
                  this.router.navigate(["../../questionnaire", this.q5500[0].SubSectionCode], { relativeTo: this.route })

                }
                // this.confirmationService.confirm({
                //   message: "You have not filled in the information in all the sections. Please update and submit",
                //   key: "rejectSignsubmitConfirmDialog",
                //   accept: () => {
                //   },
                //   reject: () => {
                //     return;
                //   }
                // });
              }
            } else {
              this.messageService.add({ key: 'employeeInfoQuestionnaire', severity: 'success', summary: 'SUCCESS', detail: 'Questionnaire is updated successfully' });
            }

          },
          error => {
            this.errorMsg = Utility.showErrMsg(error);
            this.messageService.add({ key: 'employeeInfoQuestionnaire', severity: 'error', summary: 'ERROR', detail: error.statusText });
          }
        )
    }
    else {
      this.confirmationService.confirm({
        message: "You have not selected any anwser. Please update and submit.",
        key: "rejectQuestionnaireConfirmDialog",
        accept: () => {
        },
        reject: () => {
          return;
        }
      });
    }
  }
  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }


  handleSubmitSucessResponse(response) {
    let obj = response.response;

    this.dataCollectionService.currentMenuStatus
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
        this.SectionMenu = response;
        for (let i = 0; i < response.length; i++) {
          if (this.SectionMenu[i].subSectionCode == obj.subSectionCode) {
            this.SectionMenu[i].isCompleted = obj.isCompleted;
          }
        }
        this.dataCollectionService.updateMenuStatus(this.SectionMenu);
      });

    if (obj.subSectionCode == "201") {
      this.dataCollectionService.currentQ5550Menu.pipe(distinctUntilChanged()).subscribe((response: any) => {
        this.q5500 = response;
        for (let i = 0; i < response.length; i++) {
          if (this.q5500[i].SubSectionCode == obj.subSectionCode) {
            this.q5500[i].isCompleted = obj.isCompleted;
          }
        }
        this.dataCollectionService.updateQ5550Menu(this.q5500);
      });
    } else {
      this.dataCollectionService.currentAnnualPlanQuestionnarieMenu.pipe(distinctUntilChanged()).subscribe((response: any) => {
        this.annulPlan = response;
        for (let i = 0; i < response.length; i++) {
          if (this.annulPlan[i].SubSectionCode == obj.subSectionCode) {
            this.annulPlan[i].isCompleted = obj.isCompleted;
          }
        }
        this.dataCollectionService.updateAnnualPlanQuestionnarieMenu(this.annulPlan);
      });
    }
  }

}
