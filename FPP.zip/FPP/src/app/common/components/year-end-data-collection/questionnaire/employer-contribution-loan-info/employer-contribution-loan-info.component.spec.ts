import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerContributionLoanInfoComponent } from './employer-contribution-loan-info.component';

describe('EmployerContributionLoanInfoComponent', () => {
  let component: EmployerContributionLoanInfoComponent;
  let fixture: ComponentFixture<EmployerContributionLoanInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployerContributionLoanInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployerContributionLoanInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
