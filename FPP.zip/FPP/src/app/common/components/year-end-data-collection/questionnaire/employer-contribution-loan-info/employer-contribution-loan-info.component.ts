import { Component, OnInit } from '@angular/core';
import { QuestionSection } from '../../../../vo/questionnaire.model';
import { QuestionnaireService } from '../../../../services/questionnaire.service';
import { QuestionFormGeneratorService } from '../../../../services/question-form-generator.service';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employer-contribution-loan-info',
  templateUrl: './employer-contribution-loan-info.component.html',
  styleUrls: ['./employer-contribution-loan-info.component.css']
})
export class EmployerContributionLoanInfoComponent implements OnInit {
  isEditState: boolean;
  displayNotesDialog: boolean = false;
  questionsForm: FormGroup;
  sectionQuestions: any;
  questionnaire: any;
  errorMsg:string = '';
  portalSubSectionCode:string = "DCEmployerContribution";

  constructor(private router: Router,
    private questionControlService: QuestionFormGeneratorService,
    private questionnaireService: QuestionnaireService) { }

  ngOnInit() {
    this.getEmployerContributionLoanData();  

  }

  getEmployerContributionLoanData() {
    this.questionnaireService
      .getEmployerContributionLoanInfoData()
      .subscribe((response:QuestionSection) => {
        this.questionnaire = response;
        this.sectionQuestions = this.questionnaire.questions;
        this.setFormData();
      },
      error => {
        this.errorMsg = error.statusText;
      }
      );
  }
  setFormData(){
    this.questionsForm = this.questionControlService.getQuestionsFormGroup(this.sectionQuestions, this.questionnaire);
  };
  showNotesDialog() {
    this.displayNotesDialog = true;
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  onSave() {
    console.log(this.questionsForm)

      //  this.questionnaireService
      // .updateEmployerContributionLoanInfoData(this.questionsForm.value)
      // .subscribe(
      //   response => {
      //     console.log('Sucess');
      //   },
      //   error => {
      //     console.log('Error');
      //     this.errorMsg = error.statusText;
      //   }
      // ) 
  }
  onSaveAndNext() {
    this.router.navigate(["/home/datacollection/datacollection-year-end/questionnaire5500"])
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

}
