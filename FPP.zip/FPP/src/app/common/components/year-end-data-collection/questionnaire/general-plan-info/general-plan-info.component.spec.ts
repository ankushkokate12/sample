import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralPlanInfoComponent } from './general-plan-info.component';

describe('GeneralPlanInfoComponent', () => {
  let component: GeneralPlanInfoComponent;
  let fixture: ComponentFixture<GeneralPlanInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeneralPlanInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneralPlanInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
