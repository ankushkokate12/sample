import { Component, OnInit } from '@angular/core';
import { QuestionSection, AnswersData } from 'src/app/common/vo/questionnaire.model';
import { QuestionnaireService } from 'src/app/common/services/questionnaire.service';
import { QuestionFormGeneratorService } from 'src/app/common/services/question-form-generator.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { Utility } from 'src/app/common/utils/utility';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-general-plan-info',
  templateUrl: './general-plan-info.component.html',
  styleUrls: ['./general-plan-info.component.css']
})
export class GeneralPlanInfoComponent implements OnInit {
  isEditState: boolean;
  displayNotesDialog: boolean = false;
  questionsForm: FormGroup;
  sectionQuestions: any;
  questionnaire: any;
  errorMsg: string = '';
  selectedAnswers: any = [];
  tasksId: number;
  portalSubSectionCode:string = "DCGeneralPlan";

  constructor(private router: Router,
    private questionControlService: QuestionFormGeneratorService,
    private questionnaireService: QuestionnaireService,
    private messageService: MessageService) { }

  ngOnInit() {
    this.getGeneralPlanData();
    this.tasksId = JSON.parse(localStorage.getItem('taskDetails')).taskId;

  }

  getGeneralPlanData() {
    this.questionnaireService
      .getGeneralPlanInfoData()
      .subscribe((response: QuestionSection) => {
        this.questionnaire = response;
        this.sectionQuestions = this.questionnaire.questions;
        this.setFormData();
      },
        error => {
          this.errorMsg = error.statusText;
        }
      );
  }
  setFormData() {
    this.questionsForm = this.questionControlService.getQuestionsFormGroup(this.sectionQuestions, this.questionnaire);
  };
  showNotesDialog() {
    this.displayNotesDialog = true;
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  onSave() {
    Object.keys(this.questionsForm.value).forEach(key => {
      let obj: AnswersData = {
        "SubSectionId": "",
        "QuestionMapId": key,
        "Answer": this.questionsForm.value[key],
        "DataCollectionTaskID": this.tasksId,
        "AdditionalAnswerText": null,
        "isSaveandContinue":true
      }
      this.selectedAnswers.push(obj);
    });

    this.questionnaireService
      .updateGeneralPlanInfoData(this.selectedAnswers)
      .subscribe(
        response => {
          // this.messageService.add({ key: 'generalQuestionnaire', severity: 'success', summary: 'SUCCESS', detail: "Answers saved Successfully!!" });
        },
        error => {
          this.errorMsg = Utility.showErrMsg(error);
          this.messageService.add({ key: 'generalQuestionnaire', severity: 'error', summary: 'ERROR', detail: error.statusText });
        }
      )
  }
  onSaveAndNext() {
    this.router.navigate(["/home/datacollection/datacollection-year-end/employer-contribution-loan-info"])
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

}