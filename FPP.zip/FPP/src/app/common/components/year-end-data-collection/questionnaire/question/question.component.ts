import { FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input, OnChanges, SimpleChanges, HostListener } from '@angular/core';
import { RenderingTranslationService } from '../../../../services/rendering-translation.service';
import { Question, QuestionSection } from 'src/app/common/vo/questionnaire.model';
import { DirtyComponent } from 'src/app/guard/has-unsaved-notification-guard.guard';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css'],
  providers: [RenderingTranslationService]
})
export class QuestionComponent implements OnInit, OnChanges {
  @Input() sectionQuestions: Question[];
  @Input() sectionAnswers: any;
  @Input() form: FormGroup;
  isValid: boolean;
  touched: boolean;
  isDependants: boolean;
  question: any
  maxSelectedOptions: any = [];
  counter: any;
  required: boolean;
  isDirty = false;
  constructor(private renderingTranslationService: RenderingTranslationService) {
  }

  // @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) {
  //   event.returnValue = !this.form.dirty;
  // }

  // canDeactivate() {
  //   return this.form.dirty;
  // }


  ngOnChanges(changes: SimpleChanges) {
    if (changes.sectionQuestions && changes.sectionQuestions.currentValue) {
     // this.form.reset();
      this.sectionQuestions.forEach(question => {
        if (question.isDependant && question.isDependentOn && question.isDependentOn.value) {
          // let dependentQuestion = this.sectionQuestions.find(q => q.questionId == question.isDependentOn.question);
          this.form.controls[question.isDependentOn.question].valueChanges.pipe(distinctUntilChanged()).subscribe(value => {
            if (value == question.isDependentOn.value) {
              if (question.isMendatory == true) {
                this.form.controls[question.questionId].enable({ onlySelf: true });
                this.form.controls[question.questionId].setValidators(Validators.required);
                this.form.controls[question.questionId].updateValueAndValidity();
              }
              else {
                this.form.controls[question.questionId].enable({ onlySelf: true });
                this.form.controls[question.questionId].clearValidators();
                this.form.controls[question.questionId].updateValueAndValidity();
              }
            }
            else {
              this.form.controls[question.questionId].clearValidators();
              this.form.controls[question.questionId].patchValue("", {emitEvent: false});
              this.form.controls[question.questionId].updateValueAndValidity();
              this.form.controls[question.questionId].disable({ onlySelf: true });
            }
          })
        }
        if (question.isDependant) {
          let dependentQuestion = this.sectionQuestions.find(q => q.questionId == question.isDependentOn.question);
          if (dependentQuestion.selectedAnswer != "" && dependentQuestion.selectedAnswer == question.isDependentOn.value) {
            this.form.controls[question.questionId].enable({ onlySelf: true });
            this.form.controls[question.questionId].setValidators(Validators.required);
            this.form.controls[question.questionId].updateValueAndValidity();
          }
          else {
            this.form.controls[question.questionId].disable({ onlySelf: true });
            this.form.controls[question.questionId].patchValue("", {emitEvent: false});
            this.form.controls[question.questionId].clearValidators();
            this.form.controls[question.questionId].updateValueAndValidity();
          }

        }
      })
    }
  }

  ngOnInit() {
    if((this.form != undefined)&& (this.form != null)){
      this.form.valueChanges.pipe(distinctUntilChanged()).subscribe( e => this.isDirty = true );
    }
  }

  getQuestionRendering(question: Question) {
    this.question = question;

    this.isValid = this.form.get(question.questionId).valid;
    this.touched = this.form.get(question.questionId).touched;
    return this.renderingTranslationService.getRenderingForQuestion(question);
  }
}
