import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Questionnaire5500Component } from './questionnaire5500.component';

describe('Questionnaire5500Component', () => {
  let component: Questionnaire5500Component;
  let fixture: ComponentFixture<Questionnaire5500Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Questionnaire5500Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Questionnaire5500Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
