import { Component, OnInit } from '@angular/core';
import { QuestionSection } from 'src/app/common/vo/questionnaire.model';
import { QuestionnaireService } from 'src/app/common/services/questionnaire.service';
import { QuestionFormGeneratorService } from 'src/app/common/services/question-form-generator.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-questionnaire5500',
  templateUrl: './questionnaire5500.component.html',
  styleUrls: ['./questionnaire5500.component.css']
})
export class Questionnaire5500Component implements OnInit {
  isEditState: boolean;
  displayNotesDialog: boolean = false;
  questionsForm: FormGroup;
  sectionQuestions: any;
  questionnaire: any;
  errorMsg:string = '';
  portalSubSectionCode:string = "DC5500";

  constructor(private router: Router,
    private questionControlService: QuestionFormGeneratorService,
    private questionnaireService: QuestionnaireService) { }

  ngOnInit() {
    this.getQuestionnaire5500Data();  

  }

  getQuestionnaire5500Data() {
    this.questionnaireService
      .getQuestionnaire5500InfoData()
      .subscribe((response:QuestionSection) => {
        this.questionnaire = response;
        this.sectionQuestions = this.questionnaire.questions;
        this.setFormData();
      },
      error => {
        this.errorMsg = error.statusText;
      }
      );
  }
  setFormData(){
    this.questionsForm = this.questionControlService.getQuestionsFormGroup(this.sectionQuestions, this.questionnaire);
  };
  showNotesDialog() {
    this.displayNotesDialog = true;
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  onSave() {
    console.log(this.questionsForm)

      //  this.questionnaireService
      // .updateQuestionnaire5500InfoData(this.questionsForm.value)
      // .subscribe(
      //   response => {
      //     console.log('Sucess');
      //   },
      //   error => {
      //     console.log('Error');
      //     this.errorMsg = error.statusText;
      //   }
      // ) 
  }
  onSaveAndNext() {
    this.router.navigate(["/home/datacollection/datacollection-year-end/employee-census"])
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

}
