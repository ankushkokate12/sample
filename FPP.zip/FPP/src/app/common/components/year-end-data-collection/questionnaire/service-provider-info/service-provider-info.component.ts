import { Component, OnInit } from '@angular/core';
import { QuestionSection } from '../../../../vo/questionnaire.model';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { QuestionFormGeneratorService } from '../../../../services/question-form-generator.service';
import { QuestionnaireService } from '../../../../services/questionnaire.service';

@Component({
  selector: 'service-provider-info',
  templateUrl: './service-provider-info.component.html',
  styleUrls: ['./service-provider-info.component.css']
})
export class ServiceProviderInfoComponent implements OnInit {

  isEditState: boolean;
  displayNotesDialog: boolean = false;
  questionsForm: FormGroup;
  sectionQuestions: any;
  questionnaire: any;
  errorMsg:string = '';
  portalSubSectionCode:string = "DCServiceProvider";

  constructor(private router: Router,
    private questionControlService: QuestionFormGeneratorService,
    private questionnaireService: QuestionnaireService) { }

  ngOnInit() {
    this.getUserProfileData();  
  }

  getUserProfileData() {
    this.questionnaireService
      .getServiceProviderInfoData()
      .subscribe((response:QuestionSection) => {
        this.questionnaire = response;
        this.sectionQuestions = this.questionnaire.questions;
        this.setFormData();
      },
      error => {
        this.errorMsg = error.statusText;
      }
      );
  }
  setFormData(){
    this.questionsForm = this.questionControlService.getQuestionsFormGroup(this.sectionQuestions, this.questionnaire);
  };
  showNotesDialog() {
    this.displayNotesDialog = true;
  }
  onNotesDialogClose() {
    this.displayNotesDialog = false;
  }
  onSave() {
    console.log(this.questionsForm)

      //  this.questionnaireService
      // .updateServiceProviderInfoData(this.questionsForm.value)
      // .subscribe(
      //   response => {
      //     console.log('Sucess');
      //   },
      //   error => {
      //     console.log('Error');
      //     this.errorMsg = error.statusText;
      //   }
      // ) 
  }
  onSaveAndNext() {
    this.router.navigate(["/home/datacollection/datacollection-year-end/general-plan-info"])
  }

  onClose() {
    this.router.navigate(["/home/datacollection/datacollection-landing"])
  }

}
