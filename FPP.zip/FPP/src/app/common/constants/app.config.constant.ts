export namespace AppConfig {
  //export const SERVER_PATH: string = 'https://localhost:44386/api/';
  export const SERVER_PATH: string = 'http://axisportal.dev.ascensus.com/api/';
  // export const SECURE_AUTH_TOKEN_URL = '';
  // export const SECURE_AUTH_CLIENT_ID = '';
  // export const SECURE_AUTH_SECRET_KEY = 'testingkey';
  // export const SECURE_AUTH_GRANT_TYPE = 'client_credentials';
  // export const AUTH_TOKEN_REFRESH_INTERVAL = 1800000;
}
