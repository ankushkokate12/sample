export const DataCollectionHistory={
    "dcHistory":[
        {
          "name": "Lorem ipsum dolor",
          "pstartdate": "19-2-19",
          "penddate": "03-12-19",
          "completed": "15-10-19"
        },
        {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
          {
            "name": "Lorem ipsum dolor",
            "pstartdate": "19-2-19",
            "penddate": "03-12-19",
            "completed": "15-10-19"
          },
      ]
}