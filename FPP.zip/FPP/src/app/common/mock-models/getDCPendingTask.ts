export const DataCollectionPendingTask = {
    "dcPendingTask": [
        {
            "planname": "Lorem ipsum dolor",
            "activedate": "19-2-19",
            "duedate": "03-12-19",
            "yecollectionstartdate": "15-10-19",
            "yecollectionendtdate": "13-10-19",
            "percentage":70
        },
        {
            "planname": "Lorem ipsum dolor",
            "activedate": "19-2-19",
            "duedate": "03-12-19",
            "yecollectionstartdate": "15-10-19",
            "yecollectionendtdate": "13-10-19",
            "percentage":0
        },
        {
            "planname": "Lorem ipsum dolor",
            "activedate": "19-2-19",
            "duedate": "03-12-19",
            "yecollectionstartdate": "15-10-19",
            "yecollectionendtdate": "13-10-19",
            "percentage":90
          },
          
    ]
}