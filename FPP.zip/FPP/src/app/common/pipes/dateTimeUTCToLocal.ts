import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'UTCToLocal'
})
export class DateTimeUTCToLocal implements PipeTransform {

    transform(value: string): any {

      if (!value) {
        return '';
      }  
      const dateValue = new Date(value+ 'Z');  
      return dateValue;
    }
  }