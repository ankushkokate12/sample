import { Pipe, PipeTransform } from '@angular/core';
import { CompletedTaskVo } from '../vo/datacolleciton-interface';

@Pipe({
  name: 'planSelection',
  pure: false
})
export class PlanSelectionPipe implements PipeTransform {

  transform(items: any, filter: any): any {
    if (!items) return [];

    let result: any = [];
    if (filter != undefined) {
      if (filter.planId === 'All') {
        result = items;
      } else {
        if((filter.completedTasks != undefined) && (filter.completedTasks != null)){
          result = filter.completedTasks;
        }else{
          result = [];
        }
      }
    }
    return result;
  }

}
