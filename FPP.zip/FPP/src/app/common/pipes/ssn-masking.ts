import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'SSNMask'
})
export class SSNMasking implements PipeTransform {

    transform(value: string): any {

      if (!value) {
        return null;
      } 


      const SSNMaskings = "XXX-XX-" + value.slice(value.length - 4);  
      return SSNMaskings;
    }
  }