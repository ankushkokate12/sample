import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'zipFormat'
})
export class ZipFormatPipe implements PipeTransform {

  transform(val, args) {
    if (val != undefined) {
      var value = val.toString().trim().replace(/-/, '');

      if (value.match(/[^0-9][-]/)) {
        return val;
      }
      var number, number1;
      switch (value.length) {
        case 6:
        case 7:
        case 8:
        case 9:
          number = value.slice(0, 5) + "-" + value.slice(5);
          break;
        default:
          return val;
      }
      return number.trim();
    } else {
      return val;
    }
  }
}