import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})
export class BaseApiPathService {
    configPath: string;
    userIds: string;
    inactivityTimeout: number;
    inactivityWarningTimeout: number;
    refreshTokenTimeoutInSeconds: number;
    refreshTokenWarningTimeoutInSeconds: number;

    constructor(private http: HttpClient) { }

    loadConfigPath() {
        return this.http
            .get<any>('./assets/config.json')
            .toPromise()
            .then(config => {
                this.configPath = config.apiUrl;
                this.inactivityTimeout = config.inactivityTimeoutInSeconds;
                this.inactivityWarningTimeout = config.inactivityWarningTimeoutInSeconds;
                this.refreshTokenTimeoutInSeconds = config.refreshTokenTimeoutInSeconds;
                this.refreshTokenWarningTimeoutInSeconds = config.refreshTokenWarningTimeoutInSeconds;
                // this.userIds = config.userId;
            });
    }
}