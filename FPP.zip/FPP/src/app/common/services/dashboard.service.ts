import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { AppConfig } from '../constants/app.config.constant';
import { HeaderUtil } from '../utils/header-util';
import { catchError } from 'rxjs/operators';
import { BaseApiPathService } from './baseapi.service';
import { LoginService } from './login.service';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    // userId: string = '35';
    // baseUrl: string = this.baseApiPathService.configPath + 'dashboard';
     userId: string = this.baseApiPathService.userIds;
    //userId: string;
    baseUrl: string = '../../../assets/data/employerPlan.json';

    reqHeaders: any;

    constructor(private httpClient: HttpClient, 
        private baseApiPathService: BaseApiPathService,
        private loginService: LoginService) { }

    getReadHttpOptions(): any {
        const httpReadOptions = {
            headers: new HttpHeaders({
                // Authorization: 'Bearer ' + HeaderUtil.getToken(),
                UserId: sessionStorage.getItem('contacttId')//this.loginService.contactId.toString(),
            })
        };
        return httpReadOptions;
    }

    getEmployerPlanData(): Observable<any> {
        return this.httpClient.get(
            this.baseUrl + 'DataCollection/planConsultant',
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    errorHandler(error: HttpErrorResponse) {
        return throwError(error);
    }
}
