import { Injectable } from '@angular/core';
import { Observable, throwError, BehaviorSubject, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BaseApiPathService } from './baseapi.service';

@Injectable({
    providedIn: 'root'
})
export class DataService {
    private data:any={};
    private dcMasterData = new BehaviorSubject(this.data); // Declare a source as Subject
    dataCollectionMasterData = this.dcMasterData.asObservable();

    constructor(private httpClient: HttpClient, private baseApiPathService: BaseApiPathService) { }

    baseUrl: string = this.baseApiPathService.configPath;

    FileValidations = {
        max_file_count: 10,
        max_file_size_mb: 200 * 1024 * 1024,
        max_allFile_size_mb: 300 * 1024 * 1024,
        file_types: ['xls','xlsx','csv','txt','pdf','doc','docx','ppt','pptx']
    };

    private fileValidation = new BehaviorSubject(this.FileValidations);
    currentFileValidations = this.fileValidation.asObservable();
    
    errorHandler(error: HttpErrorResponse) {
        return throwError(error);
    }

    getStateCountryCodeData() {
        return this.httpClient.get(
            this.baseUrl + 'Location'
        ).pipe(catchError(this.errorHandler));
    }

    getPrefixData() {
        return this.httpClient.get(
            this.baseUrl + 'UserProfile/prefix'
        ).pipe(catchError(this.errorHandler));
    }

    getDataCollectionMasterData() {
        return this.httpClient.get(
            this.baseUrl + 'DataCollection/masterData'
        ).subscribe(response => {
            this.dcMasterData.next(response);
        });
    }

    getFileValidations() {
        return this.httpClient.get(
            this.baseUrl + 'SecureCommunication/Master'
        ).subscribe(response => {
            this.setFileValidations(response);
        });
    }

    setFileValidations(data:any){
        let FileValidations: any = this.FileValidations;
        if (data != undefined && data != null) {
          if (data.max_AllFileSize_MB != undefined) {
            FileValidations.max_allFile_size_mb =
              data.max_AllFileSize_MB * 1024 * 1024;
          }
    
          if (data.max_file_size_mb != undefined) {
            FileValidations.max_file_size_mb = data.max_file_size_mb * 1024 * 1024;
          }
          if (data.maxFile_Count != undefined) {
            FileValidations.max_file_count = data.maxFile_Count;
          }
          if (data.fileExt != undefined && data.fileExt.length > 0) {
            let arr: Array<any> = [];
            data.fileExt.forEach(element => {
              arr.push(element.extensionType);
            });
            FileValidations.file_types = arr;
          }
        }
        this.fileValidation.next(FileValidations);
    }

    getBooleanList(): any {
        return [
            {
                value: true,
                label: "Yes"
            },
            {
                value: false,
                label: "No"
            }
        ];
    }

    getGenderList(): any {
        return [
            {
                value: "M",
                label: "Male"
            },
            {
                value: "F",
                label: "Female"
            },
            {
                value: "O",
                label: "Others"
            }
        ];
    }

    getEntityTypeList(): any {
        return [
            {
                value: "corp",
                label: "C-CORP"
            },
            {
                value: "church",
                label: "Church"
            },
            {
                value: "government",
                label: "Government (other than school)"
            },
            {
                value: "limited-partnership",
                label: "Limited Partnership"
            },
            {
                value: "llc-corporation",
                label: "LLC - Taxed as Corporation"
            },
            {
                value: "llc-partnership",
                label: "LLC - Taxed as Partnership"
            },
            {
                value: "llc-sole",
                label: "LLC - Taxed as Sole"
            },
            {
                value: "proprietorship",
                label: "Proprietorship"
            },
            {
                value: "non-profit",
                label: "Non-Profit"
            },
            {
                value: "other",
                label: "Other"
            },
            {
                value: "partnership",
                label: "Partnership"
            },
            {
                value: "s-corp",
                label: "S-CORP"
            },
            {
                value: "school",
                label: "School"
            },
            {
                value: "sole-proprietorship",
                label: "Sole Proprietorship"
            },
            {
                value: "unknown",
                label: "Unknown"
            }
        ];
    }

    getPayrollFrequencyList(): any {
        return [
            {
                value: "annually",
                label: "Annually"
            },
            {
                value: "Bi-Monthly",
                label: "Bi-Monthly"
            },
            {
                value: "bi-weekly-24",
                label: "Bi-Weekly (24)"
            },
            {
                value: "bi-weekly-26",
                label: "Bi-Weekly (26)"
            },
            {
                value: "monthly",
                label: "Monthly"
            },
            {
                value: "quarterly",
                label: "Quarterly"
            },
            {
                value: "semi-annually",
                label: "Semi-Annually"
            },
            {
                value: "semi-monthly-24",
                label: "Semi-Monthly (24)"
            },
            {
                value: "weekly",
                label: "Weekly"
            }
        ];
    }

    getContactType(): any {
        return [
            {
                value: "Fax Number",
                label: "Fax Number"
            },
            {
                value: "Home Cell",
                label: "Home Cell"
            },
            {
                value: "Mobile Number",
                label: "Mobile Number"
            },
            {
                value: "Phone Cell",
                label: "Phone Cell"
            },
            {
                value: "Phone Number 2",
                label: "Phone Number 2"
            },
            {
                value: "Toll Free",
                label: "Toll Free"
            },
            {
                value: "Work Phone",
                label: "Work Phone"
            },
            {
                value: "Work Phone 2",
                label: "Work Phone 2"
            }
        ];
    }

    getAddressType(): any {
        return [
            {
                value: "Mailing Address",
                label: "Mailing Address"
            },
            {
                value: "Physical Address",
                label: "Physical Address"
            }
        ];
    }

    getPrincipalsOwnershipTitle(): any {
        return [
            {
                value: "Administrator",
                label: "Administrator/VP"
            },
            {
                value: "CEO",
                label: "CEO"
            },
            {
                value: "CFO",
                label: "CFO"
            },
            {
                value: "Chairman",
                label: "Chairman"
            },
            {
                value: "COO",
                label: "COO"
            },
            {
                value: "CTO",
                label: "CTO"
            },
            {
                value: "Director",
                label: "Director"
            },
            {
                value: "Executive Director",
                label: "Executive Director"
            },
            {
                value: "Executive VP",
                label: "Executive VP"
            },
            {
                value: "General Manager",
                label: "General Manager"
            },
            {
                value: "Manager",
                label: "Manager"
            },
            {
                value: "Managing Member",
                label: "Managing Member"
            },
            {
                value: "Member",
                label: "Member"
            },
            {
                value: "No Title",
                label: "No Title"
            },
            {
                value: "Owner",
                label: "Owner"
            },
            {
                value: "President",
                label: "President"
            },
            {
                value: "Secretary",
                label: "Secretary"
            },
            {
                value: "Senior VP",
                label: "Senior VP"
            },
            {
                value: "Treasurer",
                label: "Treasurer"
            },
            {
                value: "Vice President",
                label: "Vice President"
            }
        ];
    }

    getRelationshipType(): any {
        return [
            {
                value: "Child",
                label: "Child"
            },
            {
                value: "Grand Child",
                label: "Grand Child"
            },
            {
                value: "Grand Parent",
                label: "Grand Parent"
            },
            {
                value: "Parent",
                label: "Parent"
            },
            {
                value: "Sibling",
                label: "Sibling"
            },
            {
                value: "Spouse",
                label: "Spouse"
            },
            {
                value: "Step-child",
                label: "Step-child"
            },
        ];
    }

    getStateList(): any {
        return [
            {
                value: "AK",
                label: "Alaska"
            },
            {
                value: "AL",
                label: "Alabama"
            },
            {
                value: "AR",
                label: "Arkansas"
            },
            {
                value: "AZ",
                label: "Arizona"
            },
            {
                value: "FL",
                label: "Florida"
            },
            {
                value: "NV",
                label: "Nevada"
            },
            {
                value: "NJ",
                label: "New Jersey"
            },
            {
                value: "TX",
                label: "Texas"
            }
        ]
    }

    getSectionList(): any {
        return [
            {
                id: "employerCompanyData",
                label: "Employer Company Data"
            },
            {
                id: "principalsOwnerships",
                label: "Principals/Ownerships"
            },
            {
                id: "familyRelationships",
                label: "Family Ralationships"
            },
            {
                id: "businesses",
                label: "Businesses"
            },
            {
                value: "contacts",
                label: "Contacts"
            }
        ]
    }

    getDocumentTypeList(): any {
        return [
            {
                id: "Annual Valuation report",
                label: "Annual Valuation report"
            },
            {
                id: "Annual Valuation report2",
                label: "Annual Valuation report2"
            },
            {
                id: "Annual Valuation report3",
                label: "Annual Valuation report3"
            }
        ]
    }

    loanStatus(): any {
        return [
            {
                value: "In Progress",
                label: "In Progress"
            },
            {
                value: "Complete",
                label: "Complete"
            }
        ];
    }

    prefixList(): any {
        return [
            {
                value: "Mr",
                label: "Mr"
            },
            {
                value: "Mrs",
                label: "Mrs"
            },
            {
                value: "Ms",
                label: "Ms"
            },
            {
                value: "Dr",
                label: "Dr"
            },
            {
                value: "Prof",
                label: "Prof"
            },
            {
                value: "Father",
                label: "Father"
            },
            {
                value: "Sister",
                label: "Sister"
            },
            {
                value: "Elder",
                label: "Elder"
            },
            {
                value: "Honorable",
                label: "Honorable"
            },
            {
                value: "Dean",
                label: "Dean"
            },
            {
                value: "Admiral",
                label: "Admiral"
            },
        ];
    }
}
