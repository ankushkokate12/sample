import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse
} from "@angular/common/http";
import { Observable, throwError, BehaviorSubject, Subject } from "rxjs";
import { AppConfig } from "../constants/app.config.constant";
import { HeaderUtil } from "../utils/header-util";
import { catchError, distinctUntilChanged } from "rxjs/operators";
import { BaseApiPathService } from "./baseapi.service";
import { LoginService } from "./login.service";

@Injectable({
  providedIn: "root"
})
export class DataCollectionService {
  //baseUrl: string = AppConfig.SERVER_PATH + 'DataCollection/';
  //baseUrl: string = '';
  // userId: string = this.baseApiPathService.userIds;

  reqHeaders: any;
  userId: string;
  PlanDate: any;
  dcEmployerCompanyData: any = [];
  annulPlan: any = [];
  q5500: any = []
  dcCensusConsenData: any;

  baseUrl: string = this.baseApiPathService.configPath;

  private getPendingTaskCount = new BehaviorSubject(0);
  currentPendingTaskCount = this.getPendingTaskCount.asObservable();

  private getCensusCount = new BehaviorSubject(0);
  currentCensusCount = this.getCensusCount.asObservable();

  private getDcMenusStatus = new BehaviorSubject(this.dcEmployerCompanyData);
  currentMenuStatus = this.getDcMenusStatus.asObservable();

  private getDcCensusConsent = new BehaviorSubject(this.dcCensusConsenData);
  currentCensusConsen = this.getDcCensusConsent.asObservable();

  private getAnnualPlanQuestionnarieMenu = new BehaviorSubject(this.annulPlan);
  currentAnnualPlanQuestionnarieMenu = this.getAnnualPlanQuestionnarieMenu.asObservable();

  private getQ5550Menu = new BehaviorSubject(this.q5500);
  currentQ5550Menu = this.getQ5550Menu.asObservable();

  constructor(
    private httpClient: HttpClient,
    private baseApiPathService: BaseApiPathService,
    private loginService: LoginService
  ) { }

  //   getMenuStatus(statusData: any){
  //     return this.httpClient.post(
  //         this.baseUrl + 'DataCollection/GetMenuSectionStatus',
  //         statusData,
  //     ).subscribe((response: any) => {
  //         this.getMenusStatus.next(response);
  //     });
  // }
  getMenuStatus(statusData: any): Observable<any> {
    return this.httpClient
      .post(this.baseUrl + "DataCollection/GetMenuSectionStatus",
        statusData,
        this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }
  // updateCensusConsentStatus(updatedData: any) {
  //   this.getDcCensusConsent.next(updatedData);
  // }
  updateMenuStatus(updatedData: any) {
    this.getDcMenusStatus.next(updatedData);
  }

  updateAnnualPlanQuestionnarieMenu(updateQ: any) {
    this.getAnnualPlanQuestionnarieMenu.next(updateQ);
  }

  updateQ5550Menu(update5500: any) {
    this.getQ5550Menu.next(update5500);
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }

  updatePendingTaskCount(taskCount: any) {
    this.getPendingTaskCount.next(taskCount);
  }

  updateCensusCount(CensusCount: any) {
    this.getCensusCount.next(CensusCount);
  }

  getReadHttpOptions(): any {
    const httpReadOptions = {
      headers: new HttpHeaders({
        //Authorization: 'Bearer ' + HeaderUtil.getToken()
        UserId: sessionStorage.getItem("contactId") //.loginService.contactId.toString(),
        // UserId: this.userId,
      })
    };
    return httpReadOptions;
  }

  // getMenuCompletion(): Observable<any> {
  //   let baseUrl: string = "../../../assets/data/menu.json";

  //   return this.httpClient
  //     .get(
  //       baseUrl,
  //       this.getReadHttpOptions()
  //     )
  //     .pipe(catchError(this.errorHandler));
  // }

  setPlanDate(val:any){
    this.PlanDate = val;
  }
  getPlanDate(){
    return this.PlanDate
  }
  getPendingTasks(): Observable<any> {
    //let baseUrl: string = "../../../assets/data/pendingtask.json";

    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/PendingTask",
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  getDataCollectionHistory(): Observable<any> {
    //let baseUrl: string = '../../../assets/data/datacollectionhistory.json';
    return this.httpClient
      .get(this.baseUrl + "DataCollection/CompletedTask",
        this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  completedTaskHistoryDownloadAsExcel(id: any): Observable<any> {
    return this.httpClient.get(
      this.baseUrl + 'DataCollection/download/' + id,
      this.taskHistoryDownloadOptionAsExcel(),
    ).pipe(catchError(this.errorHandler));
  }

  taskHistoryDownloadOptionAsExcel() {
    const fileOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/octet-stream'
      }),
      responseType: 'blob',

      ...this.getReadHttpOptions()
    };
    return fileOptions;
  }

  getFileDownloadOption() {
    const fileOptions = {
      responseType: "arraybuffer" as "json",
      headers: this.getReadHttpOptions()
    };
    return fileOptions;
  }

  downloadAsExcel(): Observable<Blob> {
    return this.httpClient.get<Blob>("", this.getFileDownloadOption());
  }
  saveAndSubmit(submitDetails: any): Observable<any> {
    return this.httpClient.post(
      this.baseUrl + "DataCollection/SubmitSection",
      submitDetails,
      this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }
  SectionMenu: any;
  completionTick(permissionCode: any) {
    this.currentMenuStatus
      .pipe(distinctUntilChanged())
      .subscribe((response: any) => {
      this.SectionMenu = response;
      for (let i = 0; i < response.length; i++) {
        if (this.SectionMenu[i].subSectionCode == permissionCode) {
          this.SectionMenu[i].isCompleted = false;
        }
      }
      this.updateMenuStatus(this.SectionMenu);
    });

  }

  // getDataCollectionNoteData(planId: string, empId: string, sectionId: string): Observable<any> {
  //     let baseUrl: string = '../../../assets/data/notes.json';
  //     return this.httpClient.get(
  //         baseUrl,
  //         this.getReadHttpOptions()
  //     ).pipe(catchError(this.errorHandler));
  // }
  getDataCollectionNoteData(taskId: string, sectionId?: string): Observable<any> {
    //let baseUrl: string = "../../../assets/data/notes.json";
    if (sectionId != undefined && sectionId != null) {
      return this.httpClient
        .get(
          this.baseUrl + "DataCollection/Notes/" + taskId + "/" + sectionId,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .get(
          this.baseUrl + "DataCollection/Notes/" + taskId,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  updateNotesData(isEdit: boolean, notesDetails: any): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(this.baseUrl + "DataCollection/Note",
          notesDetails, this.getReadHttpOptions())
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(this.baseUrl + "DataCollection/Note",
          notesDetails, this.getReadHttpOptions())
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteNotesData(noteId: any): Observable<any> {
    return this.httpClient
      .delete(this.baseUrl + "DataCollection/Note?Id=" + noteId,
        this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }
  /******************** EMPLOYER COMPANY DETAIL *********************/

  getEmployerCompanyData(taskId: any): Observable<any> {
    // let baseUrl: string = "../../../assets/data/employercompanydata.json";
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Employer/" + taskId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  AddEmployerCompanyData(employerDetails: any, taskId: any): Observable<any> {
    return this.httpClient
      .post(
        this.baseUrl + "DataCollection/Employer?taskId=" + taskId,
        employerDetails,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  UpdateEmployerCompanyData(
    employerDetails: any,
    taskId: any
  ): Observable<any> {
    return this.httpClient
      .put(
        this.baseUrl + "DataCollection/Employer?taskId=" + taskId,
        employerDetails,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  addUpdateEmployerCompanyAddress(
    isEdit: boolean,
    addressDetail: any,
    taskMapId: any
  ): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Address?taskMapId=" + taskMapId,
          addressDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Address",
          addressDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteEmployerCompanyAddress(addressId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Address?Id=" + addressId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  addUpdateEmployerCompanyContact(
    isEdit: boolean,
    contactDetail: any,
    taskMapId: any
  ): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Phone?taskMapId=" + taskMapId,
          contactDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Phone",
          contactDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteEmployerCompanyContact(contactId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Phone?Id=" + contactId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  /******************** PRINCIPALS/OWNERSHIPS ***********************/

  getPrincipalOwnershipData(taskMapId: any): Observable<any> {
    //let baseUrl: string = '../../../assets/data/principalOwnership.json';
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Ownerships/" + taskMapId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updatePrincipalsOwnership(
    isEdit: boolean,
    principalsDetail: any
  ): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Ownership",
          principalsDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Ownership",
          principalsDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deletePrincipalsOwnershipData(ownershipId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Ownership?Id=" + ownershipId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  /******************** FAMILY RELATIONSHIPS ***********************/

  getFamilyRelationshipData(taskMapId: any): Observable<any> {
    //let baseUrl: string = '../../../assets/data/familyRelationship.json';
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Relationships/" + taskMapId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  getRelatedOwnershipList(EmployerId: any): Observable<any> {
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/OwnershipList/" + EmployerId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateFamilyConsent(familyConsentObj: any): Observable<any> {
    return this.httpClient
      .put(
        this.baseUrl + "DataCollection/FamilyConsent",
        familyConsentObj,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateFamilyRelationship(
    isEdit: boolean,
    relationshipDetail: any
  ): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Relationship",
          relationshipDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Relationship",
          relationshipDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteFamilyRelationshipData(relationshipId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Relationship?Id=" + relationshipId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  /******************** BUSINESSES ***********************/

  getBusinessData(taskMapId: any): Observable<any> {
    //let baseUrl: string = "../../../assets/data/businesses.json";
    // return this.httpClient
    //   .get(baseUrl, this.getReadHttpOptions())
    //   .pipe(catchError(this.errorHandler));
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Businesses/" + taskMapId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateBusinessData(isEdit: boolean, businessDetail: any): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Business",
          businessDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Business",
          businessDetail,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteBusinessData(businessId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Business?Id=" + businessId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateBusinessConsent(businessObj: any): Observable<any> {
    return this.httpClient
      .put(
        this.baseUrl + "DataCollection/BusinessConsent ",
        businessObj,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  /******************** START: CONTACTS DETAIL *********************/

  getContactsData(taskMapId: any): Observable<any> {
    // let baseUrl: string = "../../../assets/data/contacts.json";
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Contacts/" + taskMapId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateContactsData(issuesDetails: any): Observable<any> {
    return this.httpClient
      .put(this.baseUrl, issuesDetails, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  // private dcIssuesData = new Subject<any>(); // Declare a source as Subject
  // dataCollectionIssuesData = this.dcIssuesData.asObservable();

  // getContactIssues(taskMapId: any, contactId: any) {
  //   // let baseUrl: string = '../../../assets/data/contacts.json';
  //   return this.httpClient
  //     .get(
  //       this.baseUrl + "DataCollection/Issues/" + taskMapId + "/" + contactId,
  //       this.getReadHttpOptions()
  //     )
  //     .subscribe(response => {
  //       this.dcIssuesData.next(response);
  //     });
  // }

  getContactIssues(taskMapId: any, contactId: any): Observable<any> {
    // let baseUrl: string = '../../../assets/data/contacts.json';
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/Issues/" + taskMapId + "/" + contactId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  addEditContactIssues(
    isEdit: boolean,
    issuesData: any,
    taskMapId: any
  ): Observable<any> {
    if (isEdit) {
      return this.httpClient
        .put(
          this.baseUrl + "DataCollection/Issue",
          issuesData,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    } else {
      return this.httpClient
        .post(
          this.baseUrl + "DataCollection/Issue/" + taskMapId,
          issuesData,
          this.getReadHttpOptions()
        )
        .pipe(catchError(this.errorHandler));
    }
  }

  deleteContactIssue(issueId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "DataCollection/Issue?Id=" + issueId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  /******************** START: EMPLOYEE SENSUS ***********************/

  getEmployeeSensusData(taskId: any): Observable<any> {
    // let baseUrl: string = '../../../assets/data/employee-census.json';
    return this.httpClient
      .get(
        this.baseUrl + "CensusInfo?taskId=" + taskId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  addEmployeeSensusInfo(employeeInfo: any, taskId: any): Observable<any> {
    return this.httpClient
      .post(
        this.baseUrl + "CensusInfo?taskId=" + taskId,
        employeeInfo,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  getFullSSN(dataCollectionInfoId: any): Observable<any> {
    return this.httpClient
      .get(
        this.baseUrl + "CensusInfo/getSSN?Id=" + dataCollectionInfoId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  getCensusNoConsent(taskId: any): Observable<any> {
    return this.httpClient
      .get(
        this.baseUrl + "CensusInfo/CensusConsent?taskId=" + taskId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  getCensusNoConsents(taskId: any) {
    return this.httpClient
      .get(
        this.baseUrl + "CensusInfo/CensusConsent?taskId=" + taskId,
        this.getReadHttpOptions()
      ).subscribe(response => {
        this.getDcCensusConsent.next(response);
    });
  }

  updateEmployeeSensusInfo(employeeInfo: any, taskId: any): Observable<any> {
    return this.httpClient
      .put(
        this.baseUrl + "CensusInfo?taskId=" + taskId,
        employeeInfo,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  deleteEmployeeSensusInfo(dataCollectionInfoId: any): Observable<any> {
    return this.httpClient
      .post(
        this.baseUrl + "CensusInfo/delete?Id=" + dataCollectionInfoId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  deleteAllEmployees(taskId: any): Observable<any> {
    return this.httpClient
      .delete(
        this.baseUrl + "CensusInfo/DeleteAll?taskId=" + taskId,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  importCensusFile(ImportData) {
    return this.httpClient
      .post(
        this.baseUrl + "CensusInfo/import/",
        ImportData,
        this.getFileImportOption()
      )
      .pipe(catchError(this.errorHandler));
  }

  getFileImportOption() {
    const fileOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'multipart/form-data'
      }),
      ...this.getReadHttpOptions()
    };
    return fileOptions;
  }

  CensusDownloadAsExcel(taskId: any): Observable<any> {
    return this.httpClient.get(
      this.baseUrl + 'CensusInfo/exportCensus/' + taskId,
      this.censusDownloadOptionAsExcel(),
    ).pipe(catchError(this.errorHandler));
  }

  censusDownloadOptionAsExcel() {
    const fileOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/octet-stream'
      }),
      responseType: 'blob',

      ...this.getReadHttpOptions()
    };
    return fileOptions;
  }


  /******************** START: APPROVAL ***********************/

  getApprovalDocumentData(taskId?: any): Observable<any> {
    return this.httpClient
      .get(
        this.baseUrl + "DataCollection/ApprovalDocuments",
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  updateAndDeleteApprovalDocument(selectedDocument: any): Observable<any> {
    return this.httpClient
      .post(this.baseUrl + "DataCollection/DeleteUpdateApproval",
        selectedDocument, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  addApprovalDocument(selectedDocument: any): Observable<any> {
    return this.httpClient
      .post(this.baseUrl + "DataCollection/SubmitApproval",
        selectedDocument, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  // --------------------------- Menu completion ---------------------------//

  // getMenuStatus(statusData: any): Observable<any> {
  //   return this.httpClient
  //     .post(this.baseUrl + "DataCollection/GetMenuSectionStatus",
  //       statusData,
  //       this.getReadHttpOptions())
  //     .pipe(catchError(this.errorHandler));
  // }


  //------------------------------ EMPLOYER PLANS --------------------------//
  getEmployerPlanData(): Observable<any> {
    return this.httpClient.get(
      this.baseUrl + 'DataCollection/planConsultant',
      this.getReadHttpOptions()
    ).pipe(catchError(this.errorHandler));
  }

}
