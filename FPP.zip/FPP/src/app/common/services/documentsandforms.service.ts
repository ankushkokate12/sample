import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { AppConfig } from '../constants/app.config.constant';
import { HeaderUtil } from '../utils/header-util';
import { catchError } from 'rxjs/operators';
import { LoginService } from './login.service';
import { BaseApiPathService } from './baseapi.service';

@Injectable({
    providedIn: 'root'
})
export class DocumentsAndFormsService {
     //baseUrl: string = '../../../assets/data/documentsandforms.json';
    baseUrl: string = this.baseApiPathService.configPath;
    userId: string;
    description: string = '';
    reqHeaders: any;

    private docData = new Subject<any>(); // Declare a source as Subject
    documentsAndFormsData = this.docData.asObservable();

    constructor(private httpClient: HttpClient,
        private baseApiPathService: BaseApiPathService,
        private loginService: LoginService) { }

    getReadHttpOptions(): any {
        const httpReadOptions = {
            headers: new HttpHeaders({
                // Authorization: 'Bearer ' + HeaderUtil.getToken(),
                UserId: sessionStorage.getItem("contactId") //this.loginService.contactId.toString()
            })
        };
        return httpReadOptions;
    }

    errorHandler(error: HttpErrorResponse) {
        return throwError(error);
    }

    getDocumentsAndFormsData(){
        return this.httpClient.get(
            this.baseUrl + 'DocumentsAndForms',
            this.getReadHttpOptions()
        ).subscribe(response => {
            this.docData.next(response);
        });
    }

    getFileDownloadOption() {
        const fileOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/octet-stream'
            }),
            responseType: 'blob',

            ...this.getReadHttpOptions()
        };
        return fileOptions;
    }

    downloadAsExcel(fileInfo:any): Observable<any> {
        return this.httpClient.get(
            this.baseUrl + 'DocumentsAndForms/download/' + fileInfo.guid,
            this.getFileDownloadOption(),
        ).pipe(catchError(this.errorHandler));
    }
}
