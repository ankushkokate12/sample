import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { AppConfig } from '../constants/app.config.constant';
import { HeaderUtil } from '../utils/header-util';
import { catchError } from 'rxjs/operators';
import { BaseApiPathService } from './baseapi.service';
import { LoginService } from './login.service';

@Injectable({
    providedIn: 'root'
})
export class LoansAndDistributionService {
    baseUrl: string = this.baseApiPathService.configPath;
    userId: string;
    description: string = '';
    reqHeaders: any;
    constructor(private httpClient: HttpClient,
        private baseApiPathService: BaseApiPathService,
        private loginService: LoginService) { }

    getReadHttpOptions(): any {
        const httpReadOptions = {
            headers: new HttpHeaders({
                // Authorization: 'Bearer ' + HeaderUtil.getToken(), 
                UserId: sessionStorage.getItem('contactId')//this.loginService.contactId.toString(),
            })
        };
        return httpReadOptions;
    }

    getLoanMasterData(): Observable<any> {
        return this.httpClient.get(
            this.baseUrl + 'LoanDistribution/GetLoanMaster',
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    getLoansAndDistributionData(filterObj: any): Observable<any> {
        return this.httpClient.post(
            this.baseUrl + 'LoanDistribution/Get',
            filterObj,
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    getLoanStatus(): Observable<any> {
        return this.httpClient.get(
            this.baseUrl + 'LoanDistribution/GetStatus',
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    getDistributionType(): Observable<any> {
        return this.httpClient.get(
            this.baseUrl + 'LoanDistribution/GetDistributionType',
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    errorHandler(error: HttpErrorResponse) {
        return throwError(error);
    }
}
