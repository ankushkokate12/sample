
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, Subject, throwError, BehaviorSubject } from 'rxjs';
import { AppConfig } from '../constants/app.config.constant';
import { HeaderUtil } from '../utils/header-util';
import { catchError, tap } from 'rxjs/operators';
import { BaseApiPathService } from './baseapi.service';
import { LoginDetails } from '../vo/lolgin-interface';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  
  _userActionOccured: Subject<void> = new Subject();  
  reqHeaders: any;
  userId: any = 93;
  username;
  password;
  loginData: LoginDetails;
  mfaDetails: any;
  startupPage;
  contactId: Object;
  userlogin:any = {}
  private userLoginData = new BehaviorSubject(this.userlogin); // Declare a source as Subject
  currentUserLoginData = this.userLoginData.asObservable();
  constructor(private httpClient: HttpClient, private baseApiPathService: BaseApiPathService) { }
  baseUrl: string = this.baseApiPathService.configPath;

  getReadHttpOptions(): any {
    const httpReadOptions = {
      headers: new HttpHeaders({
        //Authorization: 'Bearer ' + HeaderUtil.getToken()
        UserId: sessionStorage.getItem('contactId')//'45' //this.userId
      })
    };
    return httpReadOptions;
  }

  get userActionOccured(): Observable<void> {
    return this._userActionOccured.asObservable()
  };

  updateCurrentUserLoginData(userLoginData: any) {
    this.userLoginData.next(userLoginData);
  }

  notifyUserAction() {
    this._userActionOccured.next();
  }

  logout() {
    this.loginData = null;
    this.contactId = null;
    sessionStorage.clear();
    localStorage.clear();  
  }

  login(username, password) {
    this.baseUrl = this.baseApiPathService.configPath;
    this.username = username;
    this.password = password;
    const httpOptions = {
      headers: new HttpHeaders({
        username,
        password
      })
    };   
    return this.httpClient.post(
      this.baseApiPathService.configPath + 'login',
      { username, password },
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }

  sendOtp(type) {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.loginData.token
      })
    };

    this.mfaDetails.factorType = type;
    return this.httpClient.post(

      this.baseApiPathService.configPath + 'login/send-otp',
      { type },
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }


  validateOtp(otp) {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.loginData.token
      })
    };
    return this.httpClient.post(

      this.baseApiPathService.configPath + 'login/validate-otp',
      { OTP: otp },
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }

  changePassword(newPassword: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.loginData.token
      })
    };
    return this.httpClient.post(
      this.baseApiPathService.configPath + 'login/first-pass',
      {NewPassword: newPassword},
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }

  changePasswordUserProfile(userCredentials: any,token:any): Observable<any> {
    let currentToken:any = (((token != undefined) && (token != null)) ? (token):null);
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + currentToken
      })
    };
    return this.httpClient.post(
      this.baseApiPathService.configPath + 'login/Change-pass',
      userCredentials,
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }

  changePhoneForNewUser(data: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.loginData.token
      })
    };
    return this.httpClient.post(
      this.baseApiPathService.configPath + 'Login/change-phone',
      data,
      httpOptions
    ).pipe(catchError(this.errorHandler));
  }

  forgotPassword(emailAddress: string): Observable<any> {
    let forgotPasswordUrl= this.baseApiPathService.configPath + 'login/reset-pass?emailAddress=' + emailAddress;
    return this.httpClient.get(
      forgotPasswordUrl
    ).pipe(catchError(this.errorHandler));
  }

  resetRefreshToken(): Observable<any> {
    let tokenData:any = JSON.parse(sessionStorage.getItem('loggedInUser'));
    let tokenObj:any = {
      token:tokenData.access.token,
      refreshToken: tokenData.access.refreshToken,
      refreshTokenExpiration: tokenData.access.refreshTokenExpiration
    }

    return this.httpClient.post(
      this.baseApiPathService.configPath + 'login/refresh-token',
      tokenObj
    ).pipe(
      tap(response => {
        let loggedInUser:any = JSON.parse(sessionStorage.getItem('loggedInUser'));

        loggedInUser.access.token = response.token;
        loggedInUser.access.refreshToken = response.refreshToken;
        loggedInUser.access.expiration = response.expiration;
        loggedInUser.access.refreshTokenExpiration = response.refreshTokenExpiration;
        
        sessionStorage.setItem("loggedInUser", JSON.stringify(loggedInUser));
      })
    );
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }
}