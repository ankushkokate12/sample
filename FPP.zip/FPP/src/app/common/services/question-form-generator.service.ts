import { ValidationRule } from '../utils/validation-rules';
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators, ValidationErrors, AbstractControl, ValidatorFn } from '@angular/forms';
import { Question } from 'src/app/common/vo/questionnaire.model';
import { customRequiredValidator } from '../utils/custom-required-validator';
import { DateFormatUtility } from 'src/app/common/utils/dateFormat-utility';
import { maxSelectCheckboxesToBeCheckedValidator } from '../utils/max-select-checkbox';

const selectOne = 'RADIO';
const selectMulti = 'CHECKBOX';

@Injectable()
export class QuestionFormGeneratorService {
    formControls: any;
    selectAnswer: any;
    constructor() { }
    getQuestionsFormGroup(quesitons: Question[],answers: any): FormGroup {

        const group: { [key: string]: AbstractControl } = {};
        // for(let i=0;i<quesitons.length;i++){
        //     if(quesitons[i].questionId == answers[i].questionId){
        //         quesitons[i].selectedAnswer = answers[i].Answer;
        //     }
        // }
        quesitons.forEach(question => {
            if(answers != null){
            // this.selectAnswer = answers.filter(answer => answer.questionId === question.questionId);
            let multiAnswers = [];
            answers.forEach(answer =>{
                
                if(question.questionId == answer.QuestionMapId){
                    if(question.Type=="CheckBox"){
                       
                       multiAnswers.push(answer.Answer);    
                        question.selectedAnswer = multiAnswers;
                    }
                    else{
                    question.selectedAnswer = answer.Answer; 
                    }                   
                }
            })
        }
            if(question.Type == "Date" && question.selectedAnswer != ""){
                
                if (question.regex == "") {
                    if (question.isMendatory && question.isDependant) {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '');
                    }
                    else if (question.isMendatory == true) {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '', Validators.required);
                    }
                    else {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '');
                    }
                }
                else {
                    if (question.isMendatory && question.isDependant) {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '');
                    }
                    else if (question.isMendatory == true) {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '', [Validators.required, Validators.pattern(question.regex)]);
                    }
                    else {
                        this.formControls = new FormControl(new Date(question.selectedAnswer) || '');
                    }
                }
            }
            else{
                if (question.regex == "") {
                    if (question.isMendatory && question.isDependant) {
                        this.formControls = new FormControl(question.selectedAnswer || '');
                    }
                    else if (question.isMendatory == true) {
                        this.formControls = new FormControl(question.selectedAnswer || '', Validators.required);
                    }
                    else {
                        this.formControls = new FormControl(question.selectedAnswer || '');
                    }
                }
                else {
                    if (question.isMendatory && question.isDependant) {
                        this.formControls = new FormControl(question.selectedAnswer || '');
                    }
                    else if (question.isMendatory == true) {
                        this.formControls = new FormControl(question.selectedAnswer || '', [Validators.required, Validators.pattern(question.regex)]);
                    }
                    else {
                        this.formControls = new FormControl(question.selectedAnswer || '');
                    }
                }
            }
            
            group[question.questionId] =
                question.Type.toUpperCase() === selectMulti ?
                // new FormGroup(this.getAnswerOptionsControlsObj(question), { validators: [customRequiredValidator, maxSelectCheckboxesToBeCheckedValidator(question.MaxSelect)] }) :
                    new FormGroup(this.getAnswerOptionsControlsObj(question), { validators: [customRequiredValidator] }) :
                    this.formControls;            
        });
        

        return new FormGroup(group);
    }

    private getAnswerOptionsControlsObj(question) {
        const group: { [key: string]: AbstractControl } = {};
        question.options.forEach(Option => group[Option] = new FormControl(this.getSelectedAnswerControlsObj(question, Option)));
        return group;
    }

    private getSelectedAnswerControlsObj(question, Option) {
        var selectedOptions;
        for(let i=0;i<question.selectedAnswer.length;i++){
            if(question.selectedAnswer[i]==Option){
                selectedOptions = true
            }
        }
        return selectedOptions;
    }

    // private getValidationFunctions(validationRuleStrings: string[]): Array<(control: AbstractControl) => ValidationErrors | null> | null {

    //     const validationRules = [];
    //     for (const validationRuleStr of validationRuleStrings) {
    //         const validationRule = ValidationRule.validationRulesMap.get(validationRuleStr.toUpperCase());
    //         if (validationRule !== undefined) {
    //             validationRules.push(validationRule.validationFn);
    //         }
    //     }

    //     return validationRules.length > 0 ? validationRules : null;
    // }
}