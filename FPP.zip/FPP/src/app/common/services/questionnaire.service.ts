import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, Observable, Subject } from 'rxjs';
import { HeaderUtil } from '../utils/header-util';
import { catchError } from 'rxjs/operators';
import { AppConfig } from '../constants/app.config.constant';
import { BaseApiPathService } from './baseapi.service';
import { LoginService } from './login.service';
import { QuestionSection } from '../vo/questionnaire.model';

@Injectable({
  providedIn: 'root'
})
export class QuestionnaireService {

  public QuestionnaireData: QuestionSection[];
 
  // baseUrl: string = AppConfig.SERVER_PATH + '';
  baseUrl: string = this.baseApiPathService.configPath + 'Questionnaire';
  // baseUrl: string = '../../../assets/data/questionnaires.json';
 reqHeaders: any;

 constructor(private httpClient: HttpClient, 
             private baseApiPathService: BaseApiPathService,
             private loginService: LoginService) { }

 errorHandler(error: HttpErrorResponse) {
     return throwError(error);
 }

 getReadHttpOptions(): any {
     const httpReadOptions = {
         headers: new HttpHeaders({
            //  Authorization: 'Bearer ' + HeaderUtil.getToken()
            UserId: sessionStorage.getItem('contactId')//this.loginService.contactId.toString()
         })
     };
     return httpReadOptions;
 }

 /******************** EMPLOYEE INFORMATION *********************/

//  private dcQuestionnaireData = new Subject<any>(); // Declare a source as Subject
//   dataCollectionQuestionsData = this.dcQuestionnaireData.asObservable();

//   getEmployeeInformationData(questionData: any) {
//     return this.httpClient
//       .post(
//         this.baseUrl + "/GetQuestionnaire",
//         questionData,
//         this.getReadHttpOptions()
//       )
//       .subscribe(response => {
//         this.dcQuestionnaireData.next(response);
//       });
//   }

 getEmployeeInformationData(questionData: any): Observable<any> {
  // let baseUrl: string = '../../../assets/data/questionnaires.json';
  return this.httpClient.post(
    this.baseUrl + "/GetQuestionnaire",
    questionData,
    this.getReadHttpOptions()
).pipe(catchError(this.errorHandler));
}

// getEmployeeInformationData(questionData: any): Observable<any> {
//   let baseUrl: string = '../../../assets/data/questionnaires.json';
//   return this.httpClient.get(
//       baseUrl,
//       this.getReadHttpOptions()
//   ).pipe(catchError(this.errorHandler));
// }

setGlobalQuestionData(val:any){
  this.QuestionnaireData = val;
}
getGlobalQuestionData(){
  return this.QuestionnaireData
}

updateEmployeeInformationData(empoyeeInfoQuestions: any): Observable<any> {
  return this.httpClient.post(
      this.baseUrl +"/SubmitQuestionnaire",
      empoyeeInfoQuestions,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

getQuestionnaireMenu(planDetails: any): Observable<any> {
  return this.httpClient.post(
      this.baseUrl +"/QuestionnaireMenu",
      planDetails,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

// getQuestionnaireMenu(): Observable<any> {
//   // let baseUrl: string = "../../../assets/data/menu.json";

//   return this.httpClient
//     .get(
//       this.baseUrl +"/QuestionnaireMenu",
//       this.getReadHttpOptions()
//     )
//     .pipe(catchError(this.errorHandler));
// }

/******************** Service Provider Information *********************/

getServiceProviderInfoData(): Observable<any> {
  let baseUrl: string = '../../../assets/data/questionnaires.json';
  return this.httpClient.get(
      baseUrl,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

updateServiceProviderInfoData(serviceProviderInfoQuestions: any): Observable<any> {
  return this.httpClient.put(
      this.baseUrl,
      serviceProviderInfoQuestions,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

/******************** General Plan Information *********************/

getGeneralPlanInfoData(): Observable<any> {
  let baseUrl: string = '../../../assets/data/questionnaires.json';
  return this.httpClient.get(
      baseUrl,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

updateGeneralPlanInfoData(generalPlanInfoQuestions: any): Observable<any> {
  return this.httpClient.post(
      this.baseUrl + "/SubmitQuestionnaire",
      generalPlanInfoQuestions,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

/******************** Employer Contribution and Loan Information *********************/

getEmployerContributionLoanInfoData(): Observable<any> {
  let baseUrl: string = '../../../assets/data/questionnaires.json';
  return this.httpClient.get(
      baseUrl,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

updateEmployerContributionLoanInfoData(employerContributionLoanInfo: any): Observable<any> {
  return this.httpClient.put(
      this.baseUrl,
      employerContributionLoanInfo,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

/******************** 5500 Questionnaire *********************/

getQuestionnaire5500InfoData(): Observable<any> {
  let baseUrl: string = '../../../assets/data/questionnaires.json';
  return this.httpClient.get(
      baseUrl,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

updateQuestionnaire5500InfoData(questionnaire5500Questions: any): Observable<any> {
  return this.httpClient.put(
      this.baseUrl,
      questionnaire5500Questions,
      this.getReadHttpOptions()
  ).pipe(catchError(this.errorHandler));
}

}
