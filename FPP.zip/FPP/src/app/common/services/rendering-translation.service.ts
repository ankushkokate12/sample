import { Injectable } from '@angular/core';
import { Rendering } from '../utils/question-rendering';
import { Question } from 'src/app/common/vo/questionnaire.model';

export const comboboxOptionsThreshold = 7;

class RenderingTranslationRule {

    public static textareaRenderingRule = new RenderingTranslationRule(Rendering.textarea, (question: Question) => {
        if (question.Type.toUpperCase() === 'TEXTAREA') {
            return true;
        }
        return false;
    });

    public static textboxRenderingRule = new RenderingTranslationRule(Rendering.textbox, (question: Question) => {
        if (question.Type.toUpperCase() === 'TEXTBOX') {
            return true;
        }
        return false;
    });

    public static dateRenderingRule = new RenderingTranslationRule(Rendering.date, (question: Question) => {
        if (question.Type.toUpperCase() === 'DATE') {
            return true;
        }
        return false;
    });

    public static numberboxRenderingRule = new RenderingTranslationRule(Rendering.numberbox, (question: Question) => {
        if (question.Type.toUpperCase() === 'NUMBERBOX') {
            return true;
        }
        return false;
    });
    

    public static radioRenderingRule = new RenderingTranslationRule(Rendering.radio, (question: Question) => {
        if (question.Type.toUpperCase() === 'RADIO' &&
            question.options.length < comboboxOptionsThreshold) {
            return true;
        }

        return false;
    });

    public static checkboxRenderingRule = new RenderingTranslationRule(Rendering.checkbox, (question: Question) => {
        if (question.Type.toUpperCase() === 'CHECKBOX' &&
            question.options.length < comboboxOptionsThreshold) {
            return true;
        }

        return false;
    });

    private constructor(public rendering: Rendering, public booleanExp: (Question) => boolean) {
    }
}

@Injectable()
export class RenderingTranslationService {

    constructor() {
    }

    private renderingTranslationRules: RenderingTranslationRule[] = [
        RenderingTranslationRule.textareaRenderingRule,
        RenderingTranslationRule.textboxRenderingRule,
        RenderingTranslationRule.dateRenderingRule,
        RenderingTranslationRule.numberboxRenderingRule,
        RenderingTranslationRule.radioRenderingRule,
        RenderingTranslationRule.checkboxRenderingRule
    ];

    getRenderingForQuestion(question: Question): Rendering {

        let renderingToReturn;
        for (const renderingTranslationRule of this.renderingTranslationRules) {
            if (renderingTranslationRule.booleanExp(question)) {
                renderingToReturn = renderingTranslationRule.rendering;
                break;
            }
        }

        if (!renderingToReturn) {
            throw new Error('No renderings for question: ' + question.questionId);
        }

        return renderingToReturn;
    }
}
