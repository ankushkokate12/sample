import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse
} from "@angular/common/http";
import { Observable, throwError, Subject, BehaviorSubject } from "rxjs";
import { AppConfig } from "../constants/app.config.constant";
import { HeaderUtil } from "../utils/header-util";
import { catchError } from "rxjs/operators";
import { BaseApiPathService } from "./baseapi.service";
import { LoginService } from "./login.service";

@Injectable({
  providedIn: "root"
})
export class SecureCommunicationService {
  //baseUrl: string = '../../../assets/data/userprofile.json';
  //userId:any = '35';
  reqHeaders: any;
  plans: any;
  contacts: any;

  constructor(
    private httpClient: HttpClient,
    private baseApiPathService: BaseApiPathService,
    private loginService: LoginService
  ) {}

  baseUrl: string = this.baseApiPathService.configPath;
  //userId: string = this.baseApiPathService.userIds;
  getPlanListUrl: string = this.baseUrl + "Plan";
  secureCommunicationUrl: string = this.baseUrl + "SecureCommunication";
  getSecureMessageCountUrl: string = this.secureCommunicationUrl + "/count";
  getcontactsUrl: string = this.secureCommunicationUrl + "/myContacts/";
  getSecureCommunicationUrl: string = this.secureCommunicationUrl + "/get";
  getCategoryListUrl: string = this.secureCommunicationUrl + "/categories";
  accessHistoryUrl: string = this.secureCommunicationUrl + "/ActionHistory/";
  postActionUrl: string = this.secureCommunicationUrl + "/action";
  categories: any;
  _unreadMessageCount: Subject<void> = new Subject();

  get unreadMessageCount(): Observable<void> {
    return this._unreadMessageCount.asObservable();
  }

  notifyUnreadMessageCount(count) {
    this._unreadMessageCount.next(count);
  }

  getReadHttpOptions(): any {
    const httpReadOptions = {
      headers: new HttpHeaders({
        // Authorization: 'Bearer ' + HeaderUtil.getToken()
        UserId: sessionStorage.getItem("contactId") //this.loginService.contactId.toString(),
        //UserId: this.userId
      })
    };
    return httpReadOptions;
  }

  getSecureMessageCount(): Observable<any> {
    return this.httpClient
      .get(this.getSecureMessageCountUrl, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  getSecureCommunication(filterData): Observable<any> {
    return this.httpClient
      .post(
        this.getSecureCommunicationUrl,
        filterData,
        this.getReadHttpOptions()
      )
      .pipe(catchError(this.errorHandler));
  }

  sendSecureCommunication(data): Observable<any> {
    const fileOptions = {
      headers: new HttpHeaders({
        "enctype": "multipart/form-data",
        "Content-Type": "multipart/form-data"
      }),
      ...this.getReadHttpOptions()
    };
    return this.httpClient
      .post(this.secureCommunicationUrl, data, fileOptions)
      .pipe(catchError(this.errorHandler));
  }

  getContacts(planId) {
    return this.httpClient
      .get(this.getcontactsUrl + planId, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  getPlans() {
    return this.httpClient
      .get(this.getPlanListUrl, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  getCategories() {
    return this.httpClient
      .get(this.getCategoryListUrl, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  getAccessHistory(messageId): Observable<any> {
    return this.httpClient
      .get(this.accessHistoryUrl + messageId, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  postAction(data): Observable<any> {
    return this.httpClient
      .post(this.postActionUrl, data, this.getReadHttpOptions())
      .pipe(catchError(this.errorHandler));
  }

  download(messageId): Observable<any> {
    return this.httpClient
      .get(
        this.secureCommunicationUrl + "/download/" + messageId,
        this.getFileDownloadOption()
      )
      .pipe(catchError(this.errorHandler));
  }

  //this.getFileDownloadOption()

  getFileDownloadOption() {
    const fileOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/octet-stream"
      }),
      responseType: "blob",
      ...this.getReadHttpOptions()
    };
    return fileOptions;
  }

  // updateUserProfileData(userProfile: any): Observable<any> {
  //     return this.httpClient.put(
  //         this.baseUrl,
  //         userProfile,
  //         this.getReadHttpOptions()
  //     ).pipe(catchError(this.errorHandler));
  // }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }
}
