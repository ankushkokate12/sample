import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { AppConfig } from '../constants/app.config.constant';
import { HeaderUtil } from '../utils/header-util';
import { catchError } from 'rxjs/operators';
import { BaseApiPathService } from './baseapi.service';
import { LoginService } from './login.service';

@Injectable({
    providedIn: 'root'
})
export class UserProfileService {
    //userId: string = '35';
    reqHeaders: any;

    constructor(private httpClient: HttpClient,
        private baseApiPathService: BaseApiPathService,
        private loginService: LoginService) { }
    baseUrl: string = this.baseApiPathService.configPath + 'userprofile';
    //userId: string;
    userId: string = this.baseApiPathService.userIds;
    //baseUrl: string = '../../../assets/data/userprofile.json'; 

    getReadHttpOptions(): any {
        const httpReadOptions = {
            headers: new HttpHeaders({
                // Authorization: 'Bearer ' + HeaderUtil.getToken(),
                UserId: sessionStorage.getItem('contactId')//this.loginService.contactId.toString(),
            })
        };
        return httpReadOptions;
    }

    private getLoggedInUsers = new BehaviorSubject('');
    currentUser = this.getLoggedInUsers.asObservable();

    updateLoggedInUser(user: string) {
        this.getLoggedInUsers.next(user);
    }

    getLoggedInUser() {
        return this.httpClient.get(
            this.baseUrl + '/User',
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    getUserProfileData(): Observable<any> {
        return this.httpClient.get(
            this.baseUrl,
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    updateUserProfileData(userProfile: any): Observable<any> {
        let userDetail: any = userProfile;
        return this.httpClient.put(
            this.baseUrl,
            userDetail,
            this.getReadHttpOptions()
        ).pipe(catchError(this.errorHandler));
    }

    errorHandler(error: HttpErrorResponse) {
        return throwError(error);
    }
}
