import { AbstractControl, ValidatorFn, FormGroup } from "@angular/forms";
export class FormGroupWarn extends FormGroup { warnings: any; }

export class DateValidators {
    static dateLessThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(dateField1).value;
            const date2 = c.get(dateField2).value;
            if ((date1 !== null && date2 !== null) && date1 > date2) {
                return validatorField;
            }
            return null;
        };
    }
    
    static dobLessOHD(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(dateField1).value;
            const date2 = c.get(dateField2).value;

            if ((date1 !== null && date2 !== null) && date1 <= date2) {
                let DATE1 =  new Date(c.get(dateField1).value)
                let DATE2 = new Date(c.get(dateField2).value);
                let EIGHTEEN_YEARS_BACK = new Date(new Date(DATE2).getDate() + "/" + new Date(DATE2).getMonth() + "/" + (new Date(DATE2).getFullYear() - 18));
                // Validate Now
                let result = DATE1 > EIGHTEEN_YEARS_BACK; 
       
                if (result) {
                    return validatorField;
                }
                return null;
            }
        };
    }

    static dobLessthan99OHD(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(dateField1).value;
            const date2 = c.get(dateField2).value;

            if ((date1 !== null && date2 !== null)) {
                let DATE1 =  new Date(c.get(dateField1).value)
                let DATE2 = new Date(c.get(dateField2).value);
                let EIGHTEEN_YEARS_BACK = new Date(new Date(DATE2).getDate() + "/" + new Date(DATE2).getMonth() + "/" + (new Date(DATE2).getFullYear() - 99));
                // Validate Now
                let result = EIGHTEEN_YEARS_BACK > DATE1; 
       
                if (result) {
                    return validatorField;
                }
                return null;
            }
        };
    }

    static ODSLessThanPlanDate(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(dateField1).value;
            const date2 = c.get(dateField2).value;


            if ((date1 !== null && date2 !== null)) {
                let date1Year = +date1.getFullYear()
                let date1Month = +date1.getMonth();
                let date1Date = +date1.getDate();

                let date2Year = +date2.getFullYear()
                let date2Month = +date2.getMonth();
                let date2Date = +date2.getDate();
                let date2Validate = +(date2.getFullYear()) - 18;

                if (date1Year >= date2Year) {
                    return validatorField;
                }
                return null;
            }
        };
    }

    static rehireTerminationDateCheck(Field1: string, Field2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(Field1).value;
            const date2 = c.get(Field2).value;
            if (date1 == null  && date2 != null) {
                return validatorField;
            }
            return null;
        };
    }

    static DOBmorethatToday(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            let TODAY = new Date(Date.now());
            let EIGHTEEN_YEARS_BACK = new Date(new Date(TODAY).getDate() + "/" + new Date(TODAY).getMonth() + "/" + (new Date(TODAY).getFullYear() - 18));
            let USER_INPUT = new Date(c.get(dateField1).value);
            // Validate Now
            let result = EIGHTEEN_YEARS_BACK < USER_INPUT; 
   
            if (result) {
                return validatorField;
            }
            return null;
        };
    }
}


