import { AbstractControl, ValidatorFn, FormGroup, FormControl } from "@angular/forms";



export class ZeroCheckValidators {
    static zeroCheck(Field1: string, Field2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(Field1).value;
            const date2 = c.get(Field2).value;
            if ((date1== "0" || date1=="00" || date1=="000" || date1=="0000")) {
                return validatorField;
            }
            return null;
        };
    }

    static severanceCompCheck(Field1: string, Field2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const date1 = c.get(Field1).value;
            const date2 = c.get(Field2).value;
            if ((date1 != null && date1 != "") && date2==null) {
                return validatorField;
            }
            return null;
        };
    }

    static excludedCompensationCompareWithGrossCheck(Field1: string, Field2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl): { [key: string]: boolean } | null => {
            const field1 = c.get(Field1).value;
            const field2 = c.get(Field2).value;
            if ((field1 !== null && field2 !== null) && field1 > field2) {
                return validatorField;
            }
            return null;
        };
    }

    static validateSSN() {
        let SSN_REGEXP = '^(?!012345678$|123456789$|987654321$|876543210$|000000000$|111111111$|222222222$|333333333$|444444444$|555555555$|666666666$|777777777$|888888888$|999999999$|012-34-5678$|123-45-6789$|987-65-4321$|876-54-3210$|000-00-0000$|111-11-1111$|222-22-2222$|333-33-3333$|444-44-4444$|555-55-5555$|666-66-6666$|777-77-7777$|888-88-8888$|999-99-9999$).*';
      
        return SSN_REGEXP;
    }

}


