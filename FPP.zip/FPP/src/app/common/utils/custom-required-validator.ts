import { ValidatorFn, FormGroup, ValidationErrors } from "@angular/forms";

export const customRequiredValidator: ValidatorFn = (group: FormGroup): ValidationErrors | null => {
    let isValid = false;
    Object.keys(group.controls).forEach(key => {
        if (group.controls[key].value) {
            isValid = true;
        };
    });
    return isValid ? null : { 'groupRequired': true };
};