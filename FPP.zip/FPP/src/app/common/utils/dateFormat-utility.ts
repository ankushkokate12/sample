export class DateFormatUtility {
    public static UTCToLocal(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(new Date(date).toISOString());
        } else {
            return '';
        }
    }
   

    // public static getUTCDate(date: any): any {
    //     return new Date(this.UTCToLocal.toUTCString();


    //   }

    public static getUTCDate(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(date + 'Z');
        } else {
            return '';
        }
    }

    public static UTCToLocalInFormat(date: any): any {
        if (date != null && date != "" && date != undefined) {
            var newDate = new Date(date);

            var sMonth = this.padValue(newDate.getMonth() + 1);
            var sDay = this.padValue(newDate.getDate());
            var sYear = newDate.getFullYear();
            var sHour = newDate.getHours();
            var sMinute = this.padValue(newDate.getMinutes());
            var sAMPM = "AM";

            var iHourCheck = sHour;

            if (iHourCheck > 12) {
                sAMPM = "PM";
                sHour = iHourCheck - 12;
            }
            else if (iHourCheck === 0) {
                sHour = 12;
            }

            sHour = this.padValue(sHour);

            return sMonth + "-" + sDay + "-" + sYear + "_" + sHour + ":" + sMinute + sAMPM;

        } else {
            return '';
        }
    }

    private static padValue(value) {
        return (value < 10) ? "0" + value : value;
    }
    public static LocalToUTC(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(date).toISOString();
        } else {
            return '';
        }
    }
    public static UTCToLocalDateOnly(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(date + 'Z').toLocaleDateString();
        } else {
            return '';
        }
    }

    public static UTCToLocalDateOnlyForCensus(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(new Date(date).toISOString());
        } else {
            return '';
        }
    }

    public static UTCToLocalTimeStamp(date: any): any {
        if (date != null && date != "" && date != undefined) {
            return new Date(date + 'Z').getTime();
        } else {
            return '';
        }
    }
}

