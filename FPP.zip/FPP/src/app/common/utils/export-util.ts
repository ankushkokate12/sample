export class ExportUtil {
    public static exportReportHandler(resultBlob: any, filetype: ExportFileType, filename: string) {
        const blob = new Blob([resultBlob], {
            type: filetype
        });
        const fileUrl = window.URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.download = filename;
        anchor.href = fileUrl;
        anchor.click();
    }

    public static findFileType(fileName:string):any{
        let re = /(?:\.([^.]+))?$/;

        let fileType = re.exec(fileName)[1];
        let fileExtension = 'application/txt';

        if(fileType == 'xls' || fileType == 'xlsx'){
            fileExtension = ExportFileType.EXCEL;
        }else if(fileType == 'pdf'){
            fileExtension = ExportFileType.PDF;
        }else if(fileType == 'doc' || fileType == 'dot'){
            fileExtension = ExportFileType.DOC;
        }else if(fileType == 'ppt' || fileType == 'pptx'){
            fileExtension = ExportFileType.PPT;
        }

        return fileExtension;
    }
}

export enum ExportFileType {
    PDF = 'application/pdf',
    EXCEL = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    DOC = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    PPT = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
}