export class HeaderUtil {
  private static token: string;
  public static setToken(token: string) {
    this.token = token;
  }
  public static getToken(): string {
    return this.token;
  }

  public static isTokenSet(): boolean {
    return (this.token !== undefined);
  }
}
