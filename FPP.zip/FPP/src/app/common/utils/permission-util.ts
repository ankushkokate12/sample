export class PermissionUtil {
  private static permission: any;
  public static setPermission(allPermissionsArr: any) {
    let permissionObj:any={};
    if((allPermissionsArr != undefined) && (allPermissionsArr != null)){
      if (allPermissionsArr.length > 0) {
        for (let i = 0; i < allPermissionsArr.length; i++) {
          permissionObj[allPermissionsArr[i].permissionCode] = true;
        }
      }
      this.permission = permissionObj;
    }
  }
  
  public static getPermission(): any {
    if((this.permission != null) && (this.permission != undefined)){
      return this.permission;
    }else{
      return {};
    }
  }

  public static isPermissionSet(): boolean {
    return ((this.permission !== undefined) && (this.permission != null));
  }
}
