export class Utility {
    public static removeMasking(str:any):any{
        if(str != null || str != undefined){
            if(typeof(str) == "string"){
                return str.replace(/-/g, '');
            }else{
                return str;
            }
        }else{
            return str;
        }
    }

    public static showErrMsg(error:any):any{
        let errStr:string = '';
        if(error.error != null || error.error != undefined){
           let errorArr =  Object.values(error).join(" <br> ");
        }
        return errStr;
    }
    
    public static dcMenuArray: any = [
        {
            "SubSectionName": "Contacts",
            "SubSectionCode": "DCContacts",
            "isCompleted": true
        },
        {
            "SubSectionName": "Employee Company Data",
            "SubSectionCode": "DCEmpCompData",
            "isCompleted": true
        },
        {
            "SubSectionName": "Family Relationships",
            "SubSectionCode": "DCFamilyRelationship",
            "isCompleted": true
        },
        {
            "SubSectionName": "Other Businesses",
            "SubSectionCode": "DCOtherBusiness",
            "isCompleted": false
        },
        {
            "SubSectionName": "Ownership",
            "SubSectionCode": "DCOwnership",
            "isCompleted": false
        },
        {
            "SubSectionName": "Employee Census",
            "SubSectionCode": "DCEmployeeCensus",
            "isCompleted": false
        },
        {
            "SubSectionName": "Approval",
            "SubSectionCode": "DCApproval",
            "isCompleted": false
        }
    ]
}