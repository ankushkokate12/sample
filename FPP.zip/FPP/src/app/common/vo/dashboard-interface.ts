export interface EmployerPlanVo {
    planId: string,
    planName: string,
    consultantName: string,
    email: string,
    phoneNo: string
}
