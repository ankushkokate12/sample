export interface PendingTasksVo {
    taskMapId?: number,
    taskId?: number,
    planId: number,
    planTypeCode: string,
    plan: string,
    activeDate: string,
    dueDate: string,
    year: number,
    hasStarted: boolean
}

export interface CompletedTaskVo{
    planId:number,
    planName: string,
    roles:any,
    completedTasks: Array<DataCollectionHistoryVo>
}

export interface DataCollectionHistoryVo {
    id: number,
    startDate: string,
    endDate: string,
    completedDate: string,
    name: string
}

/***************** YEAR END DATA COLLECTION ********************** */
export interface SectionCompletion{
    employerCompanyData: string,
    principals: string,
    familyRelationship: string,
    business: string,
    contacts: string
}

export interface SaveSubmitVo{
    taskMapId: number,
    sectionID: string,
    isSave: boolean,
    contacts: string
}

export interface EmployerCompanyData {
    threadId?: string,
    employer: Employer,
    addresses: Array<AddressVo>,
    contacts: Array<ContactNumberVo>,
}

export interface Employer {
    taskMapId ?: number,
    employerId ?: number,
    companyName: string,
    ein: number,
    fiscalYear: string,
    entityTypeCode: string,
    naicCode: number,
    payrollProvider: string,
    payrlFreqTypes ?: Array<string>
    payrollFrequencyId ?: Array<string>
}

export interface AddressVo {
    taskMapId ?: number,
    id ?: number,
    address1: string,
    address2: string,
    city: string,
    state: string,
    zip: string,
    addressTypeCode: string
}

export interface ContactNumberVo {
    id ?: number,
    taskMapId ?: number,
    isdCode: string,
    phoneNumberTypeCode: string,
    phoneNumber: string,
    phoneNumberId?: number
}

export interface SectionsNotesData{
    planId: string,
    sectionId: string,
    notes: Array<NoteVo>
}

export interface NoteVo {
    id?: number,
    dcTaskId?: number,
    note?: string,
    createdBy?: number,
    createdByfullName?: string,
    createdOn?: string,
    isApproval?: boolean,
    portalSubSectionCode?: string
}

export interface PrincipalsOwnershipVo {
    dataCollectionEmployerOwnershipId ?: number,
    taskMapId ?: number,
    titleTypeCode: string,
    name: string,
    ownershipPercent: number,
    isOfficer: boolean
}

export interface FamilyRelationshipsVo {
    dcOwnerRelationshipId ?: number,
    dcEmployerOwnershipId ?: number,
    name: string,
    relatedTo: string,
    relationshipTypeCode: string,
    relationship: string
}

export interface BusinessesDetails {
    planId?: string,
    sectionId?: string,
    isOveride?:boolean,
    businesses?: Array<BusinessVo>
}

export interface BusinessVo {
    dcEmployerOtherBusinessId ?: number,
    taskMapId ?: number,
    companyName: string
    datePurchase?: string,
    ein?: number,
    phone?: string,
    isdCode?: string,
    hasEmployees?: boolean,
    qualifiedPlan?: boolean,
    entityTypeCode?: string,
    planSponsor?: string,
    addresses: AddressVo,
    otherBusinessOwners?: Array<BusinessOwnersVo>
}

export interface BusinessOwnersVo {
    dcOtherBusinessOwnerId?: number,
    dcOtherBusinessId ?: number,
    oName?: string,
    oPercent?: string
}

/*****************  DATA COLLECTION - CONTACTS ********************** */

// export interface ContactsDetailsVo {
//     planId: string,
//     sectionId: string,
//     contacts: Array<ContactsVo>
// }
export interface ContactsVo {
    contactId ? : null;
    contactName: string,
    contactInfos: Array<ContactInfoVo>,
    roles: [],
    permissions: [],
    issues: Array<IssuesVo>
}
export interface ContactInfoVo {
    name: string,
    email: string,
    mobile: string,
    workPhone: string
}
// export interface IssuesVo {
//     issueId ? : number,
//     issue: string,
//     date: number,
//     addedBy: string,
//     emailId: string,
//     isDeleted: boolean,
//     isModified: boolean
// }

export interface IssuesVo {
    id ? : number,
    description: string,
    fullName ?: string,
    contactId: number,
    createDateTimeStamp ?: string
}

/*****************  DATA COLLECTION - EMPLOYEE CENSUS ********************** */ 

export interface EmployeeSensusDetails {
    planId: string,
    sectionId: string,
    isOveride:boolean,
    employeeCensus: Array<EmployeeSensusInfo>
}

export interface EmployeeSensusInfo {
    dataCollectionCensusInfoId: number,
    dataCollectionTaskId: number,
    planId: number,
    firstName: string,
    lastName: string,
    ssn ?: string,
    dateofBirth ?: Date,
    gender: string,
    dateOfHire ?: string,
    previousDos ?: string,
    dos ?: string
    dateOfDeath ?: string,
    dateOfRehire ?: string,
    isOfficer ?: string,
    companyDivision ?: string,
    grossCompensation ?: number,
    excludedCompensation ?: number,
    severanceCompensation ?: number,
    hours ?: number,
    salariedEmployee ?: string,
    equivalencyRate ?: number,
    ksalaryDeferral ?: number,
    rothSalaryDeferral ?: number,
    safeHarborContribution ?: number,
    employerMatch ?: string,
    employerContribution ?: number,
    otherContribution ?: number,
    jobClassification ?: string,
    isUnionEmployee ?: string,
    isActiveMilitary ?: string,
    isLeasedEmployee ?: string,
    note ?: string,
}
/*****************  DATA COLLECTION - APPROVAL ********************** */ 

export interface ApprovalVo {
    planId: string,
    sectionId: string,   
    documents: Array<DocumentsVo>,
    notes:Array<ApprovalNotesVo>
}
export interface ApprovalNotesVo {
    sectionId: string,
    sectionName: string,
    noteId:string,
    note: string,
    date: number,
    createdBy: string
}
export interface DocumentsVo {
    DataCollectionApprovalDocumentID?:number,
    DataCollectionTaskID?:number,
    DisplayName?:string,
    GUID?:string,
    DocumentTypeCode?:string,
    Descreption?:string,
    FilePath?:string
}