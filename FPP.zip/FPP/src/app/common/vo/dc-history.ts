export class DCHistory {
    name: string;
    pstartdate: string;
    penddate: string;
    completed: string;
}