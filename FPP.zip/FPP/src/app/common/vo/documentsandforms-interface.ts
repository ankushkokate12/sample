export interface PlanSpecificDocumentVo {
    planSpecificDocuments: Array<PlanSpecificDocumentVo>;
    referenceDocuments: Array<ReferenceDocumentVo>;
}

export interface PlanSpecificDocumentVo {
    guid: string;
    fileName: string;
    planName: string;
    category: string;
}

export interface ReferenceDocumentVo {
    guid: string;
    fileName: string;
}