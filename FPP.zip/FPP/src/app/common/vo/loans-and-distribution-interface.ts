export interface LoansAndDistributionVo {
    employerFullName?: string,
    employerFirstName?: string,
    employerLastName?: string,
    status_val?: string,
    status_Description?: string,
    planName?: string,
    employerSSN?: string,
    distributionType_val?: string,
    distributionType_Description?: string,
    createdDate?: string,
    completionDate?: string,
    initiatedFrom?: string,
    initiatedTo?: string
}

export interface LoanStatusVo {
    value?: string,
    label?: string,
}


export interface DistributionTypeVo {
    value?: string,
    label?: string,
}