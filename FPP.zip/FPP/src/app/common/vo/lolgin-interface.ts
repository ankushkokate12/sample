export interface LoginDetails {
    authenticated: boolean;
    token: string;
    expiration: Date;
    otpFactors: OtpFactor[];
    isNewAccount: boolean;
    requiresNewPassword:boolean;
    message: any;
}

export interface OtpFactor{
    type: string;
    value: string;
}