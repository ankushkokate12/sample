
export interface Question {
    questionId: string;
    sectionId: string;
    sectionName: string;
    question: string;
    Type: string;
    options: [];
    chk_options: [];
    isMendatory: boolean;
    isDependant: boolean;
    isDependentOn: IsDependentOn;
    MaxSelect: number;
    regex: string;
    selectedAnswer?: any;
}

export interface QuestionSection {
    planId: string;
    SubsectionId: string;
    SubsectionName: string;
    questions: Question[];
    Answer: any[];
}

export interface IsDependentOn {
   question:string;
   value:string;
}

export interface AnswersData{
    SubSectionId: any,
    QuestionMapId: string,
    Answer: string,
    DataCollectionTaskID: number,
    AdditionalAnswerText: string,
    isSaveandContinue: boolean
}