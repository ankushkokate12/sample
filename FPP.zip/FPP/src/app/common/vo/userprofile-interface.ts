export interface UserProfileVo {
    userId?: string,
    prefixCode:string,
    firstName:string,
    suffix: string,
    lastName:string,
    email:string,
    title:string,
    company:string,
    address1: string,
    address2:string,
    city:string,
    state:string,
    zip:string,
    officePhone:string,
    isdOffice:string,
    extension:number,
    fax:string,
    mobile:string,
    isdMobile:string,
    isAddressDisabled:boolean,
    rolesAndPermissions: Array<rolesAndPermissionsVo>
}

export interface rolesAndPermissionsVo {
    userId:number,
    userName:string,
    companies:Array<CompaniesVo>
}
export interface CompaniesVo{
    companyId: number,
    companyName: string,
    plans: Array<PlansVo>
}
export interface PlansVo{
    planId: number,
    planName: string,
    roles: Array<RolesVo>
}
export interface RolesVo{
    roleCode: string,
    roleDescription: string,
    rolePermissions: Array<RightsVo>
}
export interface RightsVo{
    permissionID: number,
    permissionCode: string,
    permissionDescription: string
}

export interface CompanyData{
    companyName: string,
    plans: string
}
