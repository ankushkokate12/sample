import { Injectable } from "@angular/core";
import {
  CanDeactivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree
} from "@angular/router";
import { Observable } from "rxjs";
import { ConfirmationService } from "primeng/api";
import {Observer} from 'rxjs';

export declare interface DirtyComponent {
  canDeactivate: () => boolean | Observable<boolean>;
}

@Injectable({
  providedIn: "root"
})
export class HasUnsavedNotificationGuard
  implements CanDeactivate<DirtyComponent> {
  constructor(private confirmationService: ConfirmationService) {}

  canDeactivate(
    component: DirtyComponent,
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    // if (component.canDeactivate()) {
    //   return confirm('There are changes you have made to the page. If you quit, you will lose your changes.');
    // } else {
    //   return true;
    // }
    return component.canDeactivate ? component.canDeactivate() : true;

    // if (!component.canDeactivate()) {
    //   return true;
    // }
    // return Observable.create((observer: Observer<boolean>) => {
    //   this.confirmationService.confirm({
    //     message: "You have unsaved changes. Are you sure you want to leave this page?",
    //     header: "Confirmation",
    //     icon: "pi pi-exclamation-triangle",
    //     key: "warningConfirmationDialog",
    //     accept: () => {
    //       observer.next(true);
    //       observer.complete();
    //     },
    //     reject: () => {
    //       observer.next(false);
    //       observer.complete();
    //     }
    //   });
    // });
  }
}
