import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Route, CanActivateChild } from '@angular/router';

import { LoginService } from '../common/services/login.service';
import { PermissionUtil } from '../common/utils/permission-util';

@Injectable({ providedIn: 'root' })
export class SmGuard implements CanActivate, CanActivateChild {
    constructor(
        private router: Router,
        private authenticationService: LoginService
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        let permissionObj:any = {};
        
        if(!PermissionUtil.isPermissionSet()){
            PermissionUtil.setPermission(JSON.parse(sessionStorage.getItem("permissionRights")));
        }
      
        permissionObj = PermissionUtil.getPermission();
      
        if(permissionObj.MessageCenterAll != undefined){
            return true;
        }

        // not logged in so redirect to dashboard page with the return url
        this.router.navigate(['/home/dashboard'], { queryParams: { returnUrl: state.url }});
        return false;
    }

    canActivateChild(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean {
        return this.canActivate(route, state);
    }

}