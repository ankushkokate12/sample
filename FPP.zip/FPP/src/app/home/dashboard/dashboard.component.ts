import { Component, OnInit, AfterViewInit, AfterContentChecked } from "@angular/core";
import { PermissionUtil } from "../../common/utils/permission-util";
import { ConfirmationService } from "primeng/api";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent implements OnInit, AfterViewInit{
  permissionObj: any = {};
  permissionArr:any = [];

  constructor(private confirmationService:ConfirmationService) {}


  ngAfterViewInit () {
    if(this.permissionArr.length <= 0){
      this.showWarningDialogForPermission();
    }
  }

  ngOnInit() {
    this.permissionArr = JSON.parse(sessionStorage.getItem("permissionRights"));

    if (!PermissionUtil.isPermissionSet()) {
      PermissionUtil.setPermission(
        JSON.parse(sessionStorage.getItem("permissionRights"))
      );
    }
    this.permissionObj = PermissionUtil.getPermission();
  }

  showWarningDialogForPermission(){
    this.confirmationService.confirm({
      message: "You have insufficient permissions to view all pages, please contact Administrator/Consultant.",
      key: "warningPermissionConfirmDialog",
      accept: () => {
      },
      reject: () => {
        return;
      }
    });
  }
}
