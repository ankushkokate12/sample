import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home.component';
import { UserprofileComponent } from '../common/components/userprofile/userprofile.component';
import { SecureCommunicationComponent } from './secure-communication/secure-communication.component';
import { DataCollectionComponent } from '../common/components/data-collection/data-collection.component';
import { DcYearEndComponent } from '../common/components/year-end-data-collection/dc-year-end/dc-year-end.component';
import { DcLandingComponent } from '../common/components/dc-landing/dc-landing.component';
import { DocumentsFormsComponent } from '../common/components/documents-forms/documents-forms.component';
import { LoansDistributionComponent } from '../common/components/loans-distribution/loans-distribution.component';
import { EmployerCompanyDataComponent } from '../common/components/year-end-data-collection/employer-company-data/employer-company-data.component';
import { PrincipalsOwnershipsComponent } from '../common/components/year-end-data-collection/principals-ownerships/principals-ownerships.component';
import { FamilyRelationshipsComponent } from '../common/components/year-end-data-collection/family-relationships/family-relationships.component';
import { BusinessesComponent } from '../common/components/year-end-data-collection/businesses/businesses.component';
import { ContactsComponent } from '../common/components/year-end-data-collection/contacts/contacts.component';
import { EmployeeInfoComponent } from '../common/components/year-end-data-collection/questionnaire/employee-info/employee-info.component';
import { ServiceProviderInfoComponent } from '../common/components/year-end-data-collection/questionnaire/service-provider-info/service-provider-info.component';
import { GeneralPlanInfoComponent } from '../common/components/year-end-data-collection/questionnaire/general-plan-info/general-plan-info.component';
import { EmployerContributionLoanInfoComponent } from '../common/components/year-end-data-collection/questionnaire/employer-contribution-loan-info/employer-contribution-loan-info.component';
import { Questionnaire5500Component } from '../common/components/year-end-data-collection/questionnaire/questionnaire5500/questionnaire5500.component';
import { EmployeeCensusComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census/employee-census.component';
import { ApprovalComponent } from '../common/components/year-end-data-collection/approval/approval/approval.component';
import { ConfirmationGuard } from '../common/guards/confirmation/confirmation.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeCensusRecommendedComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-recommended/employee-census-recommended.component';
import { EmployeeCensusNotRecommendedComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-not-recommended/employee-census-not-recommended.component';
import { InboxComponent } from './secure-communication/inbox/inbox.component';
import { SentItemsComponent } from './secure-communication/sent-items/sent-items.component';
import { AuthGuard } from '../guard/auth-guard';
import { SmGuard } from '../guard/sm-guard';
import { DatacollectionGuard } from '../guard/datacollection-guard';
import { LoansGuard } from '../guard/loans-guard';
import { DocsGuard } from '../guard/docs-guard';
import { HasUnsavedNotificationGuard } from '../guard/has-unsaved-notification-guard.guard';

const routes: Routes = [
  {
    path: '', component: HomeComponent,
    children: [
      { path: 'profile', component: UserprofileComponent },
      { path: 'dashboard', component: DashboardComponent },
      {
        path: 'secure-messages', component: SecureCommunicationComponent,
        canActivate: [SmGuard],
        canActivateChild: [SmGuard],
        children: [
          { path: 'inbox', component: InboxComponent },
          { path: 'sent-items', component: SentItemsComponent },
          { path: '', redirectTo: 'inbox', pathMatch: 'full' }
        ]
      },
      { path: 'docs-and-forms', component: DocumentsFormsComponent, canActivate: [DocsGuard] },
      { path: 'loans-and-distribution', component: LoansDistributionComponent, canActivate: [LoansGuard] },
      {
        path: 'datacollection', component: DataCollectionComponent,
        canActivate: [DatacollectionGuard],
        canActivateChild: [DatacollectionGuard],
        children: [
          { path: 'datacollection-landing', component: DcLandingComponent },
          {
            path: 'datacollection-year-end', component: DcYearEndComponent,
            children: [
              { path: 'employeer-info', component: EmployerCompanyDataComponent,
                canDeactivate: [HasUnsavedNotificationGuard] },
              { path: 'principals-owners', component: PrincipalsOwnershipsComponent },
              { path: 'family-relationships', component: FamilyRelationshipsComponent },
              { path: 'businesses', component: BusinessesComponent },
              { path: 'contacts', component: ContactsComponent },
              { path: 'questionnaire/:id', component: EmployeeInfoComponent, 
              canDeactivate: [HasUnsavedNotificationGuard] },
              // { path: 'service-provider-info', component: ServiceProviderInfoComponent },
              // { path: 'general-plan-info', component: GeneralPlanInfoComponent },
              // { path: 'employer-contribution-loan-info', component: EmployerContributionLoanInfoComponent },
              // { path: 'questionnaire5500', component: Questionnaire5500Component },
              {
                path: 'employee-census', component: EmployeeCensusComponent,
                children: [
                  { path: 'census-recommended', component: EmployeeCensusRecommendedComponent,  canDeactivate: [HasUnsavedNotificationGuard] },
                  { path: 'census-notrecommended', component: EmployeeCensusNotRecommendedComponent },
                  // {
                  //   path: '', redirectTo: 'census-recommended', pathMatch: 'full'
                  // }
                ]
              },
              { path: 'approval', component: ApprovalComponent },
              {
                path: '', redirectTo: 'employeer-info', pathMatch: 'full'
              }
            ]
          },
          {
            path: '', redirectTo: 'datacollection-landing', pathMatch: 'full'
          }
        ]
      }
    ]
  }
];

@NgModule({
  providers: [ConfirmationGuard],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
