import { Component, OnInit, HostListener } from '@angular/core';
import { LoginService } from '../common/services/login.service';
import { DataService } from '../common/services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(private authService: LoginService,private dataService:DataService) { }

  @HostListener('document:keyup', ['$event'])
  @HostListener('document:click', ['$event'])
  @HostListener('document:mousemove', ['$event'])
  resetTimer() {
    this.authService.notifyUserAction();
  }

  ngOnInit() {
    this.dataService.getFileValidations();
  }

}
