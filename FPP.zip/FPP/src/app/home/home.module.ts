import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import {TableModule} from 'primeng/table';
import {TabViewModule} from 'primeng/tabview';
import {MultiSelectModule} from 'primeng/multiselect';
import { FormsModule } from '@angular/forms';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { DialogModule, Dialog } from 'primeng/dialog';
import {CalendarModule} from 'primeng/calendar';
import {InputMaskModule} from 'primeng/inputmask';
import {ToastModule} from 'primeng/toast';
import { BsDatepickerModule, DatepickerModule } from 'ngx-bootstrap/datepicker';
import {PanelModule} from 'primeng/panel';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { UserprofileComponent } from '../common/components/userprofile/userprofile.component';
import { ChangepasswordComponent } from '../common/components/changepassword/changepassword.component';
import { HeaderComponent } from '../common/components/header/header.component';
import { RolesRightsComponent } from '../common/components/roles-rights/roles-rights.component';
import { SecureCommunicationComponent } from './secure-communication/secure-communication.component';
import {CommunicationPopupComponent} from './secure-communication/communication-popup/communication-popup.component';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { NodeService } from './secure-communication/nodeService';
import { DataCollectionComponent } from '../common/components/data-collection/data-collection.component';
import { DataCollectionHistoryComponent } from '../common/components/data-collection-history/data-collection-history.component';
import { DcPendingTaskComponent } from '../common/components/dc-pending-task/dc-pending-task.component';
import { DcYearEndComponent } from '../common/components/year-end-data-collection/dc-year-end/dc-year-end.component';
import { DcLandingComponent } from '../common/components/dc-landing/dc-landing.component';
import { ProgressBarComponent } from '../common/components/progress-bar/progress-bar.component';
import { EmployerCompanyDataComponent } from '../common/components/year-end-data-collection/employer-company-data/employer-company-data.component';
import { AddressPopupComponent } from '../common/components/year-end-data-collection/address-popup/address-popup.component';
import { NotesComponent } from '../common/components/notes/notes.component';
import { ContactNumberPopupComponent } from '../common/components/year-end-data-collection/contact-number-popup/contact-number-popup.component';
import { PrincipalsOwnershipsComponent } from '../common/components/year-end-data-collection/principals-ownerships/principals-ownerships.component';
import { FamilyRelationshipsComponent } from '../common/components/year-end-data-collection/family-relationships/family-relationships.component';
import { PrincipalsOwnershipsPopupComponent } from '../common/components/year-end-data-collection/principals-ownerships-popup/principals-ownerships-popup.component';
import { FamilyRelationshipsPopupComponent } from '../common/components/year-end-data-collection/family-relationships-popup/family-relationships-popup.component';
import { BusinessesComponent } from '../common/components/year-end-data-collection/businesses/businesses.component';
import { BusinessesPopupComponent } from '../common/components/year-end-data-collection/businesses-popup/businesses-popup.component';
import { PlanSelectionPipe } from '../common/pipes/plan-selection.pipe';
import { ContactsComponent } from '../common/components/year-end-data-collection/contacts/contacts.component';
import { ContactsPopupComponent } from '../common/components/year-end-data-collection/contacts-popup/contacts-popup.component';
import { PhoneFormatPipe } from '../common/pipes/phone-format.pipe';
import { OnlyDigitsDirective } from '../common/directives/only-digits.directive';
import { ContactIssuesComponent } from '../common/components/year-end-data-collection/contact-issues/contact-issues.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ZipFormatPipe } from '../common/pipes/zip-format.pipe';
import { EmployeeInfoComponent } from '../common/components/year-end-data-collection/questionnaire/employee-info/employee-info.component';
import { QuestionComponent } from '../common/components/year-end-data-collection/questionnaire/question/question.component';
import { QuestionFormGeneratorService } from '../common/services/question-form-generator.service';
import { ServiceProviderInfoComponent } from '../common/components/year-end-data-collection/questionnaire/service-provider-info/service-provider-info.component';
import { GeneralPlanInfoComponent } from '../common/components/year-end-data-collection/questionnaire/general-plan-info/general-plan-info.component';
import { EmployerContributionLoanInfoComponent } from '../common/components/year-end-data-collection/questionnaire/employer-contribution-loan-info/employer-contribution-loan-info.component';
import { Questionnaire5500Component } from '../common/components/year-end-data-collection/questionnaire/questionnaire5500/questionnaire5500.component';
import { EmployeeCensusComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census/employee-census.component';
import { EmployeeCensusAddEmployeePopupComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-recommended/employee-census-add-employeepopup/employee-census-add-employee-popup.component';
import { EmployeeCensusSummaryPopupComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-recommended/employee-census-summary-popup/employee-census-summary-popup.component';


import {InactivityTimerComponent} from './inactivity-timer.component'
import { LoginService } from '../login/login.service';
import {ConfirmationService} from 'primeng/api';
import { PlanSpecificComponent } from '../common/components/plan-specific/plan-specific.component';
import { DocumentsFormsComponent } from '../common/components/documents-forms/documents-forms.component';
import { ReferenceDocumentComponent } from '../common/components/reference-document/reference-document.component';
import { LoansDistributionComponent } from '../common/components/loans-distribution/loans-distribution.component';
import { ApprovalComponent } from '../common/components/year-end-data-collection/approval/approval/approval.component';
import { DocumentsPopupComponent } from '../common/components/year-end-data-collection/approval/documents-popup/documents-popup.component';
import { AddNotesPopupComponent } from '../common/components/year-end-data-collection/approval/add-notes-popup/add-notes-popup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeePlanComponent } from '../common/components/employee-plan/employee-plan.component';
import { DateTimeUTCToLocal } from '../common/pipes/dateTimeUTCToLocal';
import { SSNMasking } from '../common/pipes/ssn-masking';
import { InboxComponent } from './secure-communication/inbox/inbox.component';
import { MessageDetailComponent } from './secure-communication/message-detail/message-detail.component';
import { EmployeeCensusRecommendedComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-recommended/employee-census-recommended.component';
import { EmployeeCensusNotRecommendedComponent } from '../common/components/year-end-data-collection/employee-sensus/employee-census-not-recommended/employee-census-not-recommended.component';
import { SentItemsComponent } from './secure-communication/sent-items/sent-items.component';
import { QuestionnaireService } from '../common/services/questionnaire.service';
import { FieldPipe } from '../common/pipes/field.pipe';
import { WarningDialogUnsavedDataComponent } from '../common/components/warning-dialog-unsaved-data/warning-dialog-unsaved-data.component';
import { PercentageDirective } from '../common/directives/percentage.directive';
import { DisableControlDirective } from '../common/directives/disable-control.directive';
@NgModule({
  declarations: [
    HomeComponent,
    HeaderComponent,
    UserprofileComponent, 
    ChangepasswordComponent,
    SecureCommunicationComponent, 
    CommunicationPopupComponent,
    RolesRightsComponent, 
    DataCollectionComponent, 
    DataCollectionHistoryComponent, 
    DcPendingTaskComponent, 
    DcYearEndComponent, 
    DcLandingComponent, 
    ProgressBarComponent, 
    EmployerCompanyDataComponent, 
    AddressPopupComponent, 
    NotesComponent, 
    ContactNumberPopupComponent, PrincipalsOwnershipsComponent, FamilyRelationshipsComponent, PrincipalsOwnershipsPopupComponent, FamilyRelationshipsPopupComponent, BusinessesComponent, BusinessesPopupComponent,
    PlanSelectionPipe,
    ContactsComponent,
    ContactsPopupComponent,
    PhoneFormatPipe,
    OnlyDigitsDirective,
    DisableControlDirective,
    PercentageDirective,
    ContactIssuesComponent,
    ZipFormatPipe,
    InactivityTimerComponent,
    DocumentsFormsComponent,
    PlanSpecificComponent,
    ReferenceDocumentComponent,
    LoansDistributionComponent,
    QuestionComponent,
    EmployeeInfoComponent,
    ServiceProviderInfoComponent,
    GeneralPlanInfoComponent,
    EmployerContributionLoanInfoComponent,
    Questionnaire5500Component,
    EmployeeCensusComponent,
    EmployeeCensusAddEmployeePopupComponent,
    EmployeeCensusSummaryPopupComponent,
    ApprovalComponent,
    DocumentsPopupComponent,
    AddNotesPopupComponent,
    DashboardComponent,
    EmployeePlanComponent,
    DateTimeUTCToLocal,
    SSNMasking,
    InboxComponent,
    MessageDetailComponent,
    EmployeeCensusRecommendedComponent,
    EmployeeCensusNotRecommendedComponent,
    SentItemsComponent,
    FieldPipe,
    WarningDialogUnsavedDataComponent,
    
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    ReactiveFormsModule,
    OverlayPanelModule,
    TableModule, 
    TabViewModule,
    MultiSelectModule,
    FormsModule,
    DialogModule,
    CalendarModule,
    InputMaskModule,
    ConfirmDialogModule,
    ToastModule,
    PanelModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgCircleProgressModule.forRoot({})
  ],
  providers: [NodeService, LoginService, ConfirmationService, QuestionFormGeneratorService,QuestionnaireService],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
})
export class HomeModule { }
