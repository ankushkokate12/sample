import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, timer, Subscription } from 'rxjs';
import { takeUntil, take, timeout } from 'rxjs/operators';
import { LoginService } from '../common/services/login.service';
import { Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { BaseApiPathService } from '../common/services/baseapi.service';




@Component({
  selector: 'inactivity-timer',
  template: `
  <p-confirmDialog key="inactivityTimerConfirmation" header="Confirmation" icon="pi pi-exclamation-triangle" [closable]= "true"></p-confirmDialog>
    <p-confirmDialog key="inactivityTimerConfirmation" icon="pi pi-exclamation-triangle" [closable]= "true"></p-confirmDialog>
  `,
  styles: []
})
export class InactivityTimerComponent implements OnDestroy, OnInit {

  minutesDisplay = 0;
  secondsDisplay = 0;
  display = false
  unsubscribe$: Subject<void> = new Subject();
  timerSubscription: Subscription;
  timeoutSubscription: Subscription;

  constructor( private baseApiPathService: BaseApiPathService, private authService: LoginService, private router: Router, private confirmationService: ConfirmationService) {

  }

  ngOnInit() {
    this.resetTimer();
    this.authService.userActionOccured.pipe(
      takeUntil(this.unsubscribe$)
    ).subscribe(() => {
      this.invokeTimer();
    });
  }

  invokeTimer() {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
      this.resetTimer();
    }
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
  }

  resetTimer() {
    const interval = 1000;
    const duration = this.baseApiPathService.inactivityTimeout;
    this.timerSubscription = timer(0, interval).pipe(
      take(duration)
    ).subscribe(value =>
      this.render((duration - +value) * interval),
      err => { },
      () => {
        this.invokeConfirmationService();
      }
    )
  }

  invokeConfirmationService() {
    let isActionTaken = false;
    const that = this;

    this.confirmationService.confirm({
      message: 'Click yes to remain signed in',
      header:'Confirmation',
      key:'inactivityTimerConfirmation',
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        if (this.timerSubscription) {
          isActionTaken = true;
          this.timerSubscription.unsubscribe();
          this.resetTimer();

        }
      },
      reject: () => {
        isActionTaken = true;
        this.invokeLogout();

      }
    });

    setTimeout(function () {
      if (!isActionTaken) {
        that.authService.logout();
        that.router.navigate(['/login']);
      }
    }, this.baseApiPathService.inactivityWarningTimeout * 1000);

  }


  invokeLogout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  private render(count) {
    this.secondsDisplay = this.getSeconds(count);
    this.minutesDisplay = this.getMinutes(count);
  }

  private getSeconds(ticks: number) {
    const seconds = ((ticks % 60000) / 1000).toFixed(0);
    return this.pad(seconds);
  }

  private getMinutes(ticks: number) {
    const minutes = Math.floor(ticks / 60000);
    return this.pad(minutes);
  }

  private pad(digit: any) {
    return digit <= 9 ? '0' + digit : digit;
  }

}