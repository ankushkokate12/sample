import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunicationPopupComponent } from './communication-popup.component';
import { NodeService } from '../nodeService';
import { DialogModule, Dialog } from 'primeng/dialog';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

class MockNodeService { 
 
}

describe('CommunicationPopupComponent', () => {
  let component: CommunicationPopupComponent;
  let fixture: ComponentFixture<CommunicationPopupComponent>;
  let mockNodeService: MockNodeService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommunicationPopupComponent ],
      imports: [DialogModule, FormsModule, ReactiveFormsModule],
      providers: [{provide: NodeService, useValue: MockNodeService}] 
    })
    .compileComponents();
  }));

  beforeEach(() => {
    mockNodeService = new MockNodeService();
    fixture = TestBed.createComponent(CommunicationPopupComponent);
    component = fixture.componentInstance;
        
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
