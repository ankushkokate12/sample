import { Component, OnInit, Input, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { SecureCommunicationService } from 'src/app/common/services/securecommunication.service';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { FileValidations } from './constants/validation.constants';
import * as $ from 'jquery'
import { DataService } from 'src/app/common/services/data.service';

@Component({
  selector: 'app-communication-popup',
  templateUrl: './communication-popup.component.html',
  styleUrls: ['./communication-popup.component.css']
})
export class CommunicationPopupComponent implements OnInit {


  @Input()
  display: boolean;

  @Input()
  threadData: any;

  @Input()
  isMandatory: boolean;

  @Output()
  onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild("fileInput", { static: false }) fileInputRef: ElementRef;
  @ViewChild('focus', { static: false }) focusElement: ElementRef;
  showContacts: boolean;
  title: string;
  conversation: FormGroup;
  showFileInput: boolean;
  filesToUpload: any = [];
  categories: any;
  isEdited: boolean = false;
  plans: any;
  sendData: any;
  contacts: any;
  showContact = false;
  totalFileSize = 0;
  selectedContacts = [];
  fileValidations = FileValidations;
  showLoadingIndicator: boolean;
  constructor(private el: ElementRef, private messageService: MessageService, private formBuilder: FormBuilder,
    private secureCommunicationService: SecureCommunicationService,
    private dataService:DataService) { }

  ngOnInit() {
    this.createConversationForm();
    this.getFileValidations()
  }

  ngAfterViewInit() {
    let acceptedFileType = [];
    this.fileValidations.file_types.forEach(i => {
      acceptedFileType.push('.' + i);
    })
    this.fileInputRef.nativeElement.accept = acceptedFileType;
  }

  getFileValidations() {
    this.dataService.currentFileValidations
      .subscribe((response: any) => {
        if((response != undefined) && (response != null)){
          this.fileValidations = response;
        }
      });
  }

  createConversationForm() {
    this.conversation = this.formBuilder.group({
      threadId: new FormControl(),
      replyToMessageId: new FormControl(),
      to: this.formBuilder.array([]),
      subject: new FormControl('', [Validators.required]),
      message: new FormControl(''),
      planId: new FormControl('', [Validators.required]),
      categoryId: new FormControl('', [Validators.required]),
      contactsArray: this.formBuilder.array([])
    });
  }

  contactSelectionChanged() {
    (this.conversation.get('to') as FormArray).clear();
    this.conversation.value.contactsArray.forEach(element => {
      if (element.selected) {
        (this.conversation.get('to') as FormArray).push(
          this.formBuilder.group({
            name: element.contactName,
            id: element.contactId
          })
        )
      }
    });
  }

  generateContactsArray(planId) {
    (this.conversation.get('to') as FormArray).clear();
    (this.conversation.get('contactsArray') as FormArray).clear();
    this.secureCommunicationService.getContacts(planId).subscribe(data => {
      this.contacts = data;
      this.contacts.forEach(element => {
        (this.conversation.get('contactsArray') as FormArray).push(this.formBuilder.group({
          contactId: element.contactId,
          contactName: element.contactName,
          selected: new FormControl()
        }));
      });
    });
  }

  onHide(data) {
    this.messageService.clear('FileUpload');
    let responseObj:any = {
      data: data,
      isEdited: this.isEdited
    }
    this.onClose.emit(responseObj);
    this.isEdited = false;
    this.display = false;
  }

  onShow() {
    this.totalFileSize = 0;
    (this.conversation.get('contactsArray') as FormArray).clear();
    this.conversation.reset();
    this.plans = this.secureCommunicationService.plans;
    this.categories = this.secureCommunicationService.categories;
    this.filesToUpload = [];

    if (this.threadData) {
      this.setConversationValues();
      this.disableControls();
    } else {
      (this.conversation.get('to') as FormArray).clear();
      (this.conversation.get('contactsArray') as FormArray).clear();
      this.enableControls();
    }
  }


  setConversationValues() {
    const plan = this.getPlan(this.threadData.planName);
    const obj = {
      threadId: this.threadData.threadId,
      replyToMessageId: this.threadData.messageId,
      subject: this.threadData.subject,
      planId: plan.planId,
      categoryId: this.getCategoryId(this.threadData.category),

    }
    this.conversation.patchValue(obj);
    this.generateContactsArray(parseInt(plan.planId, 10));
    this.sendData = obj;
  }

  disableControls() {
    this.conversation.controls['subject'].disable();
    this.conversation.controls['planId'].disable();
    this.conversation.controls['categoryId'].disable();
  }

  enableControls() {
    this.conversation.controls['subject'].enable();
    this.conversation.controls['planId'].enable();
    this.conversation.controls['categoryId'].enable();
  }

  getPlan(plan) {
    return this.plans.find(c => c.planName === plan);
  }

  planChanged(event) {
    this.showContacts = false
    if (event && event.target.value) {
      this.generateContactsArray(parseInt(event.target.value, 10));

    }

  }

  getCategoryId(category) {
    const categoryObject = this.categories.find(c => c.label === category);
    return categoryObject ? categoryObject.value : category;
  }

  getCharacterLength() {
    let characterLength = 0;
    if (this.conversation && this.conversation.value) {
      const message = this.conversation.value.message;
      characterLength = message ? message.length : 0;
    }
    return 1000 - characterLength;
  }

  get f() { return this.conversation.controls; }

  send() {
this.showLoadingIndicator = true;
    this.conversation.markAllAsTouched();
    if (this.conversation.valid) {
      let inputData = { ...this.sendData, ...this.conversation.value };
      if (inputData.message === '') {
        delete inputData['message'];
      }
      if (!inputData.message && this.filesToUpload.length === 0) {
        this.conversation.setErrors({ 'emptyMessage': true });
      } else {
        this.conversation.setErrors({ 'emptyMessage': false });
        this.conversation.setErrors(null);


        inputData.copyOthers = this.getToArray();
        inputData.planId = parseInt(inputData.planId, 10);
        delete inputData['to'];
        delete inputData['contactsArray'];

        if (!inputData.threadId) {
          delete inputData['threadId'];
          delete inputData['replyToMessageId'];
        }

        let fd = new FormData();
        for (const property in inputData) {
          if (property === 'copyOthers') {
            inputData[property].forEach(c => {
              fd.append(property, c);
            })
          } else {
            fd.append(property, inputData[property]);
          }
        }
        if (this.filesToUpload && this.filesToUpload.length > 0) {
          this.filesToUpload.forEach(f => {
            fd.append('files', f,f.name);
            
          })
      
          // for(let i=0;i<this.filesToUpload.length;i++){
          //   fd.append('files', this.filesToUpload[i])
          // }
        }

        this.secureCommunicationService.sendSecureCommunication(fd).subscribe(data => {
          console.log(data);
          this.isEdited = true;
          this.showLoadingIndicator =false;
          this.onHide(data);
        },
          error => {
            this.messageService.clear('FileUpload');
            setTimeout(() => {
              this.messageService.add({ key: 'FileUpload', severity: 'error', summary: 'ERROR', sticky: true, detail: error.errorMessage});
            }, 1000);
          }
        );
      }
    }


  }

  getToArray() {
    const to = this.conversation.value.to;
    let toArray = [];
    to.forEach(element => {
      toArray.push(element.id);
    })
    return toArray;
  }

  openFile() {
    if (this.filesToUpload.length < this.fileValidations.max_file_count) {
      document.getElementById('file-input').click();
    } else {
      alert
      this.messageService.clear('FileUpload');
      setTimeout(() => {
        this.messageService.add({ key: 'FileUpload', severity: 'error', summary: 'ERROR', sticky: true, detail: "File count exceeded. Total Files allowed per message are " + this.fileValidations.max_file_count + " files" });
      }, 1000);
    }
  }

  onFileChange(event) { 
    var target = event.target || event.srcElement; //if target isn't there then take srcElement
    let files = target.files; 

    if (target.files.length > 0) {
      this.showFileInput = false;
      const file = <File>target.files[0];
      if (file.size > this.fileValidations.max_file_size_mb) {
        this.messageService.clear('FileUpload');
        setTimeout(() => {
          this.messageService.add({
            key: 'FileUpload', severity: 'error',
            summary: 'ERROR', sticky: true, detail: "File size limit exceeded. Allowed file size per file is " + this.fileValidations.max_file_size_mb / (1024 * 1024) + " MB"
          });
        }, 1000);

      } else if (this.totalFileSize + file.size > this.fileValidations.max_allFile_size_mb) {
        this.messageService.clear('FileUpload');
        setTimeout(() => {
          this.messageService.add({
            key: 'FileUpload', severity: 'error',
            summary: 'ERROR', sticky: true, detail: "Total file size limit exceeded. Allowed total file size is" + this.fileValidations.max_allFile_size_mb / (1024 * 1024) + " MB"
          });
        }, 1000);

      } else if (this.checkFileExtension(file)) {
        this.filesToUpload.push(file);
        this.totalFileSize += file.size;
        console.log(this.filesToUpload)
      }
    }
  }

  checkFileExtension(file) {
    let returnValue = false;
    console.log(file);
    let ext = file.name.match(/\.([^\.]+)$/)[1];
    if (this.fileValidations.file_types.indexOf(ext) > -1) {
      returnValue = true
    } else {
      this.messageService.clear('FileUpload');
      setTimeout(() => {
        this.messageService.add({ key: 'FileUpload', severity: 'error', summary: 'ERROR', sticky: true, detail: "Sorry! file type is invalid, allowed extensions are-" + this.fileValidations.file_types.toString() });
      }, 1000);
    }

    return returnValue;
  }

  deleteFile(index) {
    this.filesToUpload.splice(index, 1);
  }

  isArray(obj: any) {
    return Array.isArray(obj)
  }

  showContactsOverlay(event, op: OverlayPanel) {
    this.contacts = this.secureCommunicationService.contacts;
    op.toggle(event);
  }


}
