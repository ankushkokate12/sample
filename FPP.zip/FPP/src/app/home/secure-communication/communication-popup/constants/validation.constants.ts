export const FileValidations = {
max_file_count   : 10,
   max_file_size_mb: 200 * 1024 * 1024,
   max_allFile_size_mb : 300 * 1024 * 1024,
   file_types: ['xls','xlsx','csv','txt','pdf','doc','docx','ppt','pptx']
}
