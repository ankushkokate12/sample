import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SecureCommunicationService } from 'src/app/common/services/securecommunication.service';
import { ActionHistory, Message } from '../models/message';
import { DateFormatUtility } from 'src/app/common/utils/dateFormat-utility';

@Component({
  selector: 'app-message-detail',
  templateUrl: './message-detail.component.html',
  styleUrls: ['./message-detail.component.css']
})
export class MessageDetailComponent implements OnInit {
  @Input()
  display: boolean;

  @Input()
  messageData: Message;

  @Output()
  onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  actions: ActionHistory[];
  constructor(private secureCommunicationService: SecureCommunicationService) { }

  ngOnInit() {
    

  }

  reply(){
    this.onHide(true);
  }

  onHide(replyClicked:any) {
    this.actions = [];
    if (!this.messageData.isRead) {
      this.secureCommunicationService.postAction({
        messageId: this.messageData.messageId,
        actionTaken: 'Read',
        actionBy: 'Test'
      }).subscribe(() => {
        this.messageData.isRead = true; 
        this.messageData.hasAction = true;
        
      })
    }
    this.display = false;
    this.onClose.emit(replyClicked);
  }

  onShow(){
    if (this.messageData.hasAction){
      this.showAccessHistory(this.messageData.messageId);
    }
  }

  downloadAllFiles(messageId) {
    this.secureCommunicationService.download(messageId)
      .subscribe(blobData => {
        let downloadUrl;
        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
          //msSaveBlob only available for IE & Edge
          downloadUrl = window.navigator.msSaveBlob(blobData, this.messageData.category + '_'+ 
          DateFormatUtility.UTCToLocalInFormat(this.messageData['communicationDateTime']) + '.zip');
        }else{
          downloadUrl = window.URL.createObjectURL(blobData);
        }        
        let link = document.createElement('a');
        link.href = downloadUrl;
        link.download = this.messageData.category + '_'+ 
        DateFormatUtility.UTCToLocalInFormat(this.messageData['communicationDateTime'])  + '.zip';
        link.click();        
      });
  }

  showAccessHistory(messageId){
    this.secureCommunicationService.getAccessHistory(messageId).subscribe(actions => {
      this.actions = actions;
      
    });
  }

}
