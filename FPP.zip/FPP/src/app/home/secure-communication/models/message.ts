export interface Recipient {
    id: string;
    name: string;
    emailId: string;
  }

      
  interface File {
    messageId : string;
    threadId: string;
    id: string;
    name: string;
    link?: string;
  }

  export interface ActionHistory {
    messageId : string;
    actionId: string;
    actionTaken: string;
    actionBy: string;
    actionDate: Date;
  }

export interface Message {
  messageId : string;
  threadId: string;
  totalMessageCount: number;
  availableMessageCount: number;
  unreadMessageCount: number;
  isNew: boolean;
  isRead: boolean;
  from: string;
  copyOthers: Recipient[];
  subject: string;
  communicationDate: Date;
  planName: string;
  category: string;
  message?: string;
  files?: File[];
  notes?: string;
  hasAction: boolean;
  actionDueDate?: Date;
}

export interface Plan{

}

export interface Category{

}
