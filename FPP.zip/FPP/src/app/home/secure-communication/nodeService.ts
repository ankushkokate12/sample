import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Message, ActionHistory } from './models/message';


@Injectable()
export class NodeService {
  latestMessage: Message;
  messageData: any; 

  constructor(private http: HttpClient) { }




  getCommunications() {
    return this.http.get('assets/data/communications.json')
      .toPromise()
      .then(res => {
       this.messageData = res['communicationMessageCount'];
       return <Message[]>res['communicationMessages']});
  }

  getMessagesOfThreadId(threadId) {
    return this.http.get('assets/data/more-communications.json')
      .toPromise()
      .then(res => <Message[]>res);
  }

  getAccessHistory(messageId) {
    return this.http.get('assets/data/access-history.json')
      .toPromise()
      .then(res => {
        console.log(res)
        return <ActionHistory[]>res;
      });
  }



}