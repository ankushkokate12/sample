import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser'; 
import { SecureCommunicationComponent } from './secure-communication.component';

import {TableModule} from 'primeng/table';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { Directive, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import {CalendarModule} from 'primeng/calendar';
import { NodeService } from './nodeService';
import { SecureCommunicationService } from 'src/app/common/services/securecommunication.service';
import { Observable, of } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Directive({
  selector: 'app-communication-popup'
})
class MockPopupDirective {
  @Input()
  public display: boolean;
  @Input()
  public isEditState: boolean;
  @Output()
  public onClose = new EventEmitter<boolean>();
}


class MockNodeService { 
 
}

class MockCommunicationService { 
  static getSecureCommunication(data): Observable<any>{
      return of({"communicationMessageCount":{
        "totalMessageCount":2000,
        "availableMessageCount":500,
        "unreadMessageCount":4,
        "newMessageCount":2
        },
        "communicationMessages":[
          {
          "messageId":1,
          "threadId":1,
          "messageCount":1,
          "isNew":true,
          "isRead":true,
          "from":"John Doe",
          "to":[
          {
          "id":1,
          "name":"Test 1",
          "mailId":"test1@test.com"
          }
          ],
          "subject":"New Initiation.",
          "communicationDateTime":"2019-12-24T04:58:35.717242-05:00",
          "planName":"ABC 401K company",
          "category":"Tax Forms",
          "message":"Hi Hello",
          "files":[
          {
          "id":"7656433wewefwewergfwwf34423r32",
          "name":"Test11.xmls",
          "link":null
          },
          {
          "id":"134567wewefwewergfwwf3442dasdasd32",
          "name":"Test12.xmls",
          "link":null
          }
          ],
          "note":"Test Notes",
          "hasAction":true
          }]}) ;
  }
}

   


describe('SecureCommunicationComponent', () => {
  let component: SecureCommunicationComponent;
  let fixture: ComponentFixture<SecureCommunicationComponent>;
  let mocDirectiveEl;
  let mockPopup;                                                                            
  let mockNodeService: MockNodeService;
  let mockCommunicationService: MockCommunicationService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureCommunicationComponent, MockPopupDirective ],
      imports: [BrowserAnimationsModule,TableModule, OverlayPanelModule, DialogModule, CalendarModule, FormsModule, ReactiveFormsModule],
      providers: [{provide: NodeService, useValue: mockNodeService}, 
                  {provide: SecureCommunicationService, useValue: MockCommunicationService} ]
    })
    .compileComponents();

    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureCommunicationComponent);
    component = fixture.componentInstance;
    mocDirectiveEl = fixture.debugElement.query(By.directive(MockPopupDirective));
    mockPopup = mocDirectiveEl.injector.get(MockPopupDirective) as MockPopupDirective;    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(mockPopup).toBeTruthy();
    
  });

  it('should populate messages', () => {
    // expect(component.messages.length).toBeGreaterThan(0);
    // expect(component.messagesToShow.length).toBeGreaterThan(0); 
  });
});
