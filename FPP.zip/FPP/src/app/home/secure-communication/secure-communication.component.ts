import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { SecureCommunicationService } from '../../common/services/securecommunication.service';
import { Message, Recipient } from './models/message';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';
import { DateFormatUtility } from '../../common/utils/dateFormat-utility';
import { Router } from '@angular/router';

@Component({
  selector: 'app-secure-communication',
  templateUrl: './secure-communication.component.html',
  styleUrls: ['./secure-communication.component.css']
})
export class SecureCommunicationComponent implements OnInit {
  tabindex:number = 0;
  constructor(private router: Router) { }
  
  ngOnInit() {
    let key = this.router.url.substring(this.router.url.lastIndexOf('/') + 1);
    if(key == "inbox"){
      this.tabindex = 0;
    }else{
      this.tabindex = 1;
    }
  }

  handleChange(e) {
    let index = e.index;
    let link;
    switch (index) {
        case 0:
            link = ['/home/secure-messages/inbox'];

            break;
        case 1:
            link = ['/home/secure-messages/sent-items'];
            break;        
    }
    this.router.navigate(link);
}

  


  







}
