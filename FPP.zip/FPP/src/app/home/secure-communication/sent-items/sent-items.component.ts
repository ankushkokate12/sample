

import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { SecureCommunicationService } from '../../../common/services/securecommunication.service';
import { Message, Recipient } from '../models/message';
import { OverlayPanel } from 'primeng/overlaypanel/public_api';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { DateFormatUtility } from '../../../common/utils/dateFormat-utility';

const currentDate = new Date();
const pastDate = new Date();
const pastYear = pastDate.getFullYear() - 1;
pastDate.setFullYear(pastYear);

@Component({
  selector: 'app-sent-items',
  templateUrl: './sent-items.component.html',
  styleUrls: ['./sent-items.component.css']
})
export class SentItemsComponent implements OnInit {

    showFilters = false;
    messages: Message[];
    messagesToShow: Message[] = [];
    cols: any[];
    cols1: any[];
    threadRowGroupMetadata: any;
    overlayData: any;
    expandedThreadId: any;
    loading: boolean = true
    displayCommunicationDialog: boolean;
    displayMessageDetail: boolean;
    messageCountData: any;
    calendarForm: FormGroup;
    categories: any;
    isReply:boolean = false;
    showLoadingIndicator: boolean;
    
    threadData: any;
    plans: any;
    searchObj = { from: '', subject: '', planId: '0', categoryId: '0' };
   
    @ViewChild('focus', { static: true }) communicationDialog: ElementRef;
    secureCommunications$: Observable<any>;
    categories$: Observable<any>;
    plans$: Observable<any>;
    contacts$: Observable<any>;
    messageData: any;
    filterApplied: any;
  sort: { columnName: any; isAscending: any; };
  
  
    constructor(private secureCommunicationService: SecureCommunicationService, private formBuilder: FormBuilder) { }
  
    ngOnInit() {
      this.loading = true;
  
      this.showLoadingIndicator = true;
      this.categories$ = this.secureCommunicationService.getCategories();
      this.plans$ = this.secureCommunicationService.getPlans();
      this.setDefaultSearchDate();
      this.plans = this.secureCommunicationService.plans;
      if (!this.plans) {
        this.plans$.subscribe(data => {
          if (data && data.length > 0) {
            this.plans = data;
            this.secureCommunicationService.plans = this.plans;
          }
        })
      }
      this.categories = this.secureCommunicationService.categories;
      if (!this.categories) {
        this.categories$.subscribe(data => {
          this.categories = data;
          this.secureCommunicationService.categories = this.categories;
        })
      }

      this.sort = {
        columnName: 'communicationDateTime',
        isAscending: false
      }
      //this.search();
    }
  
    messageRowClicked(event, message) {
      console.log("event : ", event);
      console.log("message :", message);
      this.displayMessageDetail = true;
      this.messageData = message;
      if (!this.messageData.isRead) {
        const threadId = this.messageData.threadId;
        this.messageCountData.unreadMessageCount--;
        this.messagesToShow.map(m => {
          if (m.threadId === threadId) {
            m.unreadMessageCount--;
          }
        })
      }
    }
  
    setDefaultSearchDate() {
  
      if (!this.calendarForm) {
        this.calendarForm = this.formBuilder.group({
          startDate: new FormControl(pastDate, [Validators.required]),
          endDate: new FormControl(currentDate, [Validators.required])
        });
      } else {
        this.calendarForm.patchValue({
          startDate: pastDate,
          endDate: currentDate
        });
      }
      this.searchObj['fromDate'] = new Date(this.calendarForm.get('startDate').value);
      this.searchObj['toDate'] = new Date(this.calendarForm.get('endDate').value);
  
    }
  
    applyDateFilter(op: OverlayPanel) {
      this.getSearchDateFields();
      op.hide();
    }
  
  
    clearDateFilter(op: OverlayPanel) {
      op.hide();
      this.setDefaultSearchDate();
    }
  
    clearSearchFilter() {
      this.searchObj = {  planId: '0', categoryId: '0', from: '', subject: '' };
      this.setDefaultSearchDate();
      this.search();
    }

    get startDate() { return this.calendarForm.get('startDate'); }
    get endDate() { return this.calendarForm.get('endDate'); }

    closeDateFilter() {
      // if (this.searchObj['fromDate'] != (this.startDate.value.toISOString()).slice(0, (this.startDate.value.toISOString()).lastIndexOf("T")) || this.searchObj['toDate'] != (this.endDate.value.toISOString()).slice(0, (this.endDate.value.toISOString()).lastIndexOf("T"))) {
      //   this.setDefaultSearchDate()
      // }
      if (Date.UTC(this.searchObj['fromDate'].getFullYear(), this.searchObj['fromDate'].getMonth(), this.searchObj['fromDate'].getDate()) != Date.UTC(this.startDate.value.getFullYear(), this.startDate.value.getMonth(), this.startDate.value.getDate()) || Date.UTC(this.searchObj['toDate'].getFullYear(), this.searchObj['toDate'].getMonth(), this.searchObj['toDate'].getDate()) != Date.UTC(this.endDate.value.getFullYear(), this.endDate.value.getMonth(), this.endDate.value.getDate())) {
        this.setDefaultSearchDate();
      }
    }

    startDateApply(fromDate) {
      this.calendarForm.get('startDate').setValue(fromDate);
    }
    endDateApply(toDate) {
      this.calendarForm.get('endDate').setValue(toDate);
    }
  
  
    setMessage(threadId, index) {
      this.messages[index]['conversationDate'] = DateFormatUtility.UTCToLocal(this.messages[index]['conversationDate']);
      this.messagesToShow.push(this.messages[index]);
      if (index === 0) {
        this.threadRowGroupMetadata[threadId] = { index: 0, size: 1 };
      } else {
        this.threadRowGroupMetadata[threadId].size++;
      }
    }
  
    compareMessage(a: Message, b: Message) {
      return parseInt(a.threadId, 10) > parseInt(b.threadId, 10) ? -1 :
        (parseInt(a.threadId, 10) === parseInt(b.threadId, 10) ?
          (new Date(a.communicationDate) > new Date(b.communicationDate) ? -1 : 1) : 1);
  
    }
  
  
  updateThreadRowGroupMetaData(expandedThreadId) {
    
      this.loading = true
      this.expandedThreadId = expandedThreadId;
      this.messagesToShow = [];
      this.threadRowGroupMetadata = {};
      let previousRowGroup = [];
      if (this.messages) {
  
        // this.messages.sort(this.compareMessage);
        console.log(this.messages);
        let removedRows = 0;
        let totalRemovedRows = 0;
        for (let i = 0; i < this.messages.length; i++) {
          let rowData = this.messages[i];
          let threadId = rowData.threadId;
          if (i == 0) {
            this.setMessage(threadId, i);
            previousRowGroup.push(threadId);
          }
          else {
            if (previousRowGroup.indexOf(threadId) > -1) {
              // if (i < this.threadRowGroupMetadata[threadId].index + removedRows + 5
              //   || threadId === expandedThreadId) {
                this.setMessage(threadId, i);
              // }
              // else {
              //   removedRows++;
              // }
            }
            else {
              this.messages[i]['conversationDate'] = DateFormatUtility.UTCToLocal(this.messages[i]['conversationDate']);
              this.messagesToShow.push(this.messages[i]);
              this.threadRowGroupMetadata[threadId] = { index: i - removedRows, size: 1 };
              previousRowGroup.push(threadId);
            }
          }
        }
        // if (expandedThreadId) {
        //   this.processForMoreMessages(expandedThreadId);
        // }
      }

      this.messagesToShow.map(m =>{
        if(m['contactType'] != "Ascensus"){
          m['recipients'] = [...m.copyOthers,{contactId: 0, name: 'FuturePlanTeam'}];
        }else{
          m['recipients'] = [...m.copyOthers];
        }
      });
      this.loading = false;
      this.showLoadingIndicator= false;
    }

    processForAllMessages(threadId){
      this.secureCommunicationService.getSecureCommunication({ threadId }).subscribe(data => {
        if (data) {
          this.addMessagesToThread(threadId, data.communicationMessages);
        }
      },error => {
        this.showLoadingIndicator = false;  
      })
    }
  
    // processForMoreMessages(threadId) {
    //   const message = this.messages.find(m => m.threadId === threadId);
    //   if (this.threadRowGroupMetadata[threadId].size < message.totalMessageCount) {
    //     this.secureCommunicationService.getSecureCommunication({ threadId }).subscribe(data => {
    //       if (data) {
    //         this.addMessagesToThread(threadId, data.communicationMessages);
    //       }
    //     })
    //   }
    // }
  
    addMessagesToThread(threadId, messages) {
      if((messages != null)&& (messages != undefined)){
        const idx:any = this.messages.findIndex(p => p.threadId== threadId);
        const currentThreadMessage:Array<any> = this.messages.filter(m => m.threadId == threadId);
        this.messages.splice(idx,currentThreadMessage.length);
        this.messages.splice.apply(this.messages, [idx, 0].concat(messages));
      }
      
      this.updateThreadRowGroupMetaData(threadId);
    }
  
    lazyLoad(event: any) {
      if (event) {
        this.sort = {
          columnName: event.sortField,
          isAscending: event.sortOrder === 1 ? true : false
        }
        this.search();
      }
    }
  
    getSearchDateFields() {
      if (this.calendarForm.get('startDate').value !== '' && this.calendarForm.get('endDate').value !== '') {
        this.searchObj['fromDate'] = new Date(this.calendarForm.get('startDate').value);
        this.searchObj['toDate'] = new Date(this.calendarForm.get('endDate').value);
      }
    }
  
    search() {
      // this.getSearchDateFields();
      let search = {
        from: this.searchObj.from, subject: this.searchObj.subject,
        fromDate: this.searchObj['fromDate'], toDate: this.searchObj['toDate']
      };
  
      if (this.searchObj['planId'] && this.searchObj['planId'] !== '0') {
        search['planId'] = parseInt(this.searchObj['planId'], 10);
      }
      if ((this.searchObj['categoryId'] && this.searchObj['categoryId'] !== '0')) {
        search['categoryId'] = this.searchObj.categoryId;
      }
      this.secureCommunicationService.getSecureCommunication({ isReceived: 2, search,sort:this.sort }).subscribe(data => {
        this.filterApplied = this.isFilterApplied(search)
        this.messages = data.communicationMessages;
        
        this.messageCountData = data.communicationMessageCount;
        this.updateThreadRowGroupMetaData(null);
        this.loading = false;
      },error => {
        this.showLoadingIndicator = false;  
      });
    }
  
    isFilterApplied(search) {
  
      return search && (search['from'] || search['subject']
        || Math.floor((Date.UTC(search['fromDate'].getFullYear(), search['fromDate'].getMonth(), search['fromDate'].getDate())
          - Date.UTC(pastDate.getFullYear(), pastDate.getMonth(), pastDate.getDate())) / (1000 * 60 * 60 * 24)) !== 0
  
        || Math.floor((Date.UTC(search['toDate'].getFullYear(), search['toDate'].getMonth(), search['toDate'].getDate())
          - Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate())) / (1000 * 60 * 60 * 24)) !== 0
        || search.planId || search.categoryId);
    }
  
    showOverlay(event, data, op: OverlayPanel) {
      this.overlayData = data;
      op.toggle(event);
    }
  
    showMessageOverlay(event, data, op: OverlayPanel) {
      this.showOverlay(event, data.message, op);
      if (!data.isRead) {
        this.secureCommunicationService.postAction({
          messageId: data.messageId,
          actionTaken: 'Read',
          actionBy: 'Test'
        }).subscribe(() => {
          data.isRead = true;
          data.hasAction = true;
        })
      }
    }
  
    showAccessHistory(event, messageId, op: OverlayPanel) {
      this.secureCommunicationService.getAccessHistory(messageId).subscribe(actions => {
        this.overlayData = actions;
        op.toggle(event);
      });
    }
      isArray(obj: any) {
      return Array.isArray(obj)
    }
  
    startNewCommunication() {
      this.displayCommunicationDialog = true;
      this.threadData = null;
      // setTimeout(() => {
      //   this.communicationDialog.nativeElement.focus();
      //   }, 0)
    }
  
    reply(threadData) {
      this.displayCommunicationDialog = true;
      this.isReply = true;
      this.threadData = threadData;
    }
  
    onCommunicationDialogClose(isEdited) {
      this.displayCommunicationDialog = false;
      this.isReply = false;
      if (isEdited) {
        this.loading = true;
        this.search();
      }
    }
  
    onMessageDetailClose(replyClicked) {
      this.displayMessageDetail = false;
      if (replyClicked){
        this.reply(this.messageData);
      }
    }
  
  }
