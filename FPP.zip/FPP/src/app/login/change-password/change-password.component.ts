import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MustMatch } from "../../common/directives/match.validator";
import { LoginService } from "../../common/services/login.service";
import { ConfirmationService, MessageService } from "primeng/api";
import { Router} from '@angular/router';

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.css"]
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  errorMsg: string = "";
  changePasswordObj = {
    newPassword: "",
    confirmPassword: ""
  };
  username: string;
  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadForm();
    this.username = this.loginService.username;
  }

  loadForm() {
    this.changePasswordForm = this.formBuilder.group(
      {
        newPassword: [
          this.changePasswordObj.newPassword,
          [
            Validators.required,
            Validators.pattern(
              "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{9,}"
            )
          ]
        ],
        confirmPassword: [
          this.changePasswordObj.confirmPassword,
          [Validators.required]
        ]
      },
      {
        validator: MustMatch("newPassword", "confirmPassword")
      }
    );
  }

  // convenience getter for easy access to form fields

  get nPassword() {
    return this.changePasswordForm.get("newPassword");
  }
  get cPassword() {
    return this.changePasswordForm.get("confirmPassword");
  }

  onChangePassword() {
    const expiryDate = new Date(this.loginService.loginData.expiration);
      if (new Date() < expiryDate) {
        this.loginService.changePassword(this.nPassword.value).subscribe(
          response => {
            this.loginService.loginData.requiresNewPassword = false;
            this.loginService.mfaDetails = {
              factorType: "",
              verifcationCodeSent: false
            };
          },
          error => {
            this.errorMsg = error.statusText;
            console.log("Error: " + error.statusText);
            this.messageService.add({
              key: "messageToast",
              severity: "error",
              summary: "ERROR",
              detail: error.statusText
            });
          }
        );
      } else {
        this.confirmationService.confirm({
          message:"Login time is expired. Please login again.",
           header:"Login Timeout Warning",
          key: "changePasswordErrorDialog",
          accept: () => {
            this.loginService.logout();
            this.router.navigate(["/login"]);
          },
          reject: () => {
          return;
          }
        });
      }
  }

  clearData() {
    this.changePasswordForm.clearValidators();
    this.changePasswordForm.reset();
  }
}
