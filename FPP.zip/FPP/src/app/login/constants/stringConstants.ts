export const StartupPages =[{
    name: 'Dashboard',
    route: '/home/dashboard'
},{
    name: 'Secure Messages',
    route: '/home/secure-messages'
},{
    name: 'User Profile',
    route: '/home/profile'
}];

export const DialogTexts = {
    FIRST_TIME_USER : 'If this is your first time accessing our portal, please enter your email address below to have a temporary password sent to your email for initial access. If you receive any error, please contact us directly for portal setup assistance.'
}

export const UrlConstants = {
    LOGIN_URL: 'http://axisapi.ascensus.com/api/auth/login'
}