import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { LoginService } from '../../common/services/login.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StartupPages, DialogTexts } from '../constants/stringConstants';
import { LoginDetails } from '../../common/vo/lolgin-interface';
import { DateFormatUtility } from '../../common/utils/dateFormat-utility';
import { ConfirmationService, MessageService } from 'primeng/api';
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  constructor(private router: Router,
    public fb: FormBuilder,
    private loginService: LoginService,
    private messageService: MessageService) { }

    
  loginForm: FormGroup;
  startupPages: { name: string, route: string }[];
  displayFirstTimeDialog: boolean = false;
  displayForgotDialog: boolean = false;
  submitClicked: boolean = false;
  showLoadingIndicator: boolean;

  @ViewChild('emailInput',{ static: false}) emailInput: ElementRef;

  ngOnInit() {
    this.loginService.logout();

    this.startupPages = StartupPages;
    let username, startupPage;
    this.loginForm = this.fb.group({
      emailAddress: [localStorage.getItem("username"), [Validators.required]],
      password: ['', [Validators.required]],

      startupPage: [localStorage.getItem("startupPage") || StartupPages[0].route],
      isRememberClicked: [localStorage.getItem("username") ? true : false]
    });

    setTimeout(() => this.emailInput.nativeElement.focus(), 0);
  }

  get f() { return this.loginForm.controls; }

  setRememberMe() {

    if (this.f.isRememberClicked.value && this.loginForm.valid) {
      localStorage.setItem("username", this.loginForm.value.emailAddress);
      localStorage.setItem("startupPage", this.loginForm.value.startupPage);
    } else {
      localStorage.clear();
    }

  }

  rememberMeClicked() {
    this.setRememberMe()
  }

  onSubmit() {
    this.submitClicked = true;
    this.showLoadingIndicator = true;
    this.setRememberMe();
    if (this.loginForm.valid) {
      const loginObj = this.loginForm.value;
      this.loginService.startupPage = loginObj.startupPage;
      this.loginService.login(loginObj.emailAddress, loginObj.password)
      .subscribe(data => {
        this.showLoadingIndicator = false;
        if (data && data['authenticated']) {
          this.loginService.loginData = data as LoginDetails;
          this.loginService.updateCurrentUserLoginData(this.loginService.loginData)
          
          if ((this.loginService.loginData.isNewAccount) && (this.loginService.loginData.requiresNewPassword)){
            this.loginService.mfaDetails = null;            
          }else {
            if((!this.loginService.loginData.isNewAccount) && (this.loginService.loginData.requiresNewPassword)){
              this.loginService.startupPage = StartupPages[2].route;
            }

            this.loginService.mfaDetails = { factorType: '', verifcationCodeSent: false };
          }
          this.loginForm.setErrors(null);
        } else {
          this.loginForm.setErrors({ 'incorrectCredentials': true });
          this.showLoadingIndicator = false;
        }
      },
      error => {
        this.showLoadingIndicator = false;
      })
    }
    else{
      this.showLoadingIndicator = false;
    }
  }

  showFirstTimeDialog() {
    this.displayFirstTimeDialog = true;
  }

  showForgotDialog() {
    this.displayForgotDialog = true;
  }

  onFistTimeDialogClose() {
    this.displayFirstTimeDialog = false;
  }
  onForgotDialogClose(data) {
    this.displayForgotDialog = false;
    if(data){
      if(data.isSucess){
        this.resetLoginPage();
      }
    }
  }

  resetLoginPage(){
    this.loginForm.reset();
    this.loginForm.markAsUntouched();
    this.loginForm.markAsPristine();

    Object.keys(this.loginForm.controls).forEach(key => {
      this.loginForm.get(key).setErrors(null) ;
    });
    
    this.loginForm.controls["startupPage"].setValue(StartupPages[2].route);
    setTimeout(() => this.emailInput.nativeElement.focus(), 0);
  }

}
