import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login.component';
import { LandingComponent } from './landing/landing.component';
import { Mfa1Component } from './mfa1/mfa1.component';
import { Mfa2Component } from './mfa2/mfa2.component';

const routes: Routes = [{
  path: '', component: LoginComponent,
  
}]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRoutingModule { }
