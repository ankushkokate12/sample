import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login.component';
//import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { DialogModule, Dialog } from 'primeng/dialog';
//import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { LoginRoutingModule } from './login-routing.module';
import { FirstTimeUserDialogComponent } from '../common/components/first-time-user-dialog/first-time-user-dialog.component';
import { ForgotPasswordDialogComponent } from '../common/components/forgot-password-dialog/forgot-password-dialog.component';
import { Browser } from 'selenium-webdriver';
import { LoginService } from './login.service';
import { Mfa1Component } from './mfa1/mfa1.component';
import { LandingComponent } from './landing/landing.component';
import { Mfa2Component } from './mfa2/mfa2.component';
import {ToastModule} from 'primeng/toast';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

@NgModule({
  declarations: [LoginComponent, FirstTimeUserDialogComponent, ForgotPasswordDialogComponent, Mfa1Component, LandingComponent, Mfa2Component, ChangePasswordComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    LoginRoutingModule,
    DialogModule,
    ToastModule,
    ConfirmDialogModule
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
  providers: [LoginService],
})
export class LoginModule { }
