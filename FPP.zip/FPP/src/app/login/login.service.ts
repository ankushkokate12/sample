import { HttpHeaders, HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { LoginModule } from "./login.module";
import { UrlConstants } from './constants/stringConstants'
import { Observable, Subject } from "rxjs";

// const httpOptions = {
//   headers: new HttpHeaders({ 'username': 'tester', 'password': 'testy' })
// };

@Injectable()
export class LoginService {
  //loginData: any;

  constructor(private http: HttpClient) { }

  // _userActionOccured: Subject<void> = new Subject();
  // get userActionOccured(): Observable<void> { return this._userActionOccured.asObservable() };


  // notifyUserAction() {
  //   this._userActionOccured.next();
  // }

  // login(): Observable<any> {
  //   return this.http.get<any>(UrlConstants.LOGIN_URL);
  // }

  // logOut() {
  //   console.log('user logout');
  // }
}
