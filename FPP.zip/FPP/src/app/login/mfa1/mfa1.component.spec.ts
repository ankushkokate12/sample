import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mfa1Component } from './mfa1.component';

describe('Mfa1Component', () => {
  let component: Mfa1Component;
  let fixture: ComponentFixture<Mfa1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mfa1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mfa1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
