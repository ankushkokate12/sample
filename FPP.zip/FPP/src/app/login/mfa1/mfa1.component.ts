import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";
import { LoginService } from "../../common/services/login.service";
import { DateFormatUtility } from "../../common/utils/dateFormat-utility";
import { ConfirmationService, MessageService } from "primeng/api";
import { LoginDetails } from "../../common/vo/lolgin-interface";

@Component({
  selector: "app-mfa1",
  templateUrl: "./mfa1.component.html",
  styleUrls: ["./mfa1.component.css"]
})
export class Mfa1Component implements OnInit {
  mfa1Form: FormGroup;
  loginData: LoginDetails;
  showLoadingIndicator: boolean;
  constructor(
    private router: Router,
    private messageService: MessageService,
    public fb: FormBuilder,
    private loginService: LoginService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.loginData = this.loginService.loginData;
    this.mfa1Form = this.fb.group({
      type: new FormControl(),
      mobile: ["", [Validators.required, Validators.minLength(10)]]
    });
    if (!this.loginData.isNewAccount) {
      this.mfa1Form
        .get("mobile")
        .setValue(this.mask(this.loginData.otpFactors[0].value));
      this.mfa1Form.controls["mobile"].disable();
    } else {
      this.mfa1Form.get("mobile").setValue("");
    }
    this.setMfaType("sms");
  }

  mask(mobile: string) {
    const stringLength = mobile.length;
    return "X".repeat(10) + mobile.substring(stringLength - 4, stringLength);
  }

  setMfaType(type) {
    this.mfa1Form.patchValue({ type });
  }

  sendOtp() {
    const expiryDate = new Date(this.loginService.loginData.expiration);
    if (new Date() < expiryDate) {
      if (!this.loginData.isNewAccount) {
        this.showLoadingIndicator = true;
        this.loginService.sendOtp(this.mfa1Form.value.type).subscribe(
          data => {
            this.loginService.mfaDetails.verificationCodeSent = true;
            this.showLoadingIndicator = false;
          },
          error => {
            this.showLoadingIndicator = false;
            this.loginService.mfaDetails.verificationCodeSent = false;
            //this.loginService.loginData = null;
            this.messageService.add({
              key: "Login",
              severity: "error",
              summary: "ERROR",
              sticky: false,
              detail: error.error + "Please try again"
            });
          }
        );
      } else {
        this.loginService.mfaDetails.factorType = "sms";
        this.loginService.mfaDetails.verificationCodeSent = true;
        this.showLoadingIndicator = false;
      }
    } else {
      this.confirmationService.confirm({
        message: "Login time is expired. Please login again.",
        header: "Login Timeout Warning",
        key: "mfa1SessionTimeOut",
        accept: () => {
          this.loginService.logout();
          this.router.navigate(["/login"]);
        },
        reject: () => {
          return;
        }
      });
    }
  }

  changePhoneForNewUser() {
    const expiryDate = new Date(this.loginService.loginData.expiration);
    if (new Date() < expiryDate) {
      let data: any = {
        NewPhoneNumber: this.mfa1Form.value.mobile
      };
      this.showLoadingIndicator = true;
      this.loginService.changePhoneForNewUser(data).subscribe(
        data => {
          if ((this.loginService.loginData.otpFactors != undefined)&& (this.loginService.loginData.otpFactors != null)) {
            this.loginService.loginData.otpFactors = this.loginService.loginData.otpFactors.filter(obj => ((obj.type != "sms") && (obj.type != "call")));
            this.loginService.loginData.otpFactors.push({
              type: "sms",
              value: this.mfa1Form.value.mobile
            });
            this.loginService.loginData.otpFactors.push({
              type: "call",
              value: this.mfa1Form.value.mobile
            });
          }
          this.sendOtp();
        },
        error => {
          this.showLoadingIndicator = false;
          this.loginService.mfaDetails.verificationCodeSent = false;
          //this.loginService.loginData = null;
          this.messageService.add({
            key: "Login",
            severity: "error",
            summary: "ERROR",
            sticky: false,
            detail: "Error occur while register phone number"
          });
        }
      );
    } else {
      this.confirmationService.confirm({
        message: "Login time is expired. Please login again.",
        header: "Login Timeout Warning",
        key: "mfa1SessionTimeOut",
        accept: () => {
          this.loginService.logout();
          this.router.navigate(["/login"]);
        },
        reject: () => {
          return;
        }
      });
    }
  }

  onSubmit() {
    this.mfa1Form.markAllAsTouched();
    if (this.loginData) {
      const expiryDate = new Date(this.loginData.expiration);
      if (new Date() < expiryDate) {
        if (this.loginData.isNewAccount) {
          this.changePhoneForNewUser();
        } else {
          this.sendOtp();
        }
      } else {
        this.confirmationService.confirm({
          message: "Login time is expired. Please login again.",
          header: "Login Timeout Warning",
          key: "mfa1SessionTimeOut",
          accept: () => {
            this.loginService.logout();
            this.router.navigate(["/login"]);
          },
          reject: () => {
            return;
          }
        });
      }
    }
  }
}
