import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mfa2Component } from './mfa2.component';

describe('Mfa2Component', () => {
  let component: Mfa2Component;
  let fixture: ComponentFixture<Mfa2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mfa2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mfa2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
