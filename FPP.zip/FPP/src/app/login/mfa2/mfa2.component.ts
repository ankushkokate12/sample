import { Component, OnInit } from "@angular/core";
import { LoginService } from "../../common/services/login.service";
import { Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from "@angular/forms";
import { DateFormatUtility } from "../../common/utils/dateFormat-utility";
import { makeStateKey } from "@angular/platform-browser";
import { MessageService, ConfirmationService } from "primeng/api";
import { PermissionUtil } from "../../common/utils/permission-util";
import { StartupPages } from "../constants/stringConstants";

@Component({
  selector: "app-mfa2",
  templateUrl: "./mfa2.component.html",
  styleUrls: ["./mfa2.component.css"]
})
export class Mfa2Component implements OnInit {
  mfa2Form: FormGroup;
  factorType: string;
  showLoadingIndicator: boolean;
  constructor(
    private messageService: MessageService,
    private router: Router,
    public fb: FormBuilder,
    private loginService: LoginService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.mfa2Form = this.fb.group({
      factorValue: new FormControl(),
      verificationCode: new FormControl("", [
        Validators.required,
        Validators.pattern("[0-9]{6}")
      ])
    });

    this.setFactorValue();
  }

  setFactorValue() {
    this.factorType = this.loginService.mfaDetails.factorType;
    const factorValue = this.loginService.loginData.otpFactors.find(
      o => o.type === this.factorType
    ).value;
    this.mfa2Form.patchValue({
      factorValue:
        this.factorType === "email" ? factorValue : this.mask(factorValue)
    });
  }

  mask(mobile: string) {
    const stringLength = mobile.length;
    return "X".repeat(10) + mobile.substring(stringLength - 4, stringLength);
  }

  onPreviousClick() {
    this.loginService.mfaDetails.verificationCodeSent = false;
  }

  resendCode() {
    if (this.loginService.loginData) {
      const expiryDate = new Date(this.loginService.loginData.expiration);
      if (new Date() < expiryDate){
        this.showLoadingIndicator = true;
        this.loginService.mfaDetails.verificationCodeSent = true;
        this.mfa2Form.get("verificationCode").reset();
    
        this.loginService
          .sendOtp(this.loginService.mfaDetails.factorType)
          .subscribe(
            data => {
              this.loginService.mfaDetails.verificationCodeSent = true;
              this.showLoadingIndicator = false;
            },
            error => {
              this.showLoadingIndicator = false;
              this.loginService.mfaDetails.verificationCodeSent = false;
              this.messageService.add({
                key: "Login",
                severity: "error",
                summary: "ERROR",
                sticky: true,
                detail: error.error
              });
            }
          );
      } else {
        this.confirmationService.confirm({
         message:"Login time is expired. Please login again.",
          header:"Login Timeout Warning",
         key: "mfa2SessionTimeOut",
         accept: () => {
          this.loginService.logout();
          this.router.navigate(["/login"]);
         },
         reject: () => {
         return;
         }
       });
     }
    }
  }

  onSubmit() {
    console.log("submitted");
    this.mfa2Form.markAllAsTouched();
    if (this.loginService.loginData) {
      const expiryDate = new Date(this.loginService.loginData.expiration);
      if (new Date() < expiryDate) {
        this.showLoadingIndicator = true;
        this.loginService
          .validateOtp(this.mfa2Form.value.verificationCode)
          .subscribe(
            data => {
              if (data) {
                let allPermissionsArr: any = [];
                sessionStorage.setItem("loggedInUser", JSON.stringify(data));
                let loginData: any = data;

                if (
                  loginData != undefined &&
                  loginData.rolesAndPermissions[0] != undefined &&
                  loginData.rolesAndPermissions[0].companies[0] != undefined &&
                  loginData.rolesAndPermissions[0].companies[0]
                    .allPermissions != undefined
                ) {
                  sessionStorage.setItem(
                    "permissionRights",
                    JSON.stringify(
                      loginData.rolesAndPermissions[0].companies[0]
                        .allPermissions
                    )
                  );

                  PermissionUtil.setPermission(
                    loginData.rolesAndPermissions[0].companies[0].allPermissions
                  );
                } else {
                  sessionStorage.setItem("permissionRights",JSON.stringify([]));
                  PermissionUtil.setPermission([]);
                  this.loginService.startupPage = StartupPages[0].route;
                  localStorage.setItem("startupPage", StartupPages[0].route);
                }

                this.loginService.contactId = data["userId"];
                sessionStorage.setItem(
                  "contactId",
                  this.loginService.contactId.toString()
                );
                this.showLoadingIndicator = false;
                this.router.navigate([this.loginService.startupPage]);
              }
              this.showLoadingIndicator = false;
            },
            error => {
              this.showLoadingIndicator = false;
              //this.mfa2Form.reset();
              this.mfa2Form.patchValue({ verificationCode: "" });

              this.confirmationService.confirm({
                header: "ERROR",
                message:
                  "The OTP you have entered is incorrect. Please try again.",
                key: "otpValidationErrorDialog",
                accept: () => {
                  //this.loginService.loginData = null;
                  this.mfa2Form.markAsUntouched();
                  this.mfa2Form.markAsPristine();
                },
                reject: () => {
                  return;
                }
              });
            }
          );
      } else {
        this.showLoadingIndicator = false;
        //this.mfa2Form.reset();

        this.confirmationService.confirm({
          message:"Login time is expired. Please login again.",
           header:"Login Timeout Warning",
          key: "mfa2SessionTimeOut",
          accept: () => {
            //this.loginService.loginData = null;
            this.loginService.logout();
            this.router.navigate(["/login"]);
          },
          reject: () => {
          return;
          }
        });
      }
    }
  }

  onKeydownForOtp(e) {
    if ([46,8, 9, 27, 40, 13, 144,35, 36, 37, 39, 190].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.key === 'a' && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.key === 'c' && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      // (e.key === 'v' && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.key === 'x' && (e.ctrlKey || e.metaKey))) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].indexOf(e.key) === -1)) {
      e.preventDefault();
    }
  }
}
