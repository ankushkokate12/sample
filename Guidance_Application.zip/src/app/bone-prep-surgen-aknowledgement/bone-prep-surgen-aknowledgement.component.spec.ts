import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BonePrepSurgenAknowledgementComponent } from './bone-prep-surgen-aknowledgement.component';

describe('BonePrepSurgenAknowledgementComponent', () => {
  let component: BonePrepSurgenAknowledgementComponent;
  let fixture: ComponentFixture<BonePrepSurgenAknowledgementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BonePrepSurgenAknowledgementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BonePrepSurgenAknowledgementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
