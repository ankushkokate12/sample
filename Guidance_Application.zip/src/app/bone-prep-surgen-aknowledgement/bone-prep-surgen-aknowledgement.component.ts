import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bone-prep-surgen-aknowledgement',
  templateUrl: './bone-prep-surgen-aknowledgement.component.html',
  styleUrls: ['./bone-prep-surgen-aknowledgement.component.css']
})
export class BonePrepSurgenAknowledgementComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<any> = new EventEmitter<any>();
  @Output() onNext: EventEmitter<any> = new EventEmitter<any>();
  acknowledge: boolean = true;

  isAgreeNext: boolean;
  isAgreeCurrent: boolean;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onHide() {
    this.display = false;
    this.isAgreeNext = true;
    this.onNext.emit({
      isDisplay:  this.display,
      isNext: this.isAgreeNext
    }); 
  }

 

  onAgree(){   
    this.display = false;
    this.isAgreeCurrent = true;
    this.onClose.emit({
      isDisplay:  this.display,
      isCurrent: this.isAgreeCurrent
    });
    // this.router.navigate(["/header/implant-details/bone-preparation"])
  }
  onDisAgree(){
    this.display = false;
    this.onClose.emit(this.display);
    this.router.navigate(["/header/implant-details/intra-op-planning"])
  }
  FieldsChange(values:any){
    if(values.currentTarget.checked){
      this.acknowledge = false;
    }
    else
    {
      this.acknowledge = true;
    }
    }

}
