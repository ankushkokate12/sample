import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BonePreparationVerifyComponent } from './bone-preparation-verify.component';

describe('BonePreparationVerifyComponent', () => {
  let component: BonePreparationVerifyComponent;
  let fixture: ComponentFixture<BonePreparationVerifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BonePreparationVerifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BonePreparationVerifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
