import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-bone-preparation-verify',
  templateUrl: './bone-preparation-verify.component.html',
  styleUrls: ['./bone-preparation-verify.component.css']
})
export class BonePreparationVerifyComponent implements OnInit {
  @Input() display: boolean = false;
  @Input() header: any;;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() verifyImage: any;

  constructor() { }

  ngOnInit() {
  }
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);
  }

}
