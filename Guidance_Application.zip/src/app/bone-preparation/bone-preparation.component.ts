import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { element } from 'protractor';

@Component({
  selector: 'app-bone-preparation',
  templateUrl: './bone-preparation.component.html',
  styleUrls: ['./bone-preparation.component.css']
})
export class BonePreparationComponent implements OnInit {
  implantPlanId: any;
  patientId: any;
  patientName: any;

  isDistal: boolean;
  isAnterior: boolean;
  isAnteriorCh: boolean;
  isPosteriorCh: boolean;
  isPosterior: boolean;
  isFemurPegHole: boolean;
  isFemurNotch: boolean;
  isTibia: boolean;
  isKeel: boolean;

  isCTView: boolean = false;
  acknowledge: boolean = true;
  surgenPopup: boolean = false;
  isbtnCTViewEnabled: boolean = false;

  displayErrorDialog: boolean;
  bonePrepImages: any;
  successMsg: boolean;
  surgenAcknowlede: boolean;

  displaySurgerDialog: boolean;

  bonePrepCTView: any;
  isFirst: boolean;

  constructor(private router: Router) { }

  ngOnInit() {
    this.displaySurgerDialog = true;
    this.implantPlanId = localStorage.getItem('selectedImplantPlanId');
    this.patientId = localStorage.getItem('selectedPatientId');
    this.patientName = localStorage.getItem('selectedPatientName');
    this.surgenPopup = true;
    
  }
  onNext() {
    // this.surgenPopup = true;
    this.router.navigate(["/header/implant-details/case-completion"])
  }
  onPrev() {
    this.router.navigate(["/header/implant-details/intra-op-planning"])
  }

  showSurgenDialog() {
    this.displaySurgerDialog = true;
  }
  onSurgenDialogClose() {
    this.displaySurgerDialog = false;
  }
  currentRoute: boolean;
  prevRoute: boolean;
  onAgree(data1: any) {
    this.surgenPopup = false;
    // this.displayErrorDialog = true;
    this.displaySurgerDialog = false;    
    this.isFirst = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";

    this.isDistal = false;
    // this.bonePrepImages = "BonePrep_distal_img1.png";
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;
    console.log("current")
    this.currentRoute = data1.isCurrent
    // this.router.navigate(["/header/implant-details/case-completion"])
  }

  onDisAgree(data: any){
    this.prevRoute = data.isNext
    if(this.prevRoute && !this.currentRoute){
      this.router.navigate(["/header/implant-details/intra-op-planning"])
    }
   
    
    console.log(data)
  }

  onCuttingTool(){
    this.surgenAcknowlede = true;
  }


  onProceed(){
    this.surgenAcknowlede = false;
    this.successMsg = false;
    this.acknowledge = true;
  }

  onClose() {
    this.surgenPopup = false;
    this.router.navigate(["/header/implant-details/intra-op-planning"])
  }

  FieldsChange(values: any) {
    if (values.currentTarget.checked) {
      this.acknowledge = false;
    }
    else {
      this.acknowledge = true;
    }
  }

  onDistal() {
    this.isDistal = true;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;
    this.bonePrepImages = "BonePrep_distal_img1.png";

    this.displayErrorDialog = true;
    this.headerText = "Femur Bone Checkpoint";
    this.verifyImg = "femur-popup-img.png";
  }

  onAnterior() {
    this.isAnterior = true;

    this.isDistal = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;

    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }
  onAnteriorCh() {
    this.isAnteriorCh = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;
    this.isbtnCTViewEnabled = true;

    this.isFirst = false;

    // this.successMsg = false;
    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }
  onPosteriorCh() {
    this.isPosteriorCh = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;
    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }
  onPosterior() {
    this.isPosterior = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;
    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }
  onFemurPegHole() {
    this.isFemurPegHole = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurNotch = false;
    this.isTibia = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;
    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }

  onFemurNotch() {
    this.isFemurNotch = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isTibia = false;
    this.isKeel = false;
    this.isbtnCTViewEnabled = true;

    this.successMsg = false;
    this.isFirst = false;
    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }

  onTibia() {
    this.isTibia = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isKeel = false;

    this.successMsg = false;
    this.isFirst = false;
    this.isbtnCTViewEnabled = true;
    this.bonePrepImages = "tibia_bone-prep-img1.png";

    this.displayErrorDialog = true;
    this.headerText = "Tibia Bone Checkpoint";
      this.verifyImg = "tibia-popup-img.png";
  }

  onKeel() {
    this.isKeel = true;

    this.isDistal = false;
    this.isAnterior = false;
    this.isAnteriorCh = false;
    this.isPosteriorCh = false;
    this.isPosterior = false;
    this.isFemurPegHole = false;
    this.isFemurNotch = false;
    this.isTibia = false;

    this.successMsg = false;
    this.isFirst = false;
     this.isbtnCTViewEnabled = true;

    // this.displayErrorDialog = true;
    // this.headerText = "Femur Bone Checkpoints";
    // this.verifyImg = "femur-popup-img.png";
  }


cutImagePlaceholder: boolean = false;
  onCTView() {
    if(this.isDistal){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = false;
    }
    else if(this.isAnterior){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isAnteriorCh){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isPosteriorCh){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isPosterior){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isFemurNotch){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isTibia){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isKeel){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }
    else if(this.isFemurPegHole){
      this.bonePrepCTView = "CT-view-bone-prep.png";
      this.cutImagePlaceholder = true;
    }


    if (this.isCTView == true) {
      this.isCTView = false;
    }
    else {
      this.isCTView = true;
    }

  }
  headerText: any;
  verifyImg: any;
  showErrorDialog() {
    this.displayErrorDialog = true;

    // if (this.isDistal == true) {
    //   this.headerText = "Femur Bone Checkpoints";
    //   this.verifyImg = "femur-popup-img.png";
    // }
    // else {
    //   this.headerText = "Tibia Bone Checkpoints";
    //   this.verifyImg = "tibia-popup-img.png";
    // }
  }
  onErrorDialogClose() {
    this.displayErrorDialog = false;
    this.successMsg = true;
  }

}
