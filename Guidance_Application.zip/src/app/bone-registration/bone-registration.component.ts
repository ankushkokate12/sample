import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bone-registration',
  templateUrl: './bone-registration.component.html',
  styleUrls: ['./bone-registration.component.css']
})
export class BoneRegistrationComponent implements OnInit {
  showHideButtons: boolean = false;
  isTabOne: boolean = true;
  isTabTwo: boolean;
  isTabThree: boolean;

  implantPlanId: any;
  patientId: any;
  patientName: any;

  hipCenter: boolean;
  medialMalleous: boolean;
  lateralMalleous: boolean;

  tab1FirstImage: any;
  tab2FirstImage: any;
  tab3FirstImage: any;

  isRotateImg: boolean = true;
  firstCheck: boolean;

  isHipCenterChecked: boolean = true;
  isMedialMalleousChecked: boolean = true;
  isLateralMalleousChecked: boolean = true;

  isFemurChecked: boolean = true;
  isTibiaChecked: boolean = true;
  tibia: boolean;
  femur: boolean;

  isTab3FemurChecked: boolean = true;
  isTab3TibiaChecked: boolean = true;
  isTab3FemurDone: boolean = true;
  isTab3TibiaDone: boolean = true;
  tibiaTab3: boolean;
  femurTab3: boolean;

  isStep1GotIt: boolean;
  isStep2GotIt: boolean;
  isStep3GotIt: boolean;

  tab1SuccessMsg: boolean;
  tab2SuccessMsg: boolean;
  tab3SuccessMsg: boolean;

  isTab3FemurVerify: Boolean = false;
  isTab3TibiaVerify: Boolean;

  tab3FemurCaptureCount: number = 0;
  tab3FemurProgress: any = 0;
  tab3FemurVerifyCount: number = 0;
  tab3FemurVerifyProgress: any = 0;

  tab3TibiaCaptureCount: number = 0;
  tab3TibiaProgress: any = 0;
  femurTab3CaptureCount: any = 0;
  tibiaTab3CaptureCount: any = 0;
  ctViewFemur: boolean;
  ctViewTibia: boolean;
  femurVerifyProgress: boolean;
  tibiaVerifyProgress: boolean;
  captureDisabled: boolean = false;
  femurVerifyDisabled: boolean = false;
  femurTab3Check: boolean = false;
  tibiaTab3Check: boolean = false;

  isFemurCompleted: boolean;
  isTibiaCompleted: boolean;

  femurRegistrartionFail: boolean = false;
  isErrorRegistration: boolean = false;
  isDisabledClearAllPointTab1: boolean = true;
  isDisabledCaptureTab1: boolean = false;
  isDisabledClearAllPointTab2: boolean = true;
  isDisabledCaptureTab2: boolean = false;
  isDisabledClearAllPointTab3: boolean = false;

  constructor(private router: Router) { }

  ngOnInit() {
    this.selectTab1();
    this.implantPlanId = localStorage.getItem('selectedImplantPlanId');
    this.patientId = localStorage.getItem('selectedPatientId');
    this.patientName = localStorage.getItem('selectedPatientName');
    this.tab1FirstImage = 'tab1-img1.png';
    this.tab2FirstImage = 'tab2-img1.png';
    this.tab3FirstImage = 'tab3-femur-img1.png';

  }
  selectTab1() {
    this.isTabOne = true;
    this.isTabTwo = false;
    this.isTabThree = false;
    this.isStep1GotIt = true;
    this.isStep2GotIt = false;
    this.isStep3GotIt = false;

    this.isHipCenterChecked = true;
    this.isMedialMalleousChecked = true;
    this.isLateralMalleousChecked = true
    this.tab1FirstImage = 'tab1-img1.png';
    this.firstCheck = false;
  }
  selectTab2() {
    this.isTabOne = false
    this.isTabTwo = true;
    this.isTabThree = false;
    this.isStep1GotIt = false;
    this.isStep2GotIt = true;
    this.isStep3GotIt = false;

    this.isFemurChecked = true;
    this.isTibiaChecked = true;
    this.tab2FirstImage = 'tab2-img1.png';
    this.firstCheck = false;
  }
  selectTab3() {
    this.isTabOne = false
    this.isTabTwo = false;
    this.isTabThree = true;
    this.isStep1GotIt = false;
    this.isStep2GotIt = false;
    this.isStep3GotIt = true;
    this.isTab3TibiaChecked = true;
    this.isTab3FemurChecked = true;
    this.tab3FirstImage = 'tab3-femur-img1.png';
    this.firstCheck = false;
  }

  onStep1WorkFlow() {
    this.isStep1GotIt = true;
    this.isStep2GotIt = false;
    this.isStep3GotIt = false;
  }
  onStep2WorkFlow() {
    this.isStep1GotIt = false;
    this.isStep2GotIt = true;
    this.isStep3GotIt = false;
  }
  onStep3WorkFlow() {
    this.isStep1GotIt = false;
    this.isStep2GotIt = false;
    this.isStep3GotIt = true;
  }


  checkedChangeTab1(event) {
    if (event.target.value == "hipCenter" && event.target.checked) {
      this.isHipCenterChecked = false;
      this.isMedialMalleousChecked = true;
      this.isLateralMalleousChecked = true
      this.isRotateImg = true;
      this.tab1FirstImage = 'tab1-img1.png';
      this.firstCheck = true;
      if (this.hipCenter) {
        this.isDisabledCaptureTab1 = true;
        this.isDisabledClearAllPointTab1 = false;
      }
      else {
        this.isDisabledCaptureTab1 = false;
        this.isDisabledClearAllPointTab1 = true;
      }
    }
    else if (event.target.value == "medialMalleous" && event.target.checked) {
      this.isMedialMalleousChecked = false;
      this.isHipCenterChecked = true;
      this.isLateralMalleousChecked = true
      this.isRotateImg = false;
      this.tab1FirstImage = 'tab1-img2.png';
      this.firstCheck = false;
      if (this.medialMalleous) {
        this.isDisabledCaptureTab1 = true;
        this.isDisabledClearAllPointTab1 = false;
      }
      else {
        this.isDisabledCaptureTab1 = false;
        this.isDisabledClearAllPointTab1 = true;
      }
    }
    else if (event.target.value == "lateralMalleous" && event.target.checked) {
      this.isMedialMalleousChecked = true;
      this.isHipCenterChecked = true;
      this.isLateralMalleousChecked = false
      this.isRotateImg = false;
      this.tab1FirstImage = 'tab1-img3.png';
      this.firstCheck = false;
      if (this.lateralMalleous) {
        this.isDisabledCaptureTab1 = true;
        this.isDisabledClearAllPointTab1 = false;
      }
      else {
        this.isDisabledCaptureTab1 = false;
        this.isDisabledClearAllPointTab1 = true;
      }
    }
    else {
      this.isMedialMalleousChecked = true;
      this.isHipCenterChecked = true;
      this.isLateralMalleousChecked = true
      this.firstCheck = false;
    }
  }
  hipCaptureCount: number = 0;
  hipProgress: any = 0;
  onCapture() {
    if ((!this.isHipCenterChecked || this.firstCheck) && !this.hipCenter) {
      this.hipCaptureCount = this.hipCaptureCount + 20;
      this.hipProgress = this.hipCaptureCount + '%';
      if (this.hipCaptureCount == 20) {
        this.isDisabledClearAllPointTab1 = false;
      }
      if (this.hipCaptureCount == 100) {
        this.hipCenter = true;
        this.isDisabledCaptureTab1 = true;
      }

    }
    if (!this.isMedialMalleousChecked && !this.medialMalleous) {
      this.medialMalleous = true;
      this.isDisabledCaptureTab1 = true;
      this.isDisabledClearAllPointTab1 = false;
    }
    if (!this.isLateralMalleousChecked && !this.lateralMalleous) {
      this.lateralMalleous = true;
      this.isDisabledCaptureTab1 = true;
      this.isDisabledClearAllPointTab1 = false;
    }

    if (this.hipCenter && this.medialMalleous && this.lateralMalleous) {
      this.tab1SuccessMsg = true;
    }
    else {
      this.tab1SuccessMsg = false;
    }

  }
  onClear() {
    if ((!this.isHipCenterChecked || this.firstCheck)) {
      this.hipCaptureCount = 0;
      this.hipProgress = this.hipCaptureCount + '%';
      this.hipCenter = false;
      this.isDisabledCaptureTab1 = false;
      this.isDisabledClearAllPointTab1 = true;
    }
    if (!this.isMedialMalleousChecked) {
      this.medialMalleous = false;
      this.isDisabledCaptureTab1 = false;
      this.isDisabledClearAllPointTab1 = true;
    }
    if (!this.isLateralMalleousChecked) {
      this.lateralMalleous = false;
      this.isDisabledCaptureTab1 = false;
      this.isDisabledClearAllPointTab1 = true;
    }
    if (this.hipCenter && this.medialMalleous && this.lateralMalleous) {
      this.tab1SuccessMsg = true;
    }
    else {
      this.tab1SuccessMsg = false;
    }
  }


  checkedChangeTab2(event) {
    if (event.target.value == "femur" && event.target.checked) {
      this.isFemurChecked = false;
      this.isTibiaChecked = true;
      this.tab2FirstImage = 'tab2-img1.png';
      this.firstCheck = true;
      if (this.femur) {
        this.isDisabledCaptureTab2 = true;
        this.isDisabledClearAllPointTab2 = false;
      }
      else {
        this.isDisabledCaptureTab2 = false;
        this.isDisabledClearAllPointTab2 = true;
      }
    }
    else if (event.target.value == "tibia" && event.target.checked) {
      this.isTibiaChecked = false;
      this.isFemurChecked = true;
      this.tab2FirstImage = 'tab2-img2.png';
      this.firstCheck = false;
      if (this.tibia) {
        this.isDisabledCaptureTab2 = true;
        this.isDisabledClearAllPointTab2 = false;
      }
      else {
        this.isDisabledCaptureTab2 = false;
        this.isDisabledClearAllPointTab2 = true;
      }
    }
    else {
      this.isTibiaChecked = true;
      this.isFemurChecked = true;
      this.firstCheck = false;
    }
  }
  onVerifyCheckPointsTab2() {
    if ((!this.isFemurChecked || this.firstCheck) && !this.femur) {
      this.femur = true;
      this.isDisabledCaptureTab2 = true;
      this.isDisabledClearAllPointTab2 = false;
    }
    if (!this.isTibiaChecked && !this.tibia) {
      this.tibia = true;
      this.isDisabledCaptureTab2 = true;
      this.isDisabledClearAllPointTab2 = false;
    }
    if (this.femur && this.tibia) {
      this.tab2SuccessMsg = true;
    }
    else {
      this.tab2SuccessMsg = false;
    }
  }
  onClearCheckPointTab2() {
    if ((!this.isFemurChecked || this.firstCheck) && this.femur) {
      this.femur = false;
      this.isDisabledCaptureTab2 = false;
      this.isDisabledClearAllPointTab2 = true;
    }
    if (!this.isTibiaChecked && this.tibia) {
      this.isDisabledCaptureTab2 = false;
      this.isDisabledClearAllPointTab2 = true;
      this.tibia = false;
    }
    if (this.femur && this.tibia) {
      this.tab2SuccessMsg = true;
    }
    else {
      this.tab2SuccessMsg = false;
    }
  }

  checkedChangeTab3(event) {
    if (event.target.value == "femurTab3" && event.target.checked) {
      if (this.isTab3FemurVerify == true) {
        this.tab3FirstImage = 'tab3-femur-img8.png';
      }
      else {
        this.tab3FirstImage = 'tab3-femur-img1.png';
      }
      if (this.isFemurCompleted) {
        this.captureDisabled = true;
        // this.isDisabledClearAllPointTab3 = false;
      }
      else {
        this.captureDisabled = false;
        // this.isDisabledClearAllPointTab3 = true;
      }

      this.isTab3FemurChecked = false;
      this.isTab3TibiaChecked = true;
      this.tibiaTab3Check = false;

      this.firstCheck = true;
      this.femurTab3CaptureCount = 0
    }
    else if (event.target.value == "tibiaTab3" && event.target.checked) {
      if (this.isTab3TibiaVerify == true) {
        this.tab3FirstImage = 'tab3-tibia-img7.png';
      }
      else {
        this.isDisabledClearAllPointTab3 = false;
        this.tab3FirstImage = 'tab3-tibia-img1.png';
      }

      if (this.isTibiaCompleted) {
        this.captureDisabled = true;
        // this.isDisabledClearAllPointTab3 = false;
      }
      else {
        this.captureDisabled = false;
        // this.isDisabledClearAllPointTab3 = true;
      }

      this.tibiaTab3CaptureCount = 0
      this.femurTab3Check = false;
      this.isTab3TibiaChecked = false;
      this.isTab3FemurChecked = true;
      this.firstCheck = false;
    }
    else {
      this.isTab3TibiaChecked = true;
      this.isTab3FemurChecked = true;
      this.firstCheck = false;
    }
  }


  onCaptureTab3() {
    if ((!this.isTab3FemurChecked || this.firstCheck)) {
      // this.femurTab3 = true;
      // this.tab3FemurCaptureCount = this.tab3FemurCaptureCount + 10;
      // this.tab3FemurProgress = this.tab3FemurCaptureCount + '%';
      // if (this.tab3FemurCaptureCount == 100) {
      //   this.femurTab3 = true;
      // }

      this.femurTab3CaptureCount = this.femurTab3CaptureCount + 1;
      this.femurVerifyDisabled = false;
      console.log(this.femurTab3CaptureCount)
      if (this.isTab3FemurVerify) {
        if (this.femurTab3CaptureCount == 1) {
          this.tab3FemurVerifyCount = 20;
          this.tab3FirstImage = 'tab3-femur-img7.png';
          this.ctViewFemur = true;
          this.femurVerifyProgress = true;
          this.femurTab3 = false;
          this.isDisabledClearAllPointTab3 = true;
        }
        else {
          this.tab3FemurVerifyCount = 100;
          this.ctViewFemur = false;
          this.tab3FirstImage = 'tab3-femur-img8.png';
          this.femurVerifyProgress = true;
          this.femurTab3 = false;
          this.femurTab3Check = true;
          this.isFemurCompleted = true;
          this.captureDisabled = true
          // this.isDisabledClearAllPointTab3 = false
        }
      }
      else {
        if (this.femurTab3CaptureCount == 1) {
          this.tab3FemurCaptureCount = 10
          this.tab3FirstImage = 'tab3-femur-img2.png';
          this.femurVerifyProgress = false;
          this.captureDisabled = false;
          this.isDisabledClearAllPointTab3 = true;
        }
        else if (this.femurTab3CaptureCount == 2) {
          this.tab3FemurCaptureCount = 90;
          this.tab3FirstImage = 'tab3-femur-img3.png';
          this.femurVerifyProgress = false;
          this.captureDisabled = false;
        }
        else if (this.femurTab3CaptureCount == 3) {

          if (!this.femurRegistrartionFail) {
            this.tab3FirstImage = 'tab3-femur-img4.png';
            this.tab3FemurCaptureCount = 100;
            this.femurRegistrartionFail = true;
            this.isErrorRegistration = true;
            this.captureDisabled = true;
            if (this.tab3FemurCaptureCount == 100) {
              this.femurTab3 = false;
            }

          }
          else {
            this.tab3FemurCaptureCount = 100;
            this.tab3FirstImage = 'tab3-femur-img5.png';
            this.femurVerifyProgress = false;
            this.captureDisabled = true;
            this.femurRegistrartionFail = false;
            this.isErrorRegistration = false;


            if (this.tab3FemurCaptureCount == 100) {
              this.femurTab3 = true;
            }
          }
        }
        this.tab3FemurProgress = this.tab3FemurCaptureCount + '%';



      }
      this.tab3FemurVerifyProgress = this.tab3FemurVerifyCount + '%';
    }
    if (!this.isTab3TibiaChecked && !this.tibiaTab3) {
      // this.tibiaTab3 = true;

      // this.tab3TibiaCaptureCount = this.tab3TibiaCaptureCount + 20;
      // this.tab3TibiaProgress = this.tab3TibiaCaptureCount + '%';
      // if (this.tab3TibiaCaptureCount == 100) {
      //   this.tibiaTab3 = true;
      // }

      this.tibiaTab3CaptureCount = this.tibiaTab3CaptureCount + 1;
      if (this.isTab3TibiaVerify) {
        if (this.tibiaTab3CaptureCount == 1) {
          this.tab3FemurVerifyCount = 20;
          this.tab3FirstImage = 'tab3-tibia-img5.png';
          this.ctViewTibia = true;
          this.tibiaVerifyProgress = true;
          this.femurTab3 = false;
          this.isDisabledClearAllPointTab3 = true;
        }
        else if (this.tibiaTab3CaptureCount == 2) {
          this.tab3FemurVerifyCount = 20;
          this.tab3FirstImage = 'tab3-tibia-img6.png';
          this.ctViewTibia = true;
          this.tibiaVerifyProgress = true;
          this.femurTab3 = false;
        }
        else {
          this.tab3FemurVerifyCount = 100;
          this.ctViewTibia = false;
          this.tab3FirstImage = 'tab3-tibia-img7.png';
          this.tibiaVerifyProgress = true;
          this.femurTab3 = false;
          this.tibiaTab3Check = true;
          this.isTibiaCompleted = true;
          this.captureDisabled = true
          // this.isDisabledClearAllPointTab3 = false;
        }
      }
      else {
        if (this.tibiaTab3CaptureCount == 1) {
          this.tab3TibiaCaptureCount = 10
          this.tab3FirstImage = 'tab3-tibia-img2.png';
          this.tibiaVerifyProgress = false;
          this.captureDisabled = false;
          this.isDisabledClearAllPointTab3 = true;
        }
        else if (this.tibiaTab3CaptureCount == 2) {
          this.tab3TibiaCaptureCount = 90;
          this.tab3FirstImage = 'tab3-tibia-img3.png';
          this.tibiaVerifyProgress = false;
          this.captureDisabled = false;
        }
        else {
          this.tab3TibiaCaptureCount = 100;
          this.tab3FirstImage = 'tab3-tibia-img4.png';
          this.tibiaVerifyProgress = false;
          this.captureDisabled = true;

        }

        this.tab3TibiaProgress = this.tab3TibiaCaptureCount + '%';
        if (this.tab3TibiaCaptureCount == 100) {
          this.tibiaTab3 = true;
        }
      }

    }

    if (this.femurTab3 && this.tibiaTab3) {
      this.tab3SuccessMsg = true;
    }
    else {
      this.tab3SuccessMsg = false;
    }
  }


  onClearAllTab3() {
    if ((!this.isTab3FemurChecked || this.firstCheck)) {
      // this.femurTab3 = false;
      // this.tab3FemurVerifyCount = 0;
      // this.femurTab3CaptureCount = 0
      // this.tab3FemurCaptureCount = 0;
      // this.tab3FemurProgress = this.tab3FemurCaptureCount + '%';

      // this.captureDisabled = false;
      // this.isErrorRegistration = false;
      // this.femurVerifyProgress = false;
      // this.femurTab3Check = false;
      // this.isFemurCompleted = false;
      // this.isTab3FemurChecked = true;
      // this.tab3FirstImage = 'tab3-femur-img1.png';
      // this.firstCheck = true;
      // this.tab3SuccessMsg = true;

      if (this.isTab3FemurVerify == true) {
        this.tab3FirstImage = 'tab3-femur-img6.png';
        this.firstCheck = false;
        this.femurTab3 = false;
        this.femurTab3CaptureCount = 0;
        this.tab3FemurVerifyCount = 0;
        this.femurVerifyProgress = true;
        this.captureDisabled = false;
        this.ctViewFemur = true;
        this.isDisabledClearAllPointTab3 = false;
      }
      else {
        this.tab3FemurVerifyCount = 0;
        this.femurTab3CaptureCount = 0
        this.tab3FemurCaptureCount = 0;
        this.tab3FemurProgress = this.tab3FemurCaptureCount + '%';

        this.captureDisabled = false;
        this.isErrorRegistration = false;
        this.femurVerifyProgress = false;
        this.femurTab3Check = false;
        this.isFemurCompleted = false;
        this.isTab3FemurChecked = true;
        this.tab3FirstImage = 'tab3-femur-img1.png';
        this.firstCheck = true;
        this.tab3SuccessMsg = true;
        this.isDisabledClearAllPointTab3 = false;
      }
    }
    else if (!this.isTab3TibiaChecked) {
      this.tibiaTab3 = false;

      if (this.isTab3TibiaVerify == true) {
        this.tab3FirstImage = 'tab3-tibia-img5.png';
        this.firstCheck = false;

        this.tibiaTab3 = false;
        this.tibiaTab3CaptureCount = 0;
        this.tibiaVerifyProgress = true;
        this.captureDisabled = false;
        this.ctViewTibia = true;
        this.isDisabledClearAllPointTab3 = false;
      }
      else {
        this.tibiaTab3CaptureCount = 0
        this.tab3TibiaCaptureCount = 0;
        this.tab3TibiaProgress = this.tab3TibiaCaptureCount + '%';

        this.tibiaVerifyProgress = false;
        this.tibiaTab3Check = false;
        this.isTibiaCompleted = false;
        this.isTab3TibiaChecked = false;
        this.tab3SuccessMsg = false;
        this.captureDisabled = false;
        this.tab3FirstImage = 'tab3-tibia-img1.png';
        this.isDisabledClearAllPointTab3 = false;
      }
    }

    // if (this.femurTab3 && this.tibiaTab3) {

    // }
    // else {

    // }
  }


  onFemurTab3Verify() {
    this.isTab3FemurVerify = true;
    this.isTab3FemurChecked = false;
    this.isTab3TibiaChecked = true;
    this.tab3FirstImage = 'tab3-femur-img6.png';
    this.firstCheck = false;
    this.femurTab3 = false;
    this.femurTab3CaptureCount = 0;
    this.tab3FemurVerifyCount = 0;
    this.femurVerifyProgress = true;
    this.captureDisabled = false;
    this.ctViewFemur = true;
    this.isDisabledClearAllPointTab3 = false;
    // this.femurVerifyDisabled = true;
  }
  onTibiaTab3Verify() {
    this.isTab3TibiaVerify = true;
    this.isTab3FemurChecked = true;
    this.isTab3TibiaChecked = false;
    this.tab3FirstImage = 'tab3-tibia-img5.png';
    this.firstCheck = false;

    this.tibiaTab3 = false;
    this.tibiaTab3CaptureCount = 0;
    this.tibiaVerifyProgress = true;
    this.captureDisabled = false;
    this.ctViewTibia = true;
    this.isDisabledClearAllPointTab3 = false;
  }

  step1GotIt() {
    this.firstCheck = true;
    this.isStep1GotIt = false;

  }
  step2GotIt() {
    this.firstCheck = true;
    this.isStep2GotIt = false;
  }
  step3GotIt() {
    this.firstCheck = true;
    this.isStep3GotIt = false;
    if (this.isTab3FemurVerify == true) {
      this.tab3FirstImage = 'tab3-femur-img6.png';
      this.firstCheck = true;
    }
    else if (this.isTab3TibiaVerify == true) {
      this.tab3FirstImage = 'tab3-tibia-img5.png';
    }

  }

  onNext() {
    this.router.navigate(["/header/implant-details/joint-assesment"])
  }
  onPrev() {
    this.router.navigate(["/header/implant-details/system-setup"])
  }

}
