import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-completion-disconnect-exit',
  templateUrl: './case-completion-disconnect-exit.component.html',
  styleUrls: ['./case-completion-disconnect-exit.component.css']
})
export class CaseCompletionDisconnectExitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
