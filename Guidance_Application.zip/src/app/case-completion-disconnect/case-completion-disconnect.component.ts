import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { UserManagementService } from '../user-managment-workflow/user-management.service';

@Component({
  selector: 'app-case-completion-disconnect',
  templateUrl: './case-completion-disconnect.component.html',
  styleUrls: ['./case-completion-disconnect.component.css']
})
export class CaseCompletionDisconnectComponent implements OnInit {
  @Output() onPreviousRoute: EventEmitter<boolean> = new EventEmitter<boolean>();

  isMountEndEffector: boolean;
  isIrrigation: boolean;
  isBobeTracker: boolean;
  isCheckpoints: boolean;
  caseCompletion: boolean;

  constructor(private router: Router,
    private userManagementService: UserManagementService) { }


  ngOnInit() {
  }

  onPrev() {
    // this.router.navigate(["/header/implant-details/joint-assesment"])
    this.onPreviousRoute.emit();
  }

  onMountConfirm() {
    this.isMountEndEffector = true;
    this.caseCompletionMark();
  }
  onIrrigationConfirm() {
    this.isIrrigation = true;
    this.caseCompletionMark();
  }
  onTrackerConfirm() {
    this.isBobeTracker = true;
    this.caseCompletionMark();
  }
  onCheckPointConfirm() {
    this.isCheckpoints = true;
    this.caseCompletionMark();
  }

  caseCompletionMark(){
    if(this.isMountEndEffector && this.isIrrigation && this.isBobeTracker && this.isCheckpoints){
      this.caseCompletion = true;
      this.userManagementService.updateJointAssessment(this.caseCompletion)
    }
  }

  onExit(){
    this.router.navigate(["/header/home"])
  }

}
