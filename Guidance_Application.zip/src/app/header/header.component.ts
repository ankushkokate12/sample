import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @ViewChild('toggleButton',{ static: false }) toggleButton: ElementRef;
  @ViewChild('menu', { static: false }) menu: ElementRef;

  navigateToHome: boolean;
  logggedUser: any;

  isUserOptionPanel: boolean;
  displayShutDownDialog: boolean;

  constructor(public router: Router,
    private renderer: Renderer2) { 
      this.renderer.listen('window', 'click',(e:Event)=>{ 
        if(e.target != this.toggleButton.nativeElement && e.target!=this.menu.nativeElement){
          this.isUserOptionPanel=false;
         
      }
      })
    }

  ngOnInit() {
    this.logggedUser = localStorage.getItem('loginUser');
    // if(this.router.url == "/home"){
    // this.navigateToHome=true;
    // }
    // else{
    //   this.navigateToHome=false;
    // }
  }

  userOptions(data:any){
      this.isUserOptionPanel= !this.isUserOptionPanel;    
  }

  onLogOff(){
    this.isUserOptionPanel=false;
    this.router.navigate(["/login"]);
  }
 

  onChangePassword(){
    this.isUserOptionPanel=false;
    this.router.navigate(["/header/change-password"]);
  }

  showShutDownDialog() {
    this.isUserOptionPanel=false;
    this.displayShutDownDialog = true;
  }
  onShutDownDialogClose() {
    this.displayShutDownDialog = false;

  }

}
