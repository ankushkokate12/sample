import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-implant-plan-cloud',
  templateUrl: './implant-plan-cloud.component.html',
  styleUrls: ['./implant-plan-cloud.component.css']
})
export class ImplantPlanCloudComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild('dt', {static: false}) dt: ElementRef;

  ImplantPlanIds: any[];
  cols: any[];

  constructor(private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.cols = [
      { field: 'implantPlanId', header: 'Implant Plan ID' },
      { field: 'patientId', header: 'Patient ID' }
    ];

    this.ImplantPlanIds= [
      {
        implantPlanId: "234132",
        patientId: "321234",
        patientName: "Jack Cameron"
      },
      {
        implantPlanId: "356234",
        patientId: "568764",
        patientName: "James Garcia"
      },
      {
        implantPlanId: "456724",
        patientId: "654432",
        patientName: "George Lawson"
      },
      {
        implantPlanId: "765435",
        patientId: "345432",
        patientName: "Robert Smith"
      },
      {
        implantPlanId: "897689",
        patientId: "345621",
        patientName: "Ronny Baker"
      },
      {
        implantPlanId: "987656",
        patientId: "234321",
        patientName: "Oliver Brown"
      },
    ]

  }
  
  loadImplantPlan(selectedPlan){
    localStorage.setItem('selectedImplantPlanId', selectedPlan.implantPlanId);
    localStorage.setItem('selectedPatientId', selectedPlan.patientId);
    localStorage.setItem('selectedPatientName', selectedPlan.patientName);
    this.router.navigate(["/header/implant-details/pre-op-planning"]);
  }  

  onHide() {
    this.display = false;
    this.onClose.emit(this.display);
  }

}
