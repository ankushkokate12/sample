import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserManagementService } from '../user-managment-workflow/user-management.service';

@Component({
  selector: 'app-joint-assessment',
  templateUrl: './joint-assessment.component.html',
  styleUrls: ['./joint-assessment.component.css']
})
export class JointAssessmentComponent implements OnInit {
  implantPlanId: any;
  patientId: any;
  patientName: any;
  isPostOpp: boolean = false;

  posesSize: number=1;

  isAxes: boolean = false;
  isPostText: boolean = false;;
  isStep1GotIt: boolean;

  constructor(private router: Router,
    private userManagementService: UserManagementService,) { }

  ngOnInit() {
    this.implantPlanId = localStorage.getItem('selectedImplantPlanId');
    this.patientId = localStorage.getItem('selectedPatientId');
    this.patientName = localStorage.getItem('selectedPatientName');
    this.isStep1GotIt = true;

    this.userManagementService.currentJointAssessment.subscribe(postOp => this.isPostOpp = postOp)
  
    if(this.isPostOpp){
      this.isPostText = true;
    }
  }

  selectTab1(){
    this.isPostText = false;
  }
  selectTab2(){
    this.isPostText = true;
  }

  decPoses(){
    if(this.posesSize==1){
      this.posesSize
    }
    else{
      this.posesSize = this.posesSize - 1;
    }
  }
  incPoses(){
    if(this.posesSize==5){
      this.posesSize
    }
    else{
      this.posesSize = this.posesSize + 1;
    }
      
  }

  onAxes(){
    if(this.isAxes){
      this.isAxes = false;
    }
    else{
      this.isAxes = true;
    }

  }

  onNext(){
    this.router.navigate(["/header/implant-details/intra-op-planning"])
  }
  onPrev(){
    this.router.navigate(["/header/implant-details/bone-registration"])
  }

  step1GotIt() {
    this.isStep1GotIt = false;

  }
  onStep1WorkFlow() {
    this.isStep1GotIt = true;
  }

}
