import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  users: any[];
  loginForm: FormGroup;
  incorrectPassword:boolean;
  displayShutDownDialog: boolean;
  displayForgotPasswordDialog: boolean;

  constructor(private fb: FormBuilder,
    private router: Router) {
    this.loadForm();
  }

  ngOnInit() {
    
    this.users = [
      {
        "value": "user1",
        "label": "Mike",
        "name": "Mike Taylor",
        "password": "Mike"
      },
      {
        "value": "user2",
        "label": "Robert",
        "name" :"Robert Brown",
        "password": "Robert"
      },
      {
        "value": "adminUser",
        "label": "AdminUser",
        "name" :"Admin User",
        "password": "AdminUser"
      },
      {
        "value": "serviceUser",
        "label": "ServiceUser",
        "name" :"Service User",
        "password": "ServiceUser"
      }
    ]
    
  }

  ngOnChanges() {

  }

  loadForm() {
    this.loginForm = this.fb.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]],
    })
  }

  get userName() { return this.loginForm.get('userName'); }
  get password() { return this.loginForm.get('password'); }

  onSubmit(){
   
    if(this.userName.invalid || this.password.invalid){
      this.loginForm.markAllAsTouched();
    }
    else{
      for(let i=0;i<=this.users.length;i++){
        if(this.userName.value == this.users[i].value){ 
          if(this.password.value != this.users[i].password){          
            this.loginForm.setErrors({ 'incorrectCredentials': true });
            return false;
          }
          else{
           

            if(this.users[i].value == "adminUser"){
              this.loginForm.setErrors(null);
              localStorage.setItem('loginUser', this.users[i].name);
              this.router.navigate(["/user-header/user-home"])  
            }
            else if(this.users[i].value == "serviceUser"){
              this.loginForm.setErrors(null);
              localStorage.setItem('loginUser', this.users[i].name);
              this.router.navigate(["/user-header/service-home"])  
            }
            else{
              this.loginForm.setErrors(null);
              localStorage.setItem('loginUser', this.users[i].name);
              this.router.navigate(["/header/home"])  
            }
           
          }
        }
       
      }
      
    }
    
  }

  onShutdown(){
    window.close();
  }

  showShutDownDialog() {
    this.displayShutDownDialog = true;
  }
  onShutDownDialogClose() {
    this.displayShutDownDialog = false;

  }
  showForgotPasswordDialog() {
    this.displayForgotPasswordDialog = true;
  }
  onForgotPasswordDialogClose() {
    this.displayForgotPasswordDialog = false;

  }

}
