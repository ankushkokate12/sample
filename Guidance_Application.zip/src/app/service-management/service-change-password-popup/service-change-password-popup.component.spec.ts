import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceChangePasswordPopupComponent } from './service-change-password-popup.component';

describe('ServiceChangePasswordPopupComponent', () => {
  let component: ServiceChangePasswordPopupComponent;
  let fixture: ComponentFixture<ServiceChangePasswordPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceChangePasswordPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceChangePasswordPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
