import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-service-change-password-popup',
  templateUrl: './service-change-password-popup.component.html',
  styleUrls: ['./service-change-password-popup.component.css']
})
export class ServiceChangePasswordPopupComponent implements OnInit {
  @Input() display: boolean = false;
  @Input() changePassword: boolean;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  

  currentURL: any;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  onHide1() {
    this.display = false;
    this.onClose.emit(this.display); 
  }

  onHide() {
    this.display = false;
    this.onClose.emit(this.display);    
    this.router.navigate(["/user-header/service-home"]) 
    // if (this.router.url.('/header')) {
    //   this.router.navigate(["/header/home"])
    // }
    // else if (this.router.url.includes('/user-header/service-home')) {
    //   this.router.navigate(["/user-header/service-home'"])
    // }
    // else {
    //   this.router.navigate(["/header/user-home"])
    // }
    // if(this.changePassword){
    //   this.router.navigate(["/header/home"]) 
    // }
    // else{
    //   this.router.navigate(["/header/user-home"]) 
    // }

  }

}
