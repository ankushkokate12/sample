import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceChangePasswordComponent } from './service-change-password.component';

describe('ServiceChangePasswordComponent', () => {
  let component: ServiceChangePasswordComponent;
  let fixture: ComponentFixture<ServiceChangePasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceChangePasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceChangePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
