import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-common',
  templateUrl: './service-common.component.html',
  styleUrls: ['./service-common.component.css']
})
export class ServiceCommonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
