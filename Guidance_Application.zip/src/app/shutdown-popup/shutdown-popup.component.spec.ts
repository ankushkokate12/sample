import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShutdownPopupComponent } from './shutdown-popup.component';

describe('ShutdownPopupComponent', () => {
  let component: ShutdownPopupComponent;
  let fixture: ComponentFixture<ShutdownPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShutdownPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShutdownPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
