import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-shutdown-popup',
  templateUrl: './shutdown-popup.component.html',
  styleUrls: ['./shutdown-popup.component.css']
})
export class ShutdownPopupComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

  onHide() {
    this.display = false;
    this.onClose.emit(this.display);  
  }

  onShutDown(){   
    window.close();
  }

}
