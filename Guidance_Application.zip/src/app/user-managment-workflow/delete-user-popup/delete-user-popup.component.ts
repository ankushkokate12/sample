import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-delete-user-popup',
  templateUrl: './delete-user-popup.component.html',
  styleUrls: ['./delete-user-popup.component.css']
})
export class DeleteUserPopupComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<any> = new EventEmitter<any>();
  isConfirmation: boolean;

  constructor() { }

  ngOnInit() {
  }
  
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);  
  }

  onDelete(){
    this.display = false;
    this.isConfirmation = true;
    this.onClose.emit({
      isDisplay: this.display,
      isConfirm: this.isConfirmation
    });  
  }

}
