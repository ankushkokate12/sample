import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntegrityCheckCancelPopupComponent } from './integrity-check-cancel-popup.component';

describe('IntegrityCheckCancelPopupComponent', () => {
  let component: IntegrityCheckCancelPopupComponent;
  let fixture: ComponentFixture<IntegrityCheckCancelPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntegrityCheckCancelPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntegrityCheckCancelPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
