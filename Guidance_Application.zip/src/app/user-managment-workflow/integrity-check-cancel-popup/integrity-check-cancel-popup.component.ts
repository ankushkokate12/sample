import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-integrity-check-cancel-popup',
  templateUrl: './integrity-check-cancel-popup.component.html',
  styleUrls: ['./integrity-check-cancel-popup.component.css']
})
export class IntegrityCheckCancelPopupComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<any> = new EventEmitter<any>();
  isCancel: boolean;

  constructor() { }

  ngOnInit() {
  }
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);  
  }
  onCancel(){
    this.display = false;
    this.isCancel = true;
    this.onClose.emit({
      isDisplay: this.display,
      isCancel: this.isCancel
    });  
  }

}
