import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntegrityCheckInprogressComponent } from './integrity-check-inprogress.component';

describe('IntegrityCheckInprogressComponent', () => {
  let component: IntegrityCheckInprogressComponent;
  let fixture: ComponentFixture<IntegrityCheckInprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntegrityCheckInprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntegrityCheckInprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
