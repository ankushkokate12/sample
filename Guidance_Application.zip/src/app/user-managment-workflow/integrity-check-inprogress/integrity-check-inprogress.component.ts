import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-integrity-check-inprogress',
  templateUrl: './integrity-check-inprogress.component.html',
  styleUrls: ['./integrity-check-inprogress.component.css']
})
export class IntegrityCheckInprogressComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<any> = new EventEmitter<any>();
  @Output() onAutoClose: EventEmitter<any> = new EventEmitter<any>();

  IntegrityCheckCount: number = 0;
  integrityCheckProgress: any = 0;
  installationCount: number = 0;
  installationProgress: any = 0;
  autoClose: boolean;
  isCompleted: boolean = false;
  isInProgess: boolean = false;


  constructor(public router: Router) { }

  ngOnInit() {
    setInterval(() => {
      if (this.IntegrityCheckCount < 100) {
        this.IntegrityCheckCount = this.IntegrityCheckCount + 20;
      }
      else {
        this.IntegrityCheckCount = 100;
        if(this.IntegrityCheckCount == 100){
          this.isInProgess = true;
          if(this.isInProgess){
            setInterval(() => {
              if (this.installationCount < 100) {
                this.installationCount = this.installationCount + 20;
              }
              else {
                this.installationCount = 100;
                if(this.installationCount == 100){
                  this.isCompleted = true;
                }
                else{
                  this.isCompleted = false;
                }
                // this.display = false;
                // this.autoClose = true;
                // this.onAutoClose.emit({
                //     Close: this.display,
                //     AutoClose: this.autoClose
                //   }
                // );
              }
        
              this.installationProgress = this.installationCount + '%';
            }, 1000);
          }
        }
        else{
          this.isInProgess = false;
        }
        // this.display = false;
        // this.autoClose = true;
        // this.onAutoClose.emit({
        //     Close: this.display,
        //     AutoClose: this.autoClose
        //   }
        // );
      }

      this.integrityCheckProgress = this.IntegrityCheckCount + '%';
    }, 1000);
    
    


  }

  onRestart(){
    this.display = false;
    this.onClose.emit(this.display);
    this.router.navigate(["/user-header/user-home"]);
    window.close();
  }

  onHide1() {
    this.display = false;
    this.onClose.emit({
      Close: this.display
    });
  }
  onHide() {
    this.display = false;
    this.onClose.emit({
      Close: this.display,
      AutoClose:  this.isCompleted
    });
  }

}
