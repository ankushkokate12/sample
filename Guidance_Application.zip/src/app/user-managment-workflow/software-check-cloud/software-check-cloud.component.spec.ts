import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareCheckCloudComponent } from './software-check-cloud.component';

describe('SoftwareCheckCloudComponent', () => {
  let component: SoftwareCheckCloudComponent;
  let fixture: ComponentFixture<SoftwareCheckCloudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoftwareCheckCloudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoftwareCheckCloudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
