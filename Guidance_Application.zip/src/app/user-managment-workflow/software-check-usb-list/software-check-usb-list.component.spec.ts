import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareCheckUsbListComponent } from './software-check-usb-list.component';

describe('SoftwareCheckUsbListComponent', () => {
  let component: SoftwareCheckUsbListComponent;
  let fixture: ComponentFixture<SoftwareCheckUsbListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoftwareCheckUsbListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoftwareCheckUsbListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
