import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-software-check-usb-list',
  templateUrl: './software-check-usb-list.component.html',
  styleUrls: ['./software-check-usb-list.component.css']
})
export class SoftwareCheckUsbListComponent implements OnInit {
  cols: any[];
  files: any[];
  displayIntegrityInprogressDialog: boolean;
  displayIntegrityCancelsDialog: boolean;

  constructor() { }

  ngOnInit() {
    this.cols = [
      { field: 'name', header: '' },
      { field: 'size', header: 'New Version' },
      { field: 'type', header: 'Current Installed Version' }
    ];

    this.files = [

      {
        "data": {
          "name": "Software Package",
          "size": "SM07611",
          "type": "SM07610"
        },
        "children": [
          {
            "data": {
              "name": "Guidance Application",
              "size": "DE07113",
              "type": "DE07111"
            }
          },
          {
            "data": {
              "name": "Database",
              "size": "SM07611",
              "type": "SM07610"
            }
          }
        ]
      }

    ]

  }

  onShowIntegrityProgressDialog() {
    this.displayIntegrityInprogressDialog = true;
  }

  onIntegrityProgressDialogClose(data: any) {
    this.displayIntegrityInprogressDialog = false;
    console.log(data)
    if (data.AutoClose == false) {
      this.displayIntegrityCancelsDialog = true;
    }

  }

  // onIntegrityProgressDialogAutoClose(data: any){
  //   if(data.AutoClose ==true){
  //   this.displayIntegrityInprogressDialog = false;
  //   }
  // }

  onShowIntegrityCancelDialog() {
    this.displayIntegrityCancelsDialog = true;
  }

  onIntegrityCancelDialogClose(data: any) {
    this.displayIntegrityCancelsDialog = false;
    if(data.isCancel){
      this.displayIntegrityInprogressDialog = true;
    }
  }

}