import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareCheckUsbComponent } from './software-check-usb.component';

describe('SoftwareCheckUsbComponent', () => {
  let component: SoftwareCheckUsbComponent;
  let fixture: ComponentFixture<SoftwareCheckUsbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoftwareCheckUsbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoftwareCheckUsbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
