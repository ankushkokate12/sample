import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-software-check-usb',
  templateUrl: './software-check-usb.component.html',
  styleUrls: ['./software-check-usb.component.css']
})
export class SoftwareCheckUsbComponent implements OnInit {
  @Input() display: boolean = false;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private router: Router) { }

  ngOnInit() {
  }
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);  
  }
  onOpenUSBCheck(){
    this.display = false;
    this.onClose.emit(this.display);  
    this.router.navigate(["/user-header/user-management/check-on-usb"])
  }

}
