import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-change-password-popup',
  templateUrl: './user-change-password-popup.component.html',
  styleUrls: ['./user-change-password-popup.component.css']
})
export class UserChangePasswordPopupComponent implements OnInit {
  @Input() display: boolean = false;
  @Input() changePassword: boolean;
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

  currentURL: any;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  onHide1() {
    this.display = false;
    this.onClose.emit(this.display);    
  }
  onHide() {
    this.display = false;
    this.onClose.emit(this.display);    
    this.router.navigate(["/user-header/user-home"]) 
    
    // else {
    //   this.router.navigate(["/header/user-home"])
    // }
    // if(this.changePassword){
    //   this.router.navigate(["/header/home"]) 
    // }
    // else{
    //   this.router.navigate(["/header/user-home"]) 
    // }

  }

}
