import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-header',
  templateUrl: './user-header.component.html',
  styleUrls: ['./user-header.component.css']
})
export class UserHeaderComponent implements OnInit {
  @ViewChild('toggleButton', { static: false }) toggleButton: ElementRef;
  @ViewChild('menu', { static: false }) menu: ElementRef;
  navigateToHome: boolean;
  logggedUser: any;

  isUserOptionPanel: boolean;
  displayShutDownDialog: boolean;

  constructor(public router: Router,
    private renderer: Renderer2) {
    this.renderer.listen('window', 'click', (e: Event) => {
      if (e.target != this.toggleButton.nativeElement && e.target != this.menu.nativeElement) {
        this.isUserOptionPanel = false;
      }
    })
  }

  ngOnInit() {
    this.logggedUser = localStorage.getItem('loginUser');
  }

  onLogOff() {
    this.isUserOptionPanel = false;
    this.router.navigate(["/login"]);
  }

  userOptions(data: any) {
    if (this.isUserOptionPanel == true) {
      this.isUserOptionPanel = false;
    }
    else {
      this.isUserOptionPanel = true
    }
  }

  onChangePassword() {
    this.isUserOptionPanel = false;
    if (this.router.url == '/user-header/service-home') {
      this.router.navigate(["/user-header/service-change-password"]);
    } else {
      this.router.navigate(["/user-header/user-change-password"]);
    }

  }

  showShutDownDialog() {
    this.isUserOptionPanel = false;
    this.displayShutDownDialog = true;
  }
  onShutDownDialogClose() {
    this.displayShutDownDialog = false;

  }

}
