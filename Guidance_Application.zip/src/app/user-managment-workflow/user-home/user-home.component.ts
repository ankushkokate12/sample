import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  isAddNewUser: boolean = false;
  displayUSBCheckDialog: boolean;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  addNewUser(){
    // this.isAddNewUser = true;
    this.router.navigate(["/user-header/user-management/add-new-user"])
  }
  manageUsers(){
    this.router.navigate(["/user-header/user-management/manage-users"])
  }

  closeNewUser(){
    this.isAddNewUser = false;
  }

  onCloudCheck(){
    this.router.navigate(["/user-header/user-management/check-on-cloud"])
  }

  onShowUSBCheckDialog() {
    this.displayUSBCheckDialog = true;
  }

  onUSBCheckDialogClose(data: any) {
    this.displayUSBCheckDialog = false;   
  }

}
