import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from './user-dto';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  annulPlan: any = [];
  bonePrepFlag: boolean = false;
  caseDoneMark: boolean = false;
 
  private getPendingTaskCount = new BehaviorSubject(this.annulPlan);
  currentPendingTaskCount = this.getPendingTaskCount.asObservable();

  private getPostOp = new BehaviorSubject(this.bonePrepFlag);
  currentJointAssessment = this.getPostOp.asObservable();

  private getCaseCompletion = new BehaviorSubject(this.caseDoneMark);
  currentCaseCompletionStatus = this.getCaseCompletion.asObservable();

  constructor(private http: HttpClient) { }

  updatePendingTaskCount(taskCount: any) {
    this.getPendingTaskCount.next(taskCount);
  }

  updateCaseCompletionMark(completionFlag: any){
    this.getCaseCompletion.next(completionFlag);
  }

  updateJointAssessment(opFlag: any) {
    this.getPostOp.next(opFlag);
  }

//   getUsers() {
//     return this.http.get<any>('assets/userData.json')
//     .toPromise()
//     .then(res => <User[]>res.data)
//     .then(data => { return data; });

    
// }
getUsers(): Observable<any> {
  let baseUrl: string = 'assets/userData.json';
  return this.http.get(
      baseUrl,
  )
}
}
