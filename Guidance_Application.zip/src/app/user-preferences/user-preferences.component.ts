import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-preferences',
  templateUrl: './user-preferences.component.html',
  styleUrls: ['./user-preferences.component.css']
})
export class UserPreferencesComponent implements OnInit {

  slider1Value: any = 35;
  slider2Value: any = 35;
  slider3Value: any = 35;

  isImplantPlanning: boolean;
  isLigamentBalancing: boolean;

  autoAdvance: boolean = true;
  resectionDepth: boolean = true;
  accuracyNo: boolean = true;

  femur: boolean = true;
  tibia: boolean = false;

  axisAngle: boolean = true;
  romAxis: boolean = true;

  distalCheck: any = "distal";
  anteriorCheck: any = "anterior";
  anteriorChanferCheck: any = "anteriorChanfer";
  posteriorChamferCheck: any = "posteriorChamfer";
  posteriorCheck: any = "posterior";
  femoralPegHolesCheck: any = "femoralPegHoles";
  femurNotchCheck: any = "femurNotch";
  tibiaCheck: any = "tibia"
  keelCheck: any = "keel";;
  boneModal: any = "femur";
  procedureWorkflow: any = "implantPlanning";
  workflowCuts: any = "distalCut";
  resectionDepthRef: any = "boneResection";

  intraSoftTissue: boolean = false;

  boneCuttingSeq: any = [];


  constructor(private router: Router) { }

  ngOnInit() {
    this.boneCuttingSeq = [
      {
        value: "distal",
        label: "Distal"
      },
      {
        value: "anterior",
        label: "Anterior"
      },
      {
        value: "anteriorChanfer",
        label: "Anterior Chamfer"
      },
      {
        value: "posteriorChamfer",
        label: "Posterior Chamfer"
      },
      {
        value: "posterior",
        label: "Posterior"
      },
      {
        value: "femoralPegHoles",
        label: "Femoral Peg Holes"
      },
      {
        value: "femurNotch",
        label: "Femur Notch"
      },
      {
        value: "tibia",
        label: "Tibia"
      },
      {
        value: "keel",
        label: "Keel"
      }
    ];
  }
  onCancel() {
    this.router.navigate(["/header/home"])
  }
  isDistalError: boolean;
  isAnteriorError: boolean;
  isAnteriorChanferError: boolean;
  isPosteriorChamferError: boolean;
  isPosteriorError: boolean;
  isFemoralPegHolesError: boolean;
  isFemurNotchError: boolean;
  isTibiaError: boolean;
  isKeelError: boolean;

  onSave() {
    if((this.distalCheck == this.anteriorCheck) || (this.distalCheck == this.anteriorChanferCheck)  || (this.distalCheck == this.posteriorChamferCheck) || (this.distalCheck == this.posteriorCheck) || (this.distalCheck == this.femoralPegHolesCheck) || (this.distalCheck == this.femurNotchCheck) || (this.distalCheck == this.tibiaCheck) || (this.distalCheck == this.keelCheck)){
      this.isDistalError = true;
    }else{
      this.isDistalError = false;
    }

    if((this.distalCheck == this.anteriorCheck) || (this.anteriorCheck == this.anteriorChanferCheck)  || (this.anteriorCheck == this.posteriorChamferCheck) || (this.anteriorCheck == this.posteriorCheck) || (this.anteriorCheck == this.femoralPegHolesCheck) || (this.anteriorCheck == this.femurNotchCheck) || (this.anteriorCheck == this.tibiaCheck) || (this.anteriorCheck == this.keelCheck)){
      this.isAnteriorError = true;
    }else{
      this.isAnteriorError = false;
    }

    if((this.anteriorChanferCheck == this.anteriorCheck) || (this.distalCheck == this.anteriorChanferCheck)  || (this.anteriorChanferCheck == this.posteriorChamferCheck) || (this.anteriorChanferCheck == this.posteriorCheck) || (this.anteriorChanferCheck == this.femoralPegHolesCheck) || (this.anteriorChanferCheck == this.femurNotchCheck) || (this.anteriorChanferCheck == this.tibiaCheck) || (this.anteriorChanferCheck == this.keelCheck)){
      this.isAnteriorChanferError = true;
    }else{
      this.isAnteriorChanferError = false;
    }

    if((this.posteriorChamferCheck == this.anteriorCheck) || (this.posteriorChamferCheck == this.anteriorChanferCheck)  || (this.distalCheck == this.posteriorChamferCheck) || (this.posteriorChamferCheck == this.posteriorCheck) || (this.posteriorChamferCheck == this.femoralPegHolesCheck) || (this.posteriorChamferCheck == this.femurNotchCheck) || (this.posteriorChamferCheck == this.tibiaCheck) || (this.posteriorChamferCheck == this.keelCheck)){
      this.isPosteriorChamferError = true;
    }else{
      this.isPosteriorChamferError = false;
    }

    if((this.posteriorCheck == this.anteriorCheck) || (this.posteriorCheck == this.anteriorChanferCheck)  || (this.posteriorCheck == this.posteriorChamferCheck) || (this.distalCheck == this.posteriorCheck) || (this.posteriorCheck == this.femoralPegHolesCheck) || (this.posteriorCheck == this.femurNotchCheck) || (this.posteriorCheck == this.tibiaCheck) || (this.posteriorCheck == this.keelCheck)){
      this.isPosteriorError = true;
    }else{
      this.isPosteriorError = false;
    }

    if((this.femoralPegHolesCheck == this.anteriorCheck) || (this.femoralPegHolesCheck == this.anteriorChanferCheck)  || (this.femoralPegHolesCheck == this.posteriorChamferCheck) || (this.femoralPegHolesCheck == this.posteriorCheck) || (this.distalCheck == this.femoralPegHolesCheck) || (this.femoralPegHolesCheck == this.femurNotchCheck) || (this.femoralPegHolesCheck == this.tibiaCheck) || (this.femoralPegHolesCheck == this.keelCheck)){
      this.isFemoralPegHolesError = true;
    }else{
      this.isFemoralPegHolesError = false;
    }

    if((this.femurNotchCheck == this.anteriorCheck) || (this.femurNotchCheck == this.anteriorChanferCheck)  || (this.femurNotchCheck == this.posteriorChamferCheck) || (this.femurNotchCheck == this.posteriorCheck) || (this.femurNotchCheck == this.femoralPegHolesCheck) || (this.distalCheck == this.femurNotchCheck) || (this.femurNotchCheck == this.tibiaCheck) || (this.femurNotchCheck == this.keelCheck)){
      this.isFemurNotchError = true;
    }else{
      this.isFemurNotchError = false;
    }

    if((this.tibiaCheck == this.anteriorCheck) || (this.tibiaCheck == this.anteriorChanferCheck)  || (this.tibiaCheck == this.posteriorChamferCheck) || (this.tibiaCheck == this.posteriorCheck) || (this.tibiaCheck == this.femoralPegHolesCheck) || (this.tibiaCheck == this.femurNotchCheck) || (this.distalCheck == this.tibiaCheck) || (this.tibiaCheck == this.keelCheck)){
      this.isTibiaError = true;
    }else{
      this.isTibiaError = false;
    }

    if((this.keelCheck == this.anteriorCheck) || (this.keelCheck == this.anteriorChanferCheck)  || (this.keelCheck == this.posteriorChamferCheck) || (this.keelCheck == this.posteriorCheck) || (this.keelCheck == this.femoralPegHolesCheck) || (this.keelCheck == this.femurNotchCheck) || (this.keelCheck == this.tibiaCheck) || (this.distalCheck == this.keelCheck)){
      this.isKeelError = true;
    }else{
      this.isKeelError = false;
    }
    

    if(!this.isDistalError && !this.isAnteriorError && 
      !this.isAnteriorChanferError && !this.isPosteriorChamferError && 
      !this.isPosteriorError && !this.isFemoralPegHolesError &&
      !this.isFemurNotchError && !this.isTibiaError && !this.isKeelError){
        this.router.navigate(["/header/home"])
      }   
  }

  onImplantPlanning() {
    this.isImplantPlanning = true;
    this.isLigamentBalancing = false
  }

  onLigamentBalancing() {
    this.isImplantPlanning = false
    this.isLigamentBalancing = true;
  }

  onReset() {
    this.slider1Value = 35;
    this.slider2Value = 35;
    this.slider3Value = 35;

    this.autoAdvance = true;
    this.resectionDepth = true;
    this.accuracyNo = true;

    this.femur = true;
    this.tibia = false;

    this.boneModal = "femur";
    this.procedureWorkflow = "implantPlanning";
    this.workflowCuts = "distalCut";
    this.resectionDepthRef = "boneResection";
    if (this.workflowCuts == "distalCut") {
      this.isLigamentBalancing = false;
    }

    this.axisAngle = true;
    this.romAxis = true;

    this.intraSoftTissue = false;
    this.distalCheck = "distal";
    this.anteriorCheck = "anterior";
    this.anteriorChanferCheck = "anteriorChanfer";
    this.posteriorChamferCheck = "posteriorChamfer";
    this.posteriorCheck = "posterior";
    this.femoralPegHolesCheck = "femoralPegHoles";
    this.femurNotchCheck = "femurNotch";
    this.tibiaCheck = "tibia"
    this.keelCheck = "keel";

    this.isDistalError = false;
    this.isAnteriorError = false;
    this.isAnteriorChanferError = false;
    this.isPosteriorChamferError = false;
    this.isPosteriorError = false;
    this.isFemoralPegHolesError = false;
    this.isFemurNotchError = false;
    this.isTibiaError = false;
    this.isKeelError = false;
  }
  onFemur() {
    this.femur = true;
    this.tibia = false;
  }
  onTibia() {
    this.femur = false;
    this.tibia = true;
  }
 
  onDistalChange(){
    if(this.distalCheck == this.anteriorCheck){
      this.isDistalError = true;
    }else{
      this.isDistalError = false;
    }
    console.log(this.isDistalError)
  }

}
