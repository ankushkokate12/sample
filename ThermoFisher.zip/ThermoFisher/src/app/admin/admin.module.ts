import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MetadataManagementComponent } from './metadata-management/metadata-management.component';
import { AdminRoutingModule } from '../admin/admin.routing.module';
import { EntityMetadataComponent } from './metadata-management/entity/entity.component';

@NgModule({
  declarations: [MetadataManagementComponent, EntityMetadataComponent],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
