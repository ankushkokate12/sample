import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MetadataManagementComponent } from '../admin/metadata-management/metadata-management.component';

const routes: Routes = [
  { path: '', component: MetadataManagementComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }