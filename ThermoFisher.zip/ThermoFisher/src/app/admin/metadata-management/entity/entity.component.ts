import { Component, OnInit, Input, ElementRef } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'entity-metadata-component',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.css']
})
export class EntityMetadataComponent implements OnInit {

  @Input()
  entityModel: any;
  isEditMode: boolean;
  isAddMore: boolean;
  copyEntityModel: any;
  riskStatusMessage: string;
  showStatusMsg:boolean=false;

  constructor(public _adminService: AdminService) { }

  ngOnInit() {
    this.copyEntityModel = JSON.parse(JSON.stringify(this.entityModel));
  }

  addMoreAttr(groupType) {
    this.isAddMore = true;
    for (var i = 0; i < this.entityModel.groupData.length; i++) {
      if (this.entityModel.groupData[i].groupType === groupType) {
        this.entityModel.groupData[i].data.push({
          "id": "", "value": "", "isReadOnly": false
        });

      }
    }
  }

  saveAttribute() {
    if (this.isEditMode) {
      let reqPayload: any = {
        "entityName": this.entityModel.entityType
      };
      let groupData: any[] = [];

      for (var i = 0; i < this.copyEntityModel.groupData.length; i++) {
        let groupType: any;
        let updatedAttr: any[] = [];
        let copyData = this.copyEntityModel.groupData[i];
        for (var j = 0; j < this.entityModel.groupData.length; j++) {

          let entityData = this.entityModel.groupData[j];
          if (this.copyEntityModel.groupData[i].groupType === this.entityModel.groupData[j].groupType) {

            for (var k = 0; k < copyData.data.length; k++) {
              for (var l = 0; l < entityData.data.length; l++) {

                if (copyData.data[k].id === entityData.data[l].id) {
                  if (copyData.data[k].value != entityData.data[l].value && entityData.data[l].value!="") {
                    updatedAttr.push({
                      "value": entityData.data[l].value,
                      "id": entityData.data[l].id
                    })
                  }
                }
              }
            }
            if (updatedAttr.length > 0) {
              groupData.push({ "groupType": this.entityModel.groupData[j].groupType, "data": updatedAttr })
            }
          }
        }
      }

      reqPayload['groupData'] = groupData;

      this._adminService.updateAttribute(reqPayload).subscribe(result => {
        //let response: any = result.metaData;
        this.showStatusMsg = true;
        this.riskStatusMessage = "Record updated successfully!";
       
        setTimeout(function () {
          this.showStatusMsg = false;
          this.riskStatusMessage = "";
        }.bind(this), 3000);
      });

    } else {
      let reqPayload: any = {
        "entityType": this.entityModel.entityType
      };
      let groupData: any[] = [];
      for (var i = 0; i < this.entityModel.groupData.length; i++) {
        let groupType: string;
        let newAttr: any[] = [];

        for (var j = 0; j < this.entityModel.groupData[i].data.length; j++) {
          if (this.entityModel.groupData[i].data[j].id === "" && this.entityModel.groupData[i].data[j].value != "") {
            newAttr.push({
              "value": this.entityModel.groupData[i].data[j].value
            });
            groupType = this.entityModel.groupData[i].groupType;
          }
        }

        if (newAttr.length > 0) {
          groupData.push({ "data": newAttr, "groupType": groupType });
        }
      }
      reqPayload['groupData'] = groupData;
      this._adminService.saveAttribute(reqPayload).subscribe(result => {
        if (result) {
          this.riskStatusMessage = "Record saved successfully!";
          this.showStatusMsg = true;
          setTimeout(function () {
            this.showStatusMsg = false;
            this.riskStatusMessage = "";
          }.bind(this), 3000);
          this.getUpdatedMetadata(this.entityModel.entityType);
        }
      });
    }
  }

  getUpdatedMetadata(entityType) {
    this._adminService.getMetadataByEntity(entityType).subscribe(result => {
      this.entityModel = result;
      this.copyEntityModel = JSON.parse(JSON.stringify(this.entityModel));
      this.isEditMode = false
      this.isAddMore = false;
    });
  }

  isReadOnly(flag) {
    if (this.isEditMode || this.isAddMore) {
      return false;
    } else {
      return true;
    }
  }

  editAttr(groupType) {
    this.isEditMode = true;
    for (var i = 0; i < this.entityModel.groupData.length; i++) {
      if (this.entityModel.groupData[i].groupType === groupType) {
        for (var j = 0; j < this.entityModel.groupData[i].data.length; j++) {
          this.entityModel.groupData[i].data[j].isReadOnly = false;
        }
      }
    }
  }

  getEntityLable(rawLable): string {
    let formatedLable: string;
    if (rawLable === "ramsRisk") {
      formatedLable = "RISK";
    } else if (rawLable === "ramsSolution") {
      formatedLable = "SOLUTION";
    } else if (rawLable === "ramsProject") {
      formatedLable = "PROJECT";
    } else if (rawLable === "ramsResource") {
      formatedLable = "RESOURCE";
    } else if (rawLable === "ramsRiskSolutionRelationship") {
      formatedLable = "ENTITY RELATIONSHIP";
    }
    return formatedLable;
  }

  getDropdownHeader(rawLable): string {
    let formatedLable: string;
    switch (rawLable) {
      case "potentialLossType": {
        formatedLable = "Potential Loss";
        break;
      }
      case "potentialLikelihood": {
        formatedLable = "Potential Likelihood";
        break;
      }
      case "riskLevel": {
        formatedLable = "Risk Level";
        break;
      }
      case "potentialImpact": {
        formatedLable = "Potential Impact";
        break;
      }
      case "levelOfEffort": {
        formatedLable = "Level Of Effort";
        break;
      }
      case "solutionType": {
        formatedLable = "Solution Type";
        break;
      }
      case "levelOfEffort": {
        formatedLable = "Level Of Effort";
        break;
      }
      case "resourceType": {
        formatedLable = "Resource Type";
        break;
      }
      case "treatmentType": {
        formatedLable = "Treatment Type";
        break;
      }
    }
    return formatedLable
  }
}
