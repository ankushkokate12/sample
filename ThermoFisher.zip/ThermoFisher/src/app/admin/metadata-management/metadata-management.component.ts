import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-metadata-management',
  templateUrl: './metadata-management.component.html',
  styleUrls: ['./metadata-management.component.css']
})
export class MetadataManagementComponent implements OnInit {

  entityMetadata: [];
  isItemRendered = false;

  constructor(public _adminService: AdminService) {
  }

  ngOnInit() {
    this._adminService.getMetadata().subscribe(result => {
      let response: any = result.metaData;
      this.entityMetadata = response;
    });

  }
  
  ngAfterViewInit() {
    if (!this._adminService.isdminRendered) {
      $(document.body).on('click', '.jquery_accordion_title', function () {
        $(this).closest('.jquery_accordion_item').siblings().find('.jquery_accordion_content').slideUp(400);
        $(this).closest('.jquery_accordion_item').toggleClass('active').find('.jquery_accordion_content').slideToggle(400);
      })
      this._adminService.isdminRendered =true;
    }
  }
}
