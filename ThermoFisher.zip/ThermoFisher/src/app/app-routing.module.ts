import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './guard/auth-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RiskManagementComponent } from './risk-management/risk-management.component';
import { ManageEntitiesComponent } from './manage-entities/manage-entities.component';
import { ListRiskComponent } from './risk-management/list-risk/list-risk.component';
import { AddRiskComponent } from './risk-management/add-risk/add-risk.component';
import { ListSolutionComponent } from './manage-entities/solution/list-solution/list-solution.component'
import { AddSolutionComponent } from './manage-entities/solution/add-solution/add-solution.component'
import { SolutionsComponent } from './manage-entities/solution/solutions.component';
import { FrameworkComponent } from './manage-entities/framework/framework.component';
import { ListFrameworkComponent } from './manage-entities/framework/list-framework/list-framework.component';
import { GroupsComponent } from './manage-entities/groups/groups.component';
import { ListGroupsComponent } from './manage-entities/groups/list-groups/list-groups.component';
import { ProjectComponent } from './manage-entities/project/project.component';
import { ListProjectComponent } from './manage-entities/project/list-project/list-project.component';
import { AddProjectComponent } from './manage-entities/project/add-project/add-project.component';
import { ResourcesComponent } from './manage-entities/resources/resources.component';
import { ListResourcesComponent } from './manage-entities/resources/list-resources/list-resources.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'app', component: HomeComponent, canActivate: [AuthGuard],
    children: [
      { path: 'admin', loadChildren: './admin/admin.module#AdminModule' },
      { path: 'dashboard', component: DashboardComponent },
      {
        path: 'risk', component: RiskManagementComponent,
        children: [
          {
            path: 'add', component: AddRiskComponent
          },
          {
            path: 'edit', component: AddRiskComponent
          },
          {
            path: 'list', component: ListRiskComponent
          },
          {
            path: '', redirectTo: '/app/risk/list', pathMatch: 'full'
          }
        ]
      },
      {
        path: 'manage-entities', component: ManageEntitiesComponent,
        children: [
          {
            path: 'solution', component: SolutionsComponent,
            children: [
              {
                path: 'add', component: AddSolutionComponent
              },

              {
                path: 'edit', component: AddSolutionComponent
              },
              {
                path: 'list', component: ListSolutionComponent
              },  
              {
                path: '', redirectTo: '/app/manage-entities/solution/list', pathMatch: 'full'
              }           
            ],
          },
          {
            path: 'framework', component: FrameworkComponent,
            children: [
              {
                path: 'add', component: ListFrameworkComponent
              },

              {
                path: 'edit', component: ListFrameworkComponent
              },
              {
                path: 'list', component: ListFrameworkComponent
              },
              {
                path: '', redirectTo: '/app/manage-entities/framework/list', pathMatch: 'full'
              }     
            ],
          },
          {
            path: 'resources', component: ResourcesComponent,
            children: [
              {
                path: 'add', component: ListResourcesComponent
              },

              {
                path: 'edit', component: ListResourcesComponent
              },
              {
                path: 'list', component: ListResourcesComponent
              },
              {
                path: '', redirectTo: '/app/manage-entities/resources/list', pathMatch: 'full'
              }     
            ],
          },
          {
            path: 'project', component: ProjectComponent,
            children: [
              {
                path: 'add', component: AddProjectComponent
              },

              {
                path: 'edit', component: AddProjectComponent
              },
              {
                path: 'list', component: ListProjectComponent
              },
              {
                path: '', redirectTo: '/app/manage-entities/project/list', pathMatch: 'full'
              }     
            ],
          },
          {
            path: 'groups', component: GroupsComponent,
            children: [
              {
                path: 'add', component: ListGroupsComponent
              },

              {
                path: 'edit', component: ListGroupsComponent
              },
              {
                path: 'list', component: ListGroupsComponent
              },
              {
                path: '', redirectTo: '/app/manage-entities/groups/list', pathMatch: 'full'
              }     
            ],
          },
          {
            path: '', redirectTo: '/app/manage-entities/solution/list', pathMatch: 'full'
          }           
        ],
        
      }
    ],
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
