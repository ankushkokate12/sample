import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { CognitoUtil } from './services/cognito.service';
import { FormsModule } from '@angular/forms';
import { HttpConfigInterceptor} from './interceptor/httpconfig.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthGuard } from './guard/auth-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageEntitiesComponent } from './manage-entities/manage-entities.component';
import { RiskManagementComponent } from './risk-management/risk-management.component';
import { AddRiskComponent } from './risk-management/add-risk/add-risk.component';
import { ListRiskComponent } from './risk-management/list-risk/list-risk.component';
import { TreeChecklist } from './risk-management/add-risk/checkbox-Tree/tree-checklist';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatIconModule} from '@angular/material/icon';
import {MatTreeModule} from '@angular/material/tree';
import { TreeviewModule } from 'ngx-treeview';
import { DataTablesModule } from 'angular-datatables';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NiceSelectModule } from "ng-nice-select";
import { SolutionSearchComponent } from './risk-management/add-risk/solution-search/solution-search.component';
import { MatSliderModule } from '@angular/material/slider';
import { SolutionComponent } from './risk-management/add-risk/solution-search/solution/solution.component';
import {ListSolutionComponent} from './manage-entities/solution/list-solution/list-solution.component'
import {AddSolutionComponent} from './manage-entities/solution/add-solution/add-solution.component';
import { ListFrameworkComponent } from './manage-entities/framework/list-framework/list-framework.component'
import { FrameworkComponent } from './manage-entities/framework/framework.component';
import { SolutionsComponent } from './manage-entities/solution/solutions.component';
import { AddFrameworkComponent } from './manage-entities/framework/list-framework/add-framework/add-framework.component';
import { GroupsComponent } from './manage-entities/groups/groups.component';
import { ListGroupsComponent } from './manage-entities/groups/list-groups/list-groups.component';
import { AddGroupsComponent } from './manage-entities/groups/list-groups/add-groups/add-groups.component';
import { ListProjectComponent } from './manage-entities/project/list-project/list-project.component';
import { AddProjectComponent } from './manage-entities/project/add-project/add-project.component';
import { AddResourcesComponent } from './manage-entities/resources/list-resources/add-resources/add-resources.component';
import { ListResourcesComponent } from './manage-entities/resources/list-resources/list-resources.component';
import { ResourcesComponent } from './manage-entities/resources/resources.component';
import { ProcessBarComponent } from './shared/process-bar/process-bar.component';
import { GaugeChartComponent } from './shared/gauge-chart/gauge-chart.component';
import { ProjectComponent } from './manage-entities/project/project.component';
import { ProjectRendererComponent } from './manage-entities/solution/add-solution/project-search/project/project.renderer.component'
import { ProjectSearchComponent } from './manage-entities/solution/add-solution/project-search/project-search.component';
import { BubbleGraphComponent } from './dashboard/graph/bubble-graph/bubble-graph.component';
import { ForceDirectedGraphComponent } from './dashboard/graph/force-directed-graph/force-directed-graph.component';
import { RiskDetailsPanelComponent } from './dashboard/panels/risk-details-panel/risk-details-panel.component';
import { SolutionDetailsPanelComponent } from './dashboard/panels/solution-details-panel/solution-details-panel.component';
import { ProjectDetailsComponent } from './dashboard/panels/solution-details-panel/project-details/project-details.component';
import { ResourceSearchComponent } from './manage-entities/project/add-project/resource-search/resource-search.component';
import { ResourceRendererComponent } from './manage-entities/project/add-project/resource-search/resource-renderer/resource-renderer.component';
import { SortByPipe } from "./pipes/sortByPipe";

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    DashboardComponent,
    ManageEntitiesComponent,
    RiskManagementComponent,
    AddRiskComponent,
    ListRiskComponent,
    TreeChecklist,
    SolutionSearchComponent,
    SolutionComponent,
    ListSolutionComponent,
    AddSolutionComponent,
    ListFrameworkComponent,
    SolutionsComponent,
    FrameworkComponent,
    AddFrameworkComponent,
    GroupsComponent,
    ListGroupsComponent,
    AddGroupsComponent,
    ProjectComponent,
    ListProjectComponent,
    AddResourcesComponent,
    ListResourcesComponent,
    ResourcesComponent,
    ProcessBarComponent,
    GaugeChartComponent,
    ProjectSearchComponent,
    ProjectRendererComponent,
    BubbleGraphComponent,
    ForceDirectedGraphComponent,
    RiskDetailsPanelComponent,
    SolutionDetailsPanelComponent,
    ProjectDetailsComponent,
    AddProjectComponent,
    ResourceSearchComponent,
    ResourceRendererComponent,
    SortByPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatTreeModule,
    TreeviewModule.forRoot(),
    DataTablesModule,
    MatSliderModule,
    NgbModule,
    NiceSelectModule
  ],
  providers: [ CognitoUtil,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }