import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';
import { RamsUtil } from '../utils/rams-util';
import { solutionVsRisk } from '../mock-model/solution-risk-relation';
import { drillDownFGraphData1 } from '.././mock-model/risk-solution-drilldown1';
import { drillDownFGraphData } from '.././mock-model/risk-solution-drilldown';
import { RiskService } from '../services/risk.service';
import { SolutionService } from '../services/solution.service';
import { RiskObject } from '../dto/risk-object';
import { SolutionObject } from '../dto/solution-object';
import { slideInAnimation } from '../shared/animations';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dashboard',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  animations: [slideInAnimation]
})
export class DashboardComponent implements OnInit {

  dimentionArray: any[] = [
    {
      name: "Risk Vs. Solutions"
    },
    {
      name: "Solutions Vs. Risk"
    }
  ];
  densityArray: any[] = [
    {
      name: "Low (25%)",
      value: 25
    },
    {
      name: "Medium (50%)",
      value: 50
    },
    {
      name: "High (100%)",
      value: 100
    }
  ];
  @ViewChild('content') contentRef: ElementRef;

  selectedDimention: any;
  bubbleGraphData: any[] = [];
  riskDetailsObj: RiskObject = new RiskObject();
  solutionDetailsObj: SolutionObject = new SolutionObject();
  isRiskSelected: boolean = false;
  isSolutionSelected: boolean = false;
  isNodeSelected: boolean = false;
  isApiInProgress: boolean;
  isAdminUser: boolean;
  moreItemsInSelectedLegends: boolean;
  legendsArray: any = [];
  desnityModel: any;
  drillDownGraphData: any;
  emptyNodes: any;
  deepCopyBubbleGraphData: any[];
  deepCopyFilteredBubbleGraphData: any[];
  selectedNodeRefId: string;

  constructor(public _dashboardService: DashboardService,
    public _riskService: RiskService,
    public _solutionService: SolutionService,
    public modalService: NgbModal,
  ) {
    this.selectedDimention = this.dimentionArray[0];
    this.desnityModel = this.densityArray[2];
    this.legendsArray = RamsUtil.getLegends();
  }

  ngOnInit() {
    this.getRiskVsSolutionData();
    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
  }

  ngAfterViewInit() {
    $(document.body).on('click', '.legend', function () {
      $(".selected-icon").addClass("showhide-icon");
      $(this).closest(".legend").siblings().removeClass("showhide-icon");
    })
  }

  getRiskVsSolutionData(): void {
    this.isApiInProgress = true;
    //reset density model to default;
    this.desnityModel = this.densityArray[2];
    this._dashboardService.getRiskVsSolutionGraphData().subscribe(result => {
      let response: any = result;
      this.bubbleGraphData = RamsUtil.getFormatedRiskVsSolutionData(response.nodes);
      //kee deep copy for legend selection
      this.deepCopyBubbleGraphData = [...this.bubbleGraphData];
      //kee deep copy for density selection
      this.deepCopyFilteredBubbleGraphData = [...this.bubbleGraphData];
      if (this.deepCopyFilteredBubbleGraphData.length >= 10) {
        this.moreItemsInSelectedLegends = true;
      } else {
        this.moreItemsInSelectedLegends = false;
      }
      this.updateLegends('riskLevel');
      this.isApiInProgress = false;
    });
  }
  getSolutionVsRiskData(): void {
    this.isApiInProgress = true;
    //reset density model to default;
    this.desnityModel = this.densityArray[2];
    this._dashboardService.getSolutionVsRiskGraphData().subscribe(result => {
      let response: any = result;
      this.bubbleGraphData = RamsUtil.getFormatedSolutionVsRiskData(response.nodes);
      //kee deep copy for legend selection
      this.deepCopyBubbleGraphData = [...this.bubbleGraphData];
      //kee deep copy for density selection
      this.deepCopyFilteredBubbleGraphData = [...this.bubbleGraphData];
      if (this.deepCopyFilteredBubbleGraphData.length >= 10) {
        this.moreItemsInSelectedLegends = true;
      } else {
        this.moreItemsInSelectedLegends = false;
      }
      this.updateLegends('levelOfEffort');
      this.isApiInProgress = false;
    });
  }

  updateLegends(level) {
    this.legendsArray = RamsUtil.getLegends();
    for (var i = 0; i < this.legendsArray.length; i++) {
      let noOfItems: number = 0;
      for (var j = 0; j < this.deepCopyBubbleGraphData.length; j++) {
        if (level === "riskLevel") {
          if (this.legendsArray[i].value === this.deepCopyBubbleGraphData[j].riskLevel) {
            noOfItems++;
          }
        } else {
          if (this.legendsArray[i].value === this.deepCopyBubbleGraphData[j].levelOfEffort) {
            noOfItems++;
          }
        }
      }
      let tempStr: string;
      if (this.legendsArray[i].value === "All") {
        tempStr = this.legendsArray[i].label;
        this.legendsArray[i].label = tempStr.concat('-' + this.deepCopyBubbleGraphData.length);
        this.legendsArray[i].noOfLinkedItems = this.deepCopyBubbleGraphData.length;
      } else {
        tempStr = this.legendsArray[i].label;
        this.legendsArray[i].label = tempStr.concat('-' + noOfItems)
        this.legendsArray[i].noOfLinkedItems = noOfItems;
      }
    }
  }
  dimentionSelectionChange(): void {
    this.isRiskSelected = false;
    this.isSolutionSelected = false;
    this.closeDrillDownGraphHandler();

    if (this.selectedDimention.name === "Risk Vs. Solutions") {
      this.getRiskVsSolutionData();
      this.isApiInProgress = true;
    } else {
      this.getSolutionVsRiskData();
      this.isApiInProgress = true;
    }
  }

  densityChangeHandler(event) {
    if (this.deepCopyFilteredBubbleGraphData.length >= 10) {
      this.moreItemsInSelectedLegends = true;
    } else {
      this.moreItemsInSelectedLegends = false;
    }
    let noOfItemsToShow: number = Math.round((this.deepCopyFilteredBubbleGraphData.length / 100) * this.desnityModel.value);
    let tempBubbleArray = [];
    for (var i = 0; i < noOfItemsToShow; i++) {
      tempBubbleArray.push(this.deepCopyFilteredBubbleGraphData[i]);
    }
    this.bubbleGraphData = tempBubbleArray;
  }

  drillDownNodeSelectionEventHandler(nodeData) {
    if (nodeData.type === "Risk") {
      this.isRiskSelected = true;
      this.isSolutionSelected = false;

      this._riskService.getRiskDetails(nodeData.id, true).subscribe(result => {
        let resPayload: any = result.riskDetails;
        this.riskDetailsObj = RamsUtil.getRiskDetailObject(resPayload, false);
      });
    } else if (nodeData.type === "Solution") {
      this.isRiskSelected = false;
      this.isSolutionSelected = true;
      this._solutionService.getSolutionDetails(nodeData.id, false).subscribe(result => {
        let resPayload: any = result;
        this.solutionDetailsObj = RamsUtil.getFormatedSolutionDetailsObj(resPayload.solution);
      });
    }
  }

  nodeSelectionEventHandler(nodeData): void {
    this.isNodeSelected = true
    this.isApiInProgress = true;
    this.selectedNodeRefId = nodeData.vertexId;
    this._dashboardService.getRiskSolutionDrillDownData(nodeData.vertexId).subscribe(result => {
      let resPayload: any = result;
      this.drillDownGraphData = resPayload;
      this.isApiInProgress = false;

      //show selected node details panel
      if (nodeData.type === "Risk") {
        this.isRiskSelected = true;
        this.isSolutionSelected = false;

        this._riskService.getRiskDetails(nodeData.id, true).subscribe(result => {
          let resPayload: any = result.riskDetails;
          this.riskDetailsObj = RamsUtil.getRiskDetailObject(resPayload, false);
        });
      } else if (nodeData.type === "Solution") {
        this.isRiskSelected = false;
        this.isSolutionSelected = true;
        this._solutionService.getSolutionDetails(nodeData.id, false).subscribe(result => {
          let resPayload: any = result;
          this.solutionDetailsObj = RamsUtil.getFormatedSolutionDetailsObj(resPayload.solution);
        });
      }
    })
  }

  legendClicked(data, type) {
    //reset density to 100%

    if (data.noOfLinkedItems === 0) {
      this.modalService.open(this.contentRef);
      this.emptyNodes = "No data to display.";
      return;
    } else {
      this.desnityModel = this.densityArray[2];
    }
    this.isRiskSelected = false;
    this.isSolutionSelected = false;
    this.isNodeSelected = false;
    if (data.value === "All") {
      this.bubbleGraphData = this.deepCopyBubbleGraphData;
      this.deepCopyFilteredBubbleGraphData = this.deepCopyBubbleGraphData;
      if (this.deepCopyFilteredBubbleGraphData.length >= 10) {
        this.moreItemsInSelectedLegends = true;
      } else {
        this.moreItemsInSelectedLegends = false;
      }
      return;
    }
    if (type === "risk") {
      this.bubbleGraphData = this.deepCopyBubbleGraphData.filter(item => item.riskLevel === data.value);
    } else {
      this.bubbleGraphData = this.deepCopyBubbleGraphData.filter(item => item.levelOfEffort === data.value);
    }
    //kee deep copy for density selection post legend fiter is applied
    this.deepCopyFilteredBubbleGraphData = [...this.bubbleGraphData];
    if (this.deepCopyFilteredBubbleGraphData.length >= 10) {
      this.moreItemsInSelectedLegends = true;
    } else {
      this.moreItemsInSelectedLegends = false;
    }
  }

  closeDrillDownGraphHandler() {
    this.isNodeSelected = false
  }

  hideDetailsPanel() {
    this.isRiskSelected = false;
    this.isSolutionSelected = false;
  }

  closeModalPopup() {
    this.modalService.dismissAll(this.contentRef);
  }
}
