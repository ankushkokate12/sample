import { Component, OnInit, ViewChild, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import { riskVsSolution } from '../../../mock-model/risk-solution-relation';
import * as d3 from 'd3';
import { selection, select } from "d3-selection";
import "d3-selection-multi";
import { RamsUtil } from 'src/app/utils/rams-util';

@Component({
    selector: 'app-bubble-graph',
    templateUrl: './bubble-graph.component.html',
    styleUrls: ['./bubble-graph.component.css']
})
export class BubbleGraphComponent implements OnInit {

    @Input()
    graphData: any[] = [];// = riskVsSolution.nodes;
    @Output()
    nodeSelectionEvent = new EventEmitter<any>();

    width = 960;
    height = 650;
    padding = 20; // separation between same-color nodes
    clusterPadding = 6; //separation between different-color nodes
    maxRadius = 100;
    minRadius = 25;
    colors: any;
    svg: any;
    nodes: any[] = [];
    clusters: any[];
    size: number;

    constructor() {
        this.colors = RamsUtil.getColors();
    }

    ngOnInit() {
    }

    ngOnChanges(simpleChanges: SimpleChange) {
        let tempSimpleObj: any = simpleChanges;

        if (!tempSimpleObj.graphData.firstChange) {
            this.drawGraph();
        }
    }

    removeExistingGraph() {
        this.svg = null;
        this.nodes = [];
        this.clusters = [];
        d3.select("#graphContainer").selectAll("svg").remove();
    }

    drawGraph() {
        if (this.svg) {
            this.removeExistingGraph();
        }
        if (this.graphData.length === 0) {
            return;
        }
        this.svg = d3.select('#graphContainer').append("svg")
            .attr("width", "100%")
            .attr("height", this.height)
            .call(d3.behavior.zoom().on("zoom", function () {
                this.svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")")
            }.bind(this)))
            .append("g");

        let maxLinkedValue: number = d3.max(this.graphData, function (d) {
            return d.type === "Risk"? d.noOfSolutionsLinked: d.noOfRisksLinked;
        })
        //define bubble size
        this.size = d3.scale.linear()
            .domain([0, maxLinkedValue])  // What's in the data
            .range([20, 50])  // Size in pixel

        //draw backround grid    
        this.drawBgGrid();

        // Define the div for the tooltip
        let div = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0)

        this.clusters = new Array(1);
        for (var i = 0; i < this.graphData.length; i++) {
            this.nodes.push(this.create_nodes(this.graphData, i));
        }

        var force = d3.layout.force()
            .nodes(this.nodes)
            .size([this.width + 300, this.height])
            .gravity(.08)
            .charge(null)
            .on("tick", function (e) {
                node.each(this.cluster(e.alpha * e.alpha)) //this.cluster(10 * e.alpha * e.alpha)
                    .each(this.collide(.5))
                    .attr("transform", function (d) {
                        var k = "translate(" + d.x + "," + d.y + ")";
                        return k;
                    })
            }.bind(this))
            .start();

        var node = this.svg.selectAll("circle")
            .data(this.nodes)
            .enter().append("g").call(force.drag);

        node.append("circle")
            .style("fill", function (d) {
                if (d.type==="Risk") {
                    return this.colors[d.riskLevel === "" ? d.riskLevel = "Undefined" : d.riskLevel];
                } else {
                    return this.colors[d.levelOfEffort === "" ? d.levelOfEffort = "Undefined" : d.levelOfEffort];
                }
            }.bind(this))
            .attr("r", function (d) { return d.radius })
        node.on("click", function (d) {
            this.nodeSelectionEvent.emit(d);
        }.bind(this))
        node.on("mouseover", function (d) {
            d3.select(this).transition()
                .ease('cubic-out')
                .duration('200')
                .style("stroke-width", "1px")
                .style("cursor", "pointer")
                .style('color', 'white');
            //tooltip div element
            div.transition()
                .duration(200)
                .style("opacity", 1)
                .style("color", "#555759")
                .style("padding", "18px")
                .style("background-color", "#fff")
                .style("background-size", "cover")
                .style("border", "1px solid rgb(220, 220, 220)")
                .style("box-shadow", "rgba(0, 0, 0, 0.1) 0px 2px 4px 0px")
                .style("border-radius", "0")
                .style("text-align", "left")
                .style("font-family", "G-Roboto-n4, Arial")
                .style("font-size", "11px")
                .style("width", "200px")
                .style("height", "auto")
            if (d.type === "Risk") {
                div.html(d.type + ' Number: <b>' + d.riskNumber + '</b><br/><br/>' + d.type + ' Name:<br/> <b>' + d.name + '</b>' + '<br/><br/>No. of Solutions Linked: <br><b style="font-size:20px;">' + d.linkedItems + '</b></br/><br/>Estimated Cost Involved: <br/><b style="font-size:20px;">' + d.budgetInvolved + '</b><br><br/><b>Click</b> to know more details...')
                    .style("left", (d3.event.pageX) + "px")
                    .style("top", (d3.event.pageY) + "px");
            }
            else {
                div.html(d.type + ' ID: <b>' + d.id + '</b><br/><br/>' + d.type + ' Name:<br/> <b>' + d.name + '</b><br/><br/>No. of Risks Attached: <br><b style="font-size:20px;">' + d.noOfRisksLinked + '</b><br/><br/>No. of Projects Linked: <br><b style="font-size:20px;">' + d.linkedProjects + '</b><br/><br/>No. of Resources Linked: <br><b style="font-size:20px;">' + d.noOfResourcesLinked +'</b></br/><br/>Estimated Cost Involved: <br/><b style="font-size:20px;">' + d.budgetInvolved + '</b><br><br/><b>Click</b> to know more details...')
                    .style("left", (d3.event.pageX) + "px")
                    .style("top", (d3.event.pageY - 28) + "px");
            }
        })
            .on("mousemove", function () {
            })
            .on("mouseout", function (d) {
                d3.select(this).transition()
                    .ease('cubic-out')
                    .duration('200')
                    .style("stroke-width", "0px");
                div.transition()
                    .duration(500)
                    .style("opacity", 0)
            });

        node.append("text")
            .attr("dy", ".3em")
            .style("text-anchor", "middle")
            .style("cursor", "pointer")
            .style('fill', 'white')
            .style("font-size", "9px")
            .style("font-family", "Arial")
            .style("font-weight", "400")
            .style("cursor", "pointer")
            .text(function (d) {
                if (d.type == "Risk") {
                    return d.riskNumber.substring(0, d.radius / 3);
                } else {
                    return d.id;//.substring(0, d.radius / 3);
                }
            });
    }

    drawBgGrid() {
        var row = this.svg.selectAll(".row")
            .data(this.gridData())
            .enter().append("g")
        var column = row.selectAll(".square")
            .data(function (d) { return d; })
            .enter().append("rect")
            .attr("x", function (d) { return d.x; })
            .attr("y", function (d) { return d.y; })
            .attr("width", function (d) { return d.width; })
            .attr("height", function (d) { return d.height; })
            .style("fill", "#fff")
    }

    gridData = function () {
        var data = new Array();
        var xpos = 1; //starting xpos and ypos at 1 so the stroke will show when we make the grid below
        var ypos = 1;
        var width = 10;
        var height = 10;

        // iterate for rows	
        for (var row = 0; row < 100; row++) {
            data.push(new Array());
            // iterate for cells/columns inside rows
            for (var column = 0; column < 150; column++) {
                data[row].push({
                    x: xpos,
                    y: ypos,
                    width: width,
                    height: height
                })
                // increment the x position. I.e. move it over by 50 (width variable)
                xpos += width;
            }
            // reset the x position after a row is complete
            xpos = 1;
            // increment the y position for the next row. Move it down 50 (height variable)
            ypos += height;
        }
        return data;
    }

    create_nodes(data, node_counter) {
        var i = 0;
        var r = Math.sqrt((i + 1) / this.graphData.length * -Math.log(Math.random())) * this.maxRadius;
        var nodeDataObj: any = function () {
            if (data[node_counter].type === "Risk") {
                return {
                    cluster: i,
                    name: data[node_counter].name,
                    riskNumber: data[node_counter].riskNumber,
                    riskLevel: data[node_counter].riskLevel,
                    linkedItems: data[node_counter].noOfSolutionsLinked,
                    type: data[node_counter].type,
                    radius: this.size(data[node_counter].noOfSolutionsLinked),
                    id: data[node_counter].id,
                    budgetInvolved: data[node_counter].budgetInvolved,
                    vertexId: data[node_counter].vertexId,
                    x: Math.cos(i / this.graphData.length * 2 * Math.PI) * 200 + this.width + Math.random(),
                    y: Math.sin(i / this.graphData.length * 2 * Math.PI) * 200 + this.height / 2 + Math.random()
                }
            } else {
                return {
                    cluster: i,
                    name: data[node_counter].name,
                    type: data[node_counter].type,
                    linkedProjects: data[node_counter].noOfProjectsLinked,
                    noOfRisksLinked: data[node_counter].noOfRisksLinked,
                    radius: this.size(data[node_counter].noOfRisksLinked),
                    id: data[node_counter].id,
                    budgetInvolved: data[node_counter].budgetRequired,
                    levelOfEffort: data[node_counter].levelOfEffort,
                    vertexId: data[node_counter].vertexId,
                    noOfResourcesLinked: data[node_counter].noOfResourcesLinked,
                    x: Math.cos(i / this.graphData.length * 2 * Math.PI) * 200 + this.width + Math.random(),
                    y: Math.sin(i / this.graphData.length * 2 * Math.PI) * 200 + this.height / 2 + Math.random()
                }
            }
        }.bind(this);
        var d = nodeDataObj();
        if (!this.clusters[i] || (r > this.clusters[i].radius)) this.clusters[i] = d;
        return d;
    };

    // Move d to be adjacent to the cluster node.
    cluster(alpha) {
        return function (d) {
            if (!d) {
                return;
            }
            var cluster = this.clusters[d.cluster];
            if (cluster === d) return;
            var x = d.x - cluster.x,
                y = d.y - cluster.y,
                l = Math.sqrt(x * x + y * y),
                r = d.radius + cluster.radius;
            if (l != r) {
                l = (l - r) / l * alpha;
                d.x -= x *= l;
                d.y -= y *= l;
                cluster.x += x;
                cluster.y += y;
            }
        }.bind(this);
    }

    // Resolves collisions between d and all other circles.
    collide(alpha) {
        var quadtree = d3.geom.quadtree(this.nodes);
        return function (d) {
            var r = d.radius + this.maxRadius + Math.max(this.padding, this.clusterPadding),
                nx1 = d.x - r,
                nx2 = d.x + r,
                ny1 = d.y - r,
                ny2 = d.y + r;
            quadtree.visit(function (quad, x1, y1, x2, y2) {
                if (quad.point && (quad.point !== d)) {
                    var x = d.x - quad.point.x,
                        y = d.y - quad.point.y,
                        l = Math.sqrt(x * x + y * y),
                        r = d.radius + quad.point.radius + (d.cluster === quad.point.cluster ? this.padding : this.clusterPadding);
                    if (l < r) {
                        l = (l - r) / l * alpha;
                        d.x -= x *= l;
                        d.y -= y *= l;
                        quad.point.x += x;
                        quad.point.y += y;
                    }
                }
                return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
            }.bind(this));
        }.bind(this);
    }
}