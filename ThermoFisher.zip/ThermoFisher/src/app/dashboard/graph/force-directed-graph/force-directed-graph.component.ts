import { Component, OnInit, ViewChild, ElementRef, Input, EventEmitter, Output, SimpleChange } from '@angular/core';
import { selection, select } from "d3-selection";
import "d3-selection-multi";
import * as d3 from 'd3';
import { RamsUtil } from 'src/app/utils/rams-util';

@Component({
  selector: 'app-force-directed-graph',
  templateUrl: './force-directed-graph.component.html',
  styleUrls: ['./force-directed-graph.component.css']
})
export class ForceDirectedGraphComponent implements OnInit {

  @Input()
  graphData: any = {};
  //graphData: any[] = [];// = riskVsSolution.nodes;
  @Input()
  startingNodeIdRef:string;
  @Output()
  nodeSelectionEvent = new EventEmitter<any>();
  @Output()
  hideDetailsPanelEvent = new EventEmitter<any>();
  @Output()
  closeGraphEvent = new EventEmitter<boolean>();

  width = 960;
  height = 650;
  colors: any;
  svg: any;

  constructor() {
    this.colors = RamsUtil.getColors();
  }

  ngOnChanges(simpleChanges: SimpleChange) {
    let tempSimpleObj: any = simpleChanges;

    if (!tempSimpleObj.graphData.firstChange) {
      this.drawGraph(this.graphData);
    }
  }

  ngOnInit() {

  }

  drawGraph(graph) {
    // if (this.graphData.length === 0) {
    //   return;
    // }
    let _this = this;

    let maxLinkedItems: number = d3.max(graph.nodes, function (d) {
      return d.type === "Risk"? d.noOfSolutionsLinked: d.noOfRisksLinked;;
    })


    //define force
    let force = d3.layout.force()
      //.charge(-1000)
      .charge(function(d, i) { return -2000; })
      .linkDistance(100)
      .gravity(.09)
      .distance(100)
      .size([_this.width + 300, _this.height]);

      //define bubble size
      var size = d3.scale.linear()
      .domain([0, maxLinkedItems])  // What's in the data
      //.range([ 15, 40])  // Size in pixel
      .range([20, 50]) 

    _this.svg = d3.select("#drillDowngraphContainer").append("svg")
      .attr("width", _this.width + _this.width)
      .attr("height", _this.height)
      // .call(d3.behavior.zoom().on("zoom", function () {
      //   _this.svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")")
      // }))
      // .append("g");

    let edges = [];
    graph.links.forEach(function (e) {
      let sourceNode = graph.nodes.filter(function (n) { return n.vertexId === e.source; })[0],
        targetNode = graph.nodes.filter(function (n) { return n.vertexId === e.target; })[0];
      edges.push({ source: sourceNode, target: targetNode, value: e.Value });
    });

    force.nodes(graph.nodes)
      .links(edges)
      .start();
    //draw bg grid
    this.drawBgGrid();

    let link = _this.svg.selectAll(".link")
      .data(edges)
      .enter().append("line")
      .attr("class", "link")
      .style("stroke-width", function (d) {
        return 1;//"Math.sqrt(d.value)";
      });

    let div = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("opacity", 0)

    let node = _this.svg.selectAll('.gnode')
      .data(graph.nodes)
      .enter().append("g")
      .classed('gnode', true);

    node.append("circle")
      .attr("class", "node")
      .attr("r", function (d) {
        if (d.type === "Risk") {         
          return d.radius = size(d.noOfSolutionsLinked);
        } else {
          return d.radius = size(d.noOfRisksLinked);
        }
      })
      .attr('stroke', function (d) {
        var color; 
        if(d.vertexId === _this.startingNodeIdRef){
          if (d.type === "Solution") {
            color= "#EE3134";
          } else {
            color= '#EE3134';//_this.colors[d.riskLevel === "" ? d.riskLevel = "Undefined" : d.riskLevel];
          }
        }
       return color;
      })
      .attr('stroke-width', function (d) { 
        if(d.vertexId === _this.startingNodeIdRef){
          return 2;
        }else{
          return 0;
        }
      })
      .style("fill", function (d) {
        if (d.type === "Solution") {
          return "#404040";//"#5e5e5e";
        } else {
          
          return _this.colors[d.riskLevel === "" ? d.riskLevel = "Undefined" : d.riskLevel];
        }
      });
      node.on("click", function (d) {
        _this.nodeSelectionEvent.emit(d);
      });
      node.on("mouseover", function (d) {
        let colors: any = {
          "Critical": "#025a25",
          "High": "#006d2c",
          "Medium": "#238b45",
          "Low": "#41ab5d",
          "Very Low": "#74c476",
          "Undefined": "#5c5959"
        }
        d3.select(this).transition()
          .ease('cubic-out')
          .duration('200')
          .style("stroke-width", "1px")
          .style("cursor", "pointer")
          .style('color', 'white');
        //tooltip div element
        div.transition()
          .duration(200)
          .style("opacity", 1)
          .style("color", "#555759")
          .style("padding", "18px")
          .style("background-color", "#fff")
          .style("background-size", "cover")
          .style("border", "1px solid rgb(220, 220, 220)")
          .style("box-shadow", "rgba(0, 0, 0, 0.1) 0px 2px 4px 0px")
          .style("border-radius", "0")
          .style("text-align", "left")
          .style("font-family", "G-Roboto-n4, Arial")
          .style("font-size", "11px")
          .style("width", "200px")
          .style("height", "auto")
        if (d.type == "Risk") {
          div.html(d.type + ' Number: <b>' + d.riskNumber + '</b><br/><br/>' + d.type + ' Name:<br/> <b>' + d.name + '</b>' + '<br/><br/>No. of Solutions Linked: <br><b style="font-size:20px;">' + d.noOfSolutionsLinked + '</b></br/><br/>Estimated Cost Involved: <br/><b style="font-size:20px;">$ ' + d.budgetInvolved + '</b><br><br/><b>Click</b> to know more details...')
            .style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY) + "px");
        }
        else {
          div.html(d.type + ' ID: <b>' + d.id + '</b><br/><br/>' + d.type + ' Name:<br/> <b>' + d.name + '</b><br/><br/>No. of Risks Attached: <br><b style="font-size:20px;">' + d.noOfRisksLinked + '</b><br/><br/>No. of Projects Linked: <br><b style="font-size:20px;">' + d.noOfProjectsLinked + '</b><br/><br/>No. of Resources Linked: <br><b style="font-size:20px;">' + d.noOfResourcesLinked + '</b></br/><br/>Estimated Cost Involved: <br/><b style="font-size:20px;">$ ' + d.budgetRequired + '</b><br><br/><b>Click</b> to know more details...')
            .style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY - 28) + "px");
        }
      });

      node.on("mouseout", function (d) {
        d3.select(this).transition()
          .ease('cubic-out')
          .duration('200')
          .style("stroke-width", "0px");
        div.transition()
          .duration(500)
          .style("opacity", 0)
      })
      .call(force.drag);

    node.append("text")
      .attr("dy", ".3em")
      .style("text-anchor", "middle")
      .style("cursor", "pointer")
      .style('fill', 'white')
      .attr("font-size", function(d){
        return 10;
      })
      .style("font-family", "Arial")
      .style("font-weight", "400")
      .style("cursor", "pointer")
      .text(function (d) {
        if (d.type == "Risk") {
          return d.riskNumber.substring(0, d.radius / 4);
        } else {
          return d.name.substring(0, d.radius / 4);
        }
      });

    force.on("tick", function () {
      link.attr("x1", function (d) {
        return d.source.x;
      })
        .attr("y1", function (d) {
          return d.source.y;
        })
        .attr("x2", function (d) {
          return d.target.x;
        })
        .attr("y2", function (d) {
          return d.target.y;
        });
      node.attr("transform", function (d) {
        return 'translate(' + [d.x, d.y] + ')';
      });
    });
  }; //End of function(graph)

  drawBgGrid() {
    let row = this.svg.selectAll(".row")
      .data(this.gridData())
      .enter().append("g")
    let column = row.selectAll(".square")
      .data(function (d) { return d; })
      .enter().append("rect")
      .on('click', function () {
        this.hideDetailsPanelEvent.emit()
      }.bind(this))
      .attr("x", function (d) { return d.x; })
      .attr("y", function (d) { return d.y; })
      .attr("width", function (d) { return d.width; })
      .attr("height", function (d) { return d.height; })
      .style("fill", "#fff")
  }
  gridData = function () {
    let data = new Array();
    let xpos = 1; //starting xpos and ypos at 1 so the stroke will show when we make the grid below
    let ypos = 1;
    let width = 10;
    let height = 10;

    // iterate for rows	
    for (let row = 0; row < 100; row++) {
      data.push(new Array());
      // iterate for cells/columns inside rows
      for (let column = 0; column < 150; column++) {
        data[row].push({
          x: xpos,
          y: ypos,
          width: width,
          height: height
        })
        // increment the x position. I.e. move it over by 50 (width variable)
        xpos += width;
      }
      // reset the x position after a row is complete
      xpos = 1;
      // increment the y position for the next row. Move it down 50 (height variable)
      ypos += height;
    }
    return data;
  }

  closeGraph() {
    this.closeGraphEvent.emit(true);
    this.hideDetailsPanelEvent.emit()
  }

  ngOnDestroy() {
    d3.select("#drillDowngraphContainer").selectAll("svg").remove();
  }
}