import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskDetailsPanelComponent } from './risk-details-panel.component';

describe('RiskDetailsPanelComponent', () => {
  let component: RiskDetailsPanelComponent;
  let fixture: ComponentFixture<RiskDetailsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskDetailsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskDetailsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
