import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { RiskObject } from 'src/app/dto/risk-object';
import { Router } from '@angular/router';


@Component({
  selector: 'app-risk-details-panel',
  templateUrl: './risk-details-panel.component.html',
  styleUrls: ['./risk-details-panel.component.css'],
 
})
export class RiskDetailsPanelComponent implements OnInit {

  @Input()
  riskDetailsObj:RiskObject = new RiskObject();
  @Output()
  closePanelEvent = new EventEmitter<boolean>();
  @Input()
  isAdminUser:boolean;

  gaugeChartConfig : {};
  frameworks:string;
  impactedBDivisions:string;

  constructor(public _router: Router) { }

  ngOnInit() {
    this.gaugeChartConfig = {
      size: 110,
      clipWidth: 110,
      clipHeight: 70,
      ringWidth: 10,
      maxValue: 10,
      transitionMs: 2000
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    //if (changes.riskDetailsObj.firstChange) {
      let data:any= changes.riskDetailsObj.currentValue;
        //framework parsing
        let framworkArr: string[] = [];
        for (var i = 0; i < data.frameworks.length; i++) {
          framworkArr.push(data.frameworks[i].name);
        }
        this.frameworks = framworkArr.join(",")
  
        //division parsing
        let divisionArr: string[] = [];
        for (var i = 0; i < data.divisions.length; i++) {
          divisionArr.push(data.divisions[i].name);
        }
        this.impactedBDivisions = divisionArr.join(",")
      //}
  }

  closeGraphPanel() {
    this.closePanelEvent.emit(true);
  }

  solutionClickedHandler(solObj){
    if(this.isAdminUser){
      this._router.navigate(['app', 'manage-entities', 'solution', 'edit'], { queryParams: { action: "edit", id: solObj.id } });
    }
  }
}
