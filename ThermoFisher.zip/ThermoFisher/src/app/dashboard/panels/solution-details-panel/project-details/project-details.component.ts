import { Component, OnInit, Input } from '@angular/core';
import { ProjectObject } from 'src/app/dto/project-object';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {
  @Input()
  projectObj:ProjectObject = new ProjectObject();

  shortDesc: boolean;
  detailButtonText: string;
  detailButton: boolean;
  
  constructor() { }

  ngOnInit() {
    if(this.projectObj.description.length === undefined){
      return
    }
    else
    {
      this.manageShowHideDetails();
    }
  }

  manageShowHideDetails() {
    
        if (this.projectObj.description.length == 0 || this.projectObj.description.length < 60) {
          this.detailButton = false;
        }
        else {
          this.detailButton = true;
        }

        if (this.projectObj.description != "" || this.projectObj.description.length != 0) {
          if (this.projectObj.description.length > 60) {
            this.shortDesc = true;
            this.detailButtonText = "Show more..."
          }
          else {
            this.shortDesc = false;
            this.detailButtonText = "Show less..."
          }
        
    }
  }

  viewDetails() {
    if (this.shortDesc == true) {
      this.shortDesc = false;
      this.detailButtonText = "Show less..."
    }
    else {
      this.shortDesc = true
      this.detailButtonText = "Show more..."
    }
  }

}
