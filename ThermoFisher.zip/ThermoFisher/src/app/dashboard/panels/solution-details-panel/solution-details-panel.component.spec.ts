import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolutionDetailsPanelComponent } from './solution-details-panel.component';

describe('SolutionDetailsPanelComponent', () => {
  let component: SolutionDetailsPanelComponent;
  let fixture: ComponentFixture<SolutionDetailsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolutionDetailsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolutionDetailsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
