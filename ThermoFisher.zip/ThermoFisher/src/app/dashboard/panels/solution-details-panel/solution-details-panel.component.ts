import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SolutionObject } from "src/app/dto/solution-object";
import { Router } from '@angular/router';

@Component({
  selector: 'app-solution-details-panel',
  templateUrl: './solution-details-panel.component.html',
  styleUrls: ['./solution-details-panel.component.css']
})
export class SolutionDetailsPanelComponent implements OnInit {

  @Input()
  solutionDetailsObj: SolutionObject = new SolutionObject();
  @Output()
  closePanelEvent = new EventEmitter<boolean>();
  @Input()
  isAdminUser:boolean;

  constructor( public _router: Router) { }

  ngOnInit() {   
  }  

  closeGraphPanel() {
    this.closePanelEvent.emit(true);
  }
  riskClickedHandler(riskObj){
    if(this.isAdminUser)
    this._router.navigate(['app', 'risk',  'edit'], { queryParams: { action: "edit", id: riskObj.id } });
  } 

}
