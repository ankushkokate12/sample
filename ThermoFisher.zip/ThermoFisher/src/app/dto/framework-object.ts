export class FrameworkObject {
    id: number;
    name: string;
    description: "";
    parentId: number;
    parentName: string;
    dateModified:number;
}