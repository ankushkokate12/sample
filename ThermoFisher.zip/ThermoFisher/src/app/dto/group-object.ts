export class GroupObject {
    id: number;
    name: string;
    description: string;
    parentId: number;
    parentName: string;
    dateModified:number;
}