export class ProjectObject {
    id: number;
    name: string;
    description: string="";
    projectId: string;
    budgetAvailable: any=0;
    levelOfEffort:string;
    isSelected:boolean=false;
    relatedResouces:any[]=[];
    relatedSolutions:any[]=[];
    dateModified:number;
}