export class ResourceObject {
    id: number;
    name: string;
    description: string="";
    parentName: string="";
    parentId: number=null;
    resourceType:string;
    isSelected:boolean;
    dateModified:number;
}