import { RiskObject } from './risk-object';

describe('RiskObject', () => {
  it('should create an instance', () => {
    expect(new RiskObject()).toBeTruthy();
  });
});
