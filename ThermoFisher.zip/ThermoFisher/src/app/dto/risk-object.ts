export class RiskObject {
        id: number;
        riskNumber: string="";
        name: string="";
        description: string="";
        potentialLossType: string="";
        potentialLikelihood: string="";
        potentialImpact: string="";
        riskLevel: string="";
        relatedRiskId:number;
        relatedRiskObj:{
                "id": 0,
                "active": true,
                "riskNumber": "",
                "name": "",
                "potentialLossType": "",
                "riskLevel": ""
            };
        approxEstimateCost:any;
        
        isEditMode: boolean;
        solutions: any[] = [];
        frameworks: any[] = [];
        divisions: any[] = [];

        constructor() {

        }
}
