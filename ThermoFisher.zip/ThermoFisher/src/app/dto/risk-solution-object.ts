export class RiskSolutionObject {
    id: number;
    name: string;
    riskNumber: string;
    riskLevel: string;
    noOfSolutionsLinked:number=0;
    budgetInvolved:any=0;
    type: string;
    vertexId:string;
}


