export class SolutionObject {
    id: number;
    name: string;
    description: string;
    levelOfEffort: string="";
    budgetRequired: any=0;
    isSelected:boolean;
    riskTreatmentType:string="";
    percentageChange:number;
    relatedProjects:any[]=[];
    relatedRisks:any[]=[];
    totalRequiredBudget:number=0;
    dateModified:number;
    relatedResources:any[]=[];
}
