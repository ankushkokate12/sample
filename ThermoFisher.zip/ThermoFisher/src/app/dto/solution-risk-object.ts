export class SolutionRiskObject {
    id: number;
    name: string;
    levelOfEffort: string;
    noOfProjectsLinked:number=0;
    budgetRequired:any=0;
    type: string;
    noOfRisksLinked:number=0;
    noOfResourcesLinked:number=0;
    vertexId:string;
}