import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UserService} from '../services/user.service';
import { Router } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(public _userService:UserService,  public _myRoute: Router) { 

  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    let isLoggedIn =  Boolean(sessionStorage.getItem('isLoggedIn'));
    if(isLoggedIn){
      return true;
    }else{
      this._myRoute.navigate(["login"]);
      return false;
    }
  }
}