import { Component, OnInit } from '@angular/core';
import { UserService } from "../services/user.service";
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  username: string;
  showHideNewEntityPanel: boolean;
  isAdminUser: boolean;
  isDisableEntityButton: boolean;

  constructor(public _userService: UserService, public _router: Router) {
    this.showHideNewEntityPanel = false;
  }

  ngOnInit() {

    if (Boolean(sessionStorage.getItem('isLoggedIn'))) {
      if (sessionStorage.getItem('userRole') === "Admin") {
       
        this.isAdminUser = true;
      } else {
        this.isAdminUser = false;
      }
      this._router.navigate(['app', 'risk', 'list']);
      this.username = sessionStorage.getItem('username');
    } else {
      this._router.navigate(['login']);
    }
  }

  doLogout() {
    //Make cognito call for logout
    this._userService.logout();
    //Clear session storage object;
    sessionStorage.clear();
    //Take user to login screen
    this._router.navigate(['login'], { queryParams: { status: "logged-off" } });
  }

  showHideAddEntityWindow() {
    if (this.showHideNewEntityPanel === true) {
      this.showHideNewEntityPanel = false;
    }
    else {
      this.showHideNewEntityPanel = true;
    }
  }
}