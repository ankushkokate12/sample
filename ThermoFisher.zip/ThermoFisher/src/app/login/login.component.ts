import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService, UserInfo } from "../services/user.service";
import { ChallengeParameters, CognitoCallback, LoggedInCallback } from "../services/cognito.service";
import { AuthenticationDetails, CognitoUser, CognitoUserSession } from "amazon-cognito-identity-js";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements CognitoCallback, LoggedInCallback, OnInit {

  router: Router;
  errorMessage: string = "Invalid username or password.";
  logOutMessage: string = "Invalid username or password.";
  isLoginError: boolean = false;
  isLoggedOut: boolean = false;
  showLogoutMsg: boolean = false;
  username: string;
  password: string;

  constructor(public _router: Router, public _userService: UserService,
    public _activateRoute: ActivatedRoute) {
    this.router = _router;
  }

  ngOnInit() {
    this._activateRoute.queryParams.subscribe(params => {
      if (params.status === "logged-off") {
        this.logOutMessage = "You have successfully logged out!";
        this.showLogoutMsg = true;
        setTimeout(function () {
          this.logOutMessage = "";
          this.showLogoutMsg = false;
        }.bind(this), 3000)
        this.isLoggedOut = true;
      }
    });
  }

  doLogin() {
    if (this.username === undefined || this.username === "" || this.password === undefined || this.password === "") {
      this.errorMessage = "All fields are required";
      this.isLoginError = true;
      return;
    }
    this.errorMessage = null;
    this._userService.doLogin(this.username, this.password, this);
  }

  onLoginError = (callback: CognitoCallback, err) => {
    callback.cognitoCallback(err.message, null);
  }

  cognitoCallback(message: string, result: any) {
    if (message != null) { //error
      this.errorMessage = message;
      this.isLoginError = true;
      sessionStorage.setItem('isLoggedIn', 'false');
      this.isLoggedOut = false;
    } else { //success
      //Set user info object in user service
      let userInfo: UserInfo = new UserInfo();
      userInfo.accessToken = result.accessToken.jwtToken;
      userInfo.username = result.accessToken.payload.username;
      userInfo.isLoggedIn = true;
      userInfo.userRole = result.accessToken.payload["cognito:groups"][0];
      this._userService.setUserInfo(userInfo);

      sessionStorage.setItem('accessToken', result.accessToken.jwtToken);
      sessionStorage.setItem('username', result.accessToken.payload.username);
      sessionStorage.setItem('isLoggedIn', 'true');
      sessionStorage.setItem('userRole', userInfo.userRole);

      this.isLoginError = false;
      this.router.navigate(['app']);
    }
  }

  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {
    // this.mfaStep = true;
    // this.mfaData.destination = challengeParameters.CODE_DELIVERY_DESTINATION;
    // this.mfaData.callback = (code: string) => {
    //   if (code == null || code.length === 0) {
    //     this.errorMessage = "Code is required";
    //     return;
    //   }
    //   this.errorMessage = null;
    //   callback(code);
    // };
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
    // if (isLoggedIn) {
    //   this.router.navigate(['/securehome']);
    // }
  }
}
