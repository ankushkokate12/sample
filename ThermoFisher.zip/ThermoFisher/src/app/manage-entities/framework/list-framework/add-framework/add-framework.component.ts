import { Component, OnInit, Output, EventEmitter, Input, ViewChild, SimpleChange } from '@angular/core';
import { FrameworkComponent } from '../../framework.component';
import { FrameworkObject } from 'src/app/dto/framework-object';
import { FrameworkService } from 'src/app/services/framework.service';

@Component({
  selector: 'app-add-framework',
  templateUrl: './add-framework.component.html',
  styleUrls: ['./add-framework.component.css']
})
export class AddFrameworkComponent implements OnInit {

  @Input()
  frameworksArr: FrameworkObject[] = [];
  @Output()
  frameworkEvent = new EventEmitter<boolean>();
  @Output()
  frameworkCancel = new EventEmitter();
  @Input()
  frameworkData: FrameworkObject = new FrameworkObject();
  @Input()
  isEditState: boolean;

  showProgressBar:boolean=false;
  isApiInProgress:boolean=false;
  operationProcessMsg:string;

  selectedParentFramework: FrameworkObject;
  copiedFrameworkArray: FrameworkObject[] = [];
  showHideAddFramework: boolean = false;


  constructor(public _frameworkService: FrameworkService) { }

  ngOnInit() {
    if (!this.isEditState) {
      this.frameworkData = new FrameworkObject();
    }
  }

  ngOnChanges(simpleChanges: SimpleChange) {
    let tempSimpleObj: any = simpleChanges;

    if (tempSimpleObj.frameworksArr.firstChange) {

      let tempFrameworkArr: FrameworkObject[] = [...tempSimpleObj.frameworksArr.currentValue];

      let blankFramework = new FrameworkObject();
      blankFramework.id= null;
      blankFramework.name= "Select a Value";
      blankFramework.description= "";
      blankFramework.parentId= null;
      blankFramework.parentName= "";
      
      tempFrameworkArr.splice(0, 0, blankFramework);
      tempFrameworkArr.join();
      this.copiedFrameworkArray = tempFrameworkArr;
      if (this.isEditState && tempSimpleObj.frameworkData.currentValue.parentId != null) {
        this.selectedParentFramework = this.copiedFrameworkArray.find(function (fr: FrameworkObject) {
          if (fr.id === tempSimpleObj.frameworkData.currentValue.parentId) {
            return true;
          }
        });
      } else {
        this.selectedParentFramework = this.copiedFrameworkArray[0];
      }
    }
  }

  ngDoCheck(){
    //this.selectedParentFramework = this.copiedFrameworkArray[0];
  }

  parentFrameworkSelectionChange(value: FrameworkObject) {

  }
  
  onAddUpdateFrameworkSubmit() {

    this.showProgressBar = true;
    this.isApiInProgress = true;

    if(this.isEditState){
      this.operationProcessMsg = "Framework update is in-progress"
    }else{
      this.operationProcessMsg = "Framework save is in-progress"
    }

    if(this.selectedParentFramework.id!=null){
      this.frameworkData.parentId = this.selectedParentFramework.id;
      this.frameworkData.parentName = this.selectedParentFramework.name;
    }else{
      this.frameworkData.parentId = null;
      this.frameworkData.parentName = "";
    }
    //make api call to post/put framework
    this._frameworkService.createUpdateFramework(this.frameworkData, this.isEditState).subscribe(result=>{
      this.frameworkEvent.emit(true);
      if(this.isEditState){
        this.operationProcessMsg = "Framework update is complete";
      }else{
        this.operationProcessMsg = "Framework save is complete";
      }
      this.isApiInProgress = false;
      setTimeout(()=>{
        this.cancelClickedHandler();
   }, 2000);
    })
  }

  cancelClickedHandler() {
    this.frameworkCancel.emit();
  }

}