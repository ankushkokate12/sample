import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListFrameworkComponent } from './list-framework.component';

describe('ListFrameworkComponent', () => {
  let component: ListFrameworkComponent;
  let fixture: ComponentFixture<ListFrameworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListFrameworkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListFrameworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
