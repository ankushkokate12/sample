import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FrameworkObject } from 'src/app/dto/framework-object';
import { FrameworkService } from 'src/app/services/framework.service';
import { RamsUtil } from 'src/app/utils/rams-util';
import { NgbModal, NgbModalOptions  } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';
import 'datatables.net'
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-list-framework',
  templateUrl: './list-framework.component.html',
  styleUrls: ['./list-framework.component.css']
})
export class ListFrameworkComponent implements OnInit {

  @ViewChild('content') contentRef: ElementRef;
  
  frameworkArray: FrameworkObject[] = [];
  modalOption: NgbModalOptions = {};
  tableWidget: any;
  dtOptions: any;
  editFrameworkObj: FrameworkObject;
  closeResult: string;
  //Flag declations
  isAdminUser: boolean = false;
  isEditState: boolean;
  showAddFramework: boolean;
  showHideButton: boolean;
  isApiInProgress:boolean;

  constructor(public _frameworkService: FrameworkService,public modalService: NgbModal,
    public _activateRoute: ActivatedRoute) {
    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
  }

  ngOnInit() {    
    this.getAllFrameworks();
    this.modalConfiguration()
    this.isApiInProgress = true;
  }
  
  drawFrameworkGrid() {
    let exampleId: any = $('#framework-grid');
    this.tableWidget = exampleId.DataTable({
      data: this.frameworkArray,
      select: true,
      columns: [
        { title: "FRAMEWORK NAME", data: "name", 'className': 'framework_th1' },
        { title: "PARENT FRAMEWORK", data: "parentName",'className': 'framework_th2' },
        { title: "DESCRIPTION", data: "description",'className': 'framework_th3' },
        {
          title: "", 'className': 'framework_th4 sorting1', visible:this.isAdminUser, render: function (data, type, row) {
            return '<td [hidden]="!isAdminUser"><abbr title="Edit Framework"><a (click)="open(content)" class="linkstyle"><svg version="1.2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" overflow="visible" preserveAspectRatio="none" viewBox="0 0 596 596" width="14" height="14"><g><g xmlns:default="http://www.w3.org/2000/svg">	<polygon points="547.7,571.5 23.8,571.5 23.8,47.6 333.3,47.6 357.1,23.8 0,23.8 0,595.4 571.5,595.4 571.5,238.1 547.7,261.9  " style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/>	<path d="M119,476.3h95.2l381-381L500,0L119,381V476.3z M561.9,95.3l-57.1,57.1l-61.9-61.9L500,33.4L561.9,95.3z M142.8,390.5   l283.4-280.9l61.9,61.9L204.7,452.5h-61.9V390.5z" style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/></g></g></svg></a></abbr></td>'
          }
        },
        { title: "Date", data: "dateModified", visible: false }
      ],
      "paging": true,
      "ordering": true,
      "info": true,
      "lengthChange": false,
      "searching": true,
      "pageLength": 10,
      "bDestroy": true,
      "bJQueryUI": true,
      "bAutoWidth": false,
      "aaSorting": [[4, 'desc']],
      "columnDefs": [
        { orderable: false, targets: -1 }
      ],
      "oLanguage": {
        "sInfoFiltered": "(filtered from _MAX_ total records)",
        "sSearchPlaceholder": "Search Framework/s",
        "sSearch": '',
        "oPaginate": {
          "sNext": '<span>&raquo;</span>',
          "sPrevious": '<span>&laquo;</span>'
        },
        "aaSorting": [[5, 'desc']],
      }
    });

    let rowRef = $('#framework-grid tbody');
    rowRef.on('click', 'a', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onEditFrameworkClick(data);
      e.stopPropagation();
    });

    var table = exampleId.DataTable();
    $('#search-box').on('keyup change', function () {
      table.search($(this).val()).draw();
    });
  }

  redrawDt() {
    this.tableWidget.clear();
    this.tableWidget.rows.add(this.frameworkArray);
    this.tableWidget.draw();
  }

  showMoreButton() {
    if (this.showHideButton == true) {
      this.showHideButton = false
    }
    else {
      this.showHideButton = true
    }
  }

  getAllFrameworks() {
    this._frameworkService.getAllFrameworks().subscribe(response => {
      let responsePayload: any = response;
      this.frameworkArray = RamsUtil.getFormatedFrameworkList(responsePayload.frameworks);
      this.isApiInProgress = false;
      if (this.tableWidget) {
        this.redrawDt();
      } else {
        this.drawFrameworkGrid();
        this._activateRoute.queryParams.subscribe(params => {
          if (params.action === "add_framework"){
            this.showAddFrameworkWindow();
          }
        });
      }
    })
  }

  modalConfiguration(){
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
  }

  onEditFrameworkClick(value: FrameworkObject) {
    this.showAddFramework = true;
    this.isEditState = true;
    this.editFrameworkObj = value;  
   this.modalService.open(this.contentRef, this.modalOption);
  }

  frameworkCreateHandler(value: boolean) {
    if (value) {
      this.getAllFrameworks();
    }
  }

  closeAddFrameworkWindow() {
    this.showAddFramework = false;
    this.isEditState = false;
    this.modalService.dismissAll(this.contentRef);
  }

  showAddFrameworkWindow() {
    this.isEditState = false;    
    this.modalService.open(this.contentRef, this.modalOption);
  }
}
