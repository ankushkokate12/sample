import { Component, OnInit, Output, EventEmitter, Input, ViewChild, SimpleChange } from '@angular/core';
import { GroupsComponent } from '../../groups.component';
import { GroupObject } from 'src/app/dto/group-object';
import { GroupService } from 'src/app/services/group.service';;

@Component({
  selector: 'app-add-groups',
  templateUrl: './add-groups.component.html',
  styleUrls: ['./add-groups.component.css']
})
export class AddGroupsComponent implements OnInit {
  @Input()
  groupsArr: GroupObject[] = [];
  @Output()
  groupEvent = new EventEmitter<boolean>();
  @Output()
  groupCancel = new EventEmitter();
  @Input()
  groupData: GroupObject = new GroupObject();
  @Input()
  isEditState: boolean;

  selectedParentGroup: GroupObject = new GroupObject();
  copiedGroupArray: GroupObject[] = [];
  showHideAddGroup: boolean = false;
  showProgressBar: boolean = false;
  isApiInProgress: boolean = false;
  operationProcessMsg: string;

  constructor(public _groupService: GroupService) { }

  ngOnInit() {
    if (!this.isEditState) {
      this.groupData = new GroupObject();
    }
  }

  ngOnChanges(simpleChanges: SimpleChange) {
    let tempSimpleObj: any = simpleChanges;

    if (tempSimpleObj.groupsArr.firstChange) {

      let tempGroupArr: GroupObject[] = [...tempSimpleObj.groupsArr.currentValue];

      tempGroupArr.splice(0, 0, {
        id: null,
        name: "Select a Value",
        description: "",
        parentId: null,
        parentName: "",
        dateModified:null
      });
      tempGroupArr.join();
      this.copiedGroupArray = tempGroupArr;
      if (this.isEditState && tempSimpleObj.groupData.currentValue.parentId != null) {
        this.selectedParentGroup = this.copiedGroupArray.find(function (fr: GroupObject) {
          if (fr.id === tempSimpleObj.groupData.currentValue.parentId) {
            return true;
          }
        });
      } else {
        this.selectedParentGroup = this.copiedGroupArray[0];
      }
    }
  }

  parentGroupSelectionChange(value: GroupObject) {

  }

  addUpdateGroupSubmit() {

    this.showProgressBar = true;
    this.isApiInProgress = true;

    if (this.isEditState) {
      this.operationProcessMsg = "Group update is in-progress"
    } else {
      this.operationProcessMsg = "Group save is in-progress"
    }

    if (this.selectedParentGroup.id != null) {
      this.groupData.parentId = this.selectedParentGroup.id;
      this.groupData.parentName = this.selectedParentGroup.name;
    } else {
      this.groupData.parentId = null;
      this.groupData.parentName = "";
    }

    this._groupService.createUpdateGroup(this.groupData, this.isEditState).subscribe(result => {
      this.groupEvent.emit(true);

      if (this.isEditState) {
        this.operationProcessMsg = "Group update is complete";
      } else {
        this.operationProcessMsg = "Group save is complete";
      }

      this.isApiInProgress = false;
      setTimeout(() => {
        this.cancelClickedHandler();
      }, 2000);

    })
  }

  cancelClickedHandler() {
    this.groupCancel.emit();
  }
}