import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';
import { RamsUtil } from 'src/app/utils/rams-util';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProjectObject } from 'src/app/dto/project-object';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  @ViewChild('content') contentRef: ElementRef;

  projectDto: ProjectObject;
  selectedLevelOfEffort: string;
  selectedSolutionId: string;
  selectedProjects: any[] = [];
  levelOfEffortsMetadata: any[] = [];
  treatmentTypeMetadata: [];
  isEditState: boolean;
  isAdminUser:boolean;
  showProgressBar: boolean = false;
  isApiInProgress: boolean = false;
  operationProcessMsg: string;
  isLOESelected:boolean=false;
  constructor(public _projectService: ProjectService,
    public _adminService: AdminService,
    public _router: Router,
    public _activateRoute: ActivatedRoute,
    public _modalService: NgbModal) {
    this.projectDto = new ProjectObject();
  }

  ngOnInit(): void {
    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
    this._adminService.getMetadataByEntity("ramsSolution").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "levelOfEffort") {
          this.levelOfEffortsMetadata = response.groupData[i].data;
          this.levelOfEffortsMetadata.splice(0, 0, {
            "id": 0,
            "isReadOnly": true,
            "value": "Select a Value"
          });
          this.levelOfEffortsMetadata.join();
          
        }
      }
      this.renderProjectDetails();
    });
  }

  ngAfterViewInit() {
    //console.log(this.input.nativeElement.value);
  }

  renderProjectDetails(): void {
    this._activateRoute.queryParams.subscribe(params => {
      if (params.action === "edit") {
        this.isEditState = true;
        this.isLOESelected= true;
        this._projectService.getProjectDetails(params.id).subscribe(result => {
          let response: any = result;
          this.projectDto = RamsUtil.getFormatedProjectDetails(response.project);

          if (this.projectDto.levelOfEffort != "") {
            for (var i = 0; i < this.levelOfEffortsMetadata.length; i++) {
              if (this.levelOfEffortsMetadata[i].value === this.projectDto.levelOfEffort) {
                this.selectedLevelOfEffort = this.levelOfEffortsMetadata[i];
              }
            }
          } else {
            if (this.levelOfEffortsMetadata.length > 0) {
              this.selectedLevelOfEffort = this.levelOfEffortsMetadata[0];
            }
          }
        });
      } else {
        this.isEditState = false;
        if (this.levelOfEffortsMetadata.length > 0) {
          this.selectedLevelOfEffort = this.levelOfEffortsMetadata[0];
        }
      }
    })
  }

  levelOfEffortsSelectionChange(data: any): void {
    //this.selectedLevelOfEffort = value;
    if (data.value != "Select a Value") {
      this.projectDto.levelOfEffort = data.value;
      this.isLOESelected = true;
    }else{
      this.projectDto.levelOfEffort = "";
      this.isLOESelected = false;
    }
  }

  updateSelectedProjects(resources): any {
    this.projectDto.relatedResouces = resources;
  }

  updateSelectedSolutions(solutions): any {
    this.projectDto.relatedSolutions = solutions;
  }

  onAddUpdateProjectSubmit(name, projectId, levelOfEffort): void {
    if( name.value === undefined || projectId.value === undefined || levelOfEffort.value.id === 0){
      if(levelOfEffort.value.id === 0){
        this.isLOESelected = false;
      }
      return;
    }
    this._modalService.open(this.contentRef);
    this.isLOESelected = true;
    this.showProgressBar = true;
    this.isApiInProgress = true;
    if (this.isEditState) {
      this.operationProcessMsg = "Project update is in-progress"
    } else {
      this.operationProcessMsg = "Project save is in-progress"
    }
    if(this.projectDto.levelOfEffort === "Select a Value"){
      this.projectDto.levelOfEffort="";
    }
    this._projectService.createUpdateProject(this.projectDto, this.isEditState).subscribe(result => {
      if (this.isEditState) {
        this.operationProcessMsg = "Project updated successfully!";
      } else {
        this.operationProcessMsg = "Project created successfully!";
      }
     
      this.isApiInProgress = false;
      setTimeout(() => {
        this._modalService.dismissAll(this.contentRef);
        this._router.navigate(['app', 'manage-entities', 'project', 'list']);
      }, 2000);
    });
  }

  cancelClickedHandler() {
    this._router.navigate(['app', 'manage-entities', 'project', 'list']);
  }

}