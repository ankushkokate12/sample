import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ProjectObject } from 'src/app/dto/project-object';
import { Router } from '@angular/router';
import { ResourceObject } from 'src/app/dto/resource-object';

@Component({
  selector: 'app-resource-renderer',
  templateUrl: './resource-renderer.component.html',
  styleUrls: ['./resource-renderer.component.css']
})
export class ResourceRendererComponent implements OnInit {

  @Input()
  resourceObj:ResourceObject = new ResourceObject();
  @Input()
  isEditState:boolean=false;
  @Output()
  resourceRemoveEvent = new EventEmitter<ResourceObject>();
  shortDesc: boolean;
  detailButtonText: string;
  detailButton: boolean;
  
  constructor(public _router: Router) { }

  ngOnInit() {
  }

  ngOnChanges() {    
    if (this.resourceObj.description === undefined) {
      return;
    } else {
      this.manageShowHideDetails();
    }

  }
  manageShowHideDetails() {
    if (this.resourceObj.description.length >= 0 && this.resourceObj.description.length < 45) {
      this.detailButton = false;
    }
    else {
      this.detailButton = true;
    }

    if (this.resourceObj.description != "" || this.resourceObj.description.length != 0) {
      if (this.resourceObj.description.length > 45) {
        this.shortDesc = true;
        this.detailButtonText = "VIEW DETAILS"
      }
      else {
        this.shortDesc = false;
        this.detailButtonText = "HIDE DETAILS"
      }
    }
  }
  removeAddedResource(resource) {
    this.resourceRemoveEvent.emit(resource);
  }
  viewDetails() {
    if (this.shortDesc == true) {
      this.shortDesc = false;
      this.detailButtonText = "HIDE DETAILS"
    }
    else {
      this.shortDesc = true
      this.detailButtonText = "VIEW DETAILS"
    }
  }

}
