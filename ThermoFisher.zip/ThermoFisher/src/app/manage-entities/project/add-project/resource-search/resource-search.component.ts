import { Component, OnInit, Input, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { RamsUtil } from 'src/app/utils/rams-util';
import { Resources } from 'aws-sdk/clients/workmail';
import { ResourceObject } from 'src/app/dto/resource-object';
import { ResourcesService } from 'src/app/services/resources.service';

@Component({
  selector: 'app-resource-search',
  templateUrl: './resource-search.component.html',
  styleUrls: ['./resource-search.component.css']
})
export class ResourceSearchComponent implements OnInit {

  @Input()
  resourceModel: ResourceObject[] = [];
  @Input()
  isEditState: boolean;
  @Input()
  addedResourcesArray: ResourceObject[] = [];
  @Output()
  projectEvent = new EventEmitter<ResourceObject[]>();

  treatmentTypeMetadata: any[] = [];
  searchedResourcesArr: ResourceObject[] = [];
  selectedResourceObj: ResourceObject = new ResourceObject();
  showProjects: boolean = true;
  showSearchResource: boolean = false;
  showSelectedResources: boolean = false;
  seachedResourcesArrCopy: ResourceObject[] = [];
  isResourceCheckboxSelected:boolean;
  constructor(public _resourceService: ResourcesService,
    public _adminService: AdminService) { }

  ngOnInit() {
    this.getAllResources();
    this.getSolutionsMetadata();
  }

  getSolutionsMetadata() {
    this._adminService.getMetadataByEntity("ramsSolution").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "levelOfEfforts") {
          this.treatmentTypeMetadata = response.groupData[i].data
        }
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState) {
      this.showSearchResource = false;
      this.showSelectedResources = true;
    }
  }

  getAllResources() {
    this._resourceService.getResources().subscribe(result => {
      let response: any = result;
      this.searchedResourcesArr = RamsUtil.getFormatedResourceList(response.resources);
      this.seachedResourcesArrCopy = [...this.searchedResourcesArr];
      if (this.resourceModel.length > 0) {
        this.selectedResourceObj = this.resourceModel[0];
      }
    });
  }

  searchResources(resourceName?: string):void {
    this.showSelectedResources = false;
    this.showSearchResource = true;
    let tempSearchArray: ResourceObject[];

    if (resourceName === "") {
      this.searchedResourcesArr = this.seachedResourcesArrCopy;
    }
    tempSearchArray = this.searchedResourcesArr.filter(function (resource) {
      return (resource.name.toLowerCase().indexOf(resourceName.toLowerCase()) > -1);
    });
    this.searchedResourcesArr = tempSearchArray;
  }

  showSearchProjectWindow():void {
    this.checkAlreadySelectedResources();
    this.showSearchResource = true;
    this.showSelectedResources = false;
  }

  checkAlreadySelectedResources():void {
    for (var i = 0; i < this.searchedResourcesArr.length; i++) {
      this.searchedResourcesArr[i].isSelected = false;
      for (var j = 0; j < this.addedResourcesArray.length; j++) {
        if (this.searchedResourcesArr[i].id === this.addedResourcesArray[j].id) {
          this.searchedResourcesArr[i].isSelected = true;
        }
      }
    }
  }

  onCheckboxChange(selectedResource: ResourceObject, event):void {
    this.isResourceCheckboxSelected =false;
    for (var i = 0; i < this.searchedResourcesArr.length; i++) {
      if (this.searchedResourcesArr[i].id === selectedResource.id) {
        if (event.target.checked) {
          this.selectedResourceObj = selectedResource;
          this.searchedResourcesArr[i].isSelected = true;
        } else {
          this.searchedResourcesArr[i].isSelected = false;
        }
      }
      if(this.searchedResourcesArr[i].isSelected){
        this.isResourceCheckboxSelected = true;
      }
    }
  }

  addSelectedProjects():void {
    this.addedResourcesArray = this.searchedResourcesArr.filter(function (project) {
      return project.isSelected;
    });

    this.projectEvent.emit(this.addedResourcesArray);
    this.showSearchResource = false;
    this.showSelectedResources = true;
  }

  onResourceRemove(resource:ResourceObject):void {
    for (var i = 0; i < this.addedResourcesArray.length; i++) {
      if (this.addedResourcesArray[i].id === resource.id) {
        this.addedResourcesArray.splice(i, 1);
        break;
      }
    }
    this.checkAlreadySelectedResources();
    this.projectEvent.emit(this.addedResourcesArray);
  }

  cancelSelection():void {
    this.showSearchResource = false;
    this.showSelectedResources = true;
  }
}