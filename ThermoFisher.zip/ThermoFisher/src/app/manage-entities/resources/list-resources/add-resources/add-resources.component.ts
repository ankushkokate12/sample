import { Component, OnInit, Output, EventEmitter, Input, SimpleChange } from '@angular/core';
import { ResourceObject } from 'src/app/dto/resource-object';
import { AdminService } from 'src/app/services/admin.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ResourcesService } from 'src/app/services/resources.service';

@Component({
  selector: 'app-add-resources',
  templateUrl: './add-resources.component.html',
  styleUrls: ['./add-resources.component.css']
})
export class AddResourcesComponent implements OnInit {
  @Input()
  resourcesArr: ResourceObject[] = [];
  @Output()
  resourceEvent = new EventEmitter<boolean>();
  @Output()
  resourceCancel = new EventEmitter();
  @Input()
  resourceDto: ResourceObject = new ResourceObject();
  @Input()
  isEditState: boolean;

  showProgressBar: boolean = false;
  isApiInProgress: boolean = false;
  operationProcessMsg: string;
  isResourceTypeSelected:boolean=false;

  selectedParentResource: ResourceObject = new ResourceObject();
  selectedResourceType: ResourceObject = new ResourceObject();
  copiedResourceArray: ResourceObject[] = [];
  resourceTypeMetadata: any[] = [];

  constructor(public _adminService: AdminService,
    public modalService: NgbModal,
    public _resourceService: ResourcesService) { 
    }

  ngOnInit() {
    this._adminService.getMetadataByEntity("ramsResource").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "resourceType") {
          this.resourceTypeMetadata = response.groupData[i].data;
          this.resourceTypeMetadata.splice(0, 0, {
            "id": 0,
            "isReadOnly": true,
            "value": "Select a Value"
          });
          this.resourceTypeMetadata.join();
        }
      }
      this.renderResourceDetails();
    });
    if (this.isEditState) {
      
    }else{
      this.resourceDto = new ResourceObject();
    }
  }

  ngOnChanges(simpleChanges: SimpleChange) {
    let tempSimpleObj: any = simpleChanges;

    if (tempSimpleObj.resourcesArr.firstChange) {
      let tempResourceArr: any[] = [...tempSimpleObj.resourcesArr.currentValue];
      tempResourceArr.splice(0, 0, {
        "id": null,
        "name": "Select a Value",
        "description": "",
        "parentId": null,
        "parentName": "",
        "resourceType": ""
      });
      tempResourceArr.join();
      this.copiedResourceArray = tempResourceArr;
      if (this.isEditState && tempSimpleObj.resourceDto.currentValue.parentId != null) {
        this.selectedParentResource = this.copiedResourceArray.find(function (fr: ResourceObject) {
          if (fr.id === tempSimpleObj.resourceDto.currentValue.parentId) {
            return true;
          }
        });
      } else {
        this.selectedParentResource = this.copiedResourceArray[0];
      }
    }
  }

  renderResourceDetails(): void {
    if (this.isEditState === true) {
      if (this.resourceDto.resourceType != "") {
        for (var i = 0; i < this.resourceTypeMetadata.length; i++) {
          if (this.resourceTypeMetadata[i].value === this.resourceDto.resourceType) {
            this.selectedResourceType = this.resourceTypeMetadata[i];
          }
        }
      } else {
        if (this.resourceTypeMetadata.length > 0) {
          this.selectedResourceType = this.resourceTypeMetadata[0];
        }
      }
    } else {
      this.isEditState = false;
      if (this.resourceTypeMetadata.length > 0) {
        this.selectedResourceType = this.resourceTypeMetadata[0];
      }
    }
  }

  parentResourceSelectionChange(data: ResourceObject) {
    if (data.name != "Select a Value") {
      this.resourceDto.parentId = data.id;
      this.isResourceTypeSelected = true;
    }else{
      this.resourceDto.parentId = null;
      this.isResourceTypeSelected = false;
    }
  }
  resourceTypeSelectionChange(data: any): void {
    if (data.value != "Select a Value") {
      this.resourceDto.resourceType = data.value;
      this.isResourceTypeSelected = true;
    }else{
      this.resourceDto.resourceType = "";
      this.isResourceTypeSelected = false;
    }
  }

  onAddUpdateResourceSubmit(rName, rType) {
    if( rName.value === undefined || rType.value.id === 0){
      if(rType.value.id === 0){
        this.isResourceTypeSelected = false;
      }
      return;
    }
    this.isResourceTypeSelected = true;
    this.showProgressBar = true;
    this.isApiInProgress = true;

    if (this.isEditState) {
      this.operationProcessMsg = "Resource update is in-progress"
    } else {
      this.operationProcessMsg = "Resource save is in-progress"
    }
    
    //make api call to post/put Project
      this._resourceService.createUpdateResource(this.resourceDto, this.isEditState).subscribe(result=>{
        this.resourceEvent.emit(true);
        if(this.isEditState){
          this.operationProcessMsg = "Resource update is complete";
        }else{
          this.operationProcessMsg = "Resource save is complete";
        }
        this.isApiInProgress = false;
        setTimeout(()=>{
          this.cancelClickedHandler();
     }, 2000);
      })
  }
  cancelClickedHandler() {
    this.resourceCancel.emit();
  }

}
