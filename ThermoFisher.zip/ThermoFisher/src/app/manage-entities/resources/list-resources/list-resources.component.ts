import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ResourcesService } from 'src/app/services/resources.service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ResourceObject } from 'src/app/dto/resource-object';
import { Subject } from 'rxjs';
import { RamsUtil } from 'src/app/utils/rams-util';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-list-resources',
  templateUrl: './list-resources.component.html',
  styleUrls: ['./list-resources.component.css']
})
export class ListResourcesComponent implements OnInit {
  @ViewChild('content') contentRef: ElementRef;

  modalOption: NgbModalOptions = {};
  resourceArray: ResourceObject[] = [];
  tableWidget: any;
  editResourceObj: ResourceObject;
  dtTrigger: Subject<ResourceObject> = new Subject();
  closeResult: string;
  //Flag declations
  isAdminUser: boolean = false;
  isEditState: boolean;
  showAddResource: boolean;
  showHideButton: boolean;
  isApiInProgress: boolean;

  constructor(public _resourceService: ResourcesService, public modalService: NgbModal,
    public _activateRoute: ActivatedRoute) {
    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
  }

  ngOnInit() {
    this.isApiInProgress = true;
    this.getAllResources();
    this.modalConfiguration()
  }
  
  drawResourceGrid() {
    let exampleId: any = $('#resource-grid');
    this.tableWidget = exampleId.DataTable({
      data: this.resourceArray,
      select: true,
      columns: [
        { title: "RESOURCE NAME", data: "name", 'className': 'resource_th1' },
        { title: "RESOURCE TYPE", data: "resourceType", 'className': 'resource_th2' },
        { title: "PARENT RESOURCE", data: "parentName", 'className': 'resource_th3' },
        { title: "DESCRIPTION", data: "description", 'className': 'resource_th4' },
        {
          title: "", 'className': 'resource_th5 sorting1', visible: this.isAdminUser, render: function (data, type, row) {
            return '<td [hidden]="!isAdminUser"><abbr title="Edit Resource"><a (click)="open(content)" class="linkstyle"><svg version="1.2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" overflow="visible" preserveAspectRatio="none" viewBox="0 0 596 596" width="14" height="14"><g><g xmlns:default="http://www.w3.org/2000/svg">	<polygon points="547.7,571.5 23.8,571.5 23.8,47.6 333.3,47.6 357.1,23.8 0,23.8 0,595.4 571.5,595.4 571.5,238.1 547.7,261.9  " style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/>	<path d="M119,476.3h95.2l381-381L500,0L119,381V476.3z M561.9,95.3l-57.1,57.1l-61.9-61.9L500,33.4L561.9,95.3z M142.8,390.5   l283.4-280.9l61.9,61.9L204.7,452.5h-61.9V390.5z" style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/></g></g></svg></a></abbr></td>'
          }
        },
        { title: "Date", data: "dateModified", visible: false }
      ],
      "paging": true,
      "ordering": true,
      "info": true,
      "lengthChange": false,
      "searching": true,
      "pageLength": 10,
      "bDestroy": true,
      "bJQueryUI": true,
      "bAutoWidth": false,
      "aaSorting": [[5, 'desc']],
      "columnDefs": [
        { orderable: false, targets: -1 }
      ],
      "oLanguage": {
        "sInfoFiltered": "(filtered from _MAX_ total records)",
        "sSearchPlaceholder": "Search Resource/s",
        "sSearch": '',
        "oPaginate": {
          "sNext": '<span>&raquo;</span>',
          "sPrevious": '<span>&laquo;</span>'
        }
      }
    });

    let rowRef = $('#resource-grid tbody');
    rowRef.on('click', 'a', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onEditResourceClick(data);
      e.stopPropagation();
    });

    var table = exampleId.DataTable();
    $('#search-box').on('keyup change', function () {
      table.search($(this).val()).draw();
    });
  }
  redrawDt() {
    this.tableWidget.clear();
    this.tableWidget.rows.add(this.resourceArray);
    this.tableWidget.draw();
  }

  getAllResources() {
    this._resourceService.getResources().subscribe(response => {
      let responsePayload: any = response;
      this.resourceArray = RamsUtil.getFormatedResourceList(responsePayload.resources);
      this.isApiInProgress = false;
      if (this.tableWidget) {
        this.redrawDt();
      } else {
        this.drawResourceGrid();
        this._activateRoute.queryParams.subscribe(params => {
          if (params.action === "add_resource") {
            this.showAddResourceWindow();
          }
        });
      }
    })
  }

  onEditResourceClick(value: ResourceObject) {
    this.isEditState = true;
    this.editResourceObj = value;
    this.modalService.open(this.contentRef, this.modalOption);
  }
  closeAddResourceWindow() {
    this.showAddResource = false;
    this.isEditState = false;
    this.modalService.dismissAll(this.contentRef);
  }

  modalConfiguration() {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
  }
  
  showAddResourceWindow() {
    this.isEditState = false;
    this.modalService.open(this.contentRef, this.modalOption);
  }
}
