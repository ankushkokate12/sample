import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SolutionObject } from "src/app/dto/solution-object";
import { SolutionService } from 'src/app/services/solution.service';
import { AdminService } from 'src/app/services/admin.service';
import { RamsUtil } from 'src/app/utils/rams-util';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-solution',
  templateUrl: './add-solution.component.html',
  styleUrls: ['./add-solution.component.css']
})
export class AddSolutionComponent implements OnInit {

  @ViewChild('content') contentRef: ElementRef;
  solutionDto: SolutionObject;

  selectedLevelOfEffort: string;
  selectedSolutionId: string;
  selectedProjects: any[] = [];
  levelOfEffortsMetadata: any[] = [];
  treatmentTypeMetadata: [];
  isEditState: boolean;
  showProgressBar: boolean = false;
  isApiInProgress: boolean = false;
  operationProcessMsg: string;

  constructor(public _solutionService: SolutionService,
    public _adminService: AdminService,
    public _router: Router,
    public _activateRoute: ActivatedRoute,
    public modalService: NgbModal) {
    this.solutionDto = new SolutionObject();
  }

  ngOnInit(): void {
    this._adminService.getMetadataByEntity("ramsSolution").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "levelOfEffort") {
          this.levelOfEffortsMetadata = response.groupData[i].data;
          this.levelOfEffortsMetadata.splice(0, 0, {
            "id": 0,
            "isReadOnly": true,
            "value": "Select a Value"
          });
          this.levelOfEffortsMetadata.join();
          
        }
      }
      this.renderSolutionDetails();
    });
  }

  renderSolutionDetails(): void {
    this._activateRoute.queryParams.subscribe(params => {
      if (params.action === "edit") {
        this.isEditState = true;
        this._solutionService.getSolutionDetails(params.id, false).subscribe(result => {
          let response: any = result;
          this.solutionDto = RamsUtil.getFormatedSolutionDetailsObj(response.solution);

          if (this.solutionDto.levelOfEffort != "") {
            for (var i = 0; i < this.levelOfEffortsMetadata.length; i++) {
              if (this.levelOfEffortsMetadata[i].value === this.solutionDto.levelOfEffort) {
                this.selectedLevelOfEffort = this.levelOfEffortsMetadata[i];
              }
            }
          } else {
            if (this.levelOfEffortsMetadata.length > 0) {
              this.selectedLevelOfEffort = this.levelOfEffortsMetadata[0];
            }
          }
        });
      } else {
        this.isEditState = false;
        if (this.levelOfEffortsMetadata.length > 0) {
          this.selectedLevelOfEffort = this.levelOfEffortsMetadata[0];
        }
      }
    })
  }

  levelOfEffortsSelectionChange(data: any): void {
    //this.selectedLevelOfEffort = value;
    if (data.value != "Select a Value") {
      this.solutionDto.levelOfEffort = data.value;
    }else{
      this.solutionDto.levelOfEffort = "";
    }
  }

  updateSelectedProjects(projects): any {
    this.solutionDto.relatedProjects = projects;
  }

  updateSelectedResources(resources): any {
    this.solutionDto.relatedResources = resources;
  }

  onAddUpdateSolutionsSubmit(): void {
    this.modalService.open(this.contentRef);
    this.showProgressBar = true;
    this.isApiInProgress = true;
    if (this.isEditState) {
      this.operationProcessMsg = "Solution update is in-progress"
    } else {
      this.operationProcessMsg = "Solution save is in-progress"
    }
    if(this.solutionDto.levelOfEffort === "Select a Value"){
      this.solutionDto.levelOfEffort="";
    }
    this._solutionService.saveAndCreateSolution(this.solutionDto, this.isEditState).subscribe(result => {
      if (this.isEditState) {
        this.operationProcessMsg = "Solution updated successfully!";
      } else {
        this.operationProcessMsg = "Solution created successfully!";
      }
     
      this.isApiInProgress = false;
      setTimeout(() => {
        this.modalService.dismissAll(this.contentRef);
        this._router.navigate(['app', 'manage-entities', 'solution', 'list']);
      }, 2000);

    });
  }

  cancelClickedHandler() {
    this._router.navigate(['app', 'manage-entities', 'solution', 'list']);
  }

  riskClickedHandler(riskObj){
    this._router.navigate(['app', 'risk',  'edit'], { queryParams: { action: "edit", id: riskObj.id } });
  }
}
