import { Component, OnInit, Input, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { ProjectObject } from 'src/app/dto/project-object';
import { AdminService } from 'src/app/services/admin.service';
import { ProjectService } from 'src/app/services/project.service';
import { RamsUtil } from 'src/app/utils/rams-util';

@Component({
  selector: 'app-project-search',
  templateUrl: './project-search.component.html',
  styleUrls: ['./project-search.component.css']
})
export class ProjectSearchComponent implements OnInit {

  @Input()
  projectsModel: ProjectObject[] = [];
  @Input()
  isEditState: boolean;
  @Input()
  addedProjectsArray: ProjectObject[] = [];
  @Output()
  projectEvent = new EventEmitter<ProjectObject[]>();

  seachedProjectsArrCopy: ProjectObject[] = [];
  treatmentTypeMetadata: any[] = [];
  seachedProjectsArr: ProjectObject[] = [];
  selectedProjectObj: ProjectObject = new ProjectObject();
  showProjects: boolean = true;
  showSearchProject: boolean = false;
  showSelectedProjects: boolean = false;
  isProjectCheckboxSelected:boolean=false;
  constructor(public _projectService: ProjectService,
    public _adminService: AdminService) { }

  ngOnInit() {
    this.getAllProjects();
    this.getSolutionsMetadata();
  }

  getSolutionsMetadata() {
    this._adminService.getMetadataByEntity("ramsSolution").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "levelOfEfforts") {
          this.treatmentTypeMetadata = response.groupData[i].data
        }
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState) {
      this.showSearchProject = false;
      this.showSelectedProjects = true;
    }
  }

  getAllProjects() {
    this._projectService.getProjectList().subscribe(result => {
      let response: any = result;
      this.seachedProjectsArr = RamsUtil.getFormatedProjectList(response.projects);
      this.seachedProjectsArrCopy = [...this.seachedProjectsArr];
      if (this.projectsModel.length > 0) {
        this.selectedProjectObj = this.projectsModel[0];
      }
    });
  }

  searchProjects(projectName?: string):void {
    this.showSelectedProjects = false;
    this.showSearchProject = true;
    let tempSearchArray: ProjectObject[];

    if (projectName === "") {
      this.seachedProjectsArr = this.seachedProjectsArrCopy;
    }
    tempSearchArray = this.seachedProjectsArr.filter(function (project) {
      return (project.name.toLowerCase().indexOf(projectName.toLowerCase()) > -1);
    });
    this.seachedProjectsArr = tempSearchArray;
  }

  showSearchProjectWindow():void {
    this.checkAlreadySelectedProjects();
    this.showSearchProject = true;
    this.showSelectedProjects = false;
  }

  checkAlreadySelectedProjects():void {
    for (var i = 0; i < this.seachedProjectsArr.length; i++) {
      this.seachedProjectsArr[i].isSelected = false;
      for (var j = 0; j < this.addedProjectsArray.length; j++) {
        if (this.seachedProjectsArr[i].id === this.addedProjectsArray[j].id) {
          this.seachedProjectsArr[i].isSelected = true;
        }
      }
    }
  }

  onCheckboxChange(selectedProject: ProjectObject, event):void {
    this.isProjectCheckboxSelected = false;
    for (var i = 0; i < this.seachedProjectsArr.length; i++) {
      if (this.seachedProjectsArr[i].id === selectedProject.id) {
        if (event.target.checked) {
          this.selectedProjectObj = selectedProject;
          this.seachedProjectsArr[i].isSelected = true;
        } else {
          this.seachedProjectsArr[i].isSelected = false;
        }
      }
      if(this.seachedProjectsArr[i].isSelected){
        this.isProjectCheckboxSelected = true;
      }
    }
  }

  addSelectedProjects():void {
    this.addedProjectsArray = this.seachedProjectsArr.filter(function (project) {
      return project.isSelected;
    });

    this.projectEvent.emit(this.addedProjectsArray);
    this.showSearchProject = false;
    this.showSelectedProjects = true;
  }
  onProjectRemove(project: ProjectObject):void {
    for (var i = 0; i < this.addedProjectsArray.length; i++) {
      if (this.addedProjectsArray[i].id === project.id) {
        this.addedProjectsArray.splice(i, 1);
        break;
      }
    }
    this.checkAlreadySelectedProjects();
    this.projectEvent.emit(this.addedProjectsArray);
  }

  cancelSelection():void {
    this.showSearchProject = false;
    this.showSelectedProjects = true;
  }
}
