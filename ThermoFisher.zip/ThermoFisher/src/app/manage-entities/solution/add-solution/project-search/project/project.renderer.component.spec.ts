import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProjectRendererComponent } from './project.renderer.component';

describe('ProjectComponent', () => {
  let component: ProjectRendererComponent;
  let fixture: ComponentFixture<ProjectRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
