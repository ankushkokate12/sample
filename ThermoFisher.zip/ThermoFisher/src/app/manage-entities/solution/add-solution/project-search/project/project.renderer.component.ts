import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ProjectObject } from 'src/app/dto/project-object';
import { Router } from '@angular/router';

@Component({
  selector: 'app-project-renderer',
  templateUrl: './project.renderer.component.html',
  styleUrls: ['./project.renderer.component.css']
})
export class ProjectRendererComponent implements OnInit {
  @Input()
  projectObj:ProjectObject = new ProjectObject();
  @Output()
  projectRemoveEvent = new EventEmitter<ProjectObject>();
  @Input()
  isEditState = false;
  
  shortDesc: boolean;
  detailButtonText: string;
  detailButton: boolean;
  
  constructor(public _router: Router) { }

  ngOnInit() {
  }

  ngOnChanges() {    
    if (this.projectObj.description === undefined) {
      return;
    } else {
      this.manageShowHideDetails();
    }

  }
  manageShowHideDetails() {
    if (this.projectObj.description.length >= 0 && this.projectObj.description.length < 45) {
      this.detailButton = false;
    }
    else {
      this.detailButton = true;
    }

    if (this.projectObj.description != "" || this.projectObj.description.length != 0) {
      if (this.projectObj.description.length > 45) {
        this.shortDesc = true;
        this.detailButtonText = "VIEW DETAILS"
      }
      else {
        this.shortDesc = false;
        this.detailButtonText = "HIDE DETAILS"
      }
    }
  }
  removeAddedProjects(project) {
    this.projectRemoveEvent.emit(project);
  }
  viewDetails() {
    if (this.shortDesc == true) {
      this.shortDesc = false;
      this.detailButtonText = "HIDE DETAILS"
    }
    else {
      this.shortDesc = true
      this.detailButtonText = "VIEW DETAILS"
    }
  }

}
