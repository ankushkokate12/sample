import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListSolutionComponent } from './list-solution.component';

describe('SolutionListComponent', () => {
  let component: ListSolutionComponent;
  let fixture: ComponentFixture<ListSolutionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListSolutionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListSolutionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
