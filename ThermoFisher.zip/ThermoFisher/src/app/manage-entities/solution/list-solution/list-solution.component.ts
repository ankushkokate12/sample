import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SolutionService } from 'src/app/services/solution.service';
import { SolutionObject } from "src/app/dto/solution-object";
import { RamsUtil } from '../../../utils/rams-util';
import { ProjectObject } from 'src/app/dto/project-object';
import { Solution } from 'aws-sdk/clients/personalize';

@Component({
  selector: 'app-list-solution',
  templateUrl: './list-solution.component.html',
  styleUrls: ['./list-solution.component.css']
})
export class ListSolutionComponent implements OnInit {

  solutionList: SolutionObject[] = [];
  selectedSolutionObject: SolutionObject = new SolutionObject();
  isAdminUser: boolean = false;
  relatedProjectArr: ProjectObject[] = [];
  tableWidget: any;
  isApiInProgres: boolean;

  constructor(public _router: Router, public _solutionService: SolutionService) { }

  ngOnInit() {
    this.isApiInProgres = true;
    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
    this._solutionService.getSolutions(true).subscribe(result => {
      let responsePayload: any = result;
      this.solutionList = RamsUtil.getFormatedSolutions(responsePayload);
      this.drawSolutionGrid();
      this.isApiInProgres = false;
    });
  }

  drawSolutionGrid() {
    let exampleId: any = $('#solution-grid');
    this.tableWidget = exampleId.DataTable({
      data: this.solutionList,
      select: true,
      columns: [
        { title: "SOLUTION NAME", data: "name", 'className': 'solution_th1' },
        {
          title: "LEVEL OF EFFORT", data: "levelOfEffort", 'className': 'solution_th2',
          "createdCell": function (td, cellData) {
            switch (cellData) {
              case "Low":
                $(td).addClass('Low');
                break;
              case "Medium":
                $(td).addClass('Medium');
                break;
              case "High":
                $(td).addClass('High');
                break;
            }
          }
        },
        {
          title: "REQUIRED BUDGET", data: "budgetRequired", 'className': 'solution_th3',
          render: function (data, type, row) {
            const formatter = new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
              minimumFractionDigits: 0
            });
            return '<td>' + formatter.format(row.budgetRequired); + '</td>'
          }
        },
        {
          title: "", 'className': 'solution_th4 sorting1', visible: this.isAdminUser, render: function (data, type, row) {
            return '<td [hidden]="!isAdminUser"><abbr title="Edit Solution"><a (click)="onEditClick(solution)" class="linkstyle"><svg version="1.2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" overflow="visible" preserveAspectRatio="none" viewBox="0 0 596 596" width="14" height="14"><g><g xmlns:default="http://www.w3.org/2000/svg">	<polygon points="547.7,571.5 23.8,571.5 23.8,47.6 333.3,47.6 357.1,23.8 0,23.8 0,595.4 571.5,595.4 571.5,238.1 547.7,261.9  " style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/>	<path d="M119,476.3h95.2l381-381L500,0L119,381V476.3z M561.9,95.3l-57.1,57.1l-61.9-61.9L500,33.4L561.9,95.3z M142.8,390.5   l283.4-280.9l61.9,61.9L204.7,452.5h-61.9V390.5z" style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/></g></g></svg></a></abbr></td>'
          }
        },
        { title: "Date", data: "dateModified", visible: false }
      ],
      "paging": true,
      "ordering": true,
      "info": true,
      "lengthChange": false,
      "searching": true,
      "bjQueryUI": true,
      "sDom": '<"search-box"r>lftip',
      "pageLength": 10,
      "aaSorting": [[4, 'desc']],
      "columnDefs": [
        { orderable: false, targets: -1 }
      ],
      "oLanguage": {
        "sInfoFiltered": "(filtered from _MAX_ total records)",
        "sSearchPlaceholder": "Search Solution/s",
        "sSearch": "",
        "oPaginate": {
          "sNext": '<span>&raquo;</span>',
          "sPrevious": '<span>&laquo;</span>'
        },
      }
    });

    var table = exampleId.DataTable();
    $('#search-box').on('keyup change', function () {
      table.search($(this).val()).draw();
    });

    let rowRef = $('#solution-grid tbody');
    rowRef.on('click', 'a', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onEditClick(data);
      e.stopPropagation();
    });

    rowRef.on('click', 'tr', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onRowClick(data);
      $row.siblings().removeClass('rowseleced');
      $row.addClass('rowseleced');
      e.stopPropagation();
    });

    if (this.solutionList.length > 1) {
      this.getSolutionsDetail(this.solutionList[0].id, false);
      $("tbody tr:first-child").addClass('rowseleced')
    }
  }

  onRowClick(clickedRisk: any) {
    this.getSolutionsDetail(clickedRisk.id, false);
  }

  getSolutionsDetail(solutionId, isSolutionsDetails) {
    this._solutionService.getSolutionDetails(solutionId, isSolutionsDetails).subscribe(result => {
      let response: any = result
      this.selectedSolutionObject = RamsUtil.getFormatedSolutionDetailsObj(response.solution);
    });
  }

  onEditClick(solution?: any) {
    let solutionId: number;
    if (solution) {
      solutionId = solution.id;
    } else {
      solutionId = this.selectedSolutionObject.id;
    }
    this._router.navigate(['app', 'manage-entities', 'solution', 'edit'], { queryParams: { action: "edit", id: solutionId } });
  }

  createNewSolution() {
    this._router.navigate(['app', 'manage-entities', 'solution', 'add']);
  }


  riskClickedHandler(riskObj) {
    if(this.isAdminUser){
      this._router.navigate(['app', 'risk', 'edit'], { queryParams: { action: "edit", id: riskObj.id } });
    }
  }

}
