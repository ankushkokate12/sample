export const divisions = {
    "divisions": [
      {
        "value": 1,
        "checked": false,
        "text": "Life Sciences Group",
        "children": [
          {
            "value": 4,
            "checked": false,
            "text": "HR"
          },
          {
            "value": 5,
            "checked": false,
            "text": "SDG IT",
            "children": [
              {
                "value": 6,
                "checked": false,
                "text": "ERP Application Team "
              }
            ]
          }
        ]
      },
      {
        "value": 2,
        "checked": false,
        "text": "Speciality Diagnostic Group"
      },
      {
        "value": 3,
        "checked": false,
        "text": "Corporate Functions",
        "children": [
          {
            "value": 7,
            "checked": false,
            "text": "Information Technology",
            "children": [
              {
                "value": 8,
                "checked": false,
                "text": "Corporate Information Security"
              },
              {
                "value": 9,
                "checked": false,
                "text": "Enterprise Technology And Operation",
                "children": [
                  {
                    "value": 10,
                    "checked": false,
                    "text": "Messaging Team"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  };