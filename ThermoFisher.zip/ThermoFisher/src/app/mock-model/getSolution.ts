export const GetSolution = {
    "solution": [{  
            "id": "1",  
            "name": "Deploy AV to systems missing it",  
            "description": "This is a description of deploying AV to the systems that doesn't have any Anti virus installed",  
            "budgetRequired": "100",  
            "levelOfEffort": "High"  
        },  
        { 
            "id": "2",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "3",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "4",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "5",  
            "name": "AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "6",  
            "name": "utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "7",  
            "name": "SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "8",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "9",  
            "name": "This is a Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "9",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "10",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "11",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },
        { 
            "id": "12",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },  
        { 
            "id": "13",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },  
        { 
            "id": "14",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },  
        { 
            "id": "15",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },  
        { 
            "id": "16",  
            "name": "Deploy AV utilizing SCCM",
            "description": "This is a description of deploying AntiVirus in the system with utilizing SCCM",  
            "budgetRequired": "100",  
            "levelOfEffort": "Medium"  
        },  
    ]  
} 