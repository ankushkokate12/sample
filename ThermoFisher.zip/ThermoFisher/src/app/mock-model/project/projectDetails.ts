export const projectDetails = {
    "project": {
      "id": 1,
      "name": " Anti-Virus Deployment",
      "description": "This is a Project of deploying Anti virus,having a team of cyber security experts",
      "projectId": "PR-75",
      "budgetAvailable": 100,
      "levelOfEffort": "High",
      "relatedResources": [
        {
          "id": 1,
          "name": "Anti-Virus Team",
          "description": "Team that owns AV",
          "parentName": "Linux Admin Team",
          "parentId": 3,
          "resourceType": "Team"
        },
        {
          "id": 2,
          "name": "Client Engineering Team",
          "description": "Team that owns SCCM",
          "parentName": null,
          "parentId": null,
          "resourceType": "Team"
        }
      ]
    }
  }