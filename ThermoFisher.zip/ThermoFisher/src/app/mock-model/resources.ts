export const resources = {
    "resources": [
        {
            "id": 1,
            "name": "Anti-Virus Team",
            "description": "This project is having a team of training expertise.Aim is to train all the employees regarding cyber security threat.",
            "parentName": "Anti-Virus Team 2",
            "parentId": 2,
            "resourceType": "Teams"
        },
        {
            "id": 2,
            "name": "Anti-Virus Team 2",
            "description": "This project is having a team of training expertise.Aim is to train all the employees regarding cyber security threat.",
            "parentName": "Anti-Virus Team 3",
            "parentId": 3,
            "resourceType": "Hardware"
        },
        {
            "id": 3,
            "name": "Anti-Virus Team 3",
            "description": "This project is having a team of training expertise.Aim is to train all the employees regarding cyber security threat.",
            "parentName": "Anti-Virus Team 4",
            "parentId": 4,
            "resourceType": "Laptop"
        },
        {
            "id": 4,
            "name": "Anti-Virus Team 4",
            "description": "This project is having a team of training expertise.Aim is to train all the employees regarding cyber security threat.",
            "parentName": "Anti-Virus Team 3",
            "parentId": 3,
            "resourceType": "Tablets"
        }
    ]
}