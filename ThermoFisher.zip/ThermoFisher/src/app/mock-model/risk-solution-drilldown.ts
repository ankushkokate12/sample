export const drillDownFGraphData = {
    "links": [{
        "source": "R1",
        "target": "S1"
    }, {
        "source": "R1",
        "target": "S2"
    }, {
        "source": "R1",
        "target": "S3"
    }, {
        "source": "S3",
        "target": "R2"
    }],

    "nodes": [{
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 100,
        "name": "Lack of endpoint security",
        "riskLevel": "Medium",
        "vertexId": "R1",
        "id": 1,
        "type": "Risk",
        "riskNumber": "RSK0001-SEC"
    }, {
        "noOfRisksLinked": 30,
        "noOfProjectsLinked": 0,
        "name": "Deploy AV to systems missing it",
        "levelOfEffort": "High",
        "vertexId": "S1",
        "id": 1,
        "type": "Solution",
        "budgetRequired": 100
    }, {
        "noOfRisksLinked": 1,
        "noOfProjectsLinked": 0,
        "name": "Deploy AV to systems missing it",
        "levelOfEffort": "High",
        "vertexId": "S2",
        "id": 2,
        "type": "Solution",
        "budgetRequired": 100

    }, {
        "noOfRisksLinked": 20,
        "noOfProjectsLinked": 0,
        "name": "Deploy AV to systems missing it",
        "levelOfEffort": "High",
        "vertexId": "S3",
        "id": 3,
        "type": "Solution",
        "budgetRequired": 100

    },
    {
        "noOfSolutionsLinked": 50,
        "budgetInvolved": 100,
        "name": "Lack of endpoint security",
        "riskLevel": "Medium",
        "vertexId": "R2",
        "id": 2,
        "type": "Risk",
        "riskNumber": "RSK-0004-TRN"
    }]
};