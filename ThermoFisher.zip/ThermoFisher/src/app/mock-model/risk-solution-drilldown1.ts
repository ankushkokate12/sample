export const drillDownFGraphData1 = {
    "links": [{
        "source": 4,

        "target": 4
    }, {
        "source": 2,

        "target": 4
    }, {
        "source": 1,

        "target": 3
    }, {
        "source": 4,

        "target": 5
    }],

    "nodes": [{
        "noOfSolutionsLinked": 1,
        "budgetInvolved": 100,
        "name": "Lack of endpoint security",
        "riskLevel": "Medium",
        "vertexId": "R1",
        "id": 1,
        "type": "Risk",
        "riskNumber": "RSK0001-SEC"
    },
    {
        "name": "RISK 2",
        "noOfSolutionsLinked": 5,
        "type": "Risk",
        "riskNumber": "RSK1002",
        "id": 2,
        "vertexId": 2,
        "riskLevel": "Low",
        "budgetInvolved": 400,
    }, {
        "name": "RISK 3",
        "noOfSolutionsLinked": 10,
        "type": "Risk",
        "riskNumber": "RSK1003",
        "id": 3,
        "vertexId": 3,
        "riskLevel": "Low",
        "budgetInvolved": 500,
    }, {
        "name": "RISK 4",
        "noOfSolutionsLinked": 7,
        "type": "Risk",
        "riskNumber": "RSK1004",
        "id": 4,
        "vertexId": 4,
        "riskLevel": "Low",
        "budgetInvolved": 400,
    },
    {
        "name": "RISK 5",
        "noOfSolutionsLinked": 1,
        "type": "Risk",
        "riskNumber": "RSK1005",
        "id": 5,
        "vertexId": 5,
        "riskLevel": "Low",
        "budgetInvolved": 400,
    }]
};