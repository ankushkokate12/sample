export const riskVsSolution = {
    "nodes": [
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      },{
        "type": "Risk",
        "riskNumber": "RSK1001",
        "name": "Unpatched Applications in the Environment",
        "id": 1,
        "riskLevel": "Low",
        "noOfSolutionsLinked": 20,
        "budgetInvolved": 400
      },
      {
        "type": "Risk",
        "riskNumber": "RSK1002",
        "name": "What is the risk associated with a lack of endpoint security software on windows",
        "id": 2,
        "riskLevel": "Medium",
        "noOfSolutionsLinked": 10,
        "budgetInvolved": 400
      }
    ]
  }