export const solutionVsRisk = {
  "nodes": [
    {
      "noOfRisksLinked": 30,
      "noOfProjectsLinked": 0,
      "name": "Deploy AV to systems missing it",
      "levelOfEffort": "Medium",
      "vertexId": "S1",
      "id": 1,
      "type": "Solution",
      "budgetRequired": 100
  }, {
      "noOfRisksLinked": 1,
      "noOfProjectsLinked": 50,
      "name": "Deploy AV to systems missing it",
      "levelOfEffort": "High",
      "vertexId": "S2",
      "id": 2,
      "type": "Solution",
      "budgetRequired": 100

  }, {
      "noOfRisksLinked": 20,
      "noOfProjectsLinked": 10,
      "name": "Deploy AV to systems missing it",
      "levelOfEffort": "Low",
      "vertexId": "S3",
      "id": 3,
      "type": "Solution",
      "budgetRequired": 100
  }
  ]
}