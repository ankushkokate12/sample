export const solutionDetails = {
    "solution": {
      "id": 1,
      "name": "Deploy AV to systems missing it",
      "description": "This is a description of deploying AV to the systems that doesn not have any Anti virus installed",
      "budgetRequired": 100,
      "levelOfEffort": "High",
      "relatedProjects": [
        {
          "id": 1,
          "name": "Anti-Virus Deployment",
          "description": "This is a Project of deploying Anti virus,having a team of cyber security experts",
          "projectId": "PRJ-001",
          "levelOfEffort": "High",
          "budgetAvailable": 500
        },
        {
          "id": 2,
          "name": "Cyber Security Training Hub",
          "description": "This project is having a team of training expertise.Aim is to train all the employees regarding cyber security threat.",
          "projectId": "PRJ-002",
          "levelOfEffort": "Medium",
          "budgetAvailable": 100
        },
        {
          "id": 3,
          "name": "Monitoring User Activities",
          "description": "The aim of the project is to monitor and control all the logging activities of employees and report whenever neccessary",
          "projectId": "PRJ-003",
          "levelOfEffort": "Medium",
          "budgetAvailable": 300
        }
      ],
      "relatedResources": [
        {
          "id": 1,
          "name": "Anti-Virus Team",
          "description": "Team that owns AV",
          "parentName": "Linux Admin Team",
          "parentId": 3,
          "resourceType": "Team"
        },
        {
          "id": 2,
          "name": "Client Engineering Team",
          "description": "Team that owns SCCM",
          "parentName": null,
          "parentId": null,
          "resourceType": "Team"
        }
      ],
      "relatedRisks": [
        {
          "id": 19,
          "riskNumber": "RSK-0016-POW",
          "name": "Power failure",
          "riskLevel": "High"
        },
        {
          "id": 25,
          "riskNumber": "RK0020457",
          "name": "Boundary Defense",
          "riskLevel": "Very Low"
        }
      ]
    }
  }