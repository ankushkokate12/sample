import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { RiskService } from '../../services/risk.service';
import { RamsUtil } from '../../utils/rams-util';
// import { divisions } from '../../mock-model/devision';
import { AdminService } from '../../services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RiskObject } from 'src/app/dto/risk-object';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-risk',
  templateUrl: './add-risk.component.html',
  styleUrls: ['./add-risk.component.css']
})
export class AddRiskComponent implements OnInit {
  @ViewChild('content') contentRef: ElementRef;
  riskDto: RiskObject;
  divisionData: any;
  frameworkData: any;
  allRisks: any[] = [];

  selectedPotentialLossType: string;
  selectedRiskId: string;
  selectedSolutions: any[] = [];
  selectedRelatedRisk: any;
  selectedPotentialImpact: string;
  selectedPotentialLikelihood: string;
  successMessage: string;

  potentialLikelihoodMetadata: [];
  potentialImpactMetadata: [];
  potentialLossTypeMetadata: [];
  treatmentTypeMetadata: [];
  isEditState: boolean;
  showProgressBar: boolean = false;
  isApiInProgress: boolean = false;
  operationProcessMsg: string;

  constructor(public _riskService: RiskService,
    public _adminService: AdminService,
    public _router: Router,
    public _activateRoute: ActivatedRoute,
    public modalService: NgbModal) {
    this.riskDto = new RiskObject();
  }

  ngOnInit(): void {
    
    this._adminService.getMetadataByEntity("ramsRisk").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "potentialLikelihood") {
          this.potentialLikelihoodMetadata = response.groupData[i].data
        }
        if (response.groupData[i].groupType === "potentialImpact") {
          this.potentialImpactMetadata = response.groupData[i].data
        }
        if (response.groupData[i].groupType === "potentialLossType") {
          this.potentialLossTypeMetadata = response.groupData[i].data
        }
        if (response.groupData[i].groupType === "potentialLossType") {
          this.potentialLossTypeMetadata = response.groupData[i].data
        }
      }
      this.renderRiskDetails();
    });
  }

  renderRiskDetails(): void {
    this._activateRoute.queryParams.subscribe(params => {
      if (params.action === "edit") {
        this.isEditState = true;
        this.selectedPotentialImpact="";
        this.selectedPotentialLikelihood="";
        this._riskService.getRiskDetails(params.id, false).subscribe(result => {
          this.riskDto = RamsUtil.getRiskDetailObject(result.riskDetails, false);
          this.divisionData = RamsUtil.getFormatedDivision(this.riskDto);
          this.frameworkData = RamsUtil.getFormatedFrameworks(this.riskDto);
          this._riskService.getAllRisk().subscribe(result => {
            let response = result.risks;
            response.splice(0, 0, {
              "id": 0,
              "active": true,
              "riskNumber": "Select a Value",
              "name": "",
              "potentialLossType": "",
              "riskLevel": ""
            });
            response.join()
            this.allRisks = response;
            if (this.riskDto.relatedRiskObj) {
              for (var i = 0; i < this.allRisks.length; i++) {
                if (this.allRisks[i].id === this.riskDto.relatedRiskObj.id) {
                  this.selectedRelatedRisk = this.allRisks[i];
                }
              }
            } else {
              if (this.allRisks.length > 0) {
                this.selectedRelatedRisk = this.allRisks[0];
              }
            }
          });
        });
      } else {
        this.isEditState = false;
        this.getAllRisk();
        this.getDivisions();
        this.getFrameworks();
      }
    });
  }

  potentialImpactSelectionChange(value: string): void {
    this.selectedPotentialImpact = value;
    this.riskDto.potentialImpact = value;
    this.checkBothDropDownSelection();
  }

  potentialLikelihoodSelectionChange(value: string): void {
    this.selectedPotentialLikelihood = value;
    this.riskDto.potentialLikelihood = value;
    this.checkBothDropDownSelection();
  }

  checkBothDropDownSelection(): void {
    if ((this.selectedPotentialImpact != undefined && this.selectedPotentialImpact != "Select a Value")
      && ( this.selectedPotentialLikelihood != undefined &&  this.selectedPotentialLikelihood != "Select a Value")) {
      this.getRiskLevels();
    }
  }

  getRiskLevels(): void {
    this._riskService.getRiskLevel(this.riskDto.potentialImpact, this.riskDto.potentialLikelihood).subscribe(result => {
      let response: any = result;
      this.riskDto.riskLevel = response.riskLevel;
    });
  }
  /**End: Get risk level implementation  */

  potentialLossTypeSelectionChange(value: string): void {
    if (value != "Select a Value") {
      this.selectedPotentialLossType = value;
      this.riskDto.potentialLossType = value;
    }
  }

  riskSelectionChange(value: any): void {
    this.riskDto.relatedRiskObj = value;
  }

  /**Get division API call */
  getDivisions(): void {
    this._riskService.getDivisions().subscribe(result => {
      this.divisionData = RamsUtil.getFormatedDivision(result);
    });
  }

  /**Get framework API call */
  getFrameworks(): void {
    this._riskService.getFrameworks().subscribe(result => {
      this.frameworkData = RamsUtil.getFormatedFrameworks(result);
    });
  }

  getAllRisk(): void {
    this._riskService.getAllRisk().subscribe(result => {
      let response = result.risks;
      response.splice(0, 0, {
        "id": 0,
        "active": true,
        "riskNumber": "Select a Value",
        "name": "",
        "potentialLossType": "",
        "riskLevel": ""
      });
      response.join();
      this.allRisks = response;
      if (this.allRisks.length > 0) {
        this.riskDto.relatedRiskObj = this.allRisks[0];
        this.selectedRelatedRisk = this.allRisks[0];
      }
    });
  }

  cancelClickedHandler(): void {
    this._router.navigate(['app', 'risk', 'list']);
  }

  updateSelectedSolutions(solutions): any {
    this.riskDto.solutions = solutions;
  }

  onAddUpdateRiskSubmit(): void {
    this.modalService.open(this.contentRef);
    this.showProgressBar = true;
    this.isApiInProgress = true;
    if (this.isEditState) {
      this.operationProcessMsg = "Risk update is in-progress"
    } else {
      this.operationProcessMsg = "Risk save is in-progress"
    }
    let divisionData = this.getJsonFromArray(this.divisionData);
    let frameworkData = this.getJsonFromArray(this.frameworkData);

    if (this.selectedRelatedRisk) {
      this.riskDto.relatedRiskObj = this.selectedRelatedRisk;
    }
    this._riskService.saveAndCreateRisk(this.riskDto, divisionData, frameworkData, this.isEditState).subscribe(result => {
      if (this.isEditState) {
       
        this.operationProcessMsg = "Risk updated successfully!";
      } else {
        this.operationProcessMsg = "Risk created successfully!";
      }
      this.isApiInProgress = false;
      setTimeout(() => {
        this.modalService.dismissAll(this.contentRef);
        this._router.navigate(['app', 'risk', 'list']);       
      }, 2000);

    });
  }

  /**recursive logic to abstract json from array */
  searchTree(element, treeStructure): any {
    treeStructure.value = element.value;
    treeStructure.checked = element.checked === undefined ? false : element.checked;
    treeStructure.text = element.text;
    if (typeof (element.children) != "undefined") {
      treeStructure.children = [];
      var i: number;
      for (i = 0; i < element.children.length; i++) {
        treeStructure.children.push({ value: '', checked: '', text: '' });
        treeStructure.children[i] = this.searchTree(element.children[i], treeStructure.children[i]);
      }
    }
    return treeStructure;
  }

  getJsonFromArray(sourceTree): any {
    var treeStructure = [];
    for (let i = 0; i < sourceTree.length; i++) {
      treeStructure.push({ value: '', checked: '', text: '' });
      treeStructure[i] = this.searchTree(sourceTree[i], treeStructure[i]);
    }
    return treeStructure;
  }
}