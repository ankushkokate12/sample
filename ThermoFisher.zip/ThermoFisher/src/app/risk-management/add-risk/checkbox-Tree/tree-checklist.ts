import { Component, Injectable, OnInit, Input, SimpleChanges } from '@angular/core';
import {TreeviewItem, TreeviewConfig, TreeviewI18n, TreeviewI18nDefault} from 'ngx-treeview';
import { __assign } from 'tslib';

@Component({
    selector: 'tree-checklist',
    templateUrl: 'tree-checklist.html',
    styleUrls: ['tree-checklist.css'],
    providers: [
        {
           provide: TreeviewI18n , useValue: Object.assign(new TreeviewI18nDefault(), {
             getFilterPlaceholder(): string {
               return 'Search';
             },
             getFilterNoItemsFoundText(): string{
                return "No matching records found";
             }
    
             // also override other methods if needed
             // getText(selection: TreeviewSelection): string;
             // getAllCheckboxText(): string;
             // getFilterPlaceholder(): string;
             // getFilterNoItemsFoundText(): string;
             // getTooltipCollapseExpandText(isCollapse: boolean): string;
          })
        }
    ],

})
export class TreeChecklist implements OnInit {
     
    @Input()
    public treeList:any;
    
    dropdownEnabled = false;
    items: TreeviewItem[];
    values: number[];
    config = TreeviewConfig.create({
        hasAllCheckBox: false,
        hasFilter: true,
        hasCollapseExpand: false,
        decoupleChildFromParent: false,
        maxHeight:290,
        
    });
    buttonClasses = [
        'btn-outline-primary',
        'btn-outline-secondary',
        'btn-outline-success',
        'btn-outline-danger',
        'btn-outline-warning',
        'btn-outline-info',
        'btn-outline-light',
        'btn-outline-dark'
    ];
    buttonClass = this.buttonClasses[0];

    ngOnInit(){
        
    }
    

    ngOnChanges(changes: SimpleChanges) {
        if(!changes.treeList.firstChange){
            this.items = changes.treeList.currentValue;
            
            
        }
    }

    onSelectedChange(event){
        this.items
    }

}


/**  Copyright 2019 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */