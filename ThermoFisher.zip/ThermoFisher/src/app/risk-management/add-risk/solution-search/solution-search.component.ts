import { Component, OnInit, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import { GetSolution } from '../../../mock-model/getSolution';
import { SolutionService } from 'src/app/services/solution.service';
import { SolutionObject } from "src/app/dto/solution-object";
import { RamsUtil } from '../../../utils/rams-util';
import { AdminService } from '../../../services/admin.service';
//import {SortByPipe} from '../../../pipes/sortByPipe';

@Component({
  selector: 'app-solution-search',
  templateUrl: './solution-search.component.html',
  styleUrls: ['./solution-search.component.css']
})
export class SolutionSearchComponent implements OnInit {

  @Input()
  solutionsModel: SolutionObject[] = [];
  @Input()
  isEditState: boolean;
  @Input()
  addedSolutionsArray: SolutionObject[] = [];
  @Output()
  solutionEvent = new EventEmitter<SolutionObject[]>();
  @Input()
  showRiskTreament:boolean;
  @Input()
  showLinkedRisk:boolean;
  @Input()
  detailButton:boolean=true;
  @Input()
  isAdminUser:boolean;
  @Input()
  isProjectModule:boolean=false;

  seachedSolutionsArrCopy:SolutionObject[]=[];
  treatmentTypeMetadata: any[] = [];
  seachedSolutionsArr: SolutionObject[] = [];
  selectedSolutionObj: SolutionObject = new SolutionObject();
  showSolutions: boolean = true;
  showSearchSolution: boolean = false;
  showSelectedSolutions: boolean = false;
  isSolutionCheckboxSelected:boolean=false; 

  constructor(public _solutionService: SolutionService,
    public _adminService: AdminService) { }

  ngOnInit() {
    this.getAllSolution();
    this.getRiskTreatmentTypeMetadata();
  }

  getRiskTreatmentTypeMetadata() {
    this._adminService.getMetadataByEntity("ramsRiskSolutionRelationship").subscribe(result => {
      let response: any = result;
      for (var i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "treatmentType") {
          this.treatmentTypeMetadata = response.groupData[i].data
        }
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.isEditState) {
      this.showSearchSolution = false;
      this.showSelectedSolutions = true;
    }
  }

  getAllSolution() {
    this._solutionService.getSolutions(true).subscribe(result => {
      let response: any = result;
      this.seachedSolutionsArr = RamsUtil.getFormatedSolutions(response);
      this.seachedSolutionsArrCopy = [...this.seachedSolutionsArr];
      if (this.solutionsModel.length > 0) {
        this.selectedSolutionObj = this.solutionsModel[0];
      }
    });
  }

  searchSolutions(solutionName?: string) {
    this.showSelectedSolutions = false;
    this.showSearchSolution = true;
    let tempSearchArray:SolutionObject[];

    if( solutionName===""){// when nothing has typed
      this.seachedSolutionsArr = this.seachedSolutionsArrCopy;
    } 
     tempSearchArray =this.seachedSolutionsArr.filter(function (solution) {
      //console.log(solution.name.toLowerCase().indexOf(solutionName.toLowerCase()) > -1);
      return (solution.name.toLowerCase().indexOf(solutionName.toLowerCase()) > -1);
    })
    this.seachedSolutionsArr =tempSearchArray;
  }

  showSearchSolutionWindow() {
    this.checkAlreadySelectedSolutions();
    this.showSearchSolution = true;
    this.showSelectedSolutions = false;
  }

  checkAlreadySelectedSolutions() {
    for (var i = 0; i < this.seachedSolutionsArr.length; i++) {
      this.seachedSolutionsArr[i].isSelected = false;
      for (var j = 0; j < this.addedSolutionsArray.length; j++) {
        if (this.seachedSolutionsArr[i].id === this.addedSolutionsArray[j].id) {
          this.seachedSolutionsArr[i].isSelected = true;
        }
      }
    }
  }  

  onCheckboxChange(selectedSolution: SolutionObject, event) {
    this.isSolutionCheckboxSelected = false;
    for (var i = 0; i < this.seachedSolutionsArr.length; i++) {
      if (this.seachedSolutionsArr[i].id === selectedSolution.id) {
        if (event.target.checked) {
          this.selectedSolutionObj = selectedSolution;
          this.seachedSolutionsArr[i].isSelected = true;
        } else {
          this.seachedSolutionsArr[i].isSelected = false;
        }
      }
      if(this.seachedSolutionsArr[i].isSelected){
        this.isSolutionCheckboxSelected = true;
      }
    }
  }

  addSelectedSolutions() {
    this.addedSolutionsArray = this.seachedSolutionsArr.filter(function (solution) {
      return solution.isSelected;
    });

    this.solutionEvent.emit(this.addedSolutionsArray);
    this.showSearchSolution = false;
    this.showSelectedSolutions = true;
  }

  onSolutionPropertyChange(event) {
    this.solutionEvent.emit(this.addedSolutionsArray);
  }

  onSolutionRemove(solution: SolutionObject) {
    for (var i = 0; i < this.addedSolutionsArray.length; i++) {
      if (this.addedSolutionsArray[i].id === solution.id) {
        this.addedSolutionsArray.splice(i, 1);
        break;
      }
    }
    this.checkAlreadySelectedSolutions();
    this.solutionEvent.emit(this.addedSolutionsArray);
  }

  cancelSelection() {
    this.showSearchSolution = false;
    this.showSelectedSolutions = true;
  }
}
