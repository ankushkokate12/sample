import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { SolutionObject } from "src/app/dto/solution-object";
import { Router } from '@angular/router';

@Component({
  selector: 'app-solution',
  templateUrl: './solution.component.html',
  styleUrls: ['./solution.component.css']
})
export class SolutionComponent implements OnInit {

  @Input()
  solutionData: SolutionObject
  @Input()
  riskTreatmentTypeMetadata: any[] = [];
  @Output()
  solutionPropertyChange = new EventEmitter<SolutionObject>();
  @Output()
  solutionRemoveEvent = new EventEmitter<SolutionObject>();
  @Input()
  isEditState:boolean=true;
  @Input()
  showLinkedRisk:boolean;
  @Input()
  showRiskTreament:boolean;
  @Input()
  detailButton:boolean=true;
  @Input()
  showMoreButton:boolean=false;
  @Input()
  isAdminUser:boolean;
  

  shortDesc: boolean;
  detailButtonText: string;
  
  
  constructor(public _router: Router) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChange) {
    if (this.riskTreatmentTypeMetadata) {
      if (this.riskTreatmentTypeMetadata.length > 0) {
        if (this.solutionData.riskTreatmentType === "" || this.solutionData.riskTreatmentType === null) {
          this.solutionData.riskTreatmentType = this.riskTreatmentTypeMetadata[0].value;
        }
      }
    }
    if (this.solutionData.description === undefined) {
      return;
    } else {
      this.manageShowHideDetails();
    }

  }

  manageShowHideDetails() {
    if (this.solutionData.description.length >= 0 && this.solutionData.description.length < 65) {
      this.detailButton = false;
    }
    else {
      if(this.detailButton){
        this.detailButton = true;
      }
     
    }

    if (this.solutionData.description != "" || this.solutionData.description.length != 0) {
      if (this.solutionData.description.length > 65) {
        this.shortDesc = true;
        this.detailButtonText = "VIEW DETAILS"
      }
      else {
        this.shortDesc = false;
        this.detailButtonText = "HIDE DETAILS"
      }
    }
  }

  riskTreamentSelectionHandler(value: string) {
    this.solutionData.riskTreatmentType = value;
    this.solutionPropertyChange.emit(this.solutionData);
  }

  sliderChangeHandler(value) {
    this.solutionData.percentageChange = value.value;
    this.solutionPropertyChange.emit(this.solutionData);
  }

  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }
    return value + "%";
  }

  removeAddedSolution(solution) {
    this.solutionRemoveEvent.emit(solution);
  }

  viewDetails() {
    if (this.shortDesc == true) {
      this.shortDesc = false;
      this.detailButtonText = "HIDE DETAILS"
    }
    else {
      this.shortDesc = true
      this.detailButtonText = "VIEW DETAILS"
    }
  }

  riskClickedHandler(riskObj){
    if(this.isAdminUser){
      this._router.navigate(['app', 'risk',  'edit'], { queryParams: { action: "edit", id: riskObj.id } });
    }
  } 
}
