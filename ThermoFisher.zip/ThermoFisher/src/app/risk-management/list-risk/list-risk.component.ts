import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RiskService } from '../../services/risk.service';
import { Subject } from 'rxjs';
import 'rxjs/add/operator/map';
import { RiskObject } from '../../dto/risk-object';
import { SolutionObject } from "src/app/dto/solution-object";
import { AdminService } from 'src/app/services/admin.service';
import { RamsUtil } from '../../utils/rams-util';
declare var $;

@Component({
  selector: 'app-list-risk',
  templateUrl: './list-risk.component.html',
  styleUrls: ['./list-risk.component.css']
})
export class ListRiskComponent implements OnInit {

  impactedBDivisions: string = "";
  frameworks: string = "";
  gaugeChartConfig: {};
  dtOptions: any;
  riskList: any[] = [];
  potentialLikelihoodMetadata: [];
  potentialImpactMetadata: any[] = [];
  selectedRiskDetails: RiskObject = new RiskObject();
  riskId: any;
  dtTrigger: Subject<string> = new Subject();
  isAdminUser = false;
  showEstimatedCost: boolean;
  isApiInProgress:boolean;
  tableWidget: any;

  constructor(public _router: Router, public _riskService: RiskService, public _adminService: AdminService) {

  }

  ngOnInit() {

    if (sessionStorage.getItem('userRole') === "Admin") {
      this.isAdminUser = true;
    }
    this.isApiInProgress = true;
    this._riskService.getAllRisk().subscribe(result => {
      this.riskList = result.risks;
      this.drawRiskGrid();
      this.isApiInProgress = false;
      if (this.riskList.length > 1) {
        this.getRiskDetail(this.riskList[0].id, true);
        $("tbody tr:first-child").addClass('rowseleced');
       
      }
    });

    this._adminService.getMetadataByEntity("ramsRisk").subscribe(result => {
      let response: any = result;
      for (let i = 0; i < response.groupData.length; i++) {
        if (response.groupData[i].groupType === "potentialLikelihood") {
          this.potentialLikelihoodMetadata = response.groupData[i].data
        }
        if (response.groupData[i].groupType === "potentialImpact") {

          for (let j = 0; j < response.groupData[i].data.length; j++) {
            let tempObj = {
              "id": response.groupData[i].data[j].id,
              "value": String(response.groupData[i].data[j].value).trim()
            }
            this.potentialImpactMetadata.push(tempObj)
          }

        }
      }
    })

    this.gaugeChartConfig = {
      size: 160,
      clipWidth: 160,
      clipHeight: 90,
      ringWidth: 15,
      maxValue: 10,
      transitionMs: 2000
    }
  }

  drawRiskGrid() {
    let exampleId: any = $('#risk-grid');
    this.tableWidget = exampleId.DataTable({
      data: this.riskList,
      select: true,
      columns: [
        { title: "NAME", data: "name", 'className': 'risk_th1' },
        {
          title: "RISK LEVEL", data: "riskLevel", 'className': 'risk_th2',
          "createdCell": function (td, cellData) {
            switch (cellData) {
              case "Very Low":
                $(td).addClass('VeryLow');
                break;
              case "Low":
                $(td).addClass('Low');
                break;
              case "Medium":
                $(td).addClass('Medium');
                break;
              case "High":
                $(td).addClass('High');
                break;
              case "Critical":
                $(td).addClass('Critical');
                break;
            }
          }
        },
        { title: "POTENTIAL LOSS TYPE", data: "potentialLossType", 'className': 'risk_th3' },
        {
          title: "STATUS", data: "active", 'className': 'risk_th4',
          render: function (data, type, row) {
            var status: string = row.active ? 'Active' : 'Inactive';
            return '<td>' +
              status
              + '<span class="active-icon">' +
              '<svg version="1.2" xmlns="http://www.w3.org/2000/svg"' +
              'xmlns:xlink="http://www.w3.org/1999/xlink" overflow="visible"' +
              'preserveAspectRatio="none" viewBox="0 0 24 24" width="14" height="14">' +
              '<g>' +
              '<path xmlns:default="http://www.w3.org/2000/svg"' +
              'd="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"' +
              'style="fill: rgb(38, 199, 40);" vector-effect="non-scaling-stroke"/>' +
              '</g>' +
              '</svg></span></td>'
          },
          "createdCell": function (td, cellData) {
            $(td).addClass('active-status');
          }
        },
        {
          title: "", 'className': 'risk_th5 sorting1', visible: this.isAdminUser, render: function (data, type, row) {
            return '<td [hidden]="!isAdminUser"><abbr title="Edit Risk"><a (click)="onEditClick(risk)" class="linkstyle"><svg version="1.2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" overflow="visible" preserveAspectRatio="none" viewBox="0 0 596 596" width="14" height="14"><g><g xmlns:default="http://www.w3.org/2000/svg">	<polygon points="547.7,571.5 23.8,571.5 23.8,47.6 333.3,47.6 357.1,23.8 0,23.8 0,595.4 571.5,595.4 571.5,238.1 547.7,261.9  " style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/>	<path d="M119,476.3h95.2l381-381L500,0L119,381V476.3z M561.9,95.3l-57.1,57.1l-61.9-61.9L500,33.4L561.9,95.3z M142.8,390.5   l283.4-280.9l61.9,61.9L204.7,452.5h-61.9V390.5z" style="fill: rgb(30, 138, 231);" vector-effect="non-scaling-stroke"/></g></g></svg></a></abbr></td>'
          }
        },
        { title: "Date", data: "dateModified", visible: false }
      ],
      "paging": true,
      "ordering": true,
      "info": true,
      "lengthChange": false,
      "searching": true,
      "bjQueryUI": true,
      "sDom": '<"search-box"r>lftip',
      "pageLength": 10,
      "aaSorting": [[5, 'desc']],
      "columnDefs": [
        { orderable: false, targets: -1 }
      ],
      "oLanguage": {
        "sInfoFiltered": "(filtered from _MAX_ total records)",
        "sSearchPlaceholder": "Search Risk/s",
        "sSearch": "",
        "oPaginate": {
          "sNext": '<span>&raquo;</span>',
          "sPrevious": '<span>&laquo;</span>'
        },
        "aaSorting": [[5, 'desc']],
      }
    });

    var table = exampleId.DataTable();
    $('#search-box').on('keyup change', function () {
      table.search($(this).val()).draw();
    });

    

    let rowRef = $('#risk-grid tbody');
    rowRef.on('click', 'a', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onEditClick(data);
      e.stopPropagation();
    });

    rowRef.on('click', 'tr', (event) => {
      var e: any = event;
      var $row = $(e.currentTarget).closest('tr');
      var data = this.tableWidget.row($row).data();
      this.onRowClick(data);

      $row.siblings().removeClass('rowseleced');
      $row.addClass('rowseleced');
      e.stopPropagation();
    });
  }

  onRowClick(clickedRisk: any) {
    this.getRiskDetail(clickedRisk.id, true);
  }

  getRiskDetail(riskId, isRiskDetails) {
    this._riskService.getRiskDetails(riskId, isRiskDetails).subscribe(result => {
      let response: any = result.riskDetails;
      let riskObj = new RiskObject();
      riskObj.id = response.id;
      riskObj.riskNumber = response.riskNumber;
      riskObj.name = response.name;
      riskObj.description = response.description;
      riskObj.potentialLossType = response.potentialLossType;
      riskObj.potentialLikelihood = response.potentialLikelihood;
      riskObj.potentialImpact = response.potentialImpact;
      riskObj.riskLevel = response.riskLevel;
      riskObj.id = response.id;

      //solution parsing
      let tempSolutions: SolutionObject[] = [];
      let budgetRequired:number=0;
      for (var i = 0; i < response.relatedSolutions.length; i++) {
        let solutionObj = new SolutionObject();
        solutionObj.id = response.relatedSolutions[i].id;
        solutionObj.name = response.relatedSolutions[i].name;
        solutionObj.budgetRequired = response.relatedSolutions[i].budgetRequired;
        budgetRequired += solutionObj.budgetRequired;
        tempSolutions.push(solutionObj);
      }

      riskObj.approxEstimateCost= budgetRequired;

      riskObj.solutions = tempSolutions;

      //framework parsing
      let framworkArr: string[] = [];
      for (var i = 0; i < response.frameworks.length; i++) {
        framworkArr.push(response.frameworks[i].name);
      }
      this.frameworks = framworkArr.join(",")

      //division parsing
      let divisionArr: string[] = [];
      for (var i = 0; i < response.impactedDivisions.length; i++) {
        divisionArr.push(response.impactedDivisions[i].name);
      }
      this.impactedBDivisions = divisionArr.join(",")

      this.selectedRiskDetails = riskObj;

      if (this.selectedRiskDetails.solutions.length > 0) {
        this.showEstimatedCost = true;
      }
      else {
        this.showEstimatedCost = false;
      }
    });
  }

  ngAfterViewInit() {

  }

  onEditClick(clickedRisk?: any) {
    let riskId:number;
    if(clickedRisk){
      riskId= clickedRisk.id;
    }else{
      riskId= this.selectedRiskDetails.id;
    }
    this._router.navigate(['app', 'risk', 'edit'], { queryParams: { action: "edit", id: riskId } });
  }

  createNewRisk() {
    this._router.navigate(['app', 'risk', 'add']);
  }

  solutionClickedHandler(solObj){
    if(this.isAdminUser){
      this._router.navigate(['app', 'manage-entities', 'solution', 'edit'], { queryParams: { action: "edit", id: solObj.id } });
    }
  }
}
