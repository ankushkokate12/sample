import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-risk-management',
  templateUrl: './risk-management.component.html',
  styleUrls: ['./risk-management.component.css']
})
export class RiskManagementComponent implements OnInit {

  constructor(public _router:Router, public _routerSnapshot:ActivatedRoute) { }

  ngOnInit() {
    this._routerSnapshot;
  }
}
