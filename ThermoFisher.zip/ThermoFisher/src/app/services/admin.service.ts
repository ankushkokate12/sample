import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {environment} from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private env:any = environment;
  private metadataEndpoint:string= this.env.apiEndpoints.metadataEndpoint;
  private getMetadataByEntityApi:string = this.env.apiEndpoints.getMetadataByEntity;

  public isdminRendered:boolean=false;
  constructor(public httpClient:HttpClient) { }

  getMetadata():any{
    return this.httpClient.get(this.metadataEndpoint);
  }

  saveAttribute(reqPayload):any{
    return this.httpClient.post(this.metadataEndpoint, reqPayload);
  }

  updateAttribute(reqPayload){
    return this.httpClient.put(this.metadataEndpoint, reqPayload);
  }

  getMetadataByEntity(entityType){
    return this.httpClient.get(this.getMetadataByEntityApi+ "?entityType="+ entityType);
  }
}
