import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { solutionVsRisk } from '../mock-model/solution-risk-relation';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private env:any = environment;
  private riskVsSolutionGraphEndpoint: string = this.env.apiEndpoints.riskVsSolutionGraphEndpoint;
  private solutionVsRiskGraphEndpoint: string = this.env.apiEndpoints.solutionVsRiskGraphEndpoint;
  private riskSolutionDrillDownEndpoint:string = this.env.apiEndpoints.riskSolutionDrillDownEndpoint;
  
  constructor(private _httpClient: HttpClient) { }

  getRiskVsSolutionGraphData() {
    return this._httpClient.get(this.riskVsSolutionGraphEndpoint);
  }

  getSolutionVsRiskGraphData() {
    // let simpleObservable = new Observable((observer) => {
    //   // observable execution
    //   observer.next(solutionVsRisk)
    //   observer.complete()
    // })
    // return simpleObservable;
     return this._httpClient.get(this.solutionVsRiskGraphEndpoint); 
  }

  getRiskSolutionDrillDownData(vertexId:string) {
    return this._httpClient.get(this.riskSolutionDrillDownEndpoint +'?vertexId='+vertexId);
  }
}
