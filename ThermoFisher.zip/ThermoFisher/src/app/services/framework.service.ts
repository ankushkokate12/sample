import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { FrameworkObject } from '../dto/framework-object';


@Injectable({
  providedIn: 'root'
})
export class FrameworkService {
  private env:any = environment;
  private frameworkDataEndpoint:string= this.env.apiEndpoints.frameworkDataEndpoint;
  
  constructor(private _httpClient: HttpClient) { }

  getAllFrameworks() {
    return this._httpClient.get(this.frameworkDataEndpoint);
  }

  createUpdateFramework(framework:FrameworkObject, isUpdate:boolean) {
    let reqPayload = {
      "framework":
      {
        "id": framework.id === null ? undefined: framework.id,
        "name": framework.name,
        "description": framework.description === undefined? framework.description="":framework.description,
        "parentId": framework.parentId,
        "parentName": framework.parentName
      }
    }
    if(isUpdate){
      return this._httpClient.put(this.frameworkDataEndpoint, reqPayload);
    }else{
      return this._httpClient.post(this.frameworkDataEndpoint, reqPayload);
    } 
  }
}
