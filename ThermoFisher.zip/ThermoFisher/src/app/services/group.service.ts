import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { GroupObject } from '../dto/group-object';

@Injectable({
  providedIn: 'root'
})
export class GroupService {
  private env:any = environment;
  private groupDataEndpoint:string= this.env.apiEndpoints.groupDataEndpoint;

  constructor(private _httpClient: HttpClient) { }

  getAllGroups() {
    return this._httpClient.get(this.groupDataEndpoint);
  }

  createUpdateGroup(division:GroupObject, isUpdate:boolean) {
    let reqPayload = {
      "division":
      {
        "id": division.id === null ? undefined: division.id,
        "name": division.name,
        "description": division.description === undefined? division.description="":division.description,
        "parentId": division.parentId,
        "parentName": division.parentName
      }
    }
    if(isUpdate){
      return this._httpClient.put(this.groupDataEndpoint, reqPayload);
    }else{
      return this._httpClient.post(this.groupDataEndpoint, reqPayload);
    } 
  }
}
