import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProjectObject } from '../dto/project-object';
import { Observable } from 'rxjs';
import { projectList } from '../mock-model/project/getProjects';
import { projectDetails } from '../mock-model/project/projectDetails';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private env:any = environment;
  private projectEnpoint: string = this.env.apiEndpoints.projectEndpoint;

  constructor(public _httpClient: HttpClient) { }

  getProjectList(): any {
    // let simpleObservable = new Observable((observer) => {
    //   // observable execution
    //   observer.next(projectList)
    //   observer.complete()
    // })
    // return simpleObservable;
    return this._httpClient.get(this.projectEnpoint+'?isProjectList=true');
  }

  getProjectDetails(projectId){
    // let simpleObservable = new Observable((observer) => {
    //   // observable execution
    //   observer.next(projectDetails)
    //   observer.complete()
    // })
    // return simpleObservable;
    return this._httpClient.get(this.projectEnpoint+'?isProjectList=false&projectId='+projectId); 
  }

  createUpdateProject(project: ProjectObject, isUpdate: boolean) {
    let reqPayload = {
      "project":
      {
        "id": project.id === null ? undefined : project.id,
        "name": project.name,
        "projectId": project.projectId,
        "levelOfEffort": project.levelOfEffort,
        "description": project.description,
        "budgetAvailable": project.budgetAvailable
      },
      "relatedResources": project.relatedResouces,
      "relatedSolutions": project.relatedSolutions
    }
    if(isUpdate){
      return this._httpClient.put(this.projectEnpoint, reqPayload);
    }else{
      return this._httpClient.post(this.projectEnpoint, reqPayload);
    } 
  }
}
