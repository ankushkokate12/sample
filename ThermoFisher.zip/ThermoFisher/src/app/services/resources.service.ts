import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { resources } from '../mock-model/resources';
import { ResourceObject } from '../dto/resource-object';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResourcesService {  
  private env:any = environment;
  private resourcesEndpoint:string= this.env.apiEndpoints.resourceEndpoint;

  constructor(public _httpClient: HttpClient) { }
 
  getResources(): any {
    // let simpleObservable = new Observable((observer) => {
    //   observer.next(resources)
    //   observer.complete()
    // })
    // return simpleObservable;
    return this._httpClient.get(this.resourcesEndpoint);
  } 

  createUpdateResource(resource:ResourceObject, isUpdate:boolean) {
    let reqPayload = {
      "resource":
      {
        "id": resource.id === null ? undefined: resource.id,
        "name": resource.name,
        "description": resource.description === undefined? resource.description="":resource.description,
        "parentId": resource.parentId,
        "resourceType":resource.resourceType
      }
    }
    if(isUpdate){
      return this._httpClient.put(this.resourcesEndpoint, reqPayload);
    }else{
      return this._httpClient.post(this.resourcesEndpoint, reqPayload);
    } 
  }
}