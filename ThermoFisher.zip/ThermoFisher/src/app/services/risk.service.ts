import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { divisions } from '../mock-model/devision';
import { environment } from '../../environments/environment';
import { RiskObject } from '../dto/risk-object';

@Injectable({
  providedIn: 'root'
})
export class RiskService {
  private env:any = environment;
  private divisionEndpoint: string = this.env.apiEndpoints.divisionEndpoint;
  private frameworkEndpoint: string = this.env.apiEndpoints.frameworkEndpoint;
  private riskLevel: string = this.env.apiEndpoints.getRiskLevel;
  private createRisk: string= this.env.apiEndpoints.createRisk;
  private allRisk:string= this.env.apiEndpoints.getAllRisk;
  private riskDetails:string= this.env.apiEndpoints.getRiskDetails;
  private updateRisk:string=this.env.apiEndpoints.updateRisk;

  constructor(public _httpClient: HttpClient) { }

  getDivisions(): any {
    return this._httpClient.get(this.divisionEndpoint);
    //return divisions;
  }

  getFrameworks(): any {
    return this._httpClient.get(this.frameworkEndpoint);
  }

  getRiskLevel(potentialImpact, potentialLikelihood):any {
    let reqPayload = {
      "potentialImpact": potentialImpact,
      "potentialLikelihood": potentialLikelihood
    }
    return this._httpClient.post(this.riskLevel, reqPayload);
  }

  saveAndCreateRisk(riskObj:RiskObject, divisions:[], frameworks:[], isEdit:boolean):any{
    let reqPayload = {
      "risk": {
            "id": riskObj.id="" ? null: riskObj.id,
            "riskNumber": riskObj.riskNumber,
            "name": riskObj.name,
            "description": riskObj.description,
            "potentialLossType": riskObj.potentialLossType,
            "potentialLikelihood": riskObj.potentialLikelihood,
            "potentialImpact": riskObj.potentialImpact,
            "riskLevel": riskObj.riskLevel,
            "relatedRiskId": riskObj.relatedRiskObj.id === 0 ? null: riskObj.relatedRiskObj.id
          },
          "solutions": riskObj.solutions,
          "frameworks": frameworks,
          "divisions": divisions  
    }
    if(isEdit){
      return this._httpClient.put(this.updateRisk, reqPayload);
    }
    return this._httpClient.post(this.createRisk, reqPayload);
  }

  getAllRisk():any{
    return this._httpClient.get(this.allRisk);
  }

  getRiskDetails(riskId, isRiskDetails:boolean):any{
    return this._httpClient.get(this.riskDetails+'?id='+riskId +'&isRiskDetails='+isRiskDetails);
  }

}