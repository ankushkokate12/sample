import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { SolutionObject } from "../dto/solution-object";
import { Observable } from 'rxjs';
import {solutionDetails} from '../mock-model/solutionDetails';

@Injectable({
  providedIn: 'root'
})
export class SolutionService {
  private env:any = environment;
  private solutions:string=this.env.apiEndpoints.solutionEndpoint;
  private solutionsList:string=this.env.apiEndpoints.getSolutions;

  constructor(public _httpClient: HttpClient) {

  }

  saveAndCreateSolution(solutionObj:SolutionObject, isEdit:boolean):any{
    let reqPayload = {
        "solution": {
          "id": solutionObj.id===undefined ? null: solutionObj.id,       
          "name": solutionObj.name, 
          "levelOfEffort": solutionObj.levelOfEffort === undefined? "":solutionObj.levelOfEffort, 
          "description": solutionObj.description === undefined? "": solutionObj.description, 
          "budgetRequired": solutionObj.budgetRequired
        }, 
        "relatedProjects": solutionObj.relatedProjects,
        "relatedResources": solutionObj.relatedResources
      }     
    if(isEdit){
      return this._httpClient.put(this.solutions, reqPayload);
    }
    return this._httpClient.post(this.solutions, reqPayload);
  }
  
   getSolutions(isSolutionList){
    return this._httpClient.get(this.solutionsList+'?isSolutionList='+isSolutionList);
   }

   getSolutionDetails(solutionId, isSolutionList){
    // let simpleObservable = new Observable((observer) => {
    //   // observable execution
    //   observer.next(solutionDetails)
    //   observer.complete()
    // })
    // return simpleObservable;
    return this._httpClient.get(this.solutionsList+'?isSolutionList='+isSolutionList+'&solutionId='+solutionId);
  }
}
