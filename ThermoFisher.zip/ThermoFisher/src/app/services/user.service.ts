import { AuthenticationDetails, CognitoUser, CognitoUserSession } from 'amazon-cognito-identity-js';
import * as AWS from "aws-sdk/global";
import * as STS from "aws-sdk/clients/sts";
import { Injectable } from '@angular/core';
import { CognitoCallback, CognitoUtil, LoggedInCallback } from "./cognito.service";
import { environment } from '../../environments/environment';

export class UserInfo{
  username:string;
  accessToken:string;
  userRole:string;
  isLoggedIn:boolean;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private userSession:CognitoUserSession;
  private userInfo:UserInfo;

  constructor(public cognitoUtil: CognitoUtil) {  }
  
  doLogin(username, password, callback: CognitoCallback) {
    let authenticationData = new AuthenticationDetails({
      Username: username,
      Password: password
    });

    let userData = {
      Username: username,
      Pool: this.cognitoUtil.getUserPool()
    };

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.authenticateUser(authenticationData, {
      onSuccess: result => this.onLoginSuccess(callback, result),
      onFailure: err => this.onLoginError(callback, err),
    })
  }

  private onLoginSuccess = (callback: CognitoCallback, session: CognitoUserSession) => {
    AWS.config.credentials = this.cognitoUtil.buildCognitoCreds(session.getIdToken().getJwtToken());
    // So, when CognitoIdentity authenticates a user, it doesn't actually hand us the IdentityID,
    // used by many of our other handlers. This is handled by some sly underhanded calls to AWS Cognito
    // API's by the SDK itself, automatically when the first AWS SDK request is made that requires our
    // security credentials. The identity is then injected directly into the credentials object.
    // If the first SDK call we make wants to use our IdentityID, we have a
    // chicken and egg problem on our hands. We resolve this problem by "priming" the AWS SDK by calling a
    // very innocuous API call that forces this behavior.
    let clientParams: any = {};
    if (environment.awsConf.sts_endpoint) {
      clientParams.endpoint = environment.awsConf.sts_endpoint;
    }
    let sts = new STS(clientParams);
    sts.getCallerIdentity(function (err, data) {
      console.log("UserLoginService: Successfully set the AWS credentials");
      this.userSession = session;
      callback.cognitoCallback(null, session);
    });
  }

  setUserInfo(userInfo:UserInfo){
    this.userInfo = userInfo;
  }
  getUserInfo():UserInfo{
    return this.userInfo;
  }

  getUserSessionInfo(){
    return this.userSession;
  }

  private onLoginError = (callback: CognitoCallback, err) => {
    callback.cognitoCallback(err.message, null);
  }

  logout() {
    this.cognitoUtil.getCurrentUser().signOut();
    this.userSession = null;
    sessionStorage.clear();
  }
}