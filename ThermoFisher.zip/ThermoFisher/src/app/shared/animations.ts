import {
  trigger, transition, animate, style
} from '@angular/animations';

export const slideInAnimation = trigger('slideInOut', [
  transition(':enter', [
    style({
      transform: 'translateX(100%)'
    }),
    animate('0.9s ease-out', style('*'))
  ]),
  transition(':leave', [
    animate('0.9s ease-out', style({
      transform: 'translateX(-100%)'
    }))
  ])
]);
