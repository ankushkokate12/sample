import { RamsUtil } from './rams-util';

describe('RamsUtil', () => {
  it('should create an instance', () => {
    expect(new RamsUtil()).toBeTruthy();
  });
});
