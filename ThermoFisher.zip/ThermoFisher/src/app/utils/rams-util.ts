import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { SolutionObject } from "../dto/solution-object";
import { RiskObject } from '../dto/risk-object';
import { FrameworkObject } from '../dto/framework-object';
import { GroupObject } from '../dto/group-object';
import { ProjectObject } from '../dto/project-object';
import { RiskSolutionObject } from '../dto/risk-solution-object';
import { SolutionRiskObject } from '../dto/solution-risk-object';
import { ResourceObject } from '../dto/resource-object';

export class RamsUtil {

    static getFormatedDivision(data: any): TreeviewItem[] {
        let divisionArray: Array<TreeviewItem> = [];
        for (var i = 0; i < data.divisions.length; i++) {

            let category: TreeviewItem = new TreeviewItem(data.divisions[i]);
            divisionArray.push(category);
        }
        return divisionArray;
    }

    static getFormatedFrameworks(data: any): TreeviewItem[] {
        let frameworkArray: Array<TreeviewItem> = [];
        for (var i = 0; i < data.frameworks.length; i++) {

            let category: TreeviewItem = new TreeviewItem(data.frameworks[i]);
            frameworkArray.push(category);
        }
        return frameworkArray;
    }

    static getFormatedSolutions(data: any): SolutionObject[] {
        let solutionsArray: Array<SolutionObject> = [];
        for (var i = 0; i < data.solution.length; i++) {
            let solution: SolutionObject = new SolutionObject();
            solution.id = data.solution[i].id;
            solution.name = data.solution[i].name;
            solution.description = data.solution[i].description;
            solution.budgetRequired = data.solution[i].budgetRequired;
            solution.levelOfEffort = data.solution[i].levelOfEffort;
            solution.dateModified = data.solution[i].dateModified;
             //risk parsing
            let tempRisksArr: any[] = [];
            for (var j = 0; j < data.solution[i].relatedRisks.length; j++) {
                let riskObj:any = {};
                riskObj.id = data.solution[i].relatedRisks[j].id;
                riskObj.name = data.solution[i].relatedRisks[j].name;
                riskObj.riskNumber = data.solution[i].relatedRisks[j].riskNumber;
                riskObj.riskLevel = data.solution[i].relatedRisks[j].riskLevel;
                tempRisksArr.push(riskObj);
            }
            solution.relatedRisks = tempRisksArr;
            
            if (data.solution[i].hasOwnProperty('percentageChange')) {
                solution.percentageChange = data.solution[i].percentageChange;
            } else {
                solution.percentageChange = 0;
            }

            solution.isSelected = data.solution[i].isSelected ? data.solution[i].isSelected : false
            solutionsArray.push(solution);
        }
        return solutionsArray;
    }

    static getRiskDetailObject(response, isRiskDetails): RiskObject {

        let riskObj = new RiskObject();
        riskObj.id = response.id;
        riskObj.riskNumber = response.riskNumber;
        riskObj.name = response.name;
        riskObj.description = response.description;
        riskObj.potentialLossType = response.potentialLossType;
        riskObj.potentialLikelihood = response.potentialLikelihood;
        riskObj.potentialImpact = response.potentialImpact;
        riskObj.riskLevel = response.riskLevel;

        if (response.relatedRisks != undefined || response.relatedRisks != null) {
            riskObj.relatedRiskObj = {
                "id": response.relatedRisks.id,
                "active": true,
                "riskNumber": response.relatedRisks.riskNumber,
                "name": response.relatedRisks.name,
                "potentialLossType": "",
                "riskLevel": ""
            }
        } else {
            riskObj.relatedRiskObj = null;
        }
        riskObj.id = response.id;
        riskObj.frameworks = response.frameworks;
        riskObj.divisions = response.impactedDivisions;

        //solution parsing
        let tempSolutions: SolutionObject[] = [];
        let budgetRequired:number=0;
        for (var i = 0; i < response.relatedSolutions.length; i++) {
            let solutionObj = new SolutionObject();
            solutionObj.id = response.relatedSolutions[i].id;
            solutionObj.name = response.relatedSolutions[i].name;
            solutionObj.budgetRequired = response.relatedSolutions[i].budgetRequired;
            solutionObj.riskTreatmentType = response.relatedSolutions[i].riskTreatmentType;
            solutionObj.percentageChange = response.relatedSolutions[i].percentageChange;
            solutionObj.description = response.relatedSolutions[i].description;
            budgetRequired += solutionObj.budgetRequired;
            
            tempSolutions.push(solutionObj);
        }
        riskObj.approxEstimateCost = budgetRequired;
        riskObj.solutions = tempSolutions;
        return riskObj
    }

    static getFormatedFrameworkList(data) {
        let frameworkArray: Array<FrameworkObject> = [];
        for (var i = 0; i < data.length; i++) {
            let frameworkObj: FrameworkObject = new FrameworkObject();
            frameworkObj.id = data[i].id;
            frameworkObj.name = data[i].name;
            frameworkObj.description = data[i].description;
            frameworkObj.parentId = data[i].parentId;
            frameworkObj.parentName = data[i].parentName;
            frameworkObj.dateModified = data[i].dateModified;
            frameworkArray.push(frameworkObj);
        }
        return frameworkArray;
    }

    static getFormatedResourceList(data){
        let resourceArray: Array<ResourceObject> = [];
        for (var i = 0; i < data.length; i++) {
            let resourceObj: ResourceObject = new ResourceObject();
            resourceObj.id = data[i].id;
            resourceObj.name = data[i].name;
            resourceObj.description = data[i].description;
            resourceObj.parentName = data[i].parentName;
            resourceObj.parentId = data[i].parentId;
            resourceObj.resourceType = data[i].resourceType;
            resourceObj.dateModified = data[i].dateModified;
            resourceArray.push(resourceObj);
        }
        return resourceArray;
    }

    static getFormatedGroupsList(data){
        let groupArray: Array<GroupObject> = [];
        for (var i = 0; i < data.length; i++) {
            let groupObj: GroupObject = new GroupObject();
            groupObj.id = data[i].id;
            groupObj.name = data[i].name;
            groupObj.description = data[i].description;
            groupObj.parentId = data[i].parentId;
            groupObj.parentName = data[i].parentName;
            groupObj.dateModified = data[i].dateModified;
            groupArray.push(groupObj);
        }
        return groupArray;
    }

    static getFormatedSolutionDetailsObj(rawSolution) {
        let solutionDetailsObj: SolutionObject = new SolutionObject();
        solutionDetailsObj.id = rawSolution.id;
        solutionDetailsObj.name = rawSolution.name;
        solutionDetailsObj.description = rawSolution.description;
        solutionDetailsObj.budgetRequired = rawSolution.budgetRequired;
        solutionDetailsObj.levelOfEffort = rawSolution.levelOfEffort;

        //project parsing
        let tempProjectsArr: ProjectObject[] = [];
        for (var i = 0; i < rawSolution.relatedProjects.length; i++) {
            let projectObj = new ProjectObject();
            projectObj.id = rawSolution.relatedProjects[i].id;
            projectObj.name = rawSolution.relatedProjects[i].name;
            projectObj.budgetAvailable = rawSolution.relatedProjects[i].budgetAvailable;
            projectObj.description = rawSolution.relatedProjects[i].description;
            projectObj.levelOfEffort = rawSolution.relatedProjects[i].levelOfEffort;
            projectObj.projectId = rawSolution.relatedProjects[i].projectId;
            tempProjectsArr.push(projectObj);
            solutionDetailsObj.totalRequiredBudget += projectObj.budgetAvailable;
        }
        solutionDetailsObj.relatedProjects = tempProjectsArr;

        //risk parsing
        let tempRisksArr: any[] = [];
        for (var i = 0; i < rawSolution.relatedRisks.length; i++) {
            let riskObj:any = {};
            riskObj.id = rawSolution.relatedRisks[i].id;
            riskObj.name = rawSolution.relatedRisks[i].name;
            riskObj.riskNumber = rawSolution.relatedRisks[i].riskNumber;
            riskObj.riskLevel = rawSolution.relatedRisks[i].riskLevel;
            tempRisksArr.push(riskObj);
        }
        solutionDetailsObj.relatedRisks = tempRisksArr;

        let tempResourceArr: any[] = [];
        for (var i = 0; i < rawSolution.relatedResources.length; i++) {
            let resourceObj = new ResourceObject();
            resourceObj.id = rawSolution.relatedResources[i].id;
            resourceObj.name = rawSolution.relatedResources[i].name;
            resourceObj.description = rawSolution.relatedResources[i].description;
            resourceObj.parentName = rawSolution.relatedResources[i].parentName;
            resourceObj.parentId = rawSolution.relatedResources[i].parentId;
            resourceObj.resourceType = rawSolution.relatedResources[i].resourceType;
            tempResourceArr.push(resourceObj);
        }
        solutionDetailsObj.relatedResources = tempResourceArr;
        
        return solutionDetailsObj;
    }

    static getFormatedProjectList(rawProject) {
        let tempProjectsArr: ProjectObject[] = [];
        for (var i = 0; i < rawProject.length; i++) {
            let projectObj = new ProjectObject();
            projectObj.id = rawProject[i].id;
            projectObj.name = rawProject[i].name;
            projectObj.budgetAvailable = rawProject[i].budgetAvailable;
            projectObj.description = rawProject[i].description;
            projectObj.levelOfEffort = rawProject[i].levelOfEffort;
            projectObj.projectId = rawProject[i].projectId;
            projectObj.dateModified = rawProject[i].dateModified;
            tempProjectsArr.push(projectObj);
        }
        return tempProjectsArr;
    }

    static getFormatedProjectDetails(rawProject) {
        let tempProjectsObj: ProjectObject= new ProjectObject();
        tempProjectsObj.id = rawProject.id;
        tempProjectsObj.name = rawProject.name;
        tempProjectsObj.budgetAvailable = rawProject.budgetAvailable;
        tempProjectsObj.description = rawProject.description;
        tempProjectsObj.levelOfEffort = rawProject.levelOfEffort;
        tempProjectsObj.projectId = rawProject.projectId;
        //make resource array
        let resourceArr:any[]=[];
        for (var i = 0; i < rawProject.relatedResources.length; i++) {
            let resourceObject = new ResourceObject();
            resourceObject.id = rawProject.relatedResources[i].id;
            resourceObject.name= rawProject.relatedResources[i].name;
            resourceObject.description= rawProject.relatedResources[i].description;
            resourceObject.parentName= rawProject.relatedResources[i].parentName;
            resourceObject.parentId= rawProject.relatedResources[i].parentId;
            resourceObject.resourceType= rawProject.relatedResources[i].resourceType;
            resourceArr.push(resourceObject);
        }
        tempProjectsObj.relatedResouces = resourceArr;
        
        //make solution array
        let solutionArr:any[]=[];
        for (var j = 0; j < rawProject.relatedSolutions.length; j++) {
            let solutionObj:SolutionObject = new SolutionObject();
            solutionObj.id = rawProject.relatedSolutions[j].id;
            solutionObj.name = rawProject.relatedSolutions[j].name;
            solutionObj.budgetRequired = rawProject.relatedSolutions[j].budgetRequired;
            solutionObj.riskTreatmentType = rawProject.relatedSolutions[j].riskTreatmentType;
            solutionObj.percentageChange = rawProject.relatedSolutions[j].percentageChange;
            solutionObj.description = rawProject.relatedSolutions[j].description;
            solutionObj.levelOfEffort = rawProject.relatedSolutions[j].levelOfEffort;

            //make related risk array
            let relatedRiskArray:any[]=[];
            for(var k = 0; k < rawProject.relatedSolutions[j].relatedRisks.length; k++){
                let riskObj:RiskObject = new RiskObject();
                riskObj.id = rawProject.relatedSolutions[j].relatedRisks[k].id;
                riskObj.riskNumber = rawProject.relatedSolutions[j].relatedRisks[k].riskNumber;
                riskObj.name = rawProject.relatedSolutions[j].relatedRisks[k].name;
                riskObj.riskLevel = rawProject.relatedSolutions[j].relatedRisks[k].riskLevel;
                relatedRiskArray.push(riskObj);
            }
            solutionObj.relatedRisks = relatedRiskArray;
            solutionArr.push(solutionObj);
        }
        tempProjectsObj.relatedSolutions = solutionArr;
        return tempProjectsObj;
    }

    static getFormatedRiskVsSolutionData(data) {
        let riskVsSolutionArr: RiskSolutionObject[] = [];
        for (var i = 0; i < data.length; i++) {
            let riskSolObj: RiskSolutionObject = new RiskSolutionObject();
            riskSolObj.id = data[i].id;
            riskSolObj.name = data[i].name;
            riskSolObj.noOfSolutionsLinked = data[i].noOfSolutionsLinked;
            riskSolObj.budgetInvolved = RamsUtil.currencyFormater(data[i].budgetInvolved);
            riskSolObj.riskLevel = data[i].riskLevel === ""? "Undefined":data[i].riskLevel;
            riskSolObj.riskNumber = data[i].riskNumber;
            riskSolObj.type = data[i].type;
            riskSolObj.vertexId = data[i].vertexId;
            riskVsSolutionArr.push(riskSolObj);
        }
        return riskVsSolutionArr;
    }

    static getFormatedSolutionVsRiskData(data) {
        let solutionVsRiskArr: SolutionRiskObject[] = [];
        for (var i = 0; i < data.length; i++) {
            let solRiskObj: SolutionRiskObject = new SolutionRiskObject();
            solRiskObj.id = data[i].id;
            solRiskObj.name = data[i].name;
            solRiskObj.noOfProjectsLinked = data[i].noOfProjectsLinked;
            solRiskObj.budgetRequired = RamsUtil.currencyFormater(data[i].budgetRequired);
            solRiskObj.levelOfEffort = data[i].levelOfEffort === ""? "Undefined":data[i].levelOfEffort;
            solRiskObj.noOfRisksLinked = data[i].noOfRisksLinked;
            solRiskObj.noOfResourcesLinked = data[i].noOfResourcesLinked;
            solRiskObj.vertexId = data[i].vertexId;
            solRiskObj.type = data[i].type;
            solutionVsRiskArr.push(solRiskObj);
        }
        return solutionVsRiskArr;
    }

    static currencyFormater(value:number){
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0
          });
          
         return formatter.format(value);
    }

    static getColors():any {
        return {
            "All": "#333333",
            "Critical": "#006d2c",
            "High": "#238b45",
            "Medium": "#41ab5d",
            "Low": "#74c476",
            "Very Low": "#a1d99b",
            "Undefined": "#888484"
        };
    }

    static getLegends():any {
        return [
            {
                label: "All",
                value: 'All',
                count: 0,
                color: '#333333',
                forSolution: true
            },
            {
                label: "Critical",
                value: 'Critical',
                count: 0,
                color: '#006d2c',
                forSolution: false
            },
            {
                label: "High",
                value: 'High',
                count: 0,
                color: '#238b45',
                forSolution: true
            }, {
                label: "Medium",
                value: 'Medium',
                count: 0,
                color: '#41ab5d',
                forSolution: true
            }, {
                label: "Low",
                value: 'Low',
                count: 0,
                color: '#74c476',
                forSolution: true
            }, {
                label: "Very Low",
                value: 'Very Low',
                count: 0,
                color: '#a1d99b',
                forSolution: false
            },
            {
                label: "Undefined",
                value: 'Undefined',
                count: 0,
                color: '#888484',
                forSolution: true
            }
        ];
    }
}
