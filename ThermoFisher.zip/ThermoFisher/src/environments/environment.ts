// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  name: 'default',
  awsConf:{
    userPoolId: 'us-east-1_mw79cMj4e',
    clientId: '5pga46o8jsr0dkqcul6f2a9d9o',
    region: 'us-east-1',
    identityPoolId: 'us-east-1:fbe0340f-9ffc-4449-a935-bb6a6661fd53',
    rekognitionBucket: 'rekognition-pics',
    albumName: "usercontent",
    bucketRegion: 'us-east-1',
    ddbTableName: 'LoginTrail',
    cognito_idp_endpoint: '',
    cognito_identity_endpoint: '',
    sts_endpoint: '',
    dynamodb_endpoint: '',
    s3_endpoint: ''
  },
  apiEndpoints:{
    //admin module API's
    metadataEndpoint: "https://smflsmb21h.execute-api.us-east-1.amazonaws.com/metaData/metadata",
    getMetadataByEntity: "https://smflsmb21h.execute-api.us-east-1.amazonaws.com/metaData/metadatabyentity",
    
    //risk module API's
    getRiskLevel:"https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/getrisklevel",
    createRisk:"https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/postRisk", 
    updateRisk:"https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/putrisk",
    getAllRisk:"https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/getallrisks",
    getRiskDetails:"https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/getriskdetails",
    divisionEndpoint: "https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/impacteddivisions",
    frameworkEndpoint: "https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/frameworks",
    getSolutions: "https://pvxs0wmts9.execute-api.us-east-1.amazonaws.com/riskData/getsolutions", 

    //framework module API's
    frameworkDataEndpoint:"https://w7vmsrzgtj.execute-api.us-east-1.amazonaws.com/frameworkData/framework",
 
    //group module API's
    groupDataEndpoint:"https://2ypcuuf2yl.execute-api.us-east-1.amazonaws.com/divisionData/division",    
    
    //solution module API's
    solutionEndpoint: "https://sd31rrdbv9.execute-api.us-east-1.amazonaws.com/solutionData/solution",
    
    //project module API's
    projectEndpoint:"https://f4u88bz2ig.execute-api.us-east-1.amazonaws.com/projectData/project",
    //projectEndpoint: "https://p7psczgyo2.execute-api.us-east-1.amazonaws.com/projectData/project",
    
    //resource module API's
    resourceEndpoint:"https://m3azdskbbe.execute-api.us-east-1.amazonaws.com/resourceData/resource",

    //dashboard module API's
    riskVsSolutionGraphEndpoint: "https://395l35u31l.execute-api.us-east-1.amazonaws.com/dashboardData/risk-solution-riskgraph",
    solutionVsRiskGraphEndpoint:"https://395l35u31l.execute-api.us-east-1.amazonaws.com/dashboardData/solution-risk-solutiongraph",
    riskSolutionDrillDownEndpoint: "https://395l35u31l.execute-api.us-east-1.amazonaws.com/dashboardData/risk-solution-detailsgraph"
  }  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
